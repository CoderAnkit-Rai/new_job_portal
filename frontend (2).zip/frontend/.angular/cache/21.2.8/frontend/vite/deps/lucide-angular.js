import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  Inject,
  Injectable,
  InjectionToken,
  Input,
  NgModule,
  Optional,
  Renderer2,
  setClassMetadata,
  ɵɵNgOnChangesFeature,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵprojection,
  ɵɵprojectionDef
} from "./chunk-BJPSW4SK.js";
import "./chunk-J46EEYGT.js";
import "./chunk-4YCCEXQQ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-U7EDC2PH.js";

// node_modules/lucide-angular/fesm2020/lucide-angular.mjs
var _c0 = ["*"];
var AArrowDown = [["path", {
  d: "m14 12 4 4 4-4",
  key: "buelq4"
}], ["path", {
  d: "M18 16V7",
  key: "ty0viw"
}], ["path", {
  d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16",
  key: "d5nyq2"
}], ["path", {
  d: "M3.304 13h6.392",
  key: "1q3zxz"
}]];
var AArrowUp = [["path", {
  d: "m14 11 4-4 4 4",
  key: "1pu57t"
}], ["path", {
  d: "M18 16V7",
  key: "ty0viw"
}], ["path", {
  d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16",
  key: "d5nyq2"
}], ["path", {
  d: "M3.304 13h6.392",
  key: "1q3zxz"
}]];
var Accessibility = [["circle", {
  cx: "16",
  cy: "4",
  r: "1",
  key: "1grugj"
}], ["path", {
  d: "m18 19 1-7-6 1",
  key: "r0i19z"
}], ["path", {
  d: "m5 8 3-3 5.5 3-2.36 3.5",
  key: "9ptxx2"
}], ["path", {
  d: "M4.24 14.5a5 5 0 0 0 6.88 6",
  key: "10kmtu"
}], ["path", {
  d: "M13.76 17.5a5 5 0 0 0-6.88-6",
  key: "2qq6rc"
}]];
var ALargeSmall = [["path", {
  d: "m15 16 2.536-7.328a1.02 1.02 1 0 1 1.928 0L22 16",
  key: "xik6mr"
}], ["path", {
  d: "M15.697 14h5.606",
  key: "1stdlc"
}], ["path", {
  d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16",
  key: "d5nyq2"
}], ["path", {
  d: "M3.304 13h6.392",
  key: "1q3zxz"
}]];
var Activity = [["path", {
  d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
  key: "169zse"
}]];
var AirVent = [["path", {
  d: "M18 17.5a2.5 2.5 0 1 1-4 2.03V12",
  key: "yd12zl"
}], ["path", {
  d: "M6 12H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
  key: "larmp2"
}], ["path", {
  d: "M6 8h12",
  key: "6g4wlu"
}], ["path", {
  d: "M6.6 15.572A2 2 0 1 0 10 17v-5",
  key: "1x1kqn"
}]];
var Airplay = [["path", {
  d: "M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1",
  key: "ns4c3b"
}], ["path", {
  d: "m12 15 5 6H7Z",
  key: "14qnn2"
}]];
var AlarmClockCheck = [["circle", {
  cx: "12",
  cy: "13",
  r: "8",
  key: "3y4lt7"
}], ["path", {
  d: "M5 3 2 6",
  key: "18tl5t"
}], ["path", {
  d: "m22 6-3-3",
  key: "1opdir"
}], ["path", {
  d: "M6.38 18.7 4 21",
  key: "17xu3x"
}], ["path", {
  d: "M17.64 18.67 20 21",
  key: "kv2oe2"
}], ["path", {
  d: "m9 13 2 2 4-4",
  key: "6343dt"
}]];
var AlarmClockMinus = [["circle", {
  cx: "12",
  cy: "13",
  r: "8",
  key: "3y4lt7"
}], ["path", {
  d: "M5 3 2 6",
  key: "18tl5t"
}], ["path", {
  d: "m22 6-3-3",
  key: "1opdir"
}], ["path", {
  d: "M6.38 18.7 4 21",
  key: "17xu3x"
}], ["path", {
  d: "M17.64 18.67 20 21",
  key: "kv2oe2"
}], ["path", {
  d: "M9 13h6",
  key: "1uhe8q"
}]];
var AlarmClockOff = [["path", {
  d: "M6.87 6.87a8 8 0 1 0 11.26 11.26",
  key: "3on8tj"
}], ["path", {
  d: "M19.9 14.25a8 8 0 0 0-9.15-9.15",
  key: "15ghsc"
}], ["path", {
  d: "m22 6-3-3",
  key: "1opdir"
}], ["path", {
  d: "M6.26 18.67 4 21",
  key: "yzmioq"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M4 4 2 6",
  key: "1ycko6"
}]];
var AlarmClockPlus = [["circle", {
  cx: "12",
  cy: "13",
  r: "8",
  key: "3y4lt7"
}], ["path", {
  d: "M5 3 2 6",
  key: "18tl5t"
}], ["path", {
  d: "m22 6-3-3",
  key: "1opdir"
}], ["path", {
  d: "M6.38 18.7 4 21",
  key: "17xu3x"
}], ["path", {
  d: "M17.64 18.67 20 21",
  key: "kv2oe2"
}], ["path", {
  d: "M12 10v6",
  key: "1bos4e"
}], ["path", {
  d: "M9 13h6",
  key: "1uhe8q"
}]];
var AlarmClock = [["circle", {
  cx: "12",
  cy: "13",
  r: "8",
  key: "3y4lt7"
}], ["path", {
  d: "M12 9v4l2 2",
  key: "1c63tq"
}], ["path", {
  d: "M5 3 2 6",
  key: "18tl5t"
}], ["path", {
  d: "m22 6-3-3",
  key: "1opdir"
}], ["path", {
  d: "M6.38 18.7 4 21",
  key: "17xu3x"
}], ["path", {
  d: "M17.64 18.67 20 21",
  key: "kv2oe2"
}]];
var AlarmSmoke = [["path", {
  d: "M11 21c0-2.5 2-2.5 2-5",
  key: "1sicvv"
}], ["path", {
  d: "M16 21c0-2.5 2-2.5 2-5",
  key: "1o3eny"
}], ["path", {
  d: "m19 8-.8 3a1.25 1.25 0 0 1-1.2 1H7a1.25 1.25 0 0 1-1.2-1L5 8",
  key: "1bvca4"
}], ["path", {
  d: "M21 3a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a1 1 0 0 1 1-1z",
  key: "x3qr1j"
}], ["path", {
  d: "M6 21c0-2.5 2-2.5 2-5",
  key: "i3w1gp"
}]];
var Album = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["polyline", {
  points: "11 3 11 11 14 8 17 11 17 3",
  key: "1wcwz3"
}]];
var AlignCenterHorizontal = [["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "M10 16v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-4",
  key: "11f1s0"
}], ["path", {
  d: "M10 8V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v4",
  key: "t14dx9"
}], ["path", {
  d: "M20 16v1a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-1",
  key: "1w07xs"
}], ["path", {
  d: "M14 8V7c0-1.1.9-2 2-2h2a2 2 0 0 1 2 2v1",
  key: "1apec2"
}]];
var AlignCenterVertical = [["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}], ["path", {
  d: "M8 10H4a2 2 0 0 1-2-2V6c0-1.1.9-2 2-2h4",
  key: "14d6g8"
}], ["path", {
  d: "M16 10h4a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4",
  key: "1e2lrw"
}], ["path", {
  d: "M8 20H7a2 2 0 0 1-2-2v-2c0-1.1.9-2 2-2h1",
  key: "1fkdwx"
}], ["path", {
  d: "M16 14h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-1",
  key: "1euafb"
}]];
var AlignEndHorizontal = [["rect", {
  width: "6",
  height: "16",
  x: "4",
  y: "2",
  rx: "2",
  key: "z5wdxg"
}], ["rect", {
  width: "6",
  height: "9",
  x: "14",
  y: "9",
  rx: "2",
  key: "um7a8w"
}], ["path", {
  d: "M22 22H2",
  key: "19qnx5"
}]];
var AlignEndVertical = [["rect", {
  width: "16",
  height: "6",
  x: "2",
  y: "4",
  rx: "2",
  key: "10wcwx"
}], ["rect", {
  width: "9",
  height: "6",
  x: "9",
  y: "14",
  rx: "2",
  key: "4p5bwg"
}], ["path", {
  d: "M22 22V2",
  key: "12ipfv"
}]];
var AlignHorizontalDistributeCenter = [["rect", {
  width: "6",
  height: "14",
  x: "4",
  y: "5",
  rx: "2",
  key: "1wwnby"
}], ["rect", {
  width: "6",
  height: "10",
  x: "14",
  y: "7",
  rx: "2",
  key: "1fe6j6"
}], ["path", {
  d: "M17 22v-5",
  key: "4b6g73"
}], ["path", {
  d: "M17 7V2",
  key: "hnrr36"
}], ["path", {
  d: "M7 22v-3",
  key: "1r4jpn"
}], ["path", {
  d: "M7 5V2",
  key: "liy1u9"
}]];
var AlignHorizontalDistributeEnd = [["rect", {
  width: "6",
  height: "14",
  x: "4",
  y: "5",
  rx: "2",
  key: "1wwnby"
}], ["rect", {
  width: "6",
  height: "10",
  x: "14",
  y: "7",
  rx: "2",
  key: "1fe6j6"
}], ["path", {
  d: "M10 2v20",
  key: "uyc634"
}], ["path", {
  d: "M20 2v20",
  key: "1tx262"
}]];
var AlignHorizontalDistributeStart = [["rect", {
  width: "6",
  height: "14",
  x: "4",
  y: "5",
  rx: "2",
  key: "1wwnby"
}], ["rect", {
  width: "6",
  height: "10",
  x: "14",
  y: "7",
  rx: "2",
  key: "1fe6j6"
}], ["path", {
  d: "M4 2v20",
  key: "gtpd5x"
}], ["path", {
  d: "M14 2v20",
  key: "tg6bpw"
}]];
var AlignHorizontalJustifyCenter = [["rect", {
  width: "6",
  height: "14",
  x: "2",
  y: "5",
  rx: "2",
  key: "dy24zr"
}], ["rect", {
  width: "6",
  height: "10",
  x: "16",
  y: "7",
  rx: "2",
  key: "13zkjt"
}], ["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}]];
var AlignHorizontalJustifyEnd = [["rect", {
  width: "6",
  height: "14",
  x: "2",
  y: "5",
  rx: "2",
  key: "dy24zr"
}], ["rect", {
  width: "6",
  height: "10",
  x: "12",
  y: "7",
  rx: "2",
  key: "1ht384"
}], ["path", {
  d: "M22 2v20",
  key: "40qfg1"
}]];
var AlignHorizontalJustifyStart = [["rect", {
  width: "6",
  height: "14",
  x: "6",
  y: "5",
  rx: "2",
  key: "hsirpf"
}], ["rect", {
  width: "6",
  height: "10",
  x: "16",
  y: "7",
  rx: "2",
  key: "13zkjt"
}], ["path", {
  d: "M2 2v20",
  key: "1ivd8o"
}]];
var AlignHorizontalSpaceAround = [["rect", {
  width: "6",
  height: "10",
  x: "9",
  y: "7",
  rx: "2",
  key: "yn7j0q"
}], ["path", {
  d: "M4 22V2",
  key: "tsjzd3"
}], ["path", {
  d: "M20 22V2",
  key: "1bnhr8"
}]];
var AlignHorizontalSpaceBetween = [["rect", {
  width: "6",
  height: "14",
  x: "3",
  y: "5",
  rx: "2",
  key: "j77dae"
}], ["rect", {
  width: "6",
  height: "10",
  x: "15",
  y: "7",
  rx: "2",
  key: "bq30hj"
}], ["path", {
  d: "M3 2v20",
  key: "1d2pfg"
}], ["path", {
  d: "M21 2v20",
  key: "p059bm"
}]];
var AlignStartHorizontal = [["rect", {
  width: "6",
  height: "16",
  x: "4",
  y: "6",
  rx: "2",
  key: "1n4dg1"
}], ["rect", {
  width: "6",
  height: "9",
  x: "14",
  y: "6",
  rx: "2",
  key: "17khns"
}], ["path", {
  d: "M22 2H2",
  key: "fhrpnj"
}]];
var AlignStartVertical = [["rect", {
  width: "9",
  height: "6",
  x: "6",
  y: "14",
  rx: "2",
  key: "lpm2y7"
}], ["rect", {
  width: "16",
  height: "6",
  x: "6",
  y: "4",
  rx: "2",
  key: "rdj6ps"
}], ["path", {
  d: "M2 2v20",
  key: "1ivd8o"
}]];
var AlignVerticalDistributeCenter = [["path", {
  d: "M22 17h-3",
  key: "1lwga1"
}], ["path", {
  d: "M22 7h-5",
  key: "o2endc"
}], ["path", {
  d: "M5 17H2",
  key: "1gx9xc"
}], ["path", {
  d: "M7 7H2",
  key: "6bq26l"
}], ["rect", {
  x: "5",
  y: "14",
  width: "14",
  height: "6",
  rx: "2",
  key: "1qrzuf"
}], ["rect", {
  x: "7",
  y: "4",
  width: "10",
  height: "6",
  rx: "2",
  key: "we8e9z"
}]];
var AlignVerticalDistributeEnd = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "14",
  rx: "2",
  key: "jmoj9s"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "4",
  rx: "2",
  key: "aza5on"
}], ["path", {
  d: "M2 20h20",
  key: "owomy5"
}], ["path", {
  d: "M2 10h20",
  key: "1ir3d8"
}]];
var AlignVerticalDistributeStart = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "14",
  rx: "2",
  key: "jmoj9s"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "4",
  rx: "2",
  key: "aza5on"
}], ["path", {
  d: "M2 14h20",
  key: "myj16y"
}], ["path", {
  d: "M2 4h20",
  key: "mda7wb"
}]];
var AlignVerticalJustifyCenter = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "16",
  rx: "2",
  key: "1i8z2d"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "2",
  rx: "2",
  key: "ypihtt"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}]];
var AlignVerticalJustifyEnd = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "12",
  rx: "2",
  key: "4l4tp2"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "2",
  rx: "2",
  key: "ypihtt"
}], ["path", {
  d: "M2 22h20",
  key: "272qi7"
}]];
var AlignVerticalJustifyStart = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "16",
  rx: "2",
  key: "1i8z2d"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "6",
  rx: "2",
  key: "13squh"
}], ["path", {
  d: "M2 2h20",
  key: "1ennik"
}]];
var AlignVerticalSpaceAround = [["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "9",
  rx: "2",
  key: "b1zbii"
}], ["path", {
  d: "M22 20H2",
  key: "1p1f7z"
}], ["path", {
  d: "M22 4H2",
  key: "1b7qnq"
}]];
var AlignVerticalSpaceBetween = [["rect", {
  width: "14",
  height: "6",
  x: "5",
  y: "15",
  rx: "2",
  key: "1w91an"
}], ["rect", {
  width: "10",
  height: "6",
  x: "7",
  y: "3",
  rx: "2",
  key: "17wqzy"
}], ["path", {
  d: "M2 21h20",
  key: "1nyx9w"
}], ["path", {
  d: "M2 3h20",
  key: "91anmk"
}]];
var Ambulance = [["path", {
  d: "M10 10H6",
  key: "1bsnug"
}], ["path", {
  d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",
  key: "wrbu53"
}], ["path", {
  d: "M19 18h2a1 1 0 0 0 1-1v-3.28a1 1 0 0 0-.684-.948l-1.923-.641a1 1 0 0 1-.578-.502l-1.539-3.076A1 1 0 0 0 16.382 8H14",
  key: "lrkjwd"
}], ["path", {
  d: "M8 8v4",
  key: "1fwk8c"
}], ["path", {
  d: "M9 18h6",
  key: "x1upvd"
}], ["circle", {
  cx: "17",
  cy: "18",
  r: "2",
  key: "332jqn"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "2",
  key: "19iecd"
}]];
var Ampersands = [["path", {
  d: "M10 17c-5-3-7-7-7-9a2 2 0 0 1 4 0c0 2.5-5 2.5-5 6 0 1.7 1.3 3 3 3 2.8 0 5-2.2 5-5",
  key: "12lh1k"
}], ["path", {
  d: "M22 17c-5-3-7-7-7-9a2 2 0 0 1 4 0c0 2.5-5 2.5-5 6 0 1.7 1.3 3 3 3 2.8 0 5-2.2 5-5",
  key: "173c68"
}]];
var Ampersand = [["path", {
  d: "M16 12h3",
  key: "4uvgyw"
}], ["path", {
  d: "M17.5 12a8 8 0 0 1-8 8A4.5 4.5 0 0 1 5 15.5c0-6 8-4 8-8.5a3 3 0 1 0-6 0c0 3 2.5 8.5 12 13",
  key: "nfoe1t"
}]];
var Amphora = [["path", {
  d: "M10 2v5.632c0 .424-.272.795-.653.982A6 6 0 0 0 6 14c.006 4 3 7 5 8",
  key: "1h8rid"
}], ["path", {
  d: "M10 5H8a2 2 0 0 0 0 4h.68",
  key: "3ezsi6"
}], ["path", {
  d: "M14 2v5.632c0 .424.272.795.652.982A6 6 0 0 1 18 14c0 4-3 7-5 8",
  key: "yt6q09"
}], ["path", {
  d: "M14 5h2a2 2 0 0 1 0 4h-.68",
  key: "8f95yk"
}], ["path", {
  d: "M18 22H6",
  key: "mg6kv4"
}], ["path", {
  d: "M9 2h6",
  key: "1jrp98"
}]];
var Anchor = [["path", {
  d: "M12 6v16",
  key: "nqf5sj"
}], ["path", {
  d: "m19 13 2-1a9 9 0 0 1-18 0l2 1",
  key: "y7qv08"
}], ["path", {
  d: "M9 11h6",
  key: "1fldmi"
}], ["circle", {
  cx: "12",
  cy: "4",
  r: "2",
  key: "muu5ef"
}]];
var Angry = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M16 16s-1.5-2-4-2-4 2-4 2",
  key: "epbg0q"
}], ["path", {
  d: "M7.5 8 10 9",
  key: "olxxln"
}], ["path", {
  d: "m14 9 2.5-1",
  key: "1j6cij"
}], ["path", {
  d: "M9 10h.01",
  key: "qbtxuw"
}], ["path", {
  d: "M15 10h.01",
  key: "1qmjsl"
}]];
var Antenna = [["path", {
  d: "M2 12 7 2",
  key: "117k30"
}], ["path", {
  d: "m7 12 5-10",
  key: "1tvx22"
}], ["path", {
  d: "m12 12 5-10",
  key: "ev1o1a"
}], ["path", {
  d: "m17 12 5-10",
  key: "1e4ti3"
}], ["path", {
  d: "M4.5 7h15",
  key: "vlsxkz"
}], ["path", {
  d: "M12 16v6",
  key: "c8a4gj"
}]];
var Annoyed = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M8 15h8",
  key: "45n4r"
}], ["path", {
  d: "M8 9h2",
  key: "1g203m"
}], ["path", {
  d: "M14 9h2",
  key: "116p9w"
}]];
var Anvil = [["path", {
  d: "M7 10H6a4 4 0 0 1-4-4 1 1 0 0 1 1-1h4",
  key: "1hjpb6"
}], ["path", {
  d: "M7 5a1 1 0 0 1 1-1h13a1 1 0 0 1 1 1 7 7 0 0 1-7 7H8a1 1 0 0 1-1-1z",
  key: "1qn45f"
}], ["path", {
  d: "M9 12v5",
  key: "3anwtq"
}], ["path", {
  d: "M15 12v5",
  key: "5xh3zn"
}], ["path", {
  d: "M5 20a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3 1 1 0 0 1-1 1H6a1 1 0 0 1-1-1",
  key: "1fi4x8"
}]];
var Aperture = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m14.31 8 5.74 9.94",
  key: "1y6ab4"
}], ["path", {
  d: "M9.69 8h11.48",
  key: "1wxppr"
}], ["path", {
  d: "m7.38 12 5.74-9.94",
  key: "1grp0k"
}], ["path", {
  d: "M9.69 16 3.95 6.06",
  key: "libnyf"
}], ["path", {
  d: "M14.31 16H2.83",
  key: "x5fava"
}], ["path", {
  d: "m16.62 12-5.74 9.94",
  key: "1vwawt"
}]];
var AppWindowMac = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M6 8h.01",
  key: "x9i8wu"
}], ["path", {
  d: "M10 8h.01",
  key: "1r9ogq"
}], ["path", {
  d: "M14 8h.01",
  key: "1primd"
}]];
var AppWindow = [["rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2",
  key: "izxlao"
}], ["path", {
  d: "M10 4v4",
  key: "pp8u80"
}], ["path", {
  d: "M2 8h20",
  key: "d11cs7"
}], ["path", {
  d: "M6 4v4",
  key: "1svtjw"
}]];
var Apple = [["path", {
  d: "M12 6.528V3a1 1 0 0 1 1-1h0",
  key: "11qiee"
}], ["path", {
  d: "M18.237 21A15 15 0 0 0 22 11a6 6 0 0 0-10-4.472A6 6 0 0 0 2 11a15.1 15.1 0 0 0 3.763 10 3 3 0 0 0 3.648.648 5.5 5.5 0 0 1 5.178 0A3 3 0 0 0 18.237 21",
  key: "110c12"
}]];
var ArchiveRestore = [["rect", {
  width: "20",
  height: "5",
  x: "2",
  y: "3",
  rx: "1",
  key: "1wp1u1"
}], ["path", {
  d: "M4 8v11a2 2 0 0 0 2 2h2",
  key: "tvwodi"
}], ["path", {
  d: "M20 8v11a2 2 0 0 1-2 2h-2",
  key: "1gkqxj"
}], ["path", {
  d: "m9 15 3-3 3 3",
  key: "1pd0qc"
}], ["path", {
  d: "M12 12v9",
  key: "192myk"
}]];
var ArchiveX = [["rect", {
  width: "20",
  height: "5",
  x: "2",
  y: "3",
  rx: "1",
  key: "1wp1u1"
}], ["path", {
  d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",
  key: "1s80jp"
}], ["path", {
  d: "m9.5 17 5-5",
  key: "nakeu6"
}], ["path", {
  d: "m9.5 12 5 5",
  key: "1hccrj"
}]];
var Archive = [["rect", {
  width: "20",
  height: "5",
  x: "2",
  y: "3",
  rx: "1",
  key: "1wp1u1"
}], ["path", {
  d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",
  key: "1s80jp"
}], ["path", {
  d: "M10 12h4",
  key: "a56b0p"
}]];
var Armchair = [["path", {
  d: "M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3",
  key: "irtipd"
}], ["path", {
  d: "M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z",
  key: "1qyhux"
}], ["path", {
  d: "M5 18v2",
  key: "ppbyun"
}], ["path", {
  d: "M19 18v2",
  key: "gy7782"
}]];
var ArrowBigDownDash = [["path", {
  d: "M15 11a1 1 0 0 0 1 1h2.939a1 1 0 0 1 .75 1.811l-6.835 6.836a1.207 1.207 0 0 1-1.707 0L4.31 13.81a1 1 0 0 1 .75-1.811H8a1 1 0 0 0 1-1V9a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1z",
  key: "1hy3w3"
}], ["path", {
  d: "M9 4h6",
  key: "10am2s"
}]];
var ArrowBigDown = [["path", {
  d: "M15 11a1 1 0 0 0 1 1h2.939a1 1 0 0 1 .75 1.811l-6.835 6.836a1.207 1.207 0 0 1-1.707 0L4.31 13.81a1 1 0 0 1 .75-1.811H8a1 1 0 0 0 1-1V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1z",
  key: "1eaqc3"
}]];
var ArrowBigLeftDash = [["path", {
  d: "M13 9a1 1 0 0 1-1-1V5.061a1 1 0 0 0-1.811-.75l-6.835 6.836a1.207 1.207 0 0 0 0 1.707l6.835 6.835a1 1 0 0 0 1.811-.75V16a1 1 0 0 1 1-1h2a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1z",
  key: "p8w4w5"
}], ["path", {
  d: "M20 9v6",
  key: "14roy0"
}]];
var ArrowBigLeft = [["path", {
  d: "M13 9a1 1 0 0 1-1-1V5.061a1 1 0 0 0-1.811-.75l-6.835 6.836a1.207 1.207 0 0 0 0 1.707l6.835 6.835a1 1 0 0 0 1.811-.75V16a1 1 0 0 1 1-1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1z",
  key: "aztept"
}]];
var ArrowBigRightDash = [["path", {
  d: "M11 9a1 1 0 0 0 1-1V5.061a1 1 0 0 1 1.811-.75l6.836 6.836a1.207 1.207 0 0 1 0 1.707l-6.836 6.835a1 1 0 0 1-1.811-.75V16a1 1 0 0 0-1-1H9a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z",
  key: "67vhrh"
}], ["path", {
  d: "M4 9v6",
  key: "bns7oa"
}]];
var ArrowBigRight = [["path", {
  d: "M11 9a1 1 0 0 0 1-1V5.061a1 1 0 0 1 1.811-.75l6.836 6.836a1.207 1.207 0 0 1 0 1.707l-6.836 6.835a1 1 0 0 1-1.811-.75V16a1 1 0 0 0-1-1H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z",
  key: "1232du"
}]];
var ArrowBigUpDash = [["path", {
  d: "M9 13a1 1 0 0 0-1-1H5.061a1 1 0 0 1-.75-1.811l6.836-6.835a1.207 1.207 0 0 1 1.707 0l6.835 6.835a1 1 0 0 1-.75 1.811H16a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z",
  key: "pnzqmc"
}], ["path", {
  d: "M9 20h6",
  key: "s66wpe"
}]];
var ArrowBigUp = [["path", {
  d: "M9 13a1 1 0 0 0-1-1H5.061a1 1 0 0 1-.75-1.811l6.836-6.835a1.207 1.207 0 0 1 1.707 0l6.835 6.835a1 1 0 0 1-.75 1.811H16a1 1 0 0 0-1 1v6a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z",
  key: "lh0v7k"
}]];
var ArrowDown01 = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["rect", {
  x: "15",
  y: "4",
  width: "4",
  height: "6",
  ry: "2",
  key: "1bwicg"
}], ["path", {
  d: "M17 20v-6h-2",
  key: "1qp1so"
}], ["path", {
  d: "M15 20h4",
  key: "1j968p"
}]];
var ArrowDown10 = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["path", {
  d: "M17 10V4h-2",
  key: "zcsr5x"
}], ["path", {
  d: "M15 10h4",
  key: "id2lce"
}], ["rect", {
  x: "15",
  y: "14",
  width: "4",
  height: "6",
  ry: "2",
  key: "33xykx"
}]];
var ArrowDownFromLine = [["path", {
  d: "M19 3H5",
  key: "1236rx"
}], ["path", {
  d: "M12 21V7",
  key: "gj6g52"
}], ["path", {
  d: "m6 15 6 6 6-6",
  key: "h15q88"
}]];
var ArrowDownAZ = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["path", {
  d: "M20 8h-5",
  key: "1vsyxs"
}], ["path", {
  d: "M15 10V6.5a2.5 2.5 0 0 1 5 0V10",
  key: "ag13bf"
}], ["path", {
  d: "M15 14h5l-5 6h5",
  key: "ur5jdg"
}]];
var ArrowDownLeft = [["path", {
  d: "M17 7 7 17",
  key: "15tmo1"
}], ["path", {
  d: "M17 17H7V7",
  key: "1org7z"
}]];
var ArrowDownNarrowWide = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["path", {
  d: "M11 4h4",
  key: "6d7r33"
}], ["path", {
  d: "M11 8h7",
  key: "djye34"
}], ["path", {
  d: "M11 12h10",
  key: "1438ji"
}]];
var ArrowDownRight = [["path", {
  d: "m7 7 10 10",
  key: "1fmybs"
}], ["path", {
  d: "M17 7v10H7",
  key: "6fjiku"
}]];
var ArrowDownToDot = [["path", {
  d: "M12 2v14",
  key: "jyx4ut"
}], ["path", {
  d: "m19 9-7 7-7-7",
  key: "1oe3oy"
}], ["circle", {
  cx: "12",
  cy: "21",
  r: "1",
  key: "o0uj5v"
}]];
var ArrowDownToLine = [["path", {
  d: "M12 17V3",
  key: "1cwfxf"
}], ["path", {
  d: "m6 11 6 6 6-6",
  key: "12ii2o"
}], ["path", {
  d: "M19 21H5",
  key: "150jfl"
}]];
var ArrowDownUp = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["path", {
  d: "m21 8-4-4-4 4",
  key: "1c9v7m"
}], ["path", {
  d: "M17 4v16",
  key: "7dpous"
}]];
var ArrowDownWideNarrow = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 20V4",
  key: "1yoxec"
}], ["path", {
  d: "M11 4h10",
  key: "1w87gc"
}], ["path", {
  d: "M11 8h7",
  key: "djye34"
}], ["path", {
  d: "M11 12h4",
  key: "q8tih4"
}]];
var ArrowDownZA = [["path", {
  d: "m3 16 4 4 4-4",
  key: "1co6wj"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M15 4h5l-5 6h5",
  key: "8asdl1"
}], ["path", {
  d: "M15 20v-3.5a2.5 2.5 0 0 1 5 0V20",
  key: "r6l5cz"
}], ["path", {
  d: "M20 18h-5",
  key: "18j1r2"
}]];
var ArrowDown = [["path", {
  d: "M12 5v14",
  key: "s699le"
}], ["path", {
  d: "m19 12-7 7-7-7",
  key: "1idqje"
}]];
var ArrowLeftFromLine = [["path", {
  d: "m9 6-6 6 6 6",
  key: "7v63n9"
}], ["path", {
  d: "M3 12h14",
  key: "13k4hi"
}], ["path", {
  d: "M21 19V5",
  key: "b4bplr"
}]];
var ArrowLeftRight = [["path", {
  d: "M8 3 4 7l4 4",
  key: "9rb6wj"
}], ["path", {
  d: "M4 7h16",
  key: "6tx8e3"
}], ["path", {
  d: "m16 21 4-4-4-4",
  key: "siv7j2"
}], ["path", {
  d: "M20 17H4",
  key: "h6l3hr"
}]];
var ArrowLeftToLine = [["path", {
  d: "M3 19V5",
  key: "rwsyhb"
}], ["path", {
  d: "m13 6-6 6 6 6",
  key: "1yhaz7"
}], ["path", {
  d: "M7 12h14",
  key: "uoisry"
}]];
var ArrowLeft = [["path", {
  d: "m12 19-7-7 7-7",
  key: "1l729n"
}], ["path", {
  d: "M19 12H5",
  key: "x3x0zl"
}]];
var ArrowRightFromLine = [["path", {
  d: "M3 5v14",
  key: "1nt18q"
}], ["path", {
  d: "M21 12H7",
  key: "13ipq5"
}], ["path", {
  d: "m15 18 6-6-6-6",
  key: "6tx3qv"
}]];
var ArrowRightLeft = [["path", {
  d: "m16 3 4 4-4 4",
  key: "1x1c3m"
}], ["path", {
  d: "M20 7H4",
  key: "zbl0bi"
}], ["path", {
  d: "m8 21-4-4 4-4",
  key: "h9nckh"
}], ["path", {
  d: "M4 17h16",
  key: "g4d7ey"
}]];
var ArrowRightToLine = [["path", {
  d: "M17 12H3",
  key: "8awo09"
}], ["path", {
  d: "m11 18 6-6-6-6",
  key: "8c2y43"
}], ["path", {
  d: "M21 5v14",
  key: "nzette"
}]];
var ArrowRight = [["path", {
  d: "M5 12h14",
  key: "1ays0h"
}], ["path", {
  d: "m12 5 7 7-7 7",
  key: "xquz4c"
}]];
var ArrowUp01 = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["rect", {
  x: "15",
  y: "4",
  width: "4",
  height: "6",
  ry: "2",
  key: "1bwicg"
}], ["path", {
  d: "M17 20v-6h-2",
  key: "1qp1so"
}], ["path", {
  d: "M15 20h4",
  key: "1j968p"
}]];
var ArrowUp10 = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M17 10V4h-2",
  key: "zcsr5x"
}], ["path", {
  d: "M15 10h4",
  key: "id2lce"
}], ["rect", {
  x: "15",
  y: "14",
  width: "4",
  height: "6",
  ry: "2",
  key: "33xykx"
}]];
var ArrowUpAZ = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M20 8h-5",
  key: "1vsyxs"
}], ["path", {
  d: "M15 10V6.5a2.5 2.5 0 0 1 5 0V10",
  key: "ag13bf"
}], ["path", {
  d: "M15 14h5l-5 6h5",
  key: "ur5jdg"
}]];
var ArrowUpFromDot = [["path", {
  d: "m5 9 7-7 7 7",
  key: "1hw5ic"
}], ["path", {
  d: "M12 16V2",
  key: "ywoabb"
}], ["circle", {
  cx: "12",
  cy: "21",
  r: "1",
  key: "o0uj5v"
}]];
var ArrowUpDown = [["path", {
  d: "m21 16-4 4-4-4",
  key: "f6ql7i"
}], ["path", {
  d: "M17 20V4",
  key: "1ejh1v"
}], ["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}]];
var ArrowUpFromLine = [["path", {
  d: "m18 9-6-6-6 6",
  key: "kcunyi"
}], ["path", {
  d: "M12 3v14",
  key: "7cf3v8"
}], ["path", {
  d: "M5 21h14",
  key: "11awu3"
}]];
var ArrowUpLeft = [["path", {
  d: "M7 17V7h10",
  key: "11bw93"
}], ["path", {
  d: "M17 17 7 7",
  key: "2786uv"
}]];
var ArrowUpNarrowWide = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M11 12h4",
  key: "q8tih4"
}], ["path", {
  d: "M11 16h7",
  key: "uosisv"
}], ["path", {
  d: "M11 20h10",
  key: "jvxblo"
}]];
var ArrowUpRight = [["path", {
  d: "M7 7h10v10",
  key: "1tivn9"
}], ["path", {
  d: "M7 17 17 7",
  key: "1vkiza"
}]];
var ArrowUpToLine = [["path", {
  d: "M5 3h14",
  key: "7usisc"
}], ["path", {
  d: "m18 13-6-6-6 6",
  key: "1kf1n9"
}], ["path", {
  d: "M12 7v14",
  key: "1akyts"
}]];
var ArrowUpWideNarrow = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M11 12h10",
  key: "1438ji"
}], ["path", {
  d: "M11 16h7",
  key: "uosisv"
}], ["path", {
  d: "M11 20h4",
  key: "1krc32"
}]];
var ArrowUpZA = [["path", {
  d: "m3 8 4-4 4 4",
  key: "11wl7u"
}], ["path", {
  d: "M7 4v16",
  key: "1glfcx"
}], ["path", {
  d: "M15 4h5l-5 6h5",
  key: "8asdl1"
}], ["path", {
  d: "M15 20v-3.5a2.5 2.5 0 0 1 5 0V20",
  key: "r6l5cz"
}], ["path", {
  d: "M20 18h-5",
  key: "18j1r2"
}]];
var ArrowUp = [["path", {
  d: "m5 12 7-7 7 7",
  key: "hav0vg"
}], ["path", {
  d: "M12 19V5",
  key: "x0mq9r"
}]];
var ArrowsUpFromLine = [["path", {
  d: "m4 6 3-3 3 3",
  key: "9aidw8"
}], ["path", {
  d: "M7 17V3",
  key: "19qxw1"
}], ["path", {
  d: "m14 6 3-3 3 3",
  key: "6iy689"
}], ["path", {
  d: "M17 17V3",
  key: "o0fmgi"
}], ["path", {
  d: "M4 21h16",
  key: "1h09gz"
}]];
var Asterisk = [["path", {
  d: "M12 6v12",
  key: "1vza4d"
}], ["path", {
  d: "M17.196 9 6.804 15",
  key: "1ah31z"
}], ["path", {
  d: "m6.804 9 10.392 6",
  key: "1b6pxd"
}]];
var AtSign = [["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["path", {
  d: "M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8",
  key: "7n84p3"
}]];
var Atom = [["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["path", {
  d: "M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",
  key: "1l2ple"
}], ["path", {
  d: "M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",
  key: "1wam0m"
}]];
var AudioLines = [["path", {
  d: "M2 10v3",
  key: "1fnikh"
}], ["path", {
  d: "M6 6v11",
  key: "11sgs0"
}], ["path", {
  d: "M10 3v18",
  key: "yhl04a"
}], ["path", {
  d: "M14 8v7",
  key: "3a1oy3"
}], ["path", {
  d: "M18 5v13",
  key: "123xd1"
}], ["path", {
  d: "M22 10v3",
  key: "154ddg"
}]];
var AudioWaveform = [["path", {
  d: "M2 13a2 2 0 0 0 2-2V7a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0V4a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0v-4a2 2 0 0 1 2-2",
  key: "57tc96"
}]];
var Award = [["path", {
  d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
  key: "1yiouv"
}], ["circle", {
  cx: "12",
  cy: "8",
  r: "6",
  key: "1vp47v"
}]];
var Axe = [["path", {
  d: "m14 12-8.381 8.38a1 1 0 0 1-3.001-3L11 9",
  key: "5z9253"
}], ["path", {
  d: "M15 15.5a.5.5 0 0 0 .5.5A6.5 6.5 0 0 0 22 9.5a.5.5 0 0 0-.5-.5h-1.672a2 2 0 0 1-1.414-.586l-5.062-5.062a1.205 1.205 0 0 0-1.704 0L9.352 5.648a1.205 1.205 0 0 0 0 1.704l5.062 5.062A2 2 0 0 1 15 13.828z",
  key: "19zklq"
}]];
var Axis3d = [["path", {
  d: "M13.5 10.5 15 9",
  key: "1nsxvm"
}], ["path", {
  d: "M4 4v15a1 1 0 0 0 1 1h15",
  key: "1w6lkd"
}], ["path", {
  d: "M4.293 19.707 6 18",
  key: "3g1p8c"
}], ["path", {
  d: "m9 15 1.5-1.5",
  key: "1xfbes"
}]];
var Baby = [["path", {
  d: "M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5",
  key: "1u7htd"
}], ["path", {
  d: "M15 12h.01",
  key: "1k8ypt"
}], ["path", {
  d: "M19.38 6.813A9 9 0 0 1 20.8 10.2a2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1",
  key: "11xh7x"
}], ["path", {
  d: "M9 12h.01",
  key: "157uk2"
}]];
var Backpack = [["path", {
  d: "M4 10a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z",
  key: "1ol0lm"
}], ["path", {
  d: "M8 10h8",
  key: "c7uz4u"
}], ["path", {
  d: "M8 18h8",
  key: "1no2b1"
}], ["path", {
  d: "M8 22v-6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v6",
  key: "1fr6do"
}], ["path", {
  d: "M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2",
  key: "donm21"
}]];
var BadgeAlert = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "8",
  y2: "12",
  key: "1pkeuh"
}], ["line", {
  x1: "12",
  x2: "12.01",
  y1: "16",
  y2: "16",
  key: "4dfq90"
}]];
var BadgeCent = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M12 7v10",
  key: "jspqdw"
}], ["path", {
  d: "M15.4 10a4 4 0 1 0 0 4",
  key: "2eqtx8"
}]];
var BadgeCheck = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var BadgeDollarSign = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",
  key: "1h4pet"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}]];
var BadgeEuro = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M7 12h5",
  key: "gblrwe"
}], ["path", {
  d: "M15 9.4a4 4 0 1 0 0 5.2",
  key: "1makmb"
}]];
var BadgeIndianRupee = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M8 8h8",
  key: "1bis0t"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "m13 17-5-1h1a4 4 0 0 0 0-8",
  key: "nu2bwa"
}]];
var BadgeInfo = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "16",
  y2: "12",
  key: "1y1yb1"
}], ["line", {
  x1: "12",
  x2: "12.01",
  y1: "8",
  y2: "8",
  key: "110wyk"
}]];
var BadgeJapaneseYen = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "m9 8 3 3v7",
  key: "17yadx"
}], ["path", {
  d: "m12 11 3-3",
  key: "p4cfq1"
}], ["path", {
  d: "M9 12h6",
  key: "1c52cq"
}], ["path", {
  d: "M9 16h6",
  key: "8wimt3"
}]];
var BadgeMinus = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "12",
  y2: "12",
  key: "1jonct"
}]];
var BadgePercent = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["path", {
  d: "M15 15h.01",
  key: "lqbp3k"
}]];
var BadgePoundSterling = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M8 12h4",
  key: "qz6y1c"
}], ["path", {
  d: "M10 16V9.5a2.5 2.5 0 0 1 5 0",
  key: "3mlbjk"
}], ["path", {
  d: "M8 16h7",
  key: "sbedsn"
}]];
var BadgeQuestionMark = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
  key: "1u773s"
}], ["line", {
  x1: "12",
  x2: "12.01",
  y1: "17",
  y2: "17",
  key: "io3f8k"
}]];
var BadgePlus = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "8",
  y2: "16",
  key: "10p56q"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "12",
  y2: "12",
  key: "1jonct"
}]];
var BadgeRussianRuble = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M9 16h5",
  key: "1syiyw"
}], ["path", {
  d: "M9 12h5a2 2 0 1 0 0-4h-3v9",
  key: "1ge9c1"
}]];
var BadgeSwissFranc = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["path", {
  d: "M11 17V8h4",
  key: "1bfq6y"
}], ["path", {
  d: "M11 12h3",
  key: "2eqnfz"
}], ["path", {
  d: "M9 16h4",
  key: "1skf3a"
}]];
var BadgeTurkishLira = [["path", {
  d: "M11 7v10a5 5 0 0 0 5-5",
  key: "1ja3ih"
}], ["path", {
  d: "m15 8-6 3",
  key: "4x0uwz"
}], ["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76",
  key: "18242g"
}]];
var BadgeX = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}], ["line", {
  x1: "15",
  x2: "9",
  y1: "9",
  y2: "15",
  key: "f7djnv"
}], ["line", {
  x1: "9",
  x2: "15",
  y1: "9",
  y2: "15",
  key: "1shsy8"
}]];
var Badge = [["path", {
  d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
  key: "3c2336"
}]];
var BaggageClaim = [["path", {
  d: "M22 18H6a2 2 0 0 1-2-2V7a2 2 0 0 0-2-2",
  key: "4irg2o"
}], ["path", {
  d: "M17 14V4a2 2 0 0 0-2-2h-1a2 2 0 0 0-2 2v10",
  key: "14fcyx"
}], ["rect", {
  width: "13",
  height: "8",
  x: "8",
  y: "6",
  rx: "1",
  key: "o6oiis"
}], ["circle", {
  cx: "18",
  cy: "20",
  r: "2",
  key: "t9985n"
}], ["circle", {
  cx: "9",
  cy: "20",
  r: "2",
  key: "e5v82j"
}]];
var Balloon = [["path", {
  d: "M12 16v1a2 2 0 0 0 2 2h1a2 2 0 0 1 2 2v1",
  key: "2nz4b"
}], ["path", {
  d: "M12 6a2 2 0 0 1 2 2",
  key: "7y7d82"
}], ["path", {
  d: "M18 8c0 4-3.5 8-6 8s-6-4-6-8a6 6 0 0 1 12 0",
  key: "vqb5s3"
}]];
var Ban = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M4.929 4.929 19.07 19.071",
  key: "196cmz"
}]];
var Banana = [["path", {
  d: "M4 13c3.5-2 8-2 10 2a5.5 5.5 0 0 1 8 5",
  key: "1cscit"
}], ["path", {
  d: "M5.15 17.89c5.52-1.52 8.65-6.89 7-12C11.55 4 11.5 2 13 2c3.22 0 5 5.5 5 8 0 6.5-4.2 12-10.49 12C5.11 22 2 22 2 20c0-1.5 1.14-1.55 3.15-2.11Z",
  key: "1y1nbv"
}]];
var Bandage = [["path", {
  d: "M10 10.01h.01",
  key: "1e9xi7"
}], ["path", {
  d: "M10 14.01h.01",
  key: "ac23bv"
}], ["path", {
  d: "M14 10.01h.01",
  key: "2wfrvf"
}], ["path", {
  d: "M14 14.01h.01",
  key: "8tw8yn"
}], ["path", {
  d: "M18 6v12",
  key: "1bcixs"
}], ["path", {
  d: "M6 6v12",
  key: "vkc79e"
}], ["rect", {
  x: "2",
  y: "6",
  width: "20",
  height: "12",
  rx: "2",
  key: "1wpnh2"
}]];
var BanknoteArrowDown = [["path", {
  d: "M12 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5",
  key: "x6cv4u"
}], ["path", {
  d: "m16 19 3 3 3-3",
  key: "1ibux0"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}], ["path", {
  d: "M19 16v6",
  key: "tddt3s"
}], ["path", {
  d: "M6 12h.01",
  key: "c2rlol"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var BanknoteArrowUp = [["path", {
  d: "M12 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5",
  key: "x6cv4u"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}], ["path", {
  d: "M19 22v-6",
  key: "qhmiwi"
}], ["path", {
  d: "m22 19-3-3-3 3",
  key: "rn6bg2"
}], ["path", {
  d: "M6 12h.01",
  key: "c2rlol"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var BanknoteX = [["path", {
  d: "M13 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5",
  key: "16nib6"
}], ["path", {
  d: "m17 17 5 5",
  key: "p7ous7"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}], ["path", {
  d: "m22 17-5 5",
  key: "gqnmv0"
}], ["path", {
  d: "M6 12h.01",
  key: "c2rlol"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var Banknote = [["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "6",
  rx: "2",
  key: "9lu3g6"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["path", {
  d: "M6 12h.01M18 12h.01",
  key: "113zkx"
}]];
var Barcode = [["path", {
  d: "M3 5v14",
  key: "1nt18q"
}], ["path", {
  d: "M8 5v14",
  key: "1ybrkv"
}], ["path", {
  d: "M12 5v14",
  key: "s699le"
}], ["path", {
  d: "M17 5v14",
  key: "ycjyhj"
}], ["path", {
  d: "M21 5v14",
  key: "nzette"
}]];
var Barrel = [["path", {
  d: "M10 3a41 41 0 0 0 0 18",
  key: "1qcnzb"
}], ["path", {
  d: "M14 3a41 41 0 0 1 0 18",
  key: "547vd4"
}], ["path", {
  d: "M17 3a2 2 0 0 1 1.68.92 15.25 15.25 0 0 1 0 16.16A2 2 0 0 1 17 21H7a2 2 0 0 1-1.68-.92 15.25 15.25 0 0 1 0-16.16A2 2 0 0 1 7 3z",
  key: "1wepyy"
}], ["path", {
  d: "M3.84 17h16.32",
  key: "1wh981"
}], ["path", {
  d: "M3.84 7h16.32",
  key: "19jf4x"
}]];
var Baseline = [["path", {
  d: "M4 20h16",
  key: "14thso"
}], ["path", {
  d: "m6 16 6-12 6 12",
  key: "1b4byz"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var Bath = [["path", {
  d: "M10 4 8 6",
  key: "1rru8s"
}], ["path", {
  d: "M17 19v2",
  key: "ts1sot"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "M7 19v2",
  key: "12npes"
}], ["path", {
  d: "M9 5 7.621 3.621A2.121 2.121 0 0 0 4 5v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5",
  key: "14ym8i"
}]];
var BatteryCharging = [["path", {
  d: "m11 7-3 5h4l-3 5",
  key: "b4a64w"
}], ["path", {
  d: "M14.856 6H16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.935",
  key: "lre1cr"
}], ["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M5.14 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2.936",
  key: "13q5k0"
}]];
var BatteryLow = [["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M6 14v-4",
  key: "14a6bd"
}], ["rect", {
  x: "2",
  y: "6",
  width: "16",
  height: "12",
  rx: "2",
  key: "13zb55"
}]];
var BatteryFull = [["path", {
  d: "M10 10v4",
  key: "1mb2ec"
}], ["path", {
  d: "M14 10v4",
  key: "1nt88p"
}], ["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M6 10v4",
  key: "1n77qd"
}], ["rect", {
  x: "2",
  y: "6",
  width: "16",
  height: "12",
  rx: "2",
  key: "13zb55"
}]];
var BatteryMedium = [["path", {
  d: "M10 14v-4",
  key: "suye4c"
}], ["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M6 14v-4",
  key: "14a6bd"
}], ["rect", {
  x: "2",
  y: "6",
  width: "16",
  height: "12",
  rx: "2",
  key: "13zb55"
}]];
var BatteryPlus = [["path", {
  d: "M10 9v6",
  key: "17i7lo"
}], ["path", {
  d: "M12.543 6H16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-3.605",
  key: "o09yah"
}], ["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M7 12h6",
  key: "iekk3h"
}], ["path", {
  d: "M7.606 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3.606",
  key: "xyqvf1"
}]];
var BatteryWarning = [["path", {
  d: "M10 17h.01",
  key: "nbq80n"
}], ["path", {
  d: "M10 7v6",
  key: "nne03l"
}], ["path", {
  d: "M14 6h2a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2",
  key: "1m83kb"
}], ["path", {
  d: "M22 14v-4",
  key: "14q9d5"
}], ["path", {
  d: "M6 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2",
  key: "h8lgfh"
}]];
var Battery = [["path", {
  d: "M 22 14 L 22 10",
  key: "nqc4tb"
}], ["rect", {
  x: "2",
  y: "6",
  width: "16",
  height: "12",
  rx: "2",
  key: "13zb55"
}]];
var Beaker = [["path", {
  d: "M4.5 3h15",
  key: "c7n0jr"
}], ["path", {
  d: "M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3",
  key: "m1uhx7"
}], ["path", {
  d: "M6 14h12",
  key: "4cwo0f"
}]];
var BeanOff = [["path", {
  d: "M9 9c-.64.64-1.521.954-2.402 1.165A6 6 0 0 0 8 22a13.96 13.96 0 0 0 9.9-4.1",
  key: "bq3udt"
}], ["path", {
  d: "M10.75 5.093A6 6 0 0 1 22 8c0 2.411-.61 4.68-1.683 6.66",
  key: "17ccse"
}], ["path", {
  d: "M5.341 10.62a4 4 0 0 0 6.487 1.208M10.62 5.341a4.015 4.015 0 0 1 2.039 2.04",
  key: "18zqgq"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Bean = [["path", {
  d: "M10.165 6.598C9.954 7.478 9.64 8.36 9 9c-.64.64-1.521.954-2.402 1.165A6 6 0 0 0 8 22c7.732 0 14-6.268 14-14a6 6 0 0 0-11.835-1.402Z",
  key: "1tvzk7"
}], ["path", {
  d: "M5.341 10.62a4 4 0 1 0 5.279-5.28",
  key: "2cyri2"
}]];
var BedDouble = [["path", {
  d: "M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8",
  key: "1k78r4"
}], ["path", {
  d: "M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4",
  key: "fb3tl2"
}], ["path", {
  d: "M12 4v6",
  key: "1dcgq2"
}], ["path", {
  d: "M2 18h20",
  key: "ajqnye"
}]];
var BedSingle = [["path", {
  d: "M3 20v-8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v8",
  key: "1wm6mi"
}], ["path", {
  d: "M5 10V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v4",
  key: "4k93s5"
}], ["path", {
  d: "M3 18h18",
  key: "1h113x"
}]];
var Bed = [["path", {
  d: "M2 4v16",
  key: "vw9hq8"
}], ["path", {
  d: "M2 8h18a2 2 0 0 1 2 2v10",
  key: "1dgv2r"
}], ["path", {
  d: "M2 17h20",
  key: "18nfp3"
}], ["path", {
  d: "M6 8v9",
  key: "1yriud"
}]];
var Beef = [["path", {
  d: "M16.4 13.7A6.5 6.5 0 1 0 6.28 6.6c-1.1 3.13-.78 3.9-3.18 6.08A3 3 0 0 0 5 18c4 0 8.4-1.8 11.4-4.3",
  key: "cisjcv"
}], ["path", {
  d: "m18.5 6 2.19 4.5a6.48 6.48 0 0 1-2.29 7.2C15.4 20.2 11 22 7 22a3 3 0 0 1-2.68-1.66L2.4 16.5",
  key: "5byaag"
}], ["circle", {
  cx: "12.5",
  cy: "8.5",
  r: "2.5",
  key: "9738u8"
}]];
var BeerOff = [["path", {
  d: "M13 13v5",
  key: "igwfh0"
}], ["path", {
  d: "M17 11.47V8",
  key: "16yw0g"
}], ["path", {
  d: "M17 11h1a3 3 0 0 1 2.745 4.211",
  key: "1xbt65"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M5 8v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-3",
  key: "c55o3e"
}], ["path", {
  d: "M7.536 7.535C6.766 7.649 6.154 8 5.5 8a2.5 2.5 0 0 1-1.768-4.268",
  key: "1ydug7"
}], ["path", {
  d: "M8.727 3.204C9.306 2.767 9.885 2 11 2c1.56 0 2 1.5 3 1.5s1.72-.5 2.5-.5a1 1 0 1 1 0 5c-.78 0-1.5-.5-2.5-.5a3.149 3.149 0 0 0-.842.12",
  key: "q81o7q"
}], ["path", {
  d: "M9 14.6V18",
  key: "20ek98"
}]];
var Beer = [["path", {
  d: "M17 11h1a3 3 0 0 1 0 6h-1",
  key: "1yp76v"
}], ["path", {
  d: "M9 12v6",
  key: "1u1cab"
}], ["path", {
  d: "M13 12v6",
  key: "1sugkk"
}], ["path", {
  d: "M14 7.5c-1 0-1.44.5-3 .5s-2-.5-3-.5-1.72.5-2.5.5a2.5 2.5 0 0 1 0-5c.78 0 1.57.5 2.5.5S9.44 2 11 2s2 1.5 3 1.5 1.72-.5 2.5-.5a2.5 2.5 0 0 1 0 5c-.78 0-1.5-.5-2.5-.5Z",
  key: "1510fo"
}], ["path", {
  d: "M5 8v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8",
  key: "19jb7n"
}]];
var BellDot = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M11.68 2.009A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673c-.824-.85-1.678-1.731-2.21-3.348",
  key: "xaq59h"
}], ["circle", {
  cx: "18",
  cy: "5",
  r: "3",
  key: "gq8acd"
}]];
var BellElectric = [["path", {
  d: "M18.518 17.347A7 7 0 0 1 14 19",
  key: "1emhpo"
}], ["path", {
  d: "M18.8 4A11 11 0 0 1 20 9",
  key: "127b67"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["circle", {
  cx: "20",
  cy: "16",
  r: "2",
  key: "1v9bxh"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "7",
  key: "p2h5vp"
}], ["rect", {
  x: "4",
  y: "16",
  width: "10",
  height: "6",
  rx: "2",
  key: "bfnviv"
}]];
var BellMinus = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M15 8h6",
  key: "8ybuxh"
}], ["path", {
  d: "M16.243 3.757A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673A9.4 9.4 0 0 1 18.667 12",
  key: "bdwj86"
}]];
var BellOff = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M17 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 .258-1.742",
  key: "178tsu"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.668 3.01A6 6 0 0 1 18 8c0 2.687.77 4.653 1.707 6.05",
  key: "1hqiys"
}]];
var BellPlus = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M15 8h6",
  key: "8ybuxh"
}], ["path", {
  d: "M18 5v6",
  key: "g5ayrv"
}], ["path", {
  d: "M20.002 14.464a9 9 0 0 0 .738.863A1 1 0 0 1 20 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 8.75-5.332",
  key: "1abcvy"
}]];
var BellRing = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M22 8c0-2.3-.8-4.3-2-6",
  key: "5bb3ad"
}], ["path", {
  d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
  key: "11g9vi"
}], ["path", {
  d: "M4 2C2.8 3.7 2 5.7 2 8",
  key: "tap9e0"
}]];
var Bell = [["path", {
  d: "M10.268 21a2 2 0 0 0 3.464 0",
  key: "vwvbt9"
}], ["path", {
  d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
  key: "11g9vi"
}]];
var BetweenHorizontalEnd = [["rect", {
  width: "13",
  height: "7",
  x: "3",
  y: "3",
  rx: "1",
  key: "11xb64"
}], ["path", {
  d: "m22 15-3-3 3-3",
  key: "26chmm"
}], ["rect", {
  width: "13",
  height: "7",
  x: "3",
  y: "14",
  rx: "1",
  key: "k6ky7n"
}]];
var BetweenHorizontalStart = [["rect", {
  width: "13",
  height: "7",
  x: "8",
  y: "3",
  rx: "1",
  key: "pkso9a"
}], ["path", {
  d: "m2 9 3 3-3 3",
  key: "1agib5"
}], ["rect", {
  width: "13",
  height: "7",
  x: "8",
  y: "14",
  rx: "1",
  key: "1q5fc1"
}]];
var BetweenVerticalEnd = [["rect", {
  width: "7",
  height: "13",
  x: "3",
  y: "3",
  rx: "1",
  key: "1fdu0f"
}], ["path", {
  d: "m9 22 3-3 3 3",
  key: "17z65a"
}], ["rect", {
  width: "7",
  height: "13",
  x: "14",
  y: "3",
  rx: "1",
  key: "1squn4"
}]];
var BetweenVerticalStart = [["rect", {
  width: "7",
  height: "13",
  x: "3",
  y: "8",
  rx: "1",
  key: "1fjrkv"
}], ["path", {
  d: "m15 2-3 3-3-3",
  key: "1uh6eb"
}], ["rect", {
  width: "7",
  height: "13",
  x: "14",
  y: "8",
  rx: "1",
  key: "w3fjg8"
}]];
var Bike = [["circle", {
  cx: "18.5",
  cy: "17.5",
  r: "3.5",
  key: "15x4ox"
}], ["circle", {
  cx: "5.5",
  cy: "17.5",
  r: "3.5",
  key: "1noe27"
}], ["circle", {
  cx: "15",
  cy: "5",
  r: "1",
  key: "19l28e"
}], ["path", {
  d: "M12 17.5V14l-3-3 4-3 2 3h2",
  key: "1npguv"
}]];
var Binary = [["rect", {
  x: "14",
  y: "14",
  width: "4",
  height: "6",
  rx: "2",
  key: "p02svl"
}], ["rect", {
  x: "6",
  y: "4",
  width: "4",
  height: "6",
  rx: "2",
  key: "xm4xkj"
}], ["path", {
  d: "M6 20h4",
  key: "1i6q5t"
}], ["path", {
  d: "M14 10h4",
  key: "ru81e7"
}], ["path", {
  d: "M6 14h2v6",
  key: "16z9wg"
}], ["path", {
  d: "M14 4h2v6",
  key: "1idq9u"
}]];
var BicepsFlexed = [["path", {
  d: "M12.409 13.017A5 5 0 0 1 22 15c0 3.866-4 7-9 7-4.077 0-8.153-.82-10.371-2.462-.426-.316-.631-.832-.62-1.362C2.118 12.723 2.627 2 10 2a3 3 0 0 1 3 3 2 2 0 0 1-2 2c-1.105 0-1.64-.444-2-1",
  key: "1pmlyh"
}], ["path", {
  d: "M15 14a5 5 0 0 0-7.584 2",
  key: "5rb254"
}], ["path", {
  d: "M9.964 6.825C8.019 7.977 9.5 13 8 15",
  key: "kbvsx9"
}]];
var Binoculars = [["path", {
  d: "M10 10h4",
  key: "tcdvrf"
}], ["path", {
  d: "M19 7V4a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3",
  key: "3apit1"
}], ["path", {
  d: "M20 21a2 2 0 0 0 2-2v-3.851c0-1.39-2-2.962-2-4.829V8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v11a2 2 0 0 0 2 2z",
  key: "rhpgnw"
}], ["path", {
  d: "M 22 16 L 2 16",
  key: "14lkq7"
}], ["path", {
  d: "M4 21a2 2 0 0 1-2-2v-3.851c0-1.39 2-2.962 2-4.829V8a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v11a2 2 0 0 1-2 2z",
  key: "104b3k"
}], ["path", {
  d: "M9 7V4a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3",
  key: "14fczp"
}]];
var Biohazard = [["circle", {
  cx: "12",
  cy: "11.9",
  r: "2",
  key: "e8h31w"
}], ["path", {
  d: "M6.7 3.4c-.9 2.5 0 5.2 2.2 6.7C6.5 9 3.7 9.6 2 11.6",
  key: "17bolr"
}], ["path", {
  d: "m8.9 10.1 1.4.8",
  key: "15ezny"
}], ["path", {
  d: "M17.3 3.4c.9 2.5 0 5.2-2.2 6.7 2.4-1.2 5.2-.6 6.9 1.5",
  key: "wtwa5u"
}], ["path", {
  d: "m15.1 10.1-1.4.8",
  key: "1r0b28"
}], ["path", {
  d: "M16.7 20.8c-2.6-.4-4.6-2.6-4.7-5.3-.2 2.6-2.1 4.8-4.7 5.2",
  key: "m7qszh"
}], ["path", {
  d: "M12 13.9v1.6",
  key: "zfyyim"
}], ["path", {
  d: "M13.5 5.4c-1-.2-2-.2-3 0",
  key: "1bi9q0"
}], ["path", {
  d: "M17 16.4c.7-.7 1.2-1.6 1.5-2.5",
  key: "1rhjqw"
}], ["path", {
  d: "M5.5 13.9c.3.9.8 1.8 1.5 2.5",
  key: "8gsud3"
}]];
var Bird = [["path", {
  d: "M16 7h.01",
  key: "1kdx03"
}], ["path", {
  d: "M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20",
  key: "oj1oa8"
}], ["path", {
  d: "m20 7 2 .5-2 .5",
  key: "12nv4d"
}], ["path", {
  d: "M10 18v3",
  key: "1yea0a"
}], ["path", {
  d: "M14 17.75V21",
  key: "1pymcb"
}], ["path", {
  d: "M7 18a6 6 0 0 0 3.84-10.61",
  key: "1npnn0"
}]];
var Birdhouse = [["path", {
  d: "M12 18v4",
  key: "jadmvz"
}], ["path", {
  d: "m17 18 1.956-11.468",
  key: "l5n2ro"
}], ["path", {
  d: "m3 8 7.82-5.615a2 2 0 0 1 2.36 0L21 8",
  key: "1sy6n7"
}], ["path", {
  d: "M4 18h16",
  key: "19g7jn"
}], ["path", {
  d: "M7 18 5.044 6.532",
  key: "1uqdf2"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "2",
  key: "1yojzk"
}]];
var Bitcoin = [["path", {
  d: "M11.767 19.089c4.924.868 6.14-6.025 1.216-6.894m-1.216 6.894L5.86 18.047m5.908 1.042-.347 1.97m1.563-8.864c4.924.869 6.14-6.025 1.215-6.893m-1.215 6.893-3.94-.694m5.155-6.2L8.29 4.26m5.908 1.042.348-1.97M7.48 20.364l3.126-17.727",
  key: "yr8idg"
}]];
var Blend = [["circle", {
  cx: "9",
  cy: "9",
  r: "7",
  key: "p2h5vp"
}], ["circle", {
  cx: "15",
  cy: "15",
  r: "7",
  key: "19ennj"
}]];
var Blinds = [["path", {
  d: "M3 3h18",
  key: "o7r712"
}], ["path", {
  d: "M20 7H8",
  key: "gd2fo2"
}], ["path", {
  d: "M20 11H8",
  key: "1ynp89"
}], ["path", {
  d: "M10 19h10",
  key: "19hjk5"
}], ["path", {
  d: "M8 15h12",
  key: "1yqzne"
}], ["path", {
  d: "M4 3v14",
  key: "fggqzn"
}], ["circle", {
  cx: "4",
  cy: "19",
  r: "2",
  key: "p3m9r0"
}]];
var Blocks = [["path", {
  d: "M10 22V7a1 1 0 0 0-1-1H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5a1 1 0 0 0-1-1H2",
  key: "1ah6g2"
}], ["rect", {
  x: "14",
  y: "2",
  width: "8",
  height: "8",
  rx: "1",
  key: "88lufb"
}]];
var BluetoothConnected = [["path", {
  d: "m7 7 10 10-5 5V2l5 5L7 17",
  key: "1q5490"
}], ["line", {
  x1: "18",
  x2: "21",
  y1: "12",
  y2: "12",
  key: "1rsjjs"
}], ["line", {
  x1: "3",
  x2: "6",
  y1: "12",
  y2: "12",
  key: "11yl8c"
}]];
var BluetoothOff = [["path", {
  d: "m17 17-5 5V12l-5 5",
  key: "v5aci6"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M14.5 9.5 17 7l-5-5v4.5",
  key: "1kddfz"
}]];
var BluetoothSearching = [["path", {
  d: "m7 7 10 10-5 5V2l5 5L7 17",
  key: "1q5490"
}], ["path", {
  d: "M20.83 14.83a4 4 0 0 0 0-5.66",
  key: "k8tn1j"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}]];
var Bluetooth = [["path", {
  d: "m7 7 10 10-5 5V2l5 5L7 17",
  key: "1q5490"
}]];
var Bold = [["path", {
  d: "M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8",
  key: "mg9rjx"
}]];
var Bolt = [["path", {
  d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
  key: "yt0hxn"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}]];
var Bomb = [["circle", {
  cx: "11",
  cy: "13",
  r: "9",
  key: "hd149"
}], ["path", {
  d: "M14.35 4.65 16.3 2.7a2.41 2.41 0 0 1 3.4 0l1.6 1.6a2.4 2.4 0 0 1 0 3.4l-1.95 1.95",
  key: "jp4j1b"
}], ["path", {
  d: "m22 2-1.5 1.5",
  key: "ay92ug"
}]];
var Bone = [["path", {
  d: "M17 10c.7-.7 1.69 0 2.5 0a2.5 2.5 0 1 0 0-5 .5.5 0 0 1-.5-.5 2.5 2.5 0 1 0-5 0c0 .81.7 1.8 0 2.5l-7 7c-.7.7-1.69 0-2.5 0a2.5 2.5 0 0 0 0 5c.28 0 .5.22.5.5a2.5 2.5 0 1 0 5 0c0-.81-.7-1.8 0-2.5Z",
  key: "w610uw"
}]];
var BookA = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "m8 13 4-7 4 7",
  key: "4rari8"
}], ["path", {
  d: "M9.1 11h5.7",
  key: "1gkovt"
}]];
var BookAlert = [["path", {
  d: "M12 13h.01",
  key: "y0uutt"
}], ["path", {
  d: "M12 6v3",
  key: "1m4b9j"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}]];
var BookAudio = [["path", {
  d: "M12 6v7",
  key: "1f6ttz"
}], ["path", {
  d: "M16 8v3",
  key: "gejaml"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M8 8v3",
  key: "1qzp49"
}]];
var BookCheck = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "m9 9.5 2 2 4-4",
  key: "1dth82"
}]];
var BookCopy = [["path", {
  d: "M5 7a2 2 0 0 0-2 2v11",
  key: "1yhqjt"
}], ["path", {
  d: "M5.803 18H5a2 2 0 0 0 0 4h9.5a.5.5 0 0 0 .5-.5V21",
  key: "edzzo5"
}], ["path", {
  d: "M9 15V4a2 2 0 0 1 2-2h9.5a.5.5 0 0 1 .5.5v14a.5.5 0 0 1-.5.5H11a2 2 0 0 1 0-4h10",
  key: "1nwzrg"
}]];
var BookDashed = [["path", {
  d: "M12 17h1.5",
  key: "1gkc67"
}], ["path", {
  d: "M12 22h1.5",
  key: "1my7sn"
}], ["path", {
  d: "M12 2h1.5",
  key: "19tvb7"
}], ["path", {
  d: "M17.5 22H19a1 1 0 0 0 1-1",
  key: "10akbh"
}], ["path", {
  d: "M17.5 2H19a1 1 0 0 1 1 1v1.5",
  key: "1vrfjs"
}], ["path", {
  d: "M20 14v3h-2.5",
  key: "1naeju"
}], ["path", {
  d: "M20 8.5V10",
  key: "1ctpfu"
}], ["path", {
  d: "M4 10V8.5",
  key: "1o3zg5"
}], ["path", {
  d: "M4 19.5V14",
  key: "ob81pf"
}], ["path", {
  d: "M4 4.5A2.5 2.5 0 0 1 6.5 2H8",
  key: "s8vcyb"
}], ["path", {
  d: "M8 22H6.5a1 1 0 0 1 0-5H8",
  key: "1cu73q"
}]];
var BookDown = [["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "m9 10 3 3 3-3",
  key: "zt5b4y"
}]];
var BookHeart = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M8.62 9.8A2.25 2.25 0 1 1 12 6.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
  key: "9v40y5"
}]];
var BookHeadphones = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M8 12v-2a4 4 0 0 1 8 0v2",
  key: "1vsqkj"
}], ["circle", {
  cx: "15",
  cy: "12",
  r: "1",
  key: "1tmaij"
}], ["circle", {
  cx: "9",
  cy: "12",
  r: "1",
  key: "1vctgf"
}]];
var BookImage = [["path", {
  d: "m20 13.7-2.1-2.1a2 2 0 0 0-2.8 0L9.7 17",
  key: "q6ojf0"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "2",
  key: "2qkj4p"
}]];
var BookKey = [["path", {
  d: "M13 2H6.5A2.5 2.5 0 0 0 4 4.5v15",
  key: "4azifu"
}], ["path", {
  d: "M17 2v6",
  key: "qgmh37"
}], ["path", {
  d: "M17 4h2",
  key: "13vrzo"
}], ["path", {
  d: "M20 15.2V21a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "192hzx"
}], ["circle", {
  cx: "17",
  cy: "10",
  r: "2",
  key: "y0i25j"
}]];
var BookLock = [["path", {
  d: "M18 6V4a2 2 0 1 0-4 0v2",
  key: "1aquzs"
}], ["path", {
  d: "M20 15v6a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "1rkj32"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H10",
  key: "18wgow"
}], ["rect", {
  x: "12",
  y: "6",
  width: "8",
  height: "5",
  rx: "1",
  key: "73l30o"
}]];
var BookMarked = [["path", {
  d: "M10 2v8l3-3 3 3V2",
  key: "sqw3rj"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}]];
var BookMinus = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}]];
var BookOpenCheck = [["path", {
  d: "M12 21V7",
  key: "gj6g52"
}], ["path", {
  d: "m16 12 2 2 4-4",
  key: "mdajum"
}], ["path", {
  d: "M22 6V4a1 1 0 0 0-1-1h-5a4 4 0 0 0-4 4 4 4 0 0 0-4-4H3a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h6a3 3 0 0 1 3 3 3 3 0 0 1 3-3h6a1 1 0 0 0 1-1v-1.3",
  key: "8arnkb"
}]];
var BookOpenText = [["path", {
  d: "M12 7v14",
  key: "1akyts"
}], ["path", {
  d: "M16 12h2",
  key: "7q9ll5"
}], ["path", {
  d: "M16 8h2",
  key: "msurwy"
}], ["path", {
  d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
  key: "ruj8y"
}], ["path", {
  d: "M6 12h2",
  key: "32wvfc"
}], ["path", {
  d: "M6 8h2",
  key: "30oboj"
}]];
var BookOpen = [["path", {
  d: "M12 7v14",
  key: "1akyts"
}], ["path", {
  d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
  key: "ruj8y"
}]];
var BookPlus = [["path", {
  d: "M12 7v6",
  key: "lw1j43"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}]];
var BookSearch = [["path", {
  d: "M11 22H5.5a1 1 0 0 1 0-5h4.501",
  key: "mcbepb"
}], ["path", {
  d: "m21 22-1.879-1.878",
  key: "12q7x1"
}], ["path", {
  d: "M3 19.5v-15A2.5 2.5 0 0 1 5.5 2H18a1 1 0 0 1 1 1v8",
  key: "olfd5n"
}], ["circle", {
  cx: "17",
  cy: "18",
  r: "3",
  key: "82mm0e"
}]];
var BookText = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "M8 11h8",
  key: "vwpz6n"
}], ["path", {
  d: "M8 7h6",
  key: "1f0q6e"
}]];
var BookType = [["path", {
  d: "M10 13h4",
  key: "ytezjc"
}], ["path", {
  d: "M12 6v7",
  key: "1f6ttz"
}], ["path", {
  d: "M16 8V6H8v2",
  key: "x8j6u4"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}]];
var BookUp2 = [["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["path", {
  d: "M18 2h1a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "161d7n"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2",
  key: "1lorq7"
}], ["path", {
  d: "m9 10 3-3 3 3",
  key: "11gsxs"
}], ["path", {
  d: "m9 5 3-3 3 3",
  key: "l8vdw6"
}]];
var BookUp = [["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "m9 10 3-3 3 3",
  key: "11gsxs"
}]];
var BookUser = [["path", {
  d: "M15 13a3 3 0 1 0-6 0",
  key: "10j68g"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["circle", {
  cx: "12",
  cy: "8",
  r: "2",
  key: "1822b1"
}]];
var BookX = [["path", {
  d: "m14.5 7-5 5",
  key: "dy991v"
}], ["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}], ["path", {
  d: "m9.5 7 5 5",
  key: "s45iea"
}]];
var Book = [["path", {
  d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
  key: "k3hazp"
}]];
var BookmarkCheck = [["path", {
  d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
  key: "oz39mx"
}], ["path", {
  d: "m9 10 2 2 4-4",
  key: "1gnqz4"
}]];
var BookmarkMinus = [["path", {
  d: "M15 10H9",
  key: "o6yqo3"
}], ["path", {
  d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
  key: "oz39mx"
}]];
var BookmarkPlus = [["path", {
  d: "M12 7v6",
  key: "lw1j43"
}], ["path", {
  d: "M15 10H9",
  key: "o6yqo3"
}], ["path", {
  d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
  key: "oz39mx"
}]];
var Bookmark = [["path", {
  d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
  key: "oz39mx"
}]];
var BookmarkX = [["path", {
  d: "m14.5 7.5-5 5",
  key: "3lb6iw"
}], ["path", {
  d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
  key: "oz39mx"
}], ["path", {
  d: "m9.5 7.5 5 5",
  key: "ko136h"
}]];
var BoomBox = [["path", {
  d: "M4 9V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4",
  key: "vvzvr1"
}], ["path", {
  d: "M8 8v1",
  key: "xcqmfk"
}], ["path", {
  d: "M12 8v1",
  key: "1rj8u4"
}], ["path", {
  d: "M16 8v1",
  key: "1q12zr"
}], ["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "9",
  rx: "2",
  key: "igpb89"
}], ["circle", {
  cx: "8",
  cy: "15",
  r: "2",
  key: "fa4a8s"
}], ["circle", {
  cx: "16",
  cy: "15",
  r: "2",
  key: "14c3ya"
}]];
var BotMessageSquare = [["path", {
  d: "M12 6V2H8",
  key: "1155em"
}], ["path", {
  d: "M15 11v2",
  key: "i11awn"
}], ["path", {
  d: "M2 12h2",
  key: "1t8f8n"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}], ["path", {
  d: "M20 16a2 2 0 0 1-2 2H8.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 4 20.286V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2z",
  key: "11gyqh"
}], ["path", {
  d: "M9 11v2",
  key: "1ueba0"
}]];
var BotOff = [["path", {
  d: "M13.67 8H18a2 2 0 0 1 2 2v4.33",
  key: "7az073"
}], ["path", {
  d: "M2 14h2",
  key: "vft8re"
}], ["path", {
  d: "M20 14h2",
  key: "4cs60a"
}], ["path", {
  d: "M22 22 2 2",
  key: "1r8tn9"
}], ["path", {
  d: "M8 8H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 1.414-.586",
  key: "s09a7a"
}], ["path", {
  d: "M9 13v2",
  key: "rq6x2g"
}], ["path", {
  d: "M9.67 4H12v2.33",
  key: "110xot"
}]];
var Bot = [["path", {
  d: "M12 8V4H8",
  key: "hb8ula"
}], ["rect", {
  width: "16",
  height: "12",
  x: "4",
  y: "8",
  rx: "2",
  key: "enze0r"
}], ["path", {
  d: "M2 14h2",
  key: "vft8re"
}], ["path", {
  d: "M20 14h2",
  key: "4cs60a"
}], ["path", {
  d: "M15 13v2",
  key: "1xurst"
}], ["path", {
  d: "M9 13v2",
  key: "rq6x2g"
}]];
var BottleWine = [["path", {
  d: "M10 3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a6 6 0 0 0 1.2 3.6l.6.8A6 6 0 0 1 17 13v8a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1v-8a6 6 0 0 1 1.2-3.6l.6-.8A6 6 0 0 0 10 5z",
  key: "blqgoc"
}], ["path", {
  d: "M17 13h-4a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h4",
  key: "43jbee"
}]];
var BowArrow = [["path", {
  d: "M17 3h4v4",
  key: "19p9u1"
}], ["path", {
  d: "M18.575 11.082a13 13 0 0 1 1.048 9.027 1.17 1.17 0 0 1-1.914.597L14 17",
  key: "12t3w9"
}], ["path", {
  d: "M7 10 3.29 6.29a1.17 1.17 0 0 1 .6-1.91 13 13 0 0 1 9.03 1.05",
  key: "ogng5l"
}], ["path", {
  d: "M7 14a1.7 1.7 0 0 0-1.207.5l-2.646 2.646A.5.5 0 0 0 3.5 18H5a1 1 0 0 1 1 1v1.5a.5.5 0 0 0 .854.354L9.5 18.207A1.7 1.7 0 0 0 10 17v-2a1 1 0 0 0-1-1z",
  key: "8v3fy2"
}], ["path", {
  d: "M9.707 14.293 21 3",
  key: "ydm3bn"
}]];
var Boxes = [["path", {
  d: "M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z",
  key: "lc1i9w"
}], ["path", {
  d: "m7 16.5-4.74-2.85",
  key: "1o9zyk"
}], ["path", {
  d: "m7 16.5 5-3",
  key: "va8pkn"
}], ["path", {
  d: "M7 16.5v5.17",
  key: "jnp8gn"
}], ["path", {
  d: "M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z",
  key: "8zsnat"
}], ["path", {
  d: "m17 16.5-5-3",
  key: "8arw3v"
}], ["path", {
  d: "m17 16.5 4.74-2.85",
  key: "8rfmw"
}], ["path", {
  d: "M17 16.5v5.17",
  key: "k6z78m"
}], ["path", {
  d: "M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z",
  key: "1xygjf"
}], ["path", {
  d: "M12 8 7.26 5.15",
  key: "1vbdud"
}], ["path", {
  d: "m12 8 4.74-2.85",
  key: "3rx089"
}], ["path", {
  d: "M12 13.5V8",
  key: "1io7kd"
}]];
var Box = [["path", {
  d: "M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",
  key: "hh9hay"
}], ["path", {
  d: "m3.3 7 8.7 5 8.7-5",
  key: "g66t2b"
}], ["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}]];
var Braces = [["path", {
  d: "M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1",
  key: "ezmyqa"
}], ["path", {
  d: "M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",
  key: "e1hn23"
}]];
var Brackets = [["path", {
  d: "M16 3h3a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-3",
  key: "1kt8lf"
}], ["path", {
  d: "M8 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h3",
  key: "gduv9"
}]];
var BrainCircuit = [["path", {
  d: "M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",
  key: "l5xja"
}], ["path", {
  d: "M9 13a4.5 4.5 0 0 0 3-4",
  key: "10igwf"
}], ["path", {
  d: "M6.003 5.125A3 3 0 0 0 6.401 6.5",
  key: "105sqy"
}], ["path", {
  d: "M3.477 10.896a4 4 0 0 1 .585-.396",
  key: "ql3yin"
}], ["path", {
  d: "M6 18a4 4 0 0 1-1.967-.516",
  key: "2e4loj"
}], ["path", {
  d: "M12 13h4",
  key: "1ku699"
}], ["path", {
  d: "M12 18h6a2 2 0 0 1 2 2v1",
  key: "105ag5"
}], ["path", {
  d: "M12 8h8",
  key: "1lhi5i"
}], ["path", {
  d: "M16 8V5a2 2 0 0 1 2-2",
  key: "u6izg6"
}], ["circle", {
  cx: "16",
  cy: "13",
  r: ".5",
  key: "ry7gng"
}], ["circle", {
  cx: "18",
  cy: "3",
  r: ".5",
  key: "1aiba7"
}], ["circle", {
  cx: "20",
  cy: "21",
  r: ".5",
  key: "yhc1fs"
}], ["circle", {
  cx: "20",
  cy: "8",
  r: ".5",
  key: "1e43v0"
}]];
var BrainCog = [["path", {
  d: "m10.852 14.772-.383.923",
  key: "11vil6"
}], ["path", {
  d: "m10.852 9.228-.383-.923",
  key: "1fjppe"
}], ["path", {
  d: "m13.148 14.772.382.924",
  key: "je3va1"
}], ["path", {
  d: "m13.531 8.305-.383.923",
  key: "18epck"
}], ["path", {
  d: "m14.772 10.852.923-.383",
  key: "k9m8cz"
}], ["path", {
  d: "m14.772 13.148.923.383",
  key: "1xvhww"
}], ["path", {
  d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 0 0-5.63-1.446 3 3 0 0 0-.368 1.571 4 4 0 0 0-2.525 5.771",
  key: "jcbbz1"
}], ["path", {
  d: "M17.998 5.125a4 4 0 0 1 2.525 5.771",
  key: "1kkn7e"
}], ["path", {
  d: "M19.505 10.294a4 4 0 0 1-1.5 7.706",
  key: "18bmuc"
}], ["path", {
  d: "M4.032 17.483A4 4 0 0 0 11.464 20c.18-.311.892-.311 1.072 0a4 4 0 0 0 7.432-2.516",
  key: "uozx0d"
}], ["path", {
  d: "M4.5 10.291A4 4 0 0 0 6 18",
  key: "whdemb"
}], ["path", {
  d: "M6.002 5.125a3 3 0 0 0 .4 1.375",
  key: "1kqy2g"
}], ["path", {
  d: "m9.228 10.852-.923-.383",
  key: "1wtb30"
}], ["path", {
  d: "m9.228 13.148-.923.383",
  key: "1a830x"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}]];
var Brain = [["path", {
  d: "M12 18V5",
  key: "adv99a"
}], ["path", {
  d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4",
  key: "1e3is1"
}], ["path", {
  d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5",
  key: "1gqd8o"
}], ["path", {
  d: "M17.997 5.125a4 4 0 0 1 2.526 5.77",
  key: "iwvgf7"
}], ["path", {
  d: "M18 18a4 4 0 0 0 2-7.464",
  key: "efp6ie"
}], ["path", {
  d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517",
  key: "1gq6am"
}], ["path", {
  d: "M6 18a4 4 0 0 1-2-7.464",
  key: "k1g0md"
}], ["path", {
  d: "M6.003 5.125a4 4 0 0 0-2.526 5.77",
  key: "q97ue3"
}]];
var BrickWallFire = [["path", {
  d: "M16 3v2.107",
  key: "gq8xun"
}], ["path", {
  d: "M17 9c1 3 2.5 3.5 3.5 4.5A5 5 0 0 1 22 17a5 5 0 0 1-10 0c0-.3 0-.6.1-.9a2 2 0 1 0 3.3-2C13 11.5 16 9 17 9",
  key: "1l2pih"
}], ["path", {
  d: "M21 8.274V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.938",
  key: "jrnqjp"
}], ["path", {
  d: "M3 15h5.253",
  key: "xqg7rb"
}], ["path", {
  d: "M3 9h8.228",
  key: "1ppb70"
}], ["path", {
  d: "M8 15v6",
  key: "1stoo3"
}], ["path", {
  d: "M8 3v6",
  key: "vlvjmk"
}]];
var BrickWallShield = [["path", {
  d: "M12 9v1.258",
  key: "iwpddn"
}], ["path", {
  d: "M16 3v5.46",
  key: "d7ew98"
}], ["path", {
  d: "M21 9.118V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5.75",
  key: "137t5x"
}], ["path", {
  d: "M22 17.5c0 2.499-1.75 3.749-3.83 4.474a.5.5 0 0 1-.335-.005c-2.085-.72-3.835-1.97-3.835-4.47V14a.5.5 0 0 1 .5-.499c1 0 2.25-.6 3.12-1.36a.6.6 0 0 1 .76-.001c.875.765 2.12 1.36 3.12 1.36a.5.5 0 0 1 .5.5z",
  key: "16j3tf"
}], ["path", {
  d: "M3 15h7",
  key: "1qldh6"
}], ["path", {
  d: "M3 9h12.142",
  key: "1yjd6m"
}], ["path", {
  d: "M8 15v6",
  key: "1stoo3"
}], ["path", {
  d: "M8 3v6",
  key: "vlvjmk"
}]];
var BrickWall = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M12 9v6",
  key: "199k2o"
}], ["path", {
  d: "M16 15v6",
  key: "8rj2es"
}], ["path", {
  d: "M16 3v6",
  key: "1j6rpj"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "M8 15v6",
  key: "1stoo3"
}], ["path", {
  d: "M8 3v6",
  key: "vlvjmk"
}]];
var BriefcaseBusiness = [["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",
  key: "1ksdt3"
}], ["path", {
  d: "M22 13a18.15 18.15 0 0 1-20 0",
  key: "12hx5q"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "6",
  rx: "2",
  key: "i6l2r4"
}]];
var BriefcaseConveyorBelt = [["path", {
  d: "M10 20v2",
  key: "1n8e1g"
}], ["path", {
  d: "M14 20v2",
  key: "1lq872"
}], ["path", {
  d: "M18 20v2",
  key: "10uadw"
}], ["path", {
  d: "M21 20H3",
  key: "kdqkdp"
}], ["path", {
  d: "M6 20v2",
  key: "a9bc87"
}], ["path", {
  d: "M8 16V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v12",
  key: "17n9tx"
}], ["rect", {
  x: "4",
  y: "6",
  width: "16",
  height: "10",
  rx: "2",
  key: "1097i5"
}]];
var BriefcaseMedical = [["path", {
  d: "M12 11v4",
  key: "a6ujw6"
}], ["path", {
  d: "M14 13h-4",
  key: "1pl8zg"
}], ["path", {
  d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",
  key: "1ksdt3"
}], ["path", {
  d: "M18 6v14",
  key: "1mu4gy"
}], ["path", {
  d: "M6 6v14",
  key: "1s15cj"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "6",
  rx: "2",
  key: "i6l2r4"
}]];
var Briefcase = [["path", {
  d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",
  key: "jecpp"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "6",
  rx: "2",
  key: "i6l2r4"
}]];
var BringToFront = [["rect", {
  x: "8",
  y: "8",
  width: "8",
  height: "8",
  rx: "2",
  key: "yj20xf"
}], ["path", {
  d: "M4 10a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2",
  key: "1ltk23"
}], ["path", {
  d: "M14 20a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2",
  key: "1q24h9"
}]];
var BrushCleaning = [["path", {
  d: "m16 22-1-4",
  key: "1ow2iv"
}], ["path", {
  d: "M19 14a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2h-3a1 1 0 0 1-1-1V4a2 2 0 0 0-4 0v5a1 1 0 0 1-1 1H6a2 2 0 0 0-2 2v1a1 1 0 0 0 1 1",
  key: "11gii7"
}], ["path", {
  d: "M19 14H5l-1.973 6.767A1 1 0 0 0 4 22h16a1 1 0 0 0 .973-1.233z",
  key: "bju7h4"
}], ["path", {
  d: "m8 22 1-4",
  key: "s3unb"
}]];
var Brush = [["path", {
  d: "m11 10 3 3",
  key: "fzmg1i"
}], ["path", {
  d: "M6.5 21A3.5 3.5 0 1 0 3 17.5a2.62 2.62 0 0 1-.708 1.792A1 1 0 0 0 3 21z",
  key: "p4q2r7"
}], ["path", {
  d: "M9.969 17.031 21.378 5.624a1 1 0 0 0-3.002-3.002L6.967 14.031",
  key: "wy6l02"
}]];
var Bubbles = [["path", {
  d: "M7.001 15.085A1.5 1.5 0 0 1 9 16.5",
  key: "y44lvh"
}], ["circle", {
  cx: "18.5",
  cy: "8.5",
  r: "3.5",
  key: "1wadoa"
}], ["circle", {
  cx: "7.5",
  cy: "16.5",
  r: "5.5",
  key: "6mdt3g"
}], ["circle", {
  cx: "7.5",
  cy: "4.5",
  r: "2.5",
  key: "637s54"
}]];
var BugOff = [["path", {
  d: "M12 20v-8",
  key: "i3yub9"
}], ["path", {
  d: "M12.656 7H14a4 4 0 0 1 4 4v1.344",
  key: "vvueyn"
}], ["path", {
  d: "M14.12 3.88 16 2",
  key: "qol33r"
}], ["path", {
  d: "M17.123 17.123A6 6 0 0 1 6 14v-3a4 4 0 0 1 1.72-3.287",
  key: "1cu21y"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M21 5a4 4 0 0 1-3.55 3.97",
  key: "5cxbf6"
}], ["path", {
  d: "M22 13h-3.344",
  key: "qb08am"
}], ["path", {
  d: "M3 21a4 4 0 0 1 3.81-4",
  key: "1fjd4g"
}], ["path", {
  d: "M3 5a4 4 0 0 0 3.55 3.97",
  key: "1d7oge"
}], ["path", {
  d: "M6 13H2",
  key: "82j7cp"
}], ["path", {
  d: "m8 2 1.88 1.88",
  key: "fmnt4t"
}], ["path", {
  d: "M9.712 4.06A3 3 0 0 1 15 6v1.13",
  key: "1bvup6"
}]];
var BugPlay = [["path", {
  d: "M10 19.655A6 6 0 0 1 6 14v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 3.97",
  key: "1gnv52"
}], ["path", {
  d: "M14 15.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
  key: "1weqy9"
}], ["path", {
  d: "M14.12 3.88 16 2",
  key: "qol33r"
}], ["path", {
  d: "M21 5a4 4 0 0 1-3.55 3.97",
  key: "5cxbf6"
}], ["path", {
  d: "M3 21a4 4 0 0 1 3.81-4",
  key: "1fjd4g"
}], ["path", {
  d: "M3 5a4 4 0 0 0 3.55 3.97",
  key: "1d7oge"
}], ["path", {
  d: "M6 13H2",
  key: "82j7cp"
}], ["path", {
  d: "m8 2 1.88 1.88",
  key: "fmnt4t"
}], ["path", {
  d: "M9 7.13V6a3 3 0 1 1 6 0v1.13",
  key: "1vgav8"
}]];
var Bug = [["path", {
  d: "M12 20v-9",
  key: "1qisl0"
}], ["path", {
  d: "M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z",
  key: "uouzyp"
}], ["path", {
  d: "M14.12 3.88 16 2",
  key: "qol33r"
}], ["path", {
  d: "M21 21a4 4 0 0 0-3.81-4",
  key: "1b0z45"
}], ["path", {
  d: "M21 5a4 4 0 0 1-3.55 3.97",
  key: "5cxbf6"
}], ["path", {
  d: "M22 13h-4",
  key: "1jl80f"
}], ["path", {
  d: "M3 21a4 4 0 0 1 3.81-4",
  key: "1fjd4g"
}], ["path", {
  d: "M3 5a4 4 0 0 0 3.55 3.97",
  key: "1d7oge"
}], ["path", {
  d: "M6 13H2",
  key: "82j7cp"
}], ["path", {
  d: "m8 2 1.88 1.88",
  key: "fmnt4t"
}], ["path", {
  d: "M9 7.13V6a3 3 0 1 1 6 0v1.13",
  key: "1vgav8"
}]];
var Building = [["path", {
  d: "M12 10h.01",
  key: "1nrarc"
}], ["path", {
  d: "M12 14h.01",
  key: "1etili"
}], ["path", {
  d: "M12 6h.01",
  key: "1vi96p"
}], ["path", {
  d: "M16 10h.01",
  key: "1m94wz"
}], ["path", {
  d: "M16 14h.01",
  key: "1gbofw"
}], ["path", {
  d: "M16 6h.01",
  key: "1x0f13"
}], ["path", {
  d: "M8 10h.01",
  key: "19clt8"
}], ["path", {
  d: "M8 14h.01",
  key: "6423bh"
}], ["path", {
  d: "M8 6h.01",
  key: "1dz90k"
}], ["path", {
  d: "M9 22v-3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3",
  key: "cabbwy"
}], ["rect", {
  x: "4",
  y: "2",
  width: "16",
  height: "20",
  rx: "2",
  key: "1uxh74"
}]];
var Building2 = [["path", {
  d: "M10 12h4",
  key: "a56b0p"
}], ["path", {
  d: "M10 8h4",
  key: "1sr2af"
}], ["path", {
  d: "M14 21v-3a2 2 0 0 0-4 0v3",
  key: "1rgiei"
}], ["path", {
  d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
  key: "secmi2"
}], ["path", {
  d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",
  key: "16ra0t"
}]];
var BusFront = [["path", {
  d: "M4 6 2 7",
  key: "1mqr15"
}], ["path", {
  d: "M10 6h4",
  key: "1itunk"
}], ["path", {
  d: "m22 7-2-1",
  key: "1umjhc"
}], ["rect", {
  width: "16",
  height: "16",
  x: "4",
  y: "3",
  rx: "2",
  key: "1wxw4b"
}], ["path", {
  d: "M4 11h16",
  key: "mpoxn0"
}], ["path", {
  d: "M8 15h.01",
  key: "a7atzg"
}], ["path", {
  d: "M16 15h.01",
  key: "rnfrdf"
}], ["path", {
  d: "M6 19v2",
  key: "1loha6"
}], ["path", {
  d: "M18 21v-2",
  key: "sqyl04"
}]];
var Bus = [["path", {
  d: "M8 6v6",
  key: "18i7km"
}], ["path", {
  d: "M15 6v6",
  key: "1sg6z9"
}], ["path", {
  d: "M2 12h19.6",
  key: "de5uta"
}], ["path", {
  d: "M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3",
  key: "1wwztk"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "2",
  key: "19iecd"
}], ["path", {
  d: "M9 18h5",
  key: "lrx6i"
}], ["circle", {
  cx: "16",
  cy: "18",
  r: "2",
  key: "1v4tcr"
}]];
var CableCar = [["path", {
  d: "M10 3h.01",
  key: "lbucoy"
}], ["path", {
  d: "M14 2h.01",
  key: "1k8aa1"
}], ["path", {
  d: "m2 9 20-5",
  key: "1kz0j5"
}], ["path", {
  d: "M12 12V6.5",
  key: "1vbrij"
}], ["rect", {
  width: "16",
  height: "10",
  x: "4",
  y: "12",
  rx: "3",
  key: "if91er"
}], ["path", {
  d: "M9 12v5",
  key: "3anwtq"
}], ["path", {
  d: "M15 12v5",
  key: "5xh3zn"
}], ["path", {
  d: "M4 17h16",
  key: "g4d7ey"
}]];
var Cable = [["path", {
  d: "M17 19a1 1 0 0 1-1-1v-2a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2a1 1 0 0 1-1 1z",
  key: "trhst0"
}], ["path", {
  d: "M17 21v-2",
  key: "ds4u3f"
}], ["path", {
  d: "M19 14V6.5a1 1 0 0 0-7 0v11a1 1 0 0 1-7 0V10",
  key: "1mo9zo"
}], ["path", {
  d: "M21 21v-2",
  key: "eo0ou"
}], ["path", {
  d: "M3 5V3",
  key: "1k5hjh"
}], ["path", {
  d: "M4 10a2 2 0 0 1-2-2V6a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2z",
  key: "1dd30t"
}], ["path", {
  d: "M7 5V3",
  key: "1t1388"
}]];
var CakeSlice = [["path", {
  d: "M16 13H3",
  key: "1wpj08"
}], ["path", {
  d: "M16 17H3",
  key: "3lvfcd"
}], ["path", {
  d: "m7.2 7.9-3.388 2.5A2 2 0 0 0 3 12.01V20a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-8.654c0-2-2.44-6.026-6.44-8.026a1 1 0 0 0-1.082.057L10.4 5.6",
  key: "1gmhf7"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "2",
  key: "1305pl"
}]];
var Cake = [["path", {
  d: "M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8",
  key: "1w3rig"
}], ["path", {
  d: "M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1",
  key: "n2jgmb"
}], ["path", {
  d: "M2 21h20",
  key: "1nyx9w"
}], ["path", {
  d: "M7 8v3",
  key: "1qtyvj"
}], ["path", {
  d: "M12 8v3",
  key: "hwp4zt"
}], ["path", {
  d: "M17 8v3",
  key: "1i6e5u"
}], ["path", {
  d: "M7 4h.01",
  key: "1bh4kh"
}], ["path", {
  d: "M12 4h.01",
  key: "1ujb9j"
}], ["path", {
  d: "M17 4h.01",
  key: "1upcoc"
}]];
var Calculator = [["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "1nb95v"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "6",
  y2: "6",
  key: "x4nwl0"
}], ["line", {
  x1: "16",
  x2: "16",
  y1: "14",
  y2: "18",
  key: "wjye3r"
}], ["path", {
  d: "M16 10h.01",
  key: "1m94wz"
}], ["path", {
  d: "M12 10h.01",
  key: "1nrarc"
}], ["path", {
  d: "M8 10h.01",
  key: "19clt8"
}], ["path", {
  d: "M12 14h.01",
  key: "1etili"
}], ["path", {
  d: "M8 14h.01",
  key: "6423bh"
}], ["path", {
  d: "M12 18h.01",
  key: "mhygvu"
}], ["path", {
  d: "M8 18h.01",
  key: "lrp35t"
}]];
var Calendar1 = [["path", {
  d: "M11 14h1v4",
  key: "fy54vd"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2",
  key: "12vinp"
}]];
var CalendarArrowDown = [["path", {
  d: "m14 18 4 4 4-4",
  key: "1waygx"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M18 14v8",
  key: "irew45"
}], ["path", {
  d: "M21 11.354V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7.343",
  key: "bse4f3"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarArrowUp = [["path", {
  d: "m14 18 4-4 4 4",
  key: "ftkppy"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M18 22v-8",
  key: "su0gjh"
}], ["path", {
  d: "M21 11.343V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h9",
  key: "1exg90"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarCheck = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "m9 16 2 2 4-4",
  key: "19s6y9"
}]];
var CalendarCheck2 = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M21 14V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8",
  key: "bce9hv"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "m16 20 2 2 4-4",
  key: "13tcca"
}]];
var CalendarClock = [["path", {
  d: "M16 14v2.2l1.6 1",
  key: "fo4ql5"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5",
  key: "1osxxc"
}], ["path", {
  d: "M3 10h5",
  key: "r794hk"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["circle", {
  cx: "16",
  cy: "16",
  r: "6",
  key: "qoo3c4"
}]];
var CalendarCog = [["path", {
  d: "m15.228 16.852-.923-.383",
  key: "npixar"
}], ["path", {
  d: "m15.228 19.148-.923.383",
  key: "51cr3n"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "m16.47 14.305.382.923",
  key: "obybxd"
}], ["path", {
  d: "m16.852 20.772-.383.924",
  key: "dpfhf9"
}], ["path", {
  d: "m19.148 15.228.383-.923",
  key: "1reyyz"
}], ["path", {
  d: "m19.53 21.696-.382-.924",
  key: "1goivc"
}], ["path", {
  d: "m20.772 16.852.924-.383",
  key: "htqkph"
}], ["path", {
  d: "m20.772 19.148.924.383",
  key: "9w9pjp"
}], ["path", {
  d: "M21 10.592V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6",
  key: "1pvbig"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var CalendarDays = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 14h.01",
  key: "6423bh"
}], ["path", {
  d: "M12 14h.01",
  key: "1etili"
}], ["path", {
  d: "M16 14h.01",
  key: "1gbofw"
}], ["path", {
  d: "M8 18h.01",
  key: "lrp35t"
}], ["path", {
  d: "M12 18h.01",
  key: "mhygvu"
}], ["path", {
  d: "M16 18h.01",
  key: "kzsmim"
}]];
var CalendarFold = [["path", {
  d: "M3 20a2 2 0 0 0 2 2h10a2.4 2.4 0 0 0 1.706-.706l3.588-3.588A2.4 2.4 0 0 0 21 16V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",
  key: "r586nh"
}], ["path", {
  d: "M15 22v-5a1 1 0 0 1 1-1h5",
  key: "xl3app"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}]];
var CalendarHeart = [["path", {
  d: "M12.127 22H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5.125",
  key: "vxdnp4"
}], ["path", {
  d: "M14.62 18.8A2.25 2.25 0 1 1 18 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
  key: "15cy7q"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarMinus2 = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M10 16h4",
  key: "17e571"
}]];
var CalendarMinus = [["path", {
  d: "M16 19h6",
  key: "xwg31i"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M21 15V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8.5",
  key: "1scpom"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarOff = [["path", {
  d: "M4.2 4.2A2 2 0 0 0 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 1.82-1.18",
  key: "16swn3"
}], ["path", {
  d: "M21 15.5V6a2 2 0 0 0-2-2H9.5",
  key: "yhw86o"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M3 10h7",
  key: "1wap6i"
}], ["path", {
  d: "M21 10h-5.5",
  key: "quycpq"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var CalendarPlus2 = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M10 16h4",
  key: "17e571"
}], ["path", {
  d: "M12 14v4",
  key: "1thi36"
}]];
var CalendarRange = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M17 14h-6",
  key: "bkmgh3"
}], ["path", {
  d: "M13 18H7",
  key: "bb0bb7"
}], ["path", {
  d: "M7 14h.01",
  key: "1qa3f1"
}], ["path", {
  d: "M17 18h.01",
  key: "1bdyru"
}]];
var CalendarPlus = [["path", {
  d: "M16 19h6",
  key: "xwg31i"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M19 16v6",
  key: "tddt3s"
}], ["path", {
  d: "M21 12.598V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8.5",
  key: "1glfrc"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarSearch = [["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M21 11.75V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7.25",
  key: "1jrsq6"
}], ["path", {
  d: "m22 22-1.875-1.875",
  key: "13zax7"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var CalendarSync = [["path", {
  d: "M11 10v4h4",
  key: "172dkj"
}], ["path", {
  d: "m11 14 1.535-1.605a5 5 0 0 1 8 1.5",
  key: "vu0qm5"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "m21 18-1.535 1.605a5 5 0 0 1-8-1.5",
  key: "1qgeyt"
}], ["path", {
  d: "M21 22v-4h-4",
  key: "hrummi"
}], ["path", {
  d: "M21 8.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4.3",
  key: "mctw84"
}], ["path", {
  d: "M3 10h4",
  key: "1el30a"
}], ["path", {
  d: "M8 2v4",
  key: "1cmpym"
}]];
var CalendarX = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "m14 14-4 4",
  key: "rymu2i"
}], ["path", {
  d: "m10 14 4 4",
  key: "3sz06r"
}]];
var CalendarX2 = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M21 13V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8",
  key: "3spt84"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}], ["path", {
  d: "m17 22 5-5",
  key: "1k6ppv"
}], ["path", {
  d: "m17 17 5 5",
  key: "p7ous7"
}]];
var Calendar = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "4",
  rx: "2",
  key: "1hopcy"
}], ["path", {
  d: "M3 10h18",
  key: "8toen8"
}]];
var Calendars = [["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M15.726 21.01A2 2 0 0 1 14 22H4a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2",
  key: "j6srht"
}], ["path", {
  d: "M18 2v2",
  key: "1kh14s"
}], ["path", {
  d: "M2 13h2",
  key: "13gyu8"
}], ["path", {
  d: "M8 8h14",
  key: "12jxz2"
}], ["rect", {
  x: "8",
  y: "3",
  width: "14",
  height: "14",
  rx: "2",
  key: "nsru6w"
}]];
var CameraOff = [["path", {
  d: "M14.564 14.558a3 3 0 1 1-4.122-4.121",
  key: "1rnrzw"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20 20H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 .819-.175",
  key: "1x3arw"
}], ["path", {
  d: "M9.695 4.024A2 2 0 0 1 10.004 4h3.993a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v7.344",
  key: "1i84u0"
}]];
var Camera = [["path", {
  d: "M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",
  key: "18u6gg"
}], ["circle", {
  cx: "12",
  cy: "13",
  r: "3",
  key: "1vg3eu"
}]];
var CandyCane = [["path", {
  d: "M5.7 21a2 2 0 0 1-3.5-2l8.6-14a6 6 0 0 1 10.4 6 2 2 0 1 1-3.464-2 2 2 0 1 0-3.464-2Z",
  key: "isaq8g"
}], ["path", {
  d: "M17.75 7 15 2.1",
  key: "12x7e8"
}], ["path", {
  d: "M10.9 4.8 13 9",
  key: "100a87"
}], ["path", {
  d: "m7.9 9.7 2 4.4",
  key: "ntfhaj"
}], ["path", {
  d: "M4.9 14.7 7 18.9",
  key: "1x43jy"
}]];
var CandyOff = [["path", {
  d: "M10 10v7.9",
  key: "m8g9tt"
}], ["path", {
  d: "M11.802 6.145a5 5 0 0 1 6.053 6.053",
  key: "dn87i3"
}], ["path", {
  d: "M14 6.1v2.243",
  key: "1kzysn"
}], ["path", {
  d: "m15.5 15.571-.964.964a5 5 0 0 1-7.071 0 5 5 0 0 1 0-7.07l.964-.965",
  key: "3sxy18"
}], ["path", {
  d: "M16 7V3a1 1 0 0 1 1.707-.707 2.5 2.5 0 0 0 2.152.717 1 1 0 0 1 1.131 1.131 2.5 2.5 0 0 0 .717 2.152A1 1 0 0 1 21 8h-4",
  key: "gpb6xx"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8 17v4a1 1 0 0 1-1.707.707 2.5 2.5 0 0 0-2.152-.717 1 1 0 0 1-1.131-1.131 2.5 2.5 0 0 0-.717-2.152A1 1 0 0 1 3 16h4",
  key: "qexcha"
}]];
var Candy = [["path", {
  d: "M10 7v10.9",
  key: "1gynux"
}], ["path", {
  d: "M14 6.1V17",
  key: "116kdf"
}], ["path", {
  d: "M16 7V3a1 1 0 0 1 1.707-.707 2.5 2.5 0 0 0 2.152.717 1 1 0 0 1 1.131 1.131 2.5 2.5 0 0 0 .717 2.152A1 1 0 0 1 21 8h-4",
  key: "gpb6xx"
}], ["path", {
  d: "M16.536 7.465a5 5 0 0 0-7.072 0l-2 2a5 5 0 0 0 0 7.07 5 5 0 0 0 7.072 0l2-2a5 5 0 0 0 0-7.07",
  key: "1tsln4"
}], ["path", {
  d: "M8 17v4a1 1 0 0 1-1.707.707 2.5 2.5 0 0 0-2.152-.717 1 1 0 0 1-1.131-1.131 2.5 2.5 0 0 0-.717-2.152A1 1 0 0 1 3 16h4",
  key: "qexcha"
}]];
var CannabisOff = [["path", {
  d: "M12 22v-4c1.5 1.5 3.5 3 6 3 0-1.5-.5-3.5-2-5",
  key: "1bqfb7"
}], ["path", {
  d: "M13.988 8.327C13.902 6.054 13.365 3.82 12 2a9.3 9.3 0 0 0-1.445 2.9",
  key: "1p520n"
}], ["path", {
  d: "M17.375 11.725C18.882 10.53 21 7.841 21 6c-2.324 0-5.08 1.296-6.662 2.684",
  key: "q2itvb"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M21.024 15.378A15 15 0 0 0 22 15c-.426-1.279-2.67-2.557-4.25-2.907",
  key: "j9amvs"
}], ["path", {
  d: "M6.995 6.992C5.714 6.4 4.29 6 3 6c0 2 2.5 5 4 6-1.5 0-4.5 1.5-5 3 3.5 1.5 6 1 6 1-1.5 1.5-2 3.5-2 5 2.5 0 4.5-1.5 6-3",
  key: "8gmd5g"
}]];
var Cannabis = [["path", {
  d: "M12 22v-4",
  key: "1utk9m"
}], ["path", {
  d: "M7 12c-1.5 0-4.5 1.5-5 3 3.5 1.5 6 1 6 1-1.5 1.5-2 3.5-2 5 2.5 0 4.5-1.5 6-3 1.5 1.5 3.5 3 6 3 0-1.5-.5-3.5-2-5 0 0 2.5.5 6-1-.5-1.5-3.5-3-5-3 1.5-1 4-4 4-6-2.5 0-5.5 1.5-7 3 0-2.5-.5-5-2-7-1.5 2-2 4.5-2 7-1.5-1.5-4.5-3-7-3 0 2 2.5 5 4 6",
  key: "1mezod"
}]];
var CaptionsOff = [["path", {
  d: "M10.5 5H19a2 2 0 0 1 2 2v8.5",
  key: "jqtk4d"
}], ["path", {
  d: "M17 11h-.5",
  key: "1961ue"
}], ["path", {
  d: "M19 19H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2",
  key: "1keqsi"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M7 11h4",
  key: "1o1z6v"
}], ["path", {
  d: "M7 15h2.5",
  key: "1ina1g"
}]];
var Captions = [["rect", {
  width: "18",
  height: "14",
  x: "3",
  y: "5",
  rx: "2",
  ry: "2",
  key: "12ruh7"
}], ["path", {
  d: "M7 15h4M15 15h2M7 11h2M13 11h4",
  key: "1ueiar"
}]];
var CarFront = [["path", {
  d: "m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8",
  key: "1imjwt"
}], ["path", {
  d: "M7 14h.01",
  key: "1qa3f1"
}], ["path", {
  d: "M17 14h.01",
  key: "7oqj8z"
}], ["rect", {
  width: "18",
  height: "8",
  x: "3",
  y: "10",
  rx: "2",
  key: "a7itu8"
}], ["path", {
  d: "M5 18v2",
  key: "ppbyun"
}], ["path", {
  d: "M19 18v2",
  key: "gy7782"
}]];
var CarTaxiFront = [["path", {
  d: "M10 2h4",
  key: "n1abiw"
}], ["path", {
  d: "m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8",
  key: "1imjwt"
}], ["path", {
  d: "M7 14h.01",
  key: "1qa3f1"
}], ["path", {
  d: "M17 14h.01",
  key: "7oqj8z"
}], ["rect", {
  width: "18",
  height: "8",
  x: "3",
  y: "10",
  rx: "2",
  key: "a7itu8"
}], ["path", {
  d: "M5 18v2",
  key: "ppbyun"
}], ["path", {
  d: "M19 18v2",
  key: "gy7782"
}]];
var Caravan = [["path", {
  d: "M18 19V9a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v8a2 2 0 0 0 2 2h2",
  key: "19jm3t"
}], ["path", {
  d: "M2 9h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2",
  key: "13hakp"
}], ["path", {
  d: "M22 17v1a1 1 0 0 1-1 1H10v-9a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v9",
  key: "1crci8"
}], ["circle", {
  cx: "8",
  cy: "19",
  r: "2",
  key: "t8fc5s"
}]];
var Car = [["path", {
  d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",
  key: "5owen"
}], ["circle", {
  cx: "7",
  cy: "17",
  r: "2",
  key: "u2ysq9"
}], ["path", {
  d: "M9 17h6",
  key: "r8uit2"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "2",
  key: "axvx0g"
}]];
var CardSim = [["path", {
  d: "M12 14v4",
  key: "1thi36"
}], ["path", {
  d: "M14.172 2a2 2 0 0 1 1.414.586l3.828 3.828A2 2 0 0 1 20 7.828V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z",
  key: "1o66bk"
}], ["path", {
  d: "M8 14h8",
  key: "1fgep2"
}], ["rect", {
  x: "8",
  y: "10",
  width: "8",
  height: "8",
  rx: "1",
  key: "1aonk6"
}]];
var Carrot = [["path", {
  d: "M2.27 21.7s9.87-3.5 12.73-6.36a4.5 4.5 0 0 0-6.36-6.37C5.77 11.84 2.27 21.7 2.27 21.7zM8.64 14l-2.05-2.04M15.34 15l-2.46-2.46",
  key: "rfqxbe"
}], ["path", {
  d: "M22 9s-1.33-2-3.5-2C16.86 7 15 9 15 9s1.33 2 3.5 2S22 9 22 9z",
  key: "6b25w4"
}], ["path", {
  d: "M15 2s-2 1.33-2 3.5S15 9 15 9s2-1.84 2-3.5C17 3.33 15 2 15 2z",
  key: "fn65lo"
}]];
var CaseLower = [["path", {
  d: "M10 9v7",
  key: "ylp826"
}], ["path", {
  d: "M14 6v10",
  key: "1jy4vg"
}], ["circle", {
  cx: "17.5",
  cy: "12.5",
  r: "3.5",
  key: "1a9481"
}], ["circle", {
  cx: "6.5",
  cy: "12.5",
  r: "3.5",
  key: "2jlv1r"
}]];
var CaseSensitive = [["path", {
  d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16",
  key: "d5nyq2"
}], ["path", {
  d: "M22 9v7",
  key: "pvm9v3"
}], ["path", {
  d: "M3.304 13h6.392",
  key: "1q3zxz"
}], ["circle", {
  cx: "18.5",
  cy: "12.5",
  r: "3.5",
  key: "z97x68"
}]];
var CaseUpper = [["path", {
  d: "M15 11h4.5a1 1 0 0 1 0 5h-4a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h3a1 1 0 0 1 0 5",
  key: "nxs35"
}], ["path", {
  d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16",
  key: "d5nyq2"
}], ["path", {
  d: "M3.304 13h6.392",
  key: "1q3zxz"
}]];
var CassetteTape = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["circle", {
  cx: "8",
  cy: "10",
  r: "2",
  key: "1xl4ub"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["circle", {
  cx: "16",
  cy: "10",
  r: "2",
  key: "r14t7q"
}], ["path", {
  d: "m6 20 .7-2.9A1.4 1.4 0 0 1 8.1 16h7.8a1.4 1.4 0 0 1 1.4 1l.7 3",
  key: "l01ucn"
}]];
var Cast = [["path", {
  d: "M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6",
  key: "3zrzxg"
}], ["path", {
  d: "M2 12a9 9 0 0 1 8 8",
  key: "g6cvee"
}], ["path", {
  d: "M2 16a5 5 0 0 1 4 4",
  key: "1y1dii"
}], ["line", {
  x1: "2",
  x2: "2.01",
  y1: "20",
  y2: "20",
  key: "xu2jvo"
}]];
var Castle = [["path", {
  d: "M10 5V3",
  key: "1y54qe"
}], ["path", {
  d: "M14 5V3",
  key: "m6isi"
}], ["path", {
  d: "M15 21v-3a3 3 0 0 0-6 0v3",
  key: "lbp5hj"
}], ["path", {
  d: "M18 3v8",
  key: "2ollhf"
}], ["path", {
  d: "M18 5H6",
  key: "98imr9"
}], ["path", {
  d: "M22 11H2",
  key: "1lmjae"
}], ["path", {
  d: "M22 9v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9",
  key: "1rly83"
}], ["path", {
  d: "M6 3v8",
  key: "csox7g"
}]];
var Cat = [["path", {
  d: "M12 5c.67 0 1.35.09 2 .26 1.78-2 5.03-2.84 6.42-2.26 1.4.58-.42 7-.42 7 .57 1.07 1 2.24 1 3.44C21 17.9 16.97 21 12 21s-9-3-9-7.56c0-1.25.5-2.4 1-3.44 0 0-1.89-6.42-.5-7 1.39-.58 4.72.23 6.5 2.23A9.04 9.04 0 0 1 12 5Z",
  key: "x6xyqk"
}], ["path", {
  d: "M8 14v.5",
  key: "1nzgdb"
}], ["path", {
  d: "M16 14v.5",
  key: "1lajdz"
}], ["path", {
  d: "M11.25 16.25h1.5L12 17l-.75-.75Z",
  key: "12kq1m"
}]];
var CctvOff = [["path", {
  d: "m12.309 6.652 4.797 2.401a1 1 0 0 1 .447 1.341l-.501 1.001.605.605h2.725a1 1 0 0 1 .894 1.447l-.724 1.448",
  key: "e75roo"
}], ["path", {
  d: "m15.166 15.166-.719 1.439a1 1 0 0 1-1.342.447L3.61 12.3a2.92 2.92 0 0 1-1.3-3.91L3.69 5.6a2.9 2.9 0 0 1 .873-1.037",
  key: "1h9o5r"
}], ["path", {
  d: "M2 19h3.76a2 2 0 0 0 1.8-1.1l1.441-2.902",
  key: "1askrb"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M2 21v-4",
  key: "l40lih"
}], ["path", {
  d: "M7 9h.01",
  key: "19b3jx"
}]];
var Cctv = [["path", {
  d: "M16.75 12h3.632a1 1 0 0 1 .894 1.447l-2.034 4.069a1 1 0 0 1-1.708.134l-2.124-2.97",
  key: "ir91b5"
}], ["path", {
  d: "M17.106 9.053a1 1 0 0 1 .447 1.341l-3.106 6.211a1 1 0 0 1-1.342.447L3.61 12.3a2.92 2.92 0 0 1-1.3-3.91L3.69 5.6a2.92 2.92 0 0 1 3.92-1.3z",
  key: "jlp8i1"
}], ["path", {
  d: "M2 19h3.76a2 2 0 0 0 1.8-1.1L9 15",
  key: "19bib8"
}], ["path", {
  d: "M2 21v-4",
  key: "l40lih"
}], ["path", {
  d: "M7 9h.01",
  key: "19b3jx"
}]];
var ChartBarBig = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["rect", {
  x: "7",
  y: "13",
  width: "9",
  height: "4",
  rx: "1",
  key: "1iip1u"
}], ["rect", {
  x: "7",
  y: "5",
  width: "12",
  height: "4",
  rx: "1",
  key: "1anskk"
}]];
var ChartBarDecreasing = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M7 11h8",
  key: "1feolt"
}], ["path", {
  d: "M7 16h3",
  key: "ur6vzw"
}], ["path", {
  d: "M7 6h12",
  key: "sz5b0d"
}]];
var ChartArea = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M7 11.207a.5.5 0 0 1 .146-.353l2-2a.5.5 0 0 1 .708 0l3.292 3.292a.5.5 0 0 0 .708 0l4.292-4.292a.5.5 0 0 1 .854.353V16a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z",
  key: "q0gr47"
}]];
var ChartBarIncreasing = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M7 11h8",
  key: "1feolt"
}], ["path", {
  d: "M7 16h12",
  key: "wsnu98"
}], ["path", {
  d: "M7 6h3",
  key: "w9rmul"
}]];
var ChartBarStacked = [["path", {
  d: "M11 13v4",
  key: "vyy2rb"
}], ["path", {
  d: "M15 5v4",
  key: "1gx88a"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["rect", {
  x: "7",
  y: "13",
  width: "9",
  height: "4",
  rx: "1",
  key: "1iip1u"
}], ["rect", {
  x: "7",
  y: "5",
  width: "12",
  height: "4",
  rx: "1",
  key: "1anskk"
}]];
var ChartBar = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M7 16h8",
  key: "srdodz"
}], ["path", {
  d: "M7 11h12",
  key: "127s9w"
}], ["path", {
  d: "M7 6h3",
  key: "w9rmul"
}]];
var ChartCandlestick = [["path", {
  d: "M9 5v4",
  key: "14uxtq"
}], ["rect", {
  width: "4",
  height: "6",
  x: "7",
  y: "9",
  rx: "1",
  key: "f4fvz0"
}], ["path", {
  d: "M9 15v2",
  key: "r5rk32"
}], ["path", {
  d: "M17 3v2",
  key: "1l2re6"
}], ["rect", {
  width: "4",
  height: "8",
  x: "15",
  y: "5",
  rx: "1",
  key: "z38je5"
}], ["path", {
  d: "M17 13v3",
  key: "5l0wba"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}]];
var ChartColumnBig = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["rect", {
  x: "15",
  y: "5",
  width: "4",
  height: "12",
  rx: "1",
  key: "q8uenq"
}], ["rect", {
  x: "7",
  y: "8",
  width: "4",
  height: "9",
  rx: "1",
  key: "sr5ea"
}]];
var ChartColumnDecreasing = [["path", {
  d: "M13 17V9",
  key: "1fwyjl"
}], ["path", {
  d: "M18 17v-3",
  key: "1sqioe"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M8 17V5",
  key: "1wzmnc"
}]];
var ChartColumnIncreasing = [["path", {
  d: "M13 17V9",
  key: "1fwyjl"
}], ["path", {
  d: "M18 17V5",
  key: "sfb6ij"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M8 17v-3",
  key: "17ska0"
}]];
var ChartColumnStacked = [["path", {
  d: "M11 13H7",
  key: "t0o9gq"
}], ["path", {
  d: "M19 9h-4",
  key: "rera1j"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["rect", {
  x: "15",
  y: "5",
  width: "4",
  height: "12",
  rx: "1",
  key: "q8uenq"
}], ["rect", {
  x: "7",
  y: "8",
  width: "4",
  height: "9",
  rx: "1",
  key: "sr5ea"
}]];
var ChartColumn = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M18 17V9",
  key: "2bz60n"
}], ["path", {
  d: "M13 17V5",
  key: "1frdt8"
}], ["path", {
  d: "M8 17v-3",
  key: "17ska0"
}]];
var ChartGantt = [["path", {
  d: "M10 6h8",
  key: "zvc2xc"
}], ["path", {
  d: "M12 16h6",
  key: "yi5mkt"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M8 11h7",
  key: "wz2hg0"
}]];
var ChartLine = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "m19 9-5 5-4-4-3 3",
  key: "2osh9i"
}]];
var ChartNetwork = [["path", {
  d: "m13.11 7.664 1.78 2.672",
  key: "go2gg9"
}], ["path", {
  d: "m14.162 12.788-3.324 1.424",
  key: "11x848"
}], ["path", {
  d: "m20 4-6.06 1.515",
  key: "1wxxh7"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["circle", {
  cx: "12",
  cy: "6",
  r: "2",
  key: "1jj5th"
}], ["circle", {
  cx: "16",
  cy: "12",
  r: "2",
  key: "4ma0v8"
}], ["circle", {
  cx: "9",
  cy: "15",
  r: "2",
  key: "lf2ghp"
}]];
var ChartNoAxesColumnDecreasing = [["path", {
  d: "M5 21V3",
  key: "clc1r8"
}], ["path", {
  d: "M12 21V9",
  key: "uvy0l4"
}], ["path", {
  d: "M19 21v-6",
  key: "tkawy9"
}]];
var ChartNoAxesColumnIncreasing = [["path", {
  d: "M5 21v-6",
  key: "1hz6c0"
}], ["path", {
  d: "M12 21V9",
  key: "uvy0l4"
}], ["path", {
  d: "M19 21V3",
  key: "11j9sm"
}]];
var ChartNoAxesColumn = [["path", {
  d: "M5 21v-6",
  key: "1hz6c0"
}], ["path", {
  d: "M12 21V3",
  key: "1lcnhd"
}], ["path", {
  d: "M19 21V9",
  key: "unv183"
}]];
var ChartNoAxesCombined = [["path", {
  d: "M12 16v5",
  key: "zza2cw"
}], ["path", {
  d: "M16 14v7",
  key: "1g90b9"
}], ["path", {
  d: "M20 10v11",
  key: "1iqoj0"
}], ["path", {
  d: "m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15",
  key: "1fw8x9"
}], ["path", {
  d: "M4 18v3",
  key: "1yp0dc"
}], ["path", {
  d: "M8 14v7",
  key: "n3cwzv"
}]];
var ChartPie = [["path", {
  d: "M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",
  key: "pzmjnu"
}], ["path", {
  d: "M21.21 15.89A10 10 0 1 1 8 2.83",
  key: "k2fpak"
}]];
var ChartNoAxesGantt = [["path", {
  d: "M6 5h12",
  key: "fvfigv"
}], ["path", {
  d: "M4 12h10",
  key: "oujl3d"
}], ["path", {
  d: "M12 19h8",
  key: "baeox8"
}]];
var ChartScatter = [["circle", {
  cx: "7.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "kqv944"
}], ["circle", {
  cx: "18.5",
  cy: "5.5",
  r: ".5",
  fill: "currentColor",
  key: "lysivs"
}], ["circle", {
  cx: "11.5",
  cy: "11.5",
  r: ".5",
  fill: "currentColor",
  key: "byv1b8"
}], ["circle", {
  cx: "7.5",
  cy: "16.5",
  r: ".5",
  fill: "currentColor",
  key: "nkw3mc"
}], ["circle", {
  cx: "17.5",
  cy: "14.5",
  r: ".5",
  fill: "currentColor",
  key: "1gjh6j"
}], ["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}]];
var ChartSpline = [["path", {
  d: "M3 3v16a2 2 0 0 0 2 2h16",
  key: "c24i48"
}], ["path", {
  d: "M7 16c.5-2 1.5-7 4-7 2 0 2 3 4 3 2.5 0 4.5-5 5-7",
  key: "lw07rv"
}]];
var CheckCheck = [["path", {
  d: "M18 6 7 17l-5-5",
  key: "116fxf"
}], ["path", {
  d: "m22 10-7.5 7.5L13 16",
  key: "ke71qq"
}]];
var CheckLine = [["path", {
  d: "M20 4L9 15",
  key: "1qkx8z"
}], ["path", {
  d: "M21 19L3 19",
  key: "100sma"
}], ["path", {
  d: "M9 15L4 10",
  key: "9zxff7"
}]];
var Check = [["path", {
  d: "M20 6 9 17l-5-5",
  key: "1gmf2c"
}]];
var ChefHat = [["path", {
  d: "M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z",
  key: "1qvrer"
}], ["path", {
  d: "M6 17h12",
  key: "1jwigz"
}]];
var Cherry = [["path", {
  d: "M2 17a5 5 0 0 0 10 0c0-2.76-2.5-5-5-3-2.5-2-5 .24-5 3Z",
  key: "cvxqlc"
}], ["path", {
  d: "M12 17a5 5 0 0 0 10 0c0-2.76-2.5-5-5-3-2.5-2-5 .24-5 3Z",
  key: "1ostrc"
}], ["path", {
  d: "M7 14c3.22-2.91 4.29-8.75 5-12 1.66 2.38 4.94 9 5 12",
  key: "hqx58h"
}], ["path", {
  d: "M22 9c-4.29 0-7.14-2.33-10-7 5.71 0 10 4.67 10 7Z",
  key: "eykp1o"
}]];
var ChessBishop = [["path", {
  d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z",
  key: "b89hwq"
}], ["path", {
  d: "M15 18c1.5-.615 3-2.461 3-4.923C18 8.769 14.5 4.462 12 2 9.5 4.462 6 8.77 6 13.077 6 15.539 7.5 17.385 9 18",
  key: "8jdkhx"
}], ["path", {
  d: "m16 7-2.5 2.5",
  key: "1jq90w"
}], ["path", {
  d: "M9 2h6",
  key: "1jrp98"
}]];
var ChessKing = [["path", {
  d: "M4 20a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z",
  key: "mqzwx6"
}], ["path", {
  d: "m6.7 18-1-1C4.35 15.682 3 14.09 3 12a5 5 0 0 1 4.95-5c1.584 0 2.7.455 4.05 1.818C13.35 7.455 14.466 7 16.05 7A5 5 0 0 1 21 12c0 2.082-1.359 3.673-2.7 5l-1 1",
  key: "1gdt1g"
}], ["path", {
  d: "M10 4h4",
  key: "1xpv9s"
}], ["path", {
  d: "M12 2v6.818",
  key: "b17a49"
}]];
var ChessKnight = [["path", {
  d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z",
  key: "b89hwq"
}], ["path", {
  d: "M16.5 18c1-2 2.5-5 2.5-9a7 7 0 0 0-7-7H6.635a1 1 0 0 0-.768 1.64L7 5l-2.32 5.802a2 2 0 0 0 .95 2.526l2.87 1.456",
  key: "axbnlq"
}], ["path", {
  d: "m15 5 1.425-1.425",
  key: "15xz8w"
}], ["path", {
  d: "m17 8 1.53-1.53",
  key: "15zhqh"
}], ["path", {
  d: "M9.713 12.185 7 18",
  key: "1ocm0l"
}]];
var ChessPawn = [["path", {
  d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z",
  key: "b89hwq"
}], ["path", {
  d: "m14.5 10 1.5 8",
  key: "cim3qy"
}], ["path", {
  d: "M7 10h10",
  key: "1101jm"
}], ["path", {
  d: "m8 18 1.5-8",
  key: "ja3yjd"
}], ["circle", {
  cx: "12",
  cy: "6",
  r: "4",
  key: "1frrej"
}]];
var ChessQueen = [["path", {
  d: "M4 20a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z",
  key: "mqzwx6"
}], ["path", {
  d: "m12.474 5.943 1.567 5.34a1 1 0 0 0 1.75.328l2.616-3.402",
  key: "1js4gl"
}], ["path", {
  d: "m20 9-3 9",
  key: "r75r3f"
}], ["path", {
  d: "m5.594 8.209 2.615 3.403a1 1 0 0 0 1.75-.329l1.567-5.34",
  key: "1joj19"
}], ["path", {
  d: "M7 18 4 9",
  key: "1mfzj8"
}], ["circle", {
  cx: "12",
  cy: "4",
  r: "2",
  key: "muu5ef"
}], ["circle", {
  cx: "20",
  cy: "7",
  r: "2",
  key: "9w7p1x"
}], ["circle", {
  cx: "4",
  cy: "7",
  r: "2",
  key: "1d9wy8"
}]];
var ChessRook = [["path", {
  d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z",
  key: "b89hwq"
}], ["path", {
  d: "M10 2v2",
  key: "7u0qdc"
}], ["path", {
  d: "M14 2v2",
  key: "6buw04"
}], ["path", {
  d: "m17 18-1-9",
  key: "10nd7q"
}], ["path", {
  d: "M6 2v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2",
  key: "uxf4yx"
}], ["path", {
  d: "M6 4h12",
  key: "1x2ag7"
}], ["path", {
  d: "m7 18 1-9",
  key: "1si9vq"
}]];
var ChevronDown = [["path", {
  d: "m6 9 6 6 6-6",
  key: "qrunsl"
}]];
var ChevronFirst = [["path", {
  d: "m17 18-6-6 6-6",
  key: "1yerx2"
}], ["path", {
  d: "M7 6v12",
  key: "1p53r6"
}]];
var ChevronLast = [["path", {
  d: "m7 18 6-6-6-6",
  key: "lwmzdw"
}], ["path", {
  d: "M17 6v12",
  key: "1o0aio"
}]];
var ChevronLeft = [["path", {
  d: "m15 18-6-6 6-6",
  key: "1wnfg3"
}]];
var ChevronRight = [["path", {
  d: "m9 18 6-6-6-6",
  key: "mthhwq"
}]];
var ChevronUp = [["path", {
  d: "m18 15-6-6-6 6",
  key: "153udz"
}]];
var ChevronsDownUp = [["path", {
  d: "m7 20 5-5 5 5",
  key: "13a0gw"
}], ["path", {
  d: "m7 4 5 5 5-5",
  key: "1kwcof"
}]];
var ChevronsDown = [["path", {
  d: "m7 6 5 5 5-5",
  key: "1lc07p"
}], ["path", {
  d: "m7 13 5 5 5-5",
  key: "1d48rs"
}]];
var ChevronsLeftRightEllipsis = [["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M16 12h.01",
  key: "1l6xoz"
}], ["path", {
  d: "m17 7 5 5-5 5",
  key: "1xlxn0"
}], ["path", {
  d: "m7 7-5 5 5 5",
  key: "19njba"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}]];
var ChevronsLeftRight = [["path", {
  d: "m9 7-5 5 5 5",
  key: "j5w590"
}], ["path", {
  d: "m15 7 5 5-5 5",
  key: "1bl6da"
}]];
var ChevronsLeft = [["path", {
  d: "m11 17-5-5 5-5",
  key: "13zhaf"
}], ["path", {
  d: "m18 17-5-5 5-5",
  key: "h8a8et"
}]];
var ChevronsRightLeft = [["path", {
  d: "m20 17-5-5 5-5",
  key: "30x0n2"
}], ["path", {
  d: "m4 17 5-5-5-5",
  key: "16spf4"
}]];
var ChevronsRight = [["path", {
  d: "m6 17 5-5-5-5",
  key: "xnjwq"
}], ["path", {
  d: "m13 17 5-5-5-5",
  key: "17xmmf"
}]];
var ChevronsUpDown = [["path", {
  d: "m7 15 5 5 5-5",
  key: "1hf1tw"
}], ["path", {
  d: "m7 9 5-5 5 5",
  key: "sgt6xg"
}]];
var ChevronsUp = [["path", {
  d: "m17 11-5-5-5 5",
  key: "e8nh98"
}], ["path", {
  d: "m17 18-5-5-5 5",
  key: "2avn1x"
}]];
var Chromium = [["path", {
  d: "M10.88 21.94 15.46 14",
  key: "xkve6t"
}], ["path", {
  d: "M21.17 8H12",
  key: "19dcdn"
}], ["path", {
  d: "M3.95 6.06 8.54 14",
  key: "g8jz9m"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}]];
var Church = [["path", {
  d: "M10 9h4",
  key: "u4k05v"
}], ["path", {
  d: "M12 7v5",
  key: "ma6bk"
}], ["path", {
  d: "M14 21v-3a2 2 0 0 0-4 0v3",
  key: "1rgiei"
}], ["path", {
  d: "m18 9 3.52 2.147a1 1 0 0 1 .48.854V19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6.999a1 1 0 0 1 .48-.854L6 9",
  key: "flvdwo"
}], ["path", {
  d: "M6 21V7a1 1 0 0 1 .376-.782l5-3.999a1 1 0 0 1 1.249.001l5 4A1 1 0 0 1 18 7v14",
  key: "a5i0n2"
}]];
var CigaretteOff = [["path", {
  d: "M12 12H3a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h13",
  key: "1gdiyg"
}], ["path", {
  d: "M18 8c0-2.5-2-2.5-2-5",
  key: "1il607"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M21 12a1 1 0 0 1 1 1v2a1 1 0 0 1-.5.866",
  key: "166zjj"
}], ["path", {
  d: "M22 8c0-2.5-2-2.5-2-5",
  key: "1gah44"
}], ["path", {
  d: "M7 12v4",
  key: "jqww69"
}]];
var Cigarette = [["path", {
  d: "M17 12H3a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h14",
  key: "1mb5g1"
}], ["path", {
  d: "M18 8c0-2.5-2-2.5-2-5",
  key: "1il607"
}], ["path", {
  d: "M21 16a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
  key: "1yl5r7"
}], ["path", {
  d: "M22 8c0-2.5-2-2.5-2-5",
  key: "1gah44"
}], ["path", {
  d: "M7 12v4",
  key: "jqww69"
}]];
var CircleAlert = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "8",
  y2: "12",
  key: "1pkeuh"
}], ["line", {
  x1: "12",
  x2: "12.01",
  y1: "16",
  y2: "16",
  key: "4dfq90"
}]];
var CircleArrowDown = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}], ["path", {
  d: "m8 12 4 4 4-4",
  key: "k98ssh"
}]];
var CircleArrowLeft = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m12 8-4 4 4 4",
  key: "15vm53"
}], ["path", {
  d: "M16 12H8",
  key: "1fr5h0"
}]];
var CircleArrowOutDownLeft = [["path", {
  d: "M2 12a10 10 0 1 1 10 10",
  key: "1yn6ov"
}], ["path", {
  d: "m2 22 10-10",
  key: "28ilpk"
}], ["path", {
  d: "M8 22H2v-6",
  key: "sulq54"
}]];
var CircleArrowOutDownRight = [["path", {
  d: "M12 22a10 10 0 1 1 10-10",
  key: "130bv5"
}], ["path", {
  d: "M22 22 12 12",
  key: "131aw7"
}], ["path", {
  d: "M22 16v6h-6",
  key: "1gvm70"
}]];
var CircleArrowOutUpLeft = [["path", {
  d: "M2 8V2h6",
  key: "hiwtdz"
}], ["path", {
  d: "m2 2 10 10",
  key: "1oh8rs"
}], ["path", {
  d: "M12 2A10 10 0 1 1 2 12",
  key: "rrk4fa"
}]];
var CircleArrowOutUpRight = [["path", {
  d: "M22 12A10 10 0 1 1 12 2",
  key: "1fm58d"
}], ["path", {
  d: "M22 2 12 12",
  key: "yg2myt"
}], ["path", {
  d: "M16 2h6v6",
  key: "zan5cs"
}]];
var CircleArrowRight = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m12 16 4-4-4-4",
  key: "1i9zcv"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var CircleArrowUp = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m16 12-4-4-4 4",
  key: "177agl"
}], ["path", {
  d: "M12 16V8",
  key: "1sbj14"
}]];
var CircleCheckBig = [["path", {
  d: "M21.801 10A10 10 0 1 1 17 3.335",
  key: "yps3ct"
}], ["path", {
  d: "m9 11 3 3L22 4",
  key: "1pflzl"
}]];
var CircleCheck = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var CircleChevronDown = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m16 10-4 4-4-4",
  key: "894hmk"
}]];
var CircleChevronLeft = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m14 16-4-4 4-4",
  key: "ojs7w8"
}]];
var CircleChevronRight = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m10 8 4 4-4 4",
  key: "1wy4r4"
}]];
var CircleChevronUp = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m8 14 4-4 4 4",
  key: "fy2ptz"
}]];
var CircleDashed = [["path", {
  d: "M10.1 2.182a10 10 0 0 1 3.8 0",
  key: "5ilxe3"
}], ["path", {
  d: "M13.9 21.818a10 10 0 0 1-3.8 0",
  key: "11zvb9"
}], ["path", {
  d: "M17.609 3.721a10 10 0 0 1 2.69 2.7",
  key: "1iw5b2"
}], ["path", {
  d: "M2.182 13.9a10 10 0 0 1 0-3.8",
  key: "c0bmvh"
}], ["path", {
  d: "M20.279 17.609a10 10 0 0 1-2.7 2.69",
  key: "1ruxm7"
}], ["path", {
  d: "M21.818 10.1a10 10 0 0 1 0 3.8",
  key: "qkgqxc"
}], ["path", {
  d: "M3.721 6.391a10 10 0 0 1 2.7-2.69",
  key: "1mcia2"
}], ["path", {
  d: "M6.391 20.279a10 10 0 0 1-2.69-2.7",
  key: "1fvljs"
}]];
var CircleDivide = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "12",
  y2: "12",
  key: "1jonct"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "16",
  y2: "16",
  key: "aqc6ln"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "8",
  y2: "8",
  key: "1mkcni"
}]];
var CircleDollarSign = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",
  key: "1h4pet"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}]];
var CircleDotDashed = [["path", {
  d: "M10.1 2.18a9.93 9.93 0 0 1 3.8 0",
  key: "1qdqn0"
}], ["path", {
  d: "M17.6 3.71a9.95 9.95 0 0 1 2.69 2.7",
  key: "1bq7p6"
}], ["path", {
  d: "M21.82 10.1a9.93 9.93 0 0 1 0 3.8",
  key: "1rlaqf"
}], ["path", {
  d: "M20.29 17.6a9.95 9.95 0 0 1-2.7 2.69",
  key: "1xk03u"
}], ["path", {
  d: "M13.9 21.82a9.94 9.94 0 0 1-3.8 0",
  key: "l7re25"
}], ["path", {
  d: "M6.4 20.29a9.95 9.95 0 0 1-2.69-2.7",
  key: "1v18p6"
}], ["path", {
  d: "M2.18 13.9a9.93 9.93 0 0 1 0-3.8",
  key: "xdo6bj"
}], ["path", {
  d: "M3.71 6.4a9.95 9.95 0 0 1 2.7-2.69",
  key: "1jjmaz"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}]];
var CircleDot = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}]];
var CircleEllipsis = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M17 12h.01",
  key: "1m0b6t"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M7 12h.01",
  key: "eqddd0"
}]];
var CircleEqual = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M7 10h10",
  key: "1101jm"
}], ["path", {
  d: "M7 14h10",
  key: "1mhdw3"
}]];
var CircleFadingArrowUp = [["path", {
  d: "M12 2a10 10 0 0 1 7.38 16.75",
  key: "175t95"
}], ["path", {
  d: "m16 12-4-4-4 4",
  key: "177agl"
}], ["path", {
  d: "M12 16V8",
  key: "1sbj14"
}], ["path", {
  d: "M2.5 8.875a10 10 0 0 0-.5 3",
  key: "1vce0s"
}], ["path", {
  d: "M2.83 16a10 10 0 0 0 2.43 3.4",
  key: "o3fkw4"
}], ["path", {
  d: "M4.636 5.235a10 10 0 0 1 .891-.857",
  key: "1szpfk"
}], ["path", {
  d: "M8.644 21.42a10 10 0 0 0 7.631-.38",
  key: "9yhvd4"
}]];
var CircleFadingPlus = [["path", {
  d: "M12 2a10 10 0 0 1 7.38 16.75",
  key: "175t95"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}], ["path", {
  d: "M16 12H8",
  key: "1fr5h0"
}], ["path", {
  d: "M2.5 8.875a10 10 0 0 0-.5 3",
  key: "1vce0s"
}], ["path", {
  d: "M2.83 16a10 10 0 0 0 2.43 3.4",
  key: "o3fkw4"
}], ["path", {
  d: "M4.636 5.235a10 10 0 0 1 .891-.857",
  key: "1szpfk"
}], ["path", {
  d: "M8.644 21.42a10 10 0 0 0 7.631-.38",
  key: "9yhvd4"
}]];
var CircleGauge = [["path", {
  d: "M15.6 2.7a10 10 0 1 0 5.7 5.7",
  key: "1e0p6d"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["path", {
  d: "M13.4 10.6 19 5",
  key: "1kr7tw"
}]];
var CircleMinus = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var CircleOff = [["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.35 2.69A10 10 0 0 1 21.3 15.65",
  key: "1pfsoa"
}], ["path", {
  d: "M19.08 19.08A10 10 0 1 1 4.92 4.92",
  key: "1ablyi"
}]];
var CircleParkingOff = [["path", {
  d: "M12.656 7H13a3 3 0 0 1 2.984 3.307",
  key: "1sjx87"
}], ["path", {
  d: "M13 13H9",
  key: "e2beee"
}], ["path", {
  d: "M19.071 19.071A1 1 0 0 1 4.93 4.93",
  key: "1kb595"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.357 2.687a10 10 0 0 1 12.956 12.956",
  key: "5bsfdx"
}], ["path", {
  d: "M9 17V9",
  key: "ojradj"
}]];
var CircleParking = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M9 17V7h4a3 3 0 0 1 0 6H9",
  key: "1dfk2c"
}]];
var CirclePause = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "10",
  x2: "10",
  y1: "15",
  y2: "9",
  key: "c1nkhi"
}], ["line", {
  x1: "14",
  x2: "14",
  y1: "15",
  y2: "9",
  key: "h65svq"
}]];
var CirclePercent = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["path", {
  d: "M15 15h.01",
  key: "lqbp3k"
}]];
var CirclePile = [["circle", {
  cx: "12",
  cy: "19",
  r: "2",
  key: "13j0tp"
}], ["circle", {
  cx: "12",
  cy: "5",
  r: "2",
  key: "f1ur92"
}], ["circle", {
  cx: "16",
  cy: "12",
  r: "2",
  key: "4ma0v8"
}], ["circle", {
  cx: "20",
  cy: "19",
  r: "2",
  key: "1obnsp"
}], ["circle", {
  cx: "4",
  cy: "19",
  r: "2",
  key: "p3m9r0"
}], ["circle", {
  cx: "8",
  cy: "12",
  r: "2",
  key: "1nvbw3"
}]];
var CirclePlay = [["path", {
  d: "M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z",
  key: "kmsa83"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var CirclePlus = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}]];
var CirclePower = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 7v4",
  key: "xawao1"
}], ["path", {
  d: "M7.998 9.003a5 5 0 1 0 8-.005",
  key: "1pek45"
}]];
var CirclePoundSterling = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M10 16V9.5a1 1 0 0 1 5 0",
  key: "1i1are"
}], ["path", {
  d: "M8 12h4",
  key: "qz6y1c"
}], ["path", {
  d: "M8 16h7",
  key: "sbedsn"
}]];
var CircleQuestionMark = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
  key: "1u773s"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}]];
var CircleSlash2 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M22 2 2 22",
  key: "y4kqgn"
}]];
var CircleSlash = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "9",
  x2: "15",
  y1: "15",
  y2: "9",
  key: "1dfufj"
}]];
var CircleSmall = [["circle", {
  cx: "12",
  cy: "12",
  r: "6",
  key: "1vlfrh"
}]];
var CircleStar = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M11.051 7.616a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.867l-1.156-1.152a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
  key: "285bvi"
}]];
var CircleStop = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["rect", {
  x: "9",
  y: "9",
  width: "6",
  height: "6",
  rx: "1",
  key: "1ssd4o"
}]];
var CircleUserRound = [["path", {
  d: "M18 20a6 6 0 0 0-12 0",
  key: "1qehca"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "4",
  key: "1h16sb"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var CircleUser = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662",
  key: "154egf"
}]];
var CircleX = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "m9 9 6 6",
  key: "z0biqf"
}]];
var Circle = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var CircuitBoard = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M11 9h4a2 2 0 0 0 2-2V3",
  key: "1ve2rv"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}], ["path", {
  d: "M7 21v-4a2 2 0 0 1 2-2h4",
  key: "1fwkro"
}], ["circle", {
  cx: "15",
  cy: "15",
  r: "2",
  key: "3i40o0"
}]];
var Clapperboard = [["path", {
  d: "m12.296 3.464 3.02 3.956",
  key: "qash78"
}], ["path", {
  d: "M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3z",
  key: "1h7j8b"
}], ["path", {
  d: "M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  key: "4lm6w1"
}], ["path", {
  d: "m6.18 5.276 3.1 3.899",
  key: "zjj9t3"
}]];
var Citrus = [["path", {
  d: "M21.66 17.67a1.08 1.08 0 0 1-.04 1.6A12 12 0 0 1 4.73 2.38a1.1 1.1 0 0 1 1.61-.04z",
  key: "4ite01"
}], ["path", {
  d: "M19.65 15.66A8 8 0 0 1 8.35 4.34",
  key: "1gxipu"
}], ["path", {
  d: "m14 10-5.5 5.5",
  key: "92pfem"
}], ["path", {
  d: "M14 17.85V10H6.15",
  key: "xqmtsk"
}]];
var ClipboardCheck = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "m9 14 2 2 4-4",
  key: "df797q"
}]];
var ClipboardClock = [["path", {
  d: "M16 14v2.2l1.6 1",
  key: "fo4ql5"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v.832",
  key: "1ujtp2"
}], ["path", {
  d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2",
  key: "qvpao1"
}], ["circle", {
  cx: "16",
  cy: "16",
  r: "6",
  key: "qoo3c4"
}], ["rect", {
  x: "8",
  y: "2",
  width: "8",
  height: "4",
  rx: "1",
  key: "ublpy"
}]];
var ClipboardCopy = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2",
  key: "4jdomd"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v4",
  key: "3hqy98"
}], ["path", {
  d: "M21 14H11",
  key: "1bme5i"
}], ["path", {
  d: "m15 10-4 4 4 4",
  key: "5dvupr"
}]];
var ClipboardList = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "M12 11h4",
  key: "1jrz19"
}], ["path", {
  d: "M12 16h4",
  key: "n85exb"
}], ["path", {
  d: "M8 11h.01",
  key: "1dfujw"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}]];
var ClipboardMinus = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "M9 14h6",
  key: "159ibu"
}]];
var ClipboardPaste = [["path", {
  d: "M11 14h10",
  key: "1w8e9d"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v1.344",
  key: "1e62lh"
}], ["path", {
  d: "m17 18 4-4-4-4",
  key: "z2g111"
}], ["path", {
  d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 1.793-1.113",
  key: "bjbb7m"
}], ["rect", {
  x: "8",
  y: "2",
  width: "8",
  height: "4",
  rx: "1",
  key: "ublpy"
}]];
var ClipboardPenLine = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  key: "1oijnt"
}], ["path", {
  d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-.5",
  key: "1but9f"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 1.73 1",
  key: "1p8n7l"
}], ["path", {
  d: "M8 18h1",
  key: "13wk12"
}], ["path", {
  d: "M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "2t3380"
}]];
var ClipboardPen = [["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v2",
  key: "j91f56"
}], ["path", {
  d: "M21.34 15.664a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "16fuwn"
}], ["path", {
  d: "M8 22H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "120tdm"
}], ["rect", {
  x: "8",
  y: "2",
  width: "8",
  height: "4",
  rx: "1",
  key: "ublpy"
}]];
var ClipboardPlus = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "M9 14h6",
  key: "159ibu"
}], ["path", {
  d: "M12 17v-6",
  key: "1y8rbf"
}]];
var ClipboardType = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "M9 12v-1h6v1",
  key: "iehl6m"
}], ["path", {
  d: "M11 17h2",
  key: "12w5me"
}], ["path", {
  d: "M12 11v6",
  key: "1bwqyc"
}]];
var ClipboardX = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}], ["path", {
  d: "m15 11-6 6",
  key: "1toa9n"
}], ["path", {
  d: "m9 11 6 6",
  key: "wlibny"
}]];
var Clipboard = [["rect", {
  width: "8",
  height: "4",
  x: "8",
  y: "2",
  rx: "1",
  ry: "1",
  key: "tgr4d6"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
  key: "116196"
}]];
var Clock1 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l2-4",
  key: "miptyd"
}]];
var Clock10 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l-4-2",
  key: "cedpoo"
}]];
var Clock11 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l-2-4",
  key: "ns39ag"
}]];
var Clock12 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6",
  key: "1ipuwl"
}]];
var Clock2 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l4-2",
  key: "1r2kuh"
}]];
var Clock3 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6h4",
  key: "135r8i"
}]];
var Clock4 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l4 2",
  key: "mmk7yg"
}]];
var Clock5 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l2 4",
  key: "1287s9"
}]];
var Clock6 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v10",
  key: "wf7rdh"
}]];
var Clock7 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l-2 4",
  key: "1095bu"
}]];
var Clock8 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l-4 2",
  key: "imc3wl"
}]];
var Clock9 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6H8",
  key: "u39vzm"
}]];
var ClockAlert = [["path", {
  d: "M12 6v6l4 2",
  key: "mmk7yg"
}], ["path", {
  d: "M20 12v5",
  key: "12wsvk"
}], ["path", {
  d: "M20 21h.01",
  key: "1p6o6n"
}], ["path", {
  d: "M21.25 8.2A10 10 0 1 0 16 21.16",
  key: "17fp9f"
}]];
var ClockArrowDown = [["path", {
  d: "M12 6v6l2 1",
  key: "19cm8n"
}], ["path", {
  d: "M12.337 21.994a10 10 0 1 1 9.588-8.767",
  key: "28moa"
}], ["path", {
  d: "m14 18 4 4 4-4",
  key: "1waygx"
}], ["path", {
  d: "M18 14v8",
  key: "irew45"
}]];
var ClockArrowUp = [["path", {
  d: "M12 6v6l1.56.78",
  key: "14ed3g"
}], ["path", {
  d: "M13.227 21.925a10 10 0 1 1 8.767-9.588",
  key: "jwkls1"
}], ["path", {
  d: "m14 18 4-4 4 4",
  key: "ftkppy"
}], ["path", {
  d: "M18 22v-8",
  key: "su0gjh"
}]];
var ClockCheck = [["path", {
  d: "M12 6v6l4 2",
  key: "mmk7yg"
}], ["path", {
  d: "M22 12a10 10 0 1 0-11 9.95",
  key: "17dhok"
}], ["path", {
  d: "m22 16-5.5 5.5L14 19",
  key: "1eibut"
}]];
var ClockFading = [["path", {
  d: "M12 2a10 10 0 0 1 7.38 16.75",
  key: "175t95"
}], ["path", {
  d: "M12 6v6l4 2",
  key: "mmk7yg"
}], ["path", {
  d: "M2.5 8.875a10 10 0 0 0-.5 3",
  key: "1vce0s"
}], ["path", {
  d: "M2.83 16a10 10 0 0 0 2.43 3.4",
  key: "o3fkw4"
}], ["path", {
  d: "M4.636 5.235a10 10 0 0 1 .891-.857",
  key: "1szpfk"
}], ["path", {
  d: "M8.644 21.42a10 10 0 0 0 7.631-.38",
  key: "9yhvd4"
}]];
var Clock = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 6v6l4 2",
  key: "mmk7yg"
}]];
var ClockPlus = [["path", {
  d: "M12 6v6l3.644 1.822",
  key: "1jmett"
}], ["path", {
  d: "M16 19h6",
  key: "xwg31i"
}], ["path", {
  d: "M19 16v6",
  key: "tddt3s"
}], ["path", {
  d: "M21.92 13.267a10 10 0 1 0-8.653 8.653",
  key: "1u0osk"
}]];
var ClosedCaption = [["path", {
  d: "M10 9.17a3 3 0 1 0 0 5.66",
  key: "h9wayk"
}], ["path", {
  d: "M17 9.17a3 3 0 1 0 0 5.66",
  key: "1v6zke"
}], ["rect", {
  x: "2",
  y: "5",
  width: "20",
  height: "14",
  rx: "2",
  key: "qneu4z"
}]];
var CloudAlert = [["path", {
  d: "M12 12v4",
  key: "tww15h"
}], ["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M8.128 16.949A7 7 0 1 1 15.71 8h1.79a1 1 0 0 1 0 9h-1.642",
  key: "1namsd"
}]];
var CloudBackup = [["path", {
  d: "M21 15.251A4.5 4.5 0 0 0 17.5 8h-1.79A7 7 0 1 0 3 13.607",
  key: "xpoh9y"
}], ["path", {
  d: "M7 11v4h4",
  key: "q9yh32"
}], ["path", {
  d: "M8 19a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5 4.82 4.82 0 0 0-3.41 1.41L7 15",
  key: "1xm8iu"
}]];
var CloudCheck = [["path", {
  d: "m17 15-5.5 5.5L9 18",
  key: "15q87x"
}], ["path", {
  d: "M5.516 16.07A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 3.501 7.327",
  key: "1xtj56"
}]];
var CloudDownload = [["path", {
  d: "M12 13v8l-4-4",
  key: "1f5nwf"
}], ["path", {
  d: "m12 21 4-4",
  key: "1lfcce"
}], ["path", {
  d: "M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284",
  key: "ui1hmy"
}]];
var CloudCog = [["path", {
  d: "m10.852 19.772-.383.924",
  key: "r7sl7d"
}], ["path", {
  d: "m13.148 14.228.383-.923",
  key: "1d5zpm"
}], ["path", {
  d: "M13.148 19.772a3 3 0 1 0-2.296-5.544l-.383-.923",
  key: "1ydik7"
}], ["path", {
  d: "m13.53 20.696-.382-.924a3 3 0 1 1-2.296-5.544",
  key: "1m1vsf"
}], ["path", {
  d: "m14.772 15.852.923-.383",
  key: "660p6e"
}], ["path", {
  d: "m14.772 18.148.923.383",
  key: "hrcpis"
}], ["path", {
  d: "M4.2 15.1a7 7 0 1 1 9.93-9.858A7 7 0 0 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.2",
  key: "j2q98n"
}], ["path", {
  d: "m9.228 15.852-.923-.383",
  key: "1p9ong"
}], ["path", {
  d: "m9.228 18.148-.923.383",
  key: "6558rz"
}]];
var CloudDrizzle = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "M8 19v1",
  key: "1dk2by"
}], ["path", {
  d: "M8 14v1",
  key: "84yxot"
}], ["path", {
  d: "M16 19v1",
  key: "v220m7"
}], ["path", {
  d: "M16 14v1",
  key: "g12gj6"
}], ["path", {
  d: "M12 21v1",
  key: "q8vafk"
}], ["path", {
  d: "M12 16v1",
  key: "1mx6rx"
}]];
var CloudFog = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "M16 17H7",
  key: "pygtm1"
}], ["path", {
  d: "M17 21H9",
  key: "1u2q02"
}]];
var CloudHail = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "M16 14v2",
  key: "a1is7l"
}], ["path", {
  d: "M8 14v2",
  key: "1e9m6t"
}], ["path", {
  d: "M16 20h.01",
  key: "xwek51"
}], ["path", {
  d: "M8 20h.01",
  key: "1vjney"
}], ["path", {
  d: "M12 16v2",
  key: "z66u1j"
}], ["path", {
  d: "M12 22h.01",
  key: "1urd7a"
}]];
var CloudLightning = [["path", {
  d: "M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973",
  key: "1cez44"
}], ["path", {
  d: "m13 12-3 5h4l-3 5",
  key: "1t22er"
}]];
var CloudMoonRain = [["path", {
  d: "M11 20v2",
  key: "174qtz"
}], ["path", {
  d: "M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36",
  key: "zwnc1e"
}], ["path", {
  d: "M3 20a5 5 0 1 1 8.9-4H13a3 3 0 0 1 2 5.24",
  key: "1qmrp3"
}], ["path", {
  d: "M7 19v2",
  key: "12npes"
}]];
var CloudMoon = [["path", {
  d: "M13 16a3 3 0 0 1 0 6H7a5 5 0 1 1 4.9-6z",
  key: "ie2ih4"
}], ["path", {
  d: "M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36",
  key: "zwnc1e"
}]];
var CloudOff = [["path", {
  d: "M10.94 5.274A7 7 0 0 1 15.71 10h1.79a4.5 4.5 0 0 1 4.222 6.057",
  key: "1uxyv8"
}], ["path", {
  d: "M18.796 18.81A4.5 4.5 0 0 1 17.5 19H9A7 7 0 0 1 5.79 5.78",
  key: "99tcn7"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var CloudRainWind = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "m9.2 22 3-7",
  key: "sb5f6j"
}], ["path", {
  d: "m9 13-3 7",
  key: "500co5"
}], ["path", {
  d: "m17 13-3 7",
  key: "8t2fiy"
}]];
var CloudRain = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "M16 14v6",
  key: "1j4efv"
}], ["path", {
  d: "M8 14v6",
  key: "17c4r9"
}], ["path", {
  d: "M12 16v6",
  key: "c8a4gj"
}]];
var CloudSnow = [["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "M8 15h.01",
  key: "a7atzg"
}], ["path", {
  d: "M8 19h.01",
  key: "puxtts"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}], ["path", {
  d: "M12 21h.01",
  key: "h35vbk"
}], ["path", {
  d: "M16 15h.01",
  key: "rnfrdf"
}], ["path", {
  d: "M16 19h.01",
  key: "1vcnzz"
}]];
var CloudSunRain = [["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "m4.93 4.93 1.41 1.41",
  key: "149t6j"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}], ["path", {
  d: "m19.07 4.93-1.41 1.41",
  key: "1shlcs"
}], ["path", {
  d: "M15.947 12.65a4 4 0 0 0-5.925-4.128",
  key: "dpwdj0"
}], ["path", {
  d: "M3 20a5 5 0 1 1 8.9-4H13a3 3 0 0 1 2 5.24",
  key: "1qmrp3"
}], ["path", {
  d: "M11 20v2",
  key: "174qtz"
}], ["path", {
  d: "M7 19v2",
  key: "12npes"
}]];
var CloudSun = [["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "m4.93 4.93 1.41 1.41",
  key: "149t6j"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}], ["path", {
  d: "m19.07 4.93-1.41 1.41",
  key: "1shlcs"
}], ["path", {
  d: "M15.947 12.65a4 4 0 0 0-5.925-4.128",
  key: "dpwdj0"
}], ["path", {
  d: "M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z",
  key: "s09mg5"
}]];
var CloudSync = [["path", {
  d: "m17 18-1.535 1.605a5 5 0 0 1-8-1.5",
  key: "adpv5j"
}], ["path", {
  d: "M17 22v-4h-4",
  key: "ex1ofj"
}], ["path", {
  d: "M20.996 15.251A4.5 4.5 0 0 0 17.495 8h-1.79a7 7 0 1 0-12.709 5.607",
  key: "ziqt14"
}], ["path", {
  d: "M7 10v4h4",
  key: "1j6gx1"
}], ["path", {
  d: "m7 14 1.535-1.605a5 5 0 0 1 8 1.5",
  key: "19q5h7"
}]];
var CloudUpload = [["path", {
  d: "M12 13v8",
  key: "1l5pq0"
}], ["path", {
  d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
  key: "1pljnt"
}], ["path", {
  d: "m8 17 4-4 4 4",
  key: "1quai1"
}]];
var Cloud = [["path", {
  d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
  key: "p7xjir"
}]];
var Cloudy = [["path", {
  d: "M17.5 12a1 1 0 1 1 0 9H9.006a7 7 0 1 1 6.702-9z",
  key: "44yre2"
}], ["path", {
  d: "M21.832 9A3 3 0 0 0 19 7h-2.207a5.5 5.5 0 0 0-10.72.61",
  key: "leugyv"
}]];
var Clover = [["path", {
  d: "M16.17 7.83 2 22",
  key: "t58vo8"
}], ["path", {
  d: "M4.02 12a2.827 2.827 0 1 1 3.81-4.17A2.827 2.827 0 1 1 12 4.02a2.827 2.827 0 1 1 4.17 3.81A2.827 2.827 0 1 1 19.98 12a2.827 2.827 0 1 1-3.81 4.17A2.827 2.827 0 1 1 12 19.98a2.827 2.827 0 1 1-4.17-3.81A1 1 0 1 1 4 12",
  key: "17k36q"
}], ["path", {
  d: "m7.83 7.83 8.34 8.34",
  key: "1d7sxk"
}]];
var Club = [["path", {
  d: "M17.28 9.05a5.5 5.5 0 1 0-10.56 0A5.5 5.5 0 1 0 12 17.66a5.5 5.5 0 1 0 5.28-8.6Z",
  key: "27yuqz"
}], ["path", {
  d: "M12 17.66L12 22",
  key: "ogfahf"
}]];
var CodeXml = [["path", {
  d: "m18 16 4-4-4-4",
  key: "1inbqp"
}], ["path", {
  d: "m6 8-4 4 4 4",
  key: "15zrgr"
}], ["path", {
  d: "m14.5 4-5 16",
  key: "e7oirm"
}]];
var Code = [["path", {
  d: "m16 18 6-6-6-6",
  key: "eg8j8"
}], ["path", {
  d: "m8 6-6 6 6 6",
  key: "ppft3o"
}]];
var Codepen = [["polygon", {
  points: "12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2",
  key: "srzb37"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "22",
  y2: "15.5",
  key: "1t73f2"
}], ["polyline", {
  points: "22 8.5 12 15.5 2 8.5",
  key: "ajlxae"
}], ["polyline", {
  points: "2 15.5 12 8.5 22 15.5",
  key: "susrui"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "2",
  y2: "8.5",
  key: "2cldga"
}]];
var Codesandbox = [["path", {
  d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
  key: "yt0hxn"
}], ["polyline", {
  points: "7.5 4.21 12 6.81 16.5 4.21",
  key: "fabo96"
}], ["polyline", {
  points: "7.5 19.79 7.5 14.6 3 12",
  key: "z377f1"
}], ["polyline", {
  points: "21 12 16.5 14.6 16.5 19.79",
  key: "9nrev1"
}], ["polyline", {
  points: "3.27 6.96 12 12.01 20.73 6.96",
  key: "1180pa"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "22.08",
  y2: "12",
  key: "3z3uq6"
}]];
var Cog = [["path", {
  d: "M11 10.27 7 3.34",
  key: "16pf9h"
}], ["path", {
  d: "m11 13.73-4 6.93",
  key: "794ttg"
}], ["path", {
  d: "M12 22v-2",
  key: "1osdcq"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M14 12h8",
  key: "4f43i9"
}], ["path", {
  d: "m17 20.66-1-1.73",
  key: "eq3orb"
}], ["path", {
  d: "m17 3.34-1 1.73",
  key: "2wel8s"
}], ["path", {
  d: "M2 12h2",
  key: "1t8f8n"
}], ["path", {
  d: "m20.66 17-1.73-1",
  key: "sg0v6f"
}], ["path", {
  d: "m20.66 7-1.73 1",
  key: "1ow05n"
}], ["path", {
  d: "m3.34 17 1.73-1",
  key: "nuk764"
}], ["path", {
  d: "m3.34 7 1.73 1",
  key: "1ulond"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "8",
  key: "46899m"
}]];
var Coffee = [["path", {
  d: "M10 2v2",
  key: "7u0qdc"
}], ["path", {
  d: "M14 2v2",
  key: "6buw04"
}], ["path", {
  d: "M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",
  key: "pwadti"
}], ["path", {
  d: "M6 2v2",
  key: "colzsn"
}]];
var Columns2 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M12 3v18",
  key: "108xh3"
}]];
var Coins = [["path", {
  d: "M13.744 17.736a6 6 0 1 1-7.48-7.48",
  key: "bq4yh3"
}], ["path", {
  d: "M15 6h1v4",
  key: "11y1tn"
}], ["path", {
  d: "m6.134 14.768.866-.5 2 3.464",
  key: "17snzx"
}], ["circle", {
  cx: "16",
  cy: "8",
  r: "6",
  key: "14bfc9"
}]];
var Columns3Cog = [["path", {
  d: "M10.5 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5.5",
  key: "1g2yzs"
}], ["path", {
  d: "m14.3 19.6 1-.4",
  key: "11sv9r"
}], ["path", {
  d: "M15 3v7.5",
  key: "7lm50a"
}], ["path", {
  d: "m15.2 16.9-.9-.3",
  key: "1t7mvx"
}], ["path", {
  d: "m16.6 21.7.3-.9",
  key: "1j67ps"
}], ["path", {
  d: "m16.8 15.3-.4-1",
  key: "1ei7r6"
}], ["path", {
  d: "m19.1 15.2.3-.9",
  key: "18r7jp"
}], ["path", {
  d: "m19.6 21.7-.4-1",
  key: "z2vh2"
}], ["path", {
  d: "m20.7 16.8 1-.4",
  key: "19m87a"
}], ["path", {
  d: "m21.7 19.4-.9-.3",
  key: "1qgwi9"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var Columns3 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}]];
var Columns4 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7.5 3v18",
  key: "w0wo6v"
}], ["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["path", {
  d: "M16.5 3v18",
  key: "10tjh1"
}]];
var Combine = [["path", {
  d: "M14 3a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1",
  key: "1l7d7l"
}], ["path", {
  d: "M19 3a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1",
  key: "9955pe"
}], ["path", {
  d: "m7 15 3 3",
  key: "4hkfgk"
}], ["path", {
  d: "m7 21 3-3H5a2 2 0 0 1-2-2v-2",
  key: "1xljwe"
}], ["rect", {
  x: "14",
  y: "14",
  width: "7",
  height: "7",
  rx: "1",
  key: "1cdgtw"
}], ["rect", {
  x: "3",
  y: "3",
  width: "7",
  height: "7",
  rx: "1",
  key: "zi3rio"
}]];
var Command = [["path", {
  d: "M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3",
  key: "11bfej"
}]];
var Component2 = [["path", {
  d: "M15.536 11.293a1 1 0 0 0 0 1.414l2.376 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",
  key: "1uwlt4"
}], ["path", {
  d: "M2.297 11.293a1 1 0 0 0 0 1.414l2.377 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414L6.088 8.916a1 1 0 0 0-1.414 0z",
  key: "10291m"
}], ["path", {
  d: "M8.916 17.912a1 1 0 0 0 0 1.415l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.415l-2.377-2.376a1 1 0 0 0-1.414 0z",
  key: "1tqoq1"
}], ["path", {
  d: "M8.916 4.674a1 1 0 0 0 0 1.414l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",
  key: "1x6lto"
}]];
var Compass = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",
  key: "9ktpf1"
}]];
var Computer = [["rect", {
  width: "14",
  height: "8",
  x: "5",
  y: "2",
  rx: "2",
  key: "wc9tft"
}], ["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "14",
  rx: "2",
  key: "w68u3i"
}], ["path", {
  d: "M6 18h2",
  key: "rwmk9e"
}], ["path", {
  d: "M12 18h6",
  key: "aqd8w3"
}]];
var ConciergeBell = [["path", {
  d: "M3 20a1 1 0 0 1-1-1v-1a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1Z",
  key: "1pvr1r"
}], ["path", {
  d: "M20 16a8 8 0 1 0-16 0",
  key: "1pa543"
}], ["path", {
  d: "M12 4v4",
  key: "1bq03y"
}], ["path", {
  d: "M10 4h4",
  key: "1xpv9s"
}]];
var Cone = [["path", {
  d: "m20.9 18.55-8-15.98a1 1 0 0 0-1.8 0l-8 15.98",
  key: "53pte7"
}], ["ellipse", {
  cx: "12",
  cy: "19",
  rx: "9",
  ry: "3",
  key: "1ji25f"
}]];
var Construction = [["rect", {
  x: "2",
  y: "6",
  width: "20",
  height: "8",
  rx: "1",
  key: "1estib"
}], ["path", {
  d: "M17 14v7",
  key: "7m2elx"
}], ["path", {
  d: "M7 14v7",
  key: "1cm7wv"
}], ["path", {
  d: "M17 3v3",
  key: "1v4jwn"
}], ["path", {
  d: "M7 3v3",
  key: "7o6guu"
}], ["path", {
  d: "M10 14 2.3 6.3",
  key: "1023jk"
}], ["path", {
  d: "m14 6 7.7 7.7",
  key: "1s8pl2"
}], ["path", {
  d: "m8 6 8 8",
  key: "hl96qh"
}]];
var ContactRound = [["path", {
  d: "M16 2v2",
  key: "scm5qe"
}], ["path", {
  d: "M17.915 22a6 6 0 0 0-12 0",
  key: "suqz9p"
}], ["path", {
  d: "M8 2v2",
  key: "pbkmx"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2",
  key: "12vinp"
}]];
var Contact = [["path", {
  d: "M16 2v2",
  key: "scm5qe"
}], ["path", {
  d: "M7 22v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2",
  key: "1waht3"
}], ["path", {
  d: "M8 2v2",
  key: "pbkmx"
}], ["circle", {
  cx: "12",
  cy: "11",
  r: "3",
  key: "itu57m"
}], ["rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "18",
  rx: "2",
  key: "12vinp"
}]];
var Container = [["path", {
  d: "M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z",
  key: "1t2lqe"
}], ["path", {
  d: "M10 21.9V14L2.1 9.1",
  key: "o7czzq"
}], ["path", {
  d: "m10 14 11.9-6.9",
  key: "zm5e20"
}], ["path", {
  d: "M14 19.8v-8.1",
  key: "159ecu"
}], ["path", {
  d: "M18 17.5V9.4",
  key: "11uown"
}]];
var Contrast = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 18a6 6 0 0 0 0-12v12z",
  key: "j4l70d"
}]];
var Cookie = [["path", {
  d: "M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5",
  key: "laymnq"
}], ["path", {
  d: "M8.5 8.5v.01",
  key: "ue8clq"
}], ["path", {
  d: "M16 15.5v.01",
  key: "14dtrp"
}], ["path", {
  d: "M12 12v.01",
  key: "u5ubse"
}], ["path", {
  d: "M11 17v.01",
  key: "1hyl5a"
}], ["path", {
  d: "M7 14v.01",
  key: "uct60s"
}]];
var CookingPot = [["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "M20 12v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8",
  key: "u0tga0"
}], ["path", {
  d: "m4 8 16-4",
  key: "16g0ng"
}], ["path", {
  d: "m8.86 6.78-.45-1.81a2 2 0 0 1 1.45-2.43l1.94-.48a2 2 0 0 1 2.43 1.46l.45 1.8",
  key: "12cejc"
}]];
var CopyCheck = [["path", {
  d: "m12 15 2 2 4-4",
  key: "2c609p"
}], ["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var CopyMinus = [["line", {
  x1: "12",
  x2: "18",
  y1: "15",
  y2: "15",
  key: "1nscbv"
}], ["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var CopyPlus = [["line", {
  x1: "15",
  x2: "15",
  y1: "12",
  y2: "18",
  key: "1p7wdc"
}], ["line", {
  x1: "12",
  x2: "18",
  y1: "15",
  y2: "15",
  key: "1nscbv"
}], ["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var CopySlash = [["line", {
  x1: "12",
  x2: "18",
  y1: "18",
  y2: "12",
  key: "ebkxgr"
}], ["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var CopyX = [["line", {
  x1: "12",
  x2: "18",
  y1: "12",
  y2: "18",
  key: "1rg63v"
}], ["line", {
  x1: "12",
  x2: "18",
  y1: "18",
  y2: "12",
  key: "ebkxgr"
}], ["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var Copy = [["rect", {
  width: "14",
  height: "14",
  x: "8",
  y: "8",
  rx: "2",
  ry: "2",
  key: "17jyea"
}], ["path", {
  d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
  key: "zix9uf"
}]];
var Copyleft = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M9.17 14.83a4 4 0 1 0 0-5.66",
  key: "1sveal"
}]];
var Copyright = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M14.83 14.83a4 4 0 1 1 0-5.66",
  key: "1i56pz"
}]];
var CornerDownLeft = [["path", {
  d: "M20 4v7a4 4 0 0 1-4 4H4",
  key: "6o5b7l"
}], ["path", {
  d: "m9 10-5 5 5 5",
  key: "1kshq7"
}]];
var CornerDownRight = [["path", {
  d: "m15 10 5 5-5 5",
  key: "qqa56n"
}], ["path", {
  d: "M4 4v7a4 4 0 0 0 4 4h12",
  key: "z08zvw"
}]];
var CornerLeftDown = [["path", {
  d: "m14 15-5 5-5-5",
  key: "1eia93"
}], ["path", {
  d: "M20 4h-7a4 4 0 0 0-4 4v12",
  key: "nbpdq2"
}]];
var CornerLeftUp = [["path", {
  d: "M14 9 9 4 4 9",
  key: "1af5af"
}], ["path", {
  d: "M20 20h-7a4 4 0 0 1-4-4V4",
  key: "1blwi3"
}]];
var CornerRightDown = [["path", {
  d: "m10 15 5 5 5-5",
  key: "1hpjnr"
}], ["path", {
  d: "M4 4h7a4 4 0 0 1 4 4v12",
  key: "wcbgct"
}]];
var CornerUpLeft = [["path", {
  d: "M20 20v-7a4 4 0 0 0-4-4H4",
  key: "1nkjon"
}], ["path", {
  d: "M9 14 4 9l5-5",
  key: "102s5s"
}]];
var CornerRightUp = [["path", {
  d: "m10 9 5-5 5 5",
  key: "9ctzwi"
}], ["path", {
  d: "M4 20h7a4 4 0 0 0 4-4V4",
  key: "1plgdj"
}]];
var CornerUpRight = [["path", {
  d: "m15 14 5-5-5-5",
  key: "12vg1m"
}], ["path", {
  d: "M4 20v-7a4 4 0 0 1 4-4h12",
  key: "1lu4f8"
}]];
var Cpu = [["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M17 20v2",
  key: "1rnc9c"
}], ["path", {
  d: "M17 2v2",
  key: "11trls"
}], ["path", {
  d: "M2 12h2",
  key: "1t8f8n"
}], ["path", {
  d: "M2 17h2",
  key: "7oei6x"
}], ["path", {
  d: "M2 7h2",
  key: "asdhe0"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}], ["path", {
  d: "M20 17h2",
  key: "1fpfkl"
}], ["path", {
  d: "M20 7h2",
  key: "1o8tra"
}], ["path", {
  d: "M7 20v2",
  key: "4gnj0m"
}], ["path", {
  d: "M7 2v2",
  key: "1i4yhu"
}], ["rect", {
  x: "4",
  y: "4",
  width: "16",
  height: "16",
  rx: "2",
  key: "1vbyd7"
}], ["rect", {
  x: "8",
  y: "8",
  width: "8",
  height: "8",
  rx: "1",
  key: "z9xiuo"
}]];
var CreativeCommons = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M10 9.3a2.8 2.8 0 0 0-3.5 1 3.1 3.1 0 0 0 0 3.4 2.7 2.7 0 0 0 3.5 1",
  key: "1ss3eq"
}], ["path", {
  d: "M17 9.3a2.8 2.8 0 0 0-3.5 1 3.1 3.1 0 0 0 0 3.4 2.7 2.7 0 0 0 3.5 1",
  key: "1od56t"
}]];
var CreditCard = [["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "5",
  rx: "2",
  key: "ynyp8z"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "10",
  y2: "10",
  key: "1b3vmo"
}]];
var Croissant = [["path", {
  d: "M10.2 18H4.774a1.5 1.5 0 0 1-1.352-.97 11 11 0 0 1 .132-6.487",
  key: "14kkz9"
}], ["path", {
  d: "M18 10.2V4.774a1.5 1.5 0 0 0-.97-1.352 11 11 0 0 0-6.486.132",
  key: "1g7v07"
}], ["path", {
  d: "M18 5a4 3 0 0 1 4 3 2 2 0 0 1-2 2 10 10 0 0 0-5.139 1.42",
  key: "ratg6b"
}], ["path", {
  d: "M5 18a3 4 0 0 0 3 4 2 2 0 0 0 2-2 10 10 0 0 1 1.42-5.14",
  key: "4454f0"
}], ["path", {
  d: "M8.709 2.554a10 10 0 0 0-6.155 6.155 1.5 1.5 0 0 0 .676 1.626l9.807 5.42a2 2 0 0 0 2.718-2.718l-5.42-9.807a1.5 1.5 0 0 0-1.626-.676",
  key: "qmemie"
}]];
var Crop = [["path", {
  d: "M6 2v14a2 2 0 0 0 2 2h14",
  key: "ron5a4"
}], ["path", {
  d: "M18 22V8a2 2 0 0 0-2-2H2",
  key: "7s9ehn"
}]];
var Crosshair = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "22",
  x2: "18",
  y1: "12",
  y2: "12",
  key: "l9bcsi"
}], ["line", {
  x1: "6",
  x2: "2",
  y1: "12",
  y2: "12",
  key: "13hhkx"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "6",
  y2: "2",
  key: "10w3f3"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "22",
  y2: "18",
  key: "15g9kq"
}]];
var Cross = [["path", {
  d: "M4 9a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h4a1 1 0 0 1 1 1v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a1 1 0 0 1 1-1h4a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-4a1 1 0 0 1-1-1V4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4a1 1 0 0 1-1 1z",
  key: "1xbrqy"
}]];
var Crown = [["path", {
  d: "M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",
  key: "1vdc57"
}], ["path", {
  d: "M5 21h14",
  key: "11awu3"
}]];
var Cuboid = [["path", {
  d: "M10 22v-8",
  key: "1f8443"
}], ["path", {
  d: "M2.336 8.89 10 14l11.715-7.029",
  key: "1qnufy"
}], ["path", {
  d: "M22 14a2 2 0 0 1-.971 1.715l-10 6a2 2 0 0 1-2.138-.05l-6-4A2 2 0 0 1 2 16v-6a2 2 0 0 1 .971-1.715l10-6a2 2 0 0 1 2.138.05l6 4A2 2 0 0 1 22 8z",
  key: "670npk"
}]];
var CupSoda = [["path", {
  d: "m6 8 1.75 12.28a2 2 0 0 0 2 1.72h4.54a2 2 0 0 0 2-1.72L18 8",
  key: "8166m8"
}], ["path", {
  d: "M5 8h14",
  key: "pcz4l3"
}], ["path", {
  d: "M7 15a6.47 6.47 0 0 1 5 0 6.47 6.47 0 0 0 5 0",
  key: "yjz344"
}], ["path", {
  d: "m12 8 1-6h2",
  key: "3ybfa4"
}]];
var Currency = [["circle", {
  cx: "12",
  cy: "12",
  r: "8",
  key: "46899m"
}], ["line", {
  x1: "3",
  x2: "6",
  y1: "3",
  y2: "6",
  key: "1jkytn"
}], ["line", {
  x1: "21",
  x2: "18",
  y1: "3",
  y2: "6",
  key: "14zfjt"
}], ["line", {
  x1: "3",
  x2: "6",
  y1: "21",
  y2: "18",
  key: "iusuec"
}], ["line", {
  x1: "21",
  x2: "18",
  y1: "21",
  y2: "18",
  key: "yj2dd7"
}]];
var Cylinder = [["ellipse", {
  cx: "12",
  cy: "5",
  rx: "9",
  ry: "3",
  key: "msslwz"
}], ["path", {
  d: "M3 5v14a9 3 0 0 0 18 0V5",
  key: "aqi0yr"
}]];
var DatabaseBackup = [["ellipse", {
  cx: "12",
  cy: "5",
  rx: "9",
  ry: "3",
  key: "msslwz"
}], ["path", {
  d: "M3 12a9 3 0 0 0 5 2.69",
  key: "1ui2ym"
}], ["path", {
  d: "M21 9.3V5",
  key: "6k6cib"
}], ["path", {
  d: "M3 5v14a9 3 0 0 0 6.47 2.88",
  key: "i62tjy"
}], ["path", {
  d: "M12 12v4h4",
  key: "1bxaet"
}], ["path", {
  d: "M13 20a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5c-1.33 0-2.54.54-3.41 1.41L12 16",
  key: "1f4ei9"
}]];
var Dam = [["path", {
  d: "M11 11.31c1.17.56 1.54 1.69 3.5 1.69 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "157kva"
}], ["path", {
  d: "M11.75 18c.35.5 1.45 1 2.75 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "d7q6m6"
}], ["path", {
  d: "M2 10h4",
  key: "l0bgd4"
}], ["path", {
  d: "M2 14h4",
  key: "1gsvsf"
}], ["path", {
  d: "M2 18h4",
  key: "1bu2t1"
}], ["path", {
  d: "M2 6h4",
  key: "aawbzj"
}], ["path", {
  d: "M7 3a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1L10 4a1 1 0 0 0-1-1z",
  key: "pr6s65"
}]];
var DatabaseSearch = [["path", {
  d: "M21 11.693V5",
  key: "175m1t"
}], ["path", {
  d: "m22 22-1.875-1.875",
  key: "13zax7"
}], ["path", {
  d: "M3 12a9 3 0 0 0 8.697 2.998",
  key: "151u9p"
}], ["path", {
  d: "M3 5v14a9 3 0 0 0 9.28 2.999",
  key: "q2rs2p"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["ellipse", {
  cx: "12",
  cy: "5",
  rx: "9",
  ry: "3",
  key: "msslwz"
}]];
var DatabaseZap = [["ellipse", {
  cx: "12",
  cy: "5",
  rx: "9",
  ry: "3",
  key: "msslwz"
}], ["path", {
  d: "M3 5V19A9 3 0 0 0 15 21.84",
  key: "14ibmq"
}], ["path", {
  d: "M21 5V8",
  key: "1marbg"
}], ["path", {
  d: "M21 12L18 17H22L19 22",
  key: "zafso"
}], ["path", {
  d: "M3 12A9 3 0 0 0 14.59 14.87",
  key: "1y4wr8"
}]];
var Database = [["ellipse", {
  cx: "12",
  cy: "5",
  rx: "9",
  ry: "3",
  key: "msslwz"
}], ["path", {
  d: "M3 5V19A9 3 0 0 0 21 19V5",
  key: "1wlel7"
}], ["path", {
  d: "M3 12A9 3 0 0 0 21 12",
  key: "mv7ke4"
}]];
var DecimalsArrowLeft = [["path", {
  d: "m13 21-3-3 3-3",
  key: "s3o1nf"
}], ["path", {
  d: "M20 18H10",
  key: "14r3mt"
}], ["path", {
  d: "M3 11h.01",
  key: "1eifu7"
}], ["rect", {
  x: "6",
  y: "3",
  width: "5",
  height: "8",
  rx: "2.5",
  key: "v9paqo"
}]];
var DecimalsArrowRight = [["path", {
  d: "M10 18h10",
  key: "1y5s8o"
}], ["path", {
  d: "m17 21 3-3-3-3",
  key: "1ammt0"
}], ["path", {
  d: "M3 11h.01",
  key: "1eifu7"
}], ["rect", {
  x: "15",
  y: "3",
  width: "5",
  height: "8",
  rx: "2.5",
  key: "76md6a"
}], ["rect", {
  x: "6",
  y: "3",
  width: "5",
  height: "8",
  rx: "2.5",
  key: "v9paqo"
}]];
var Delete = [["path", {
  d: "M10 5a2 2 0 0 0-1.344.519l-6.328 5.74a1 1 0 0 0 0 1.481l6.328 5.741A2 2 0 0 0 10 19h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z",
  key: "1yo7s0"
}], ["path", {
  d: "m12 9 6 6",
  key: "anjzzh"
}], ["path", {
  d: "m18 9-6 6",
  key: "1fp51s"
}]];
var Dessert = [["path", {
  d: "M10.162 3.167A10 10 0 0 0 2 13a2 2 0 0 0 4 0v-1a2 2 0 0 1 4 0v4a2 2 0 0 0 4 0v-4a2 2 0 0 1 4 0v1a2 2 0 0 0 4-.006 10 10 0 0 0-8.161-9.826",
  key: "xi88qy"
}], ["path", {
  d: "M20.804 14.869a9 9 0 0 1-17.608 0",
  key: "1r28rg"
}], ["circle", {
  cx: "12",
  cy: "4",
  r: "2",
  key: "muu5ef"
}]];
var Diameter = [["circle", {
  cx: "19",
  cy: "19",
  r: "2",
  key: "17f5cg"
}], ["circle", {
  cx: "5",
  cy: "5",
  r: "2",
  key: "1gwv83"
}], ["path", {
  d: "M6.48 3.66a10 10 0 0 1 13.86 13.86",
  key: "xr8kdq"
}], ["path", {
  d: "m6.41 6.41 11.18 11.18",
  key: "uhpjw7"
}], ["path", {
  d: "M3.66 6.48a10 10 0 0 0 13.86 13.86",
  key: "cldpwv"
}]];
var DiamondMinus = [["path", {
  d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0z",
  key: "1ey20j"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var DiamondPercent = [["path", {
  d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0Z",
  key: "1tpxz2"
}], ["path", {
  d: "M9.2 9.2h.01",
  key: "1b7bvt"
}], ["path", {
  d: "m14.5 9.5-5 5",
  key: "17q4r4"
}], ["path", {
  d: "M14.7 14.8h.01",
  key: "17nsh4"
}]];
var DiamondPlus = [["path", {
  d: "M12 8v8",
  key: "napkw2"
}], ["path", {
  d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0z",
  key: "1ey20j"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var Diamond = [["path", {
  d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z",
  key: "1f1r0c"
}]];
var Dice1 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}]];
var Dice2 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M15 9h.01",
  key: "x1ddxp"
}], ["path", {
  d: "M9 15h.01",
  key: "fzyn71"
}]];
var Dice3 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M16 8h.01",
  key: "cr5u4v"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}]];
var Dice4 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M16 8h.01",
  key: "cr5u4v"
}], ["path", {
  d: "M8 8h.01",
  key: "1e4136"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}], ["path", {
  d: "M16 16h.01",
  key: "1f9h7w"
}]];
var Dice5 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M16 8h.01",
  key: "cr5u4v"
}], ["path", {
  d: "M8 8h.01",
  key: "1e4136"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}], ["path", {
  d: "M16 16h.01",
  key: "1f9h7w"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}]];
var Dice6 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M16 8h.01",
  key: "cr5u4v"
}], ["path", {
  d: "M16 12h.01",
  key: "1l6xoz"
}], ["path", {
  d: "M16 16h.01",
  key: "1f9h7w"
}], ["path", {
  d: "M8 8h.01",
  key: "1e4136"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}]];
var Dices = [["rect", {
  width: "12",
  height: "12",
  x: "2",
  y: "10",
  rx: "2",
  ry: "2",
  key: "6agr2n"
}], ["path", {
  d: "m17.92 14 3.5-3.5a2.24 2.24 0 0 0 0-3l-5-4.92a2.24 2.24 0 0 0-3 0L10 6",
  key: "1o487t"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "M10 14h.01",
  key: "ssrbsk"
}], ["path", {
  d: "M15 6h.01",
  key: "cblpky"
}], ["path", {
  d: "M18 9h.01",
  key: "2061c0"
}]];
var Diff = [["path", {
  d: "M12 3v14",
  key: "7cf3v8"
}], ["path", {
  d: "M5 10h14",
  key: "elsbfy"
}], ["path", {
  d: "M5 21h14",
  key: "11awu3"
}]];
var Disc2 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}]];
var Disc3 = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M6 12c0-1.7.7-3.2 1.8-4.2",
  key: "oqkarx"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["path", {
  d: "M18 12c0 1.7-.7 3.2-1.8 4.2",
  key: "1eah9h"
}]];
var DiscAlbum = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "5",
  key: "nd82uf"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}]];
var Disc = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var Divide = [["circle", {
  cx: "12",
  cy: "6",
  r: "1",
  key: "1bh7o1"
}], ["line", {
  x1: "5",
  x2: "19",
  y1: "12",
  y2: "12",
  key: "13b5wn"
}], ["circle", {
  cx: "12",
  cy: "18",
  r: "1",
  key: "lqb9t5"
}]];
var DnaOff = [["path", {
  d: "M15 2c-1.35 1.5-2.092 3-2.5 4.5L14 8",
  key: "1bivrr"
}], ["path", {
  d: "m17 6-2.891-2.891",
  key: "xu6p2f"
}], ["path", {
  d: "M2 15c3.333-3 6.667-3 10-3",
  key: "nxix30"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "m20 9 .891.891",
  key: "3xwk7g"
}], ["path", {
  d: "M22 9c-1.5 1.35-3 2.092-4.5 2.5l-1-1",
  key: "18cutr"
}], ["path", {
  d: "M3.109 14.109 4 15",
  key: "q76aoh"
}], ["path", {
  d: "m6.5 12.5 1 1",
  key: "cs35ky"
}], ["path", {
  d: "m7 18 2.891 2.891",
  key: "1sisit"
}], ["path", {
  d: "M9 22c1.35-1.5 2.092-3 2.5-4.5L10 16",
  key: "rlvei3"
}]];
var Dna = [["path", {
  d: "m10 16 1.5 1.5",
  key: "11lckj"
}], ["path", {
  d: "m14 8-1.5-1.5",
  key: "1ohn8i"
}], ["path", {
  d: "M15 2c-1.798 1.998-2.518 3.995-2.807 5.993",
  key: "80uv8i"
}], ["path", {
  d: "m16.5 10.5 1 1",
  key: "696xn5"
}], ["path", {
  d: "m17 6-2.891-2.891",
  key: "xu6p2f"
}], ["path", {
  d: "M2 15c6.667-6 13.333 0 20-6",
  key: "1pyr53"
}], ["path", {
  d: "m20 9 .891.891",
  key: "3xwk7g"
}], ["path", {
  d: "M3.109 14.109 4 15",
  key: "q76aoh"
}], ["path", {
  d: "m6.5 12.5 1 1",
  key: "cs35ky"
}], ["path", {
  d: "m7 18 2.891 2.891",
  key: "1sisit"
}], ["path", {
  d: "M9 22c1.798-1.998 2.518-3.995 2.807-5.993",
  key: "q3hbxp"
}]];
var Dock = [["path", {
  d: "M2 8h20",
  key: "d11cs7"
}], ["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M6 16h12",
  key: "u522kt"
}]];
var Dog = [["path", {
  d: "M11.25 16.25h1.5L12 17z",
  key: "w7jh35"
}], ["path", {
  d: "M16 14v.5",
  key: "1lajdz"
}], ["path", {
  d: "M4.42 11.247A13.152 13.152 0 0 0 4 14.556C4 18.728 7.582 21 12 21s8-2.272 8-6.444a11.702 11.702 0 0 0-.493-3.309",
  key: "u7s9ue"
}], ["path", {
  d: "M8 14v.5",
  key: "1nzgdb"
}], ["path", {
  d: "M8.5 8.5c-.384 1.05-1.083 2.028-2.344 2.5-1.931.722-3.576-.297-3.656-1-.113-.994 1.177-6.53 4-7 1.923-.321 3.651.845 3.651 2.235A7.497 7.497 0 0 1 14 5.277c0-1.39 1.844-2.598 3.767-2.277 2.823.47 4.113 6.006 4 7-.08.703-1.725 1.722-3.656 1-1.261-.472-1.855-1.45-2.239-2.5",
  key: "v8hric"
}]];
var DollarSign = [["line", {
  x1: "12",
  x2: "12",
  y1: "2",
  y2: "22",
  key: "7eqyqh"
}], ["path", {
  d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
  key: "1b0p4s"
}]];
var Donut = [["path", {
  d: "M20.5 10a2.5 2.5 0 0 1-2.4-3H18a2.95 2.95 0 0 1-2.6-4.4 10 10 0 1 0 6.3 7.1c-.3.2-.8.3-1.2.3",
  key: "19sr3x"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}]];
var DoorClosedLocked = [["path", {
  d: "M10 12h.01",
  key: "1kxr2c"
}], ["path", {
  d: "M18 9V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14",
  key: "1bnhmg"
}], ["path", {
  d: "M2 20h8",
  key: "10ntw1"
}], ["path", {
  d: "M20 17v-2a2 2 0 1 0-4 0v2",
  key: "pwaxnr"
}], ["rect", {
  x: "14",
  y: "17",
  width: "8",
  height: "5",
  rx: "1",
  key: "15pjcy"
}]];
var DoorOpen = [["path", {
  d: "M11 20H2",
  key: "nlcfvz"
}], ["path", {
  d: "M11 4.562v16.157a1 1 0 0 0 1.242.97L19 20V5.562a2 2 0 0 0-1.515-1.94l-4-1A2 2 0 0 0 11 4.561z",
  key: "au4z13"
}], ["path", {
  d: "M11 4H8a2 2 0 0 0-2 2v14",
  key: "74r1mk"
}], ["path", {
  d: "M14 12h.01",
  key: "1jfl7z"
}], ["path", {
  d: "M22 20h-3",
  key: "vhrsz"
}]];
var DoorClosed = [["path", {
  d: "M10 12h.01",
  key: "1kxr2c"
}], ["path", {
  d: "M18 20V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14",
  key: "36qu9e"
}], ["path", {
  d: "M2 20h20",
  key: "owomy5"
}]];
var Dot = [["circle", {
  cx: "12.1",
  cy: "12.1",
  r: "1",
  key: "18d7e5"
}]];
var Download = [["path", {
  d: "M12 15V3",
  key: "m9g1x1"
}], ["path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
  key: "ih7n3h"
}], ["path", {
  d: "m7 10 5 5 5-5",
  key: "brsn70"
}]];
var DraftingCompass = [["path", {
  d: "m12.99 6.74 1.93 3.44",
  key: "iwagvd"
}], ["path", {
  d: "M19.136 12a10 10 0 0 1-14.271 0",
  key: "ppmlo4"
}], ["path", {
  d: "m21 21-2.16-3.84",
  key: "vylbct"
}], ["path", {
  d: "m3 21 8.02-14.26",
  key: "1ssaw4"
}], ["circle", {
  cx: "12",
  cy: "5",
  r: "2",
  key: "f1ur92"
}]];
var Drama = [["path", {
  d: "M10 11h.01",
  key: "d2at3l"
}], ["path", {
  d: "M14 6h.01",
  key: "k028ub"
}], ["path", {
  d: "M18 6h.01",
  key: "1v4wsw"
}], ["path", {
  d: "M6.5 13.1h.01",
  key: "1748ia"
}], ["path", {
  d: "M22 5c0 9-4 12-6 12s-6-3-6-12c0-2 2-3 6-3s6 1 6 3",
  key: "172yzv"
}], ["path", {
  d: "M17.4 9.9c-.8.8-2 .8-2.8 0",
  key: "1obv0w"
}], ["path", {
  d: "M10.1 7.1C9 7.2 7.7 7.7 6 8.6c-3.5 2-4.7 3.9-3.7 5.6 4.5 7.8 9.5 8.4 11.2 7.4.9-.5 1.9-2.1 1.9-4.7",
  key: "rqjl8i"
}], ["path", {
  d: "M9.1 16.5c.3-1.1 1.4-1.7 2.4-1.4",
  key: "1mr6wy"
}]];
var Dribbble = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94",
  key: "hpej1"
}], ["path", {
  d: "M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32",
  key: "1tr44o"
}], ["path", {
  d: "M8.56 2.75c4.37 6 6 9.42 8 17.72",
  key: "kbh691"
}]];
var Drill = [["path", {
  d: "M10 18a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H5a3 3 0 0 1-3-3 1 1 0 0 1 1-1z",
  key: "ioqxb1"
}], ["path", {
  d: "M13 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1l-.81 3.242a1 1 0 0 1-.97.758H8",
  key: "1rs59n"
}], ["path", {
  d: "M14 4h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-3",
  key: "105ega"
}], ["path", {
  d: "M18 6h4",
  key: "66u95g"
}], ["path", {
  d: "m5 10-2 8",
  key: "xt2lic"
}], ["path", {
  d: "m7 18 2-8",
  key: "1bzku2"
}]];
var Drone = [["path", {
  d: "M10 10 7 7",
  key: "zp14k7"
}], ["path", {
  d: "m10 14-3 3",
  key: "1jrpxk"
}], ["path", {
  d: "m14 10 3-3",
  key: "7tigam"
}], ["path", {
  d: "m14 14 3 3",
  key: "vm23p3"
}], ["path", {
  d: "M14.205 4.139a4 4 0 1 1 5.439 5.863",
  key: "1tm5p2"
}], ["path", {
  d: "M19.637 14a4 4 0 1 1-5.432 5.868",
  key: "16egi2"
}], ["path", {
  d: "M4.367 10a4 4 0 1 1 5.438-5.862",
  key: "1wta6a"
}], ["path", {
  d: "M9.795 19.862a4 4 0 1 1-5.429-5.873",
  key: "q39hpv"
}], ["rect", {
  x: "10",
  y: "8",
  width: "4",
  height: "8",
  rx: "1",
  key: "phrjt1"
}]];
var DropletOff = [["path", {
  d: "M18.715 13.186C18.29 11.858 17.384 10.607 16 9.5c-2-1.6-3.5-4-4-6.5a10.7 10.7 0 0 1-.884 2.586",
  key: "8suz2t"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.795 8.797A11 11 0 0 1 8 9.5C6 11.1 5 13 5 15a7 7 0 0 0 13.222 3.208",
  key: "19dw9m"
}]];
var Droplet = [["path", {
  d: "M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",
  key: "c7niix"
}]];
var Droplets = [["path", {
  d: "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",
  key: "1ptgy4"
}], ["path", {
  d: "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",
  key: "1sl1rz"
}]];
var Drum = [["path", {
  d: "m2 2 8 8",
  key: "1v6059"
}], ["path", {
  d: "m22 2-8 8",
  key: "173r8a"
}], ["ellipse", {
  cx: "12",
  cy: "9",
  rx: "10",
  ry: "5",
  key: "liohsx"
}], ["path", {
  d: "M7 13.4v7.9",
  key: "1yi6u9"
}], ["path", {
  d: "M12 14v8",
  key: "1tn2tj"
}], ["path", {
  d: "M17 13.4v7.9",
  key: "eqz2v3"
}], ["path", {
  d: "M2 9v8a10 5 0 0 0 20 0V9",
  key: "1750ul"
}]];
var Drumstick = [["path", {
  d: "M15.4 15.63a7.875 6 135 1 1 6.23-6.23 4.5 3.43 135 0 0-6.23 6.23",
  key: "1dtqwm"
}], ["path", {
  d: "m8.29 12.71-2.6 2.6a2.5 2.5 0 1 0-1.65 4.65A2.5 2.5 0 1 0 8.7 18.3l2.59-2.59",
  key: "1oq1fw"
}]];
var Dumbbell = [["path", {
  d: "M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z",
  key: "9m4mmf"
}], ["path", {
  d: "m2.5 21.5 1.4-1.4",
  key: "17g3f0"
}], ["path", {
  d: "m20.1 3.9 1.4-1.4",
  key: "1qn309"
}], ["path", {
  d: "M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z",
  key: "1t2c92"
}], ["path", {
  d: "m9.6 14.4 4.8-4.8",
  key: "6umqxw"
}]];
var EarOff = [["path", {
  d: "M6 18.5a3.5 3.5 0 1 0 7 0c0-1.57.92-2.52 2.04-3.46",
  key: "1qngmn"
}], ["path", {
  d: "M6 8.5c0-.75.13-1.47.36-2.14",
  key: "b06bma"
}], ["path", {
  d: "M8.8 3.15A6.5 6.5 0 0 1 19 8.5c0 1.63-.44 2.81-1.09 3.76",
  key: "g10hsz"
}], ["path", {
  d: "M12.5 6A2.5 2.5 0 0 1 15 8.5M10 13a2 2 0 0 0 1.82-1.18",
  key: "ygzou7"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Ear = [["path", {
  d: "M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0",
  key: "1dfaln"
}], ["path", {
  d: "M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4",
  key: "1qnva7"
}]];
var EarthLock = [["path", {
  d: "M7 3.34V5a3 3 0 0 0 3 3",
  key: "w732o8"
}], ["path", {
  d: "M11 21.95V18a2 2 0 0 0-2-2 2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",
  key: "f02343"
}], ["path", {
  d: "M21.54 15H17a2 2 0 0 0-2 2v4.54",
  key: "1djwo0"
}], ["path", {
  d: "M12 2a10 10 0 1 0 9.54 13",
  key: "zjsr6q"
}], ["path", {
  d: "M20 6V4a2 2 0 1 0-4 0v2",
  key: "1of5e8"
}], ["rect", {
  width: "8",
  height: "5",
  x: "14",
  y: "6",
  rx: "1",
  key: "1fmf51"
}]];
var Earth = [["path", {
  d: "M21.54 15H17a2 2 0 0 0-2 2v4.54",
  key: "1djwo0"
}], ["path", {
  d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
  key: "1tzkfa"
}], ["path", {
  d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",
  key: "14pb5j"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var Eclipse = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 2a7 7 0 1 0 10 10",
  key: "1yuj32"
}]];
var EggFried = [["circle", {
  cx: "11.5",
  cy: "12.5",
  r: "3.5",
  key: "1cl1mi"
}], ["path", {
  d: "M3 8c0-3.5 2.5-6 6.5-6 5 0 4.83 3 7.5 5s5 2 5 6c0 4.5-2.5 6.5-7 6.5-2.5 0-2.5 2.5-6 2.5s-7-2-7-5.5c0-3 1.5-3 1.5-5C3.5 10 3 9 3 8Z",
  key: "165ef9"
}]];
var EggOff = [["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20 14.347V14c0-6-4-12-8-12-1.078 0-2.157.436-3.157 1.19",
  key: "13g2jy"
}], ["path", {
  d: "M6.206 6.21C4.871 8.4 4 11.2 4 14a8 8 0 0 0 14.568 4.568",
  key: "1581id"
}]];
var Egg = [["path", {
  d: "M12 2C8 2 4 8 4 14a8 8 0 0 0 16 0c0-6-4-12-8-12",
  key: "1le142"
}]];
var Ellipse = [["ellipse", {
  cx: "12",
  cy: "12",
  rx: "10",
  ry: "6",
  key: "swdkt4"
}]];
var EllipsisVertical = [["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["circle", {
  cx: "12",
  cy: "5",
  r: "1",
  key: "gxeob9"
}], ["circle", {
  cx: "12",
  cy: "19",
  r: "1",
  key: "lyex9k"
}]];
var Ellipsis = [["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["circle", {
  cx: "19",
  cy: "12",
  r: "1",
  key: "1wjl8i"
}], ["circle", {
  cx: "5",
  cy: "12",
  r: "1",
  key: "1pcz8c"
}]];
var EqualApproximately = [["path", {
  d: "M5 15a6.5 6.5 0 0 1 7 0 6.5 6.5 0 0 0 7 0",
  key: "yrdkhy"
}], ["path", {
  d: "M5 9a6.5 6.5 0 0 1 7 0 6.5 6.5 0 0 0 7 0",
  key: "gzkvyz"
}]];
var EqualNot = [["line", {
  x1: "5",
  x2: "19",
  y1: "9",
  y2: "9",
  key: "1nwqeh"
}], ["line", {
  x1: "5",
  x2: "19",
  y1: "15",
  y2: "15",
  key: "g8yjpy"
}], ["line", {
  x1: "19",
  x2: "5",
  y1: "5",
  y2: "19",
  key: "1x9vlm"
}]];
var Eraser = [["path", {
  d: "M21 21H8a2 2 0 0 1-1.42-.587l-3.994-3.999a2 2 0 0 1 0-2.828l10-10a2 2 0 0 1 2.829 0l5.999 6a2 2 0 0 1 0 2.828L12.834 21",
  key: "g5wo59"
}], ["path", {
  d: "m5.082 11.09 8.828 8.828",
  key: "1wx5vj"
}]];
var Equal = [["line", {
  x1: "5",
  x2: "19",
  y1: "9",
  y2: "9",
  key: "1nwqeh"
}], ["line", {
  x1: "5",
  x2: "19",
  y1: "15",
  y2: "15",
  key: "g8yjpy"
}]];
var EthernetPort = [["path", {
  d: "m15 20 3-3h2a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h2l3 3z",
  key: "rbahqx"
}], ["path", {
  d: "M6 8v1",
  key: "1636ez"
}], ["path", {
  d: "M10 8v1",
  key: "1talb4"
}], ["path", {
  d: "M14 8v1",
  key: "1rsfgr"
}], ["path", {
  d: "M18 8v1",
  key: "gnkwox"
}]];
var Euro = [["path", {
  d: "M4 10h12",
  key: "1y6xl8"
}], ["path", {
  d: "M4 14h9",
  key: "1loblj"
}], ["path", {
  d: "M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 7.8 8 2 0 3.8-.8 5.2-2",
  key: "1j6lzo"
}]];
var EvCharger = [["path", {
  d: "M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 4 0v-6.998a2 2 0 0 0-.59-1.42L18 5",
  key: "1wtuz0"
}], ["path", {
  d: "M14 21V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v16",
  key: "e09ifn"
}], ["path", {
  d: "M2 21h13",
  key: "1x0fut"
}], ["path", {
  d: "M3 7h11",
  key: "19efrr"
}], ["path", {
  d: "m9 11-2 3h3l-2 3",
  key: "lmzxi1"
}]];
var Expand = [["path", {
  d: "m15 15 6 6",
  key: "1s409w"
}], ["path", {
  d: "m15 9 6-6",
  key: "ko1vev"
}], ["path", {
  d: "M21 16v5h-5",
  key: "1ck2sf"
}], ["path", {
  d: "M21 8V3h-5",
  key: "1qoq8a"
}], ["path", {
  d: "M3 16v5h5",
  key: "1t08am"
}], ["path", {
  d: "m3 21 6-6",
  key: "wwnumi"
}], ["path", {
  d: "M3 8V3h5",
  key: "1ln10m"
}], ["path", {
  d: "M9 9 3 3",
  key: "v551iv"
}]];
var ExternalLink = [["path", {
  d: "M15 3h6v6",
  key: "1q9fwt"
}], ["path", {
  d: "M10 14 21 3",
  key: "gplh6r"
}], ["path", {
  d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
  key: "a6xqqp"
}]];
var EyeClosed = [["path", {
  d: "m15 18-.722-3.25",
  key: "1j64jw"
}], ["path", {
  d: "M2 8a10.645 10.645 0 0 0 20 0",
  key: "1e7gxb"
}], ["path", {
  d: "m20 15-1.726-2.05",
  key: "1cnuld"
}], ["path", {
  d: "m4 15 1.726-2.05",
  key: "1dsqqd"
}], ["path", {
  d: "m9 18 .722-3.25",
  key: "ypw2yx"
}]];
var EyeOff = [["path", {
  d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
  key: "ct8e1f"
}], ["path", {
  d: "M14.084 14.158a3 3 0 0 1-4.242-4.242",
  key: "151rxh"
}], ["path", {
  d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
  key: "13bj9a"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Eye = [["path", {
  d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
  key: "1nclc0"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}]];
var Factory = [["path", {
  d: "M12 16h.01",
  key: "1drbdi"
}], ["path", {
  d: "M16 16h.01",
  key: "1f9h7w"
}], ["path", {
  d: "M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",
  key: "1iv0i2"
}], ["path", {
  d: "M8 16h.01",
  key: "18s6g9"
}]];
var Fan = [["path", {
  d: "M10.827 16.379a6.082 6.082 0 0 1-8.618-7.002l5.412 1.45a6.082 6.082 0 0 1 7.002-8.618l-1.45 5.412a6.082 6.082 0 0 1 8.618 7.002l-5.412-1.45a6.082 6.082 0 0 1-7.002 8.618l1.45-5.412Z",
  key: "484a7f"
}], ["path", {
  d: "M12 12v.01",
  key: "u5ubse"
}]];
var Facebook = [["path", {
  d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",
  key: "1jg4f8"
}]];
var FastForward = [["path", {
  d: "M12 6a2 2 0 0 1 3.414-1.414l6 6a2 2 0 0 1 0 2.828l-6 6A2 2 0 0 1 12 18z",
  key: "b19h5q"
}], ["path", {
  d: "M2 6a2 2 0 0 1 3.414-1.414l6 6a2 2 0 0 1 0 2.828l-6 6A2 2 0 0 1 2 18z",
  key: "h7h5ge"
}]];
var Feather = [["path", {
  d: "M12.67 19a2 2 0 0 0 1.416-.588l6.154-6.172a6 6 0 0 0-8.49-8.49L5.586 9.914A2 2 0 0 0 5 11.328V18a1 1 0 0 0 1 1z",
  key: "18jl4k"
}], ["path", {
  d: "M16 8 2 22",
  key: "vp34q"
}], ["path", {
  d: "M17.5 15H9",
  key: "1oz8nu"
}]];
var Fence = [["path", {
  d: "M4 3 2 5v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",
  key: "1n2rgs"
}], ["path", {
  d: "M6 8h4",
  key: "utf9t1"
}], ["path", {
  d: "M6 18h4",
  key: "12yh4b"
}], ["path", {
  d: "m12 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",
  key: "3ha7mj"
}], ["path", {
  d: "M14 8h4",
  key: "1r8wg2"
}], ["path", {
  d: "M14 18h4",
  key: "1t3kbu"
}], ["path", {
  d: "m20 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",
  key: "dfd4e2"
}]];
var FerrisWheel = [["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["path", {
  d: "M12 2v4",
  key: "3427ic"
}], ["path", {
  d: "m6.8 15-3.5 2",
  key: "hjy98k"
}], ["path", {
  d: "m20.7 7-3.5 2",
  key: "f08gto"
}], ["path", {
  d: "M6.8 9 3.3 7",
  key: "1aevh4"
}], ["path", {
  d: "m20.7 17-3.5-2",
  key: "1liqo3"
}], ["path", {
  d: "m9 22 3-8 3 8",
  key: "wees03"
}], ["path", {
  d: "M8 22h8",
  key: "rmew8v"
}], ["path", {
  d: "M18 18.7a9 9 0 1 0-12 0",
  key: "dhzg4g"
}]];
var Figma = [["path", {
  d: "M5 5.5A3.5 3.5 0 0 1 8.5 2H12v7H8.5A3.5 3.5 0 0 1 5 5.5z",
  key: "1340ok"
}], ["path", {
  d: "M12 2h3.5a3.5 3.5 0 1 1 0 7H12V2z",
  key: "1hz3m3"
}], ["path", {
  d: "M12 12.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 1 1-7 0z",
  key: "1oz8n2"
}], ["path", {
  d: "M5 19.5A3.5 3.5 0 0 1 8.5 16H12v3.5a3.5 3.5 0 1 1-7 0z",
  key: "1ff65i"
}], ["path", {
  d: "M5 12.5A3.5 3.5 0 0 1 8.5 9H12v7H8.5A3.5 3.5 0 0 1 5 12.5z",
  key: "pdip6e"
}]];
var FileArchive = [["path", {
  d: "M13.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v11.5",
  key: "4pqfef"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 12v-1",
  key: "1ej8lb"
}], ["path", {
  d: "M8 18v-2",
  key: "qcmpov"
}], ["path", {
  d: "M8 7V6",
  key: "1nbb54"
}], ["circle", {
  cx: "8",
  cy: "20",
  r: "2",
  key: "ckkr5m"
}]];
var FileAxis3d = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m8 18 4-4",
  key: "12zab0"
}], ["path", {
  d: "M8 10v8h8",
  key: "tlaukw"
}]];
var FileBadge = [["path", {
  d: "M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3",
  key: "cvl1xm"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88",
  key: "1ff7gj"
}], ["circle", {
  cx: "6",
  cy: "14",
  r: "3",
  key: "a1xfv6"
}]];
var FileBox = [["path", {
  d: "M14.5 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.8",
  key: "1kchwa"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M11.7 14.2 7 17l-4.7-2.8",
  key: "1yk8tc"
}], ["path", {
  d: "M3 13.1a2 2 0 0 0-.999 1.76v3.24a2 2 0 0 0 .969 1.78L6 21.7a2 2 0 0 0 2.03.01L11 19.9a2 2 0 0 0 1-1.76V14.9a2 2 0 0 0-.97-1.78L8 11.3a2 2 0 0 0-2.03-.01z",
  key: "19flxy"
}], ["path", {
  d: "M7 17v5",
  key: "1yj1jh"
}]];
var FileBracesCorner = [["path", {
  d: "M14 22h4a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v6",
  key: "14cnrg"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M5 14a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1 1 1 0 0 1 1 1v2a1 1 0 0 0 1 1",
  key: "sr0ebq"
}], ["path", {
  d: "M9 22a1 1 0 0 0 1-1v-2a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-2a1 1 0 0 0-1-1",
  key: "w793db"
}]];
var FileBraces = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1",
  key: "1oajmo"
}], ["path", {
  d: "M14 18a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-1a1 1 0 0 0-1-1",
  key: "mpwhp6"
}]];
var FileChartColumnIncreasing = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 18v-2",
  key: "qcmpov"
}], ["path", {
  d: "M12 18v-4",
  key: "q1q25u"
}], ["path", {
  d: "M16 18v-6",
  key: "15y0np"
}]];
var FileChartColumn = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 18v-1",
  key: "zg0ygc"
}], ["path", {
  d: "M12 18v-6",
  key: "17g6i2"
}], ["path", {
  d: "M16 18v-3",
  key: "j5jt4h"
}]];
var FileChartLine = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m16 13-3.5 3.5-2-2L8 17",
  key: "zz7yod"
}]];
var FileChartPie = [["path", {
  d: "M15.941 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.704l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.512",
  key: "13hoie"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M4.017 11.512a6 6 0 1 0 8.466 8.475",
  key: "s6vs5t"
}], ["path", {
  d: "M9 16a1 1 0 0 1-1-1v-4c0-.552.45-1.008.995-.917a6 6 0 0 1 4.922 4.922c.091.544-.365.995-.917.995z",
  key: "1dl6s6"
}]];
var FileCheckCorner = [["path", {
  d: "M10.5 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v6",
  key: "g5mvt7"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m14 20 2 2 4-4",
  key: "15kota"
}]];
var FileClock = [["path", {
  d: "M16 22h2a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v2.85",
  key: "ryk6xj"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 14v2.2l1.6 1",
  key: "6m4bie"
}], ["circle", {
  cx: "8",
  cy: "16",
  r: "6",
  key: "10v15b"
}]];
var FileCheck = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m9 15 2 2 4-4",
  key: "1grp1n"
}]];
var FileCodeCorner = [["path", {
  d: "M4 12.15V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3.35",
  key: "1wthlu"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m5 16-3 3 3 3",
  key: "331omg"
}], ["path", {
  d: "m9 22 3-3-3-3",
  key: "lsp7cz"
}]];
var FileCode = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10 12.5 8 15l2 2.5",
  key: "1tg20x"
}], ["path", {
  d: "m14 12.5 2 2.5-2 2.5",
  key: "yinavb"
}]];
var FileCog = [["path", {
  d: "M15 8a1 1 0 0 1-1-1V2a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8z",
  key: "1ckgky"
}], ["path", {
  d: "M20 8v12a2 2 0 0 1-2 2h-4.182",
  key: "1726p0"
}], ["path", {
  d: "m3.305 19.53.923-.382",
  key: "ao1pio"
}], ["path", {
  d: "M4 10.592V4a2 2 0 0 1 2-2h8",
  key: "1foop0"
}], ["path", {
  d: "m4.228 16.852-.924-.383",
  key: "1fv9zy"
}], ["path", {
  d: "m5.852 15.228-.383-.923",
  key: "1a9hc2"
}], ["path", {
  d: "m5.852 20.772-.383.924",
  key: "1sh9ke"
}], ["path", {
  d: "m8.148 15.228.383-.923",
  key: "4yu6lf"
}], ["path", {
  d: "m8.53 21.696-.382-.924",
  key: "18b0s9"
}], ["path", {
  d: "m9.773 16.852.922-.383",
  key: "ti6xop"
}], ["path", {
  d: "m9.773 19.148.922.383",
  key: "rws47d"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "3",
  key: "lvkj7j"
}]];
var FileDigit = [["path", {
  d: "M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2",
  key: "jrl274"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10 16h2v6",
  key: "1bxocy"
}], ["path", {
  d: "M10 22h4",
  key: "ceow96"
}], ["rect", {
  x: "2",
  y: "16",
  width: "4",
  height: "6",
  rx: "2",
  key: "r45zd0"
}]];
var FileDiff = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}], ["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["path", {
  d: "M9 17h6",
  key: "r8uit2"
}]];
var FileDown = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M12 18v-6",
  key: "17g6i2"
}], ["path", {
  d: "m9 15 3 3 3-3",
  key: "1npd3o"
}]];
var FileExclamationPoint = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M12 9v4",
  key: "juzpu7"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}]];
var FileHeadphone = [["path", {
  d: "M4 6.835V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-.343",
  key: "1vfytu"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M2 19a2 2 0 0 1 4 0v1a2 2 0 0 1-4 0v-4a6 6 0 0 1 12 0v4a2 2 0 0 1-4 0v-1a2 2 0 0 1 4 0",
  key: "1etmh7"
}]];
var FileHeart = [["path", {
  d: "M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v7",
  key: "oagw2b"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M3.62 18.8A2.25 2.25 0 1 1 7 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a1 1 0 0 1-1.507 0z",
  key: "rg3psg"
}]];
var FileImage = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["circle", {
  cx: "10",
  cy: "12",
  r: "2",
  key: "737tya"
}], ["path", {
  d: "m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22",
  key: "wt3hpn"
}]];
var FileInput = [["path", {
  d: "M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1",
  key: "1q9hii"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M2 15h10",
  key: "jfw4w8"
}], ["path", {
  d: "m9 18 3-3-3-3",
  key: "112psh"
}]];
var FileKey = [["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M4 12v6",
  key: "bg1pfk"
}], ["path", {
  d: "M4 14h2",
  key: "1sf9f8"
}], ["path", {
  d: "M9.65 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v4",
  key: "d56i0q"
}], ["circle", {
  cx: "4",
  cy: "20",
  r: "2",
  key: "6kqj1y"
}]];
var FileLock = [["path", {
  d: "M4 9.8V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3",
  key: "1432pc"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M9 17v-2a2 2 0 0 0-4 0v2",
  key: "168m41"
}], ["rect", {
  width: "8",
  height: "5",
  x: "3",
  y: "17",
  rx: "1",
  key: "o8vfew"
}]];
var FileMinusCorner = [["path", {
  d: "M20 14V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12",
  key: "l9p8hp"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M14 18h6",
  key: "1m8k6r"
}]];
var FileMinus = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M9 15h6",
  key: "cctwl0"
}]];
var FileMusic = [["path", {
  d: "M11.65 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v10.35",
  key: "5ad7z2"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 20v-7l3 1.474",
  key: "1ggyb9"
}], ["circle", {
  cx: "6",
  cy: "20",
  r: "2",
  key: "j7wjp0"
}]];
var FileOutput = [["path", {
  d: "M4.226 20.925A2 2 0 0 0 6 22h12a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.127",
  key: "wfxp4w"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m5 11-3 3",
  key: "1dgrs4"
}], ["path", {
  d: "m5 17-3-3h10",
  key: "1mvvaf"
}]];
var FilePenLine = [["path", {
  d: "M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z",
  key: "ukzhwg"
}], ["path", {
  d: "M14.487 7.858A1 1 0 0 1 14 7V2",
  key: "1klhew"
}], ["path", {
  d: "M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516",
  key: "rxaxab"
}], ["path", {
  d: "M8 18h1",
  key: "13wk12"
}]];
var FilePen = [["path", {
  d: "M12.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v9.34",
  key: "o6klzx"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10.378 12.622a1 1 0 0 1 3 3.003L8.36 20.637a2 2 0 0 1-.854.506l-2.867.837a.5.5 0 0 1-.62-.62l.836-2.869a2 2 0 0 1 .506-.853z",
  key: "zhnas1"
}]];
var FilePlay = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M15.033 13.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56v-4.704a.645.645 0 0 1 .967-.56z",
  key: "1tzo1f"
}]];
var FilePlusCorner = [["path", {
  d: "M11.35 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5.35",
  key: "17jvcc"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M14 19h6",
  key: "bvotb8"
}], ["path", {
  d: "M17 16v6",
  key: "18yu1i"
}]];
var FilePlus = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M9 15h6",
  key: "cctwl0"
}], ["path", {
  d: "M12 18v-6",
  key: "17g6i2"
}]];
var FileQuestionMark = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}], ["path", {
  d: "M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3",
  key: "mhlwft"
}]];
var FileScan = [["path", {
  d: "M20 10V8a2.4 2.4 0 0 0-.706-1.704l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4.35",
  key: "1cdjst"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M16 14a2 2 0 0 0-2 2",
  key: "ceaadl"
}], ["path", {
  d: "M16 22a2 2 0 0 1-2-2",
  key: "1wqh5n"
}], ["path", {
  d: "M20 14a2 2 0 0 1 2 2",
  key: "1ny6zw"
}], ["path", {
  d: "M20 22a2 2 0 0 0 2-2",
  key: "1l9q4k"
}]];
var FileSearchCorner = [["path", {
  d: "M11.1 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.589 3.588A2.4 2.4 0 0 1 20 8v3.25",
  key: "uh4ikj"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m21 22-2.88-2.88",
  key: "9dd25w"
}], ["circle", {
  cx: "16",
  cy: "17",
  r: "3",
  key: "11br10"
}]];
var FileSignal = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 15h.01",
  key: "a7atzg"
}], ["path", {
  d: "M11.5 13.5a2.5 2.5 0 0 1 0 3",
  key: "1fccat"
}], ["path", {
  d: "M15 12a5 5 0 0 1 0 6",
  key: "ps46cm"
}]];
var FileSearch = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["circle", {
  cx: "11.5",
  cy: "14.5",
  r: "2.5",
  key: "1bq0ko"
}], ["path", {
  d: "M13.3 16.3 15 18",
  key: "2quom7"
}]];
var FileSliders = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "M10 11v2",
  key: "1s651w"
}], ["path", {
  d: "M8 17h8",
  key: "wh5c61"
}], ["path", {
  d: "M14 16v2",
  key: "12fp5e"
}]];
var FileSpreadsheet = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M8 13h2",
  key: "yr2amv"
}], ["path", {
  d: "M14 13h2",
  key: "un5t4a"
}], ["path", {
  d: "M8 17h2",
  key: "2yhykz"
}], ["path", {
  d: "M14 17h2",
  key: "10kma7"
}]];
var FileStack = [["path", {
  d: "M11 21a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1",
  key: "likhh7"
}], ["path", {
  d: "M16 16a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1",
  key: "17ky3x"
}], ["path", {
  d: "M21 6a2 2 0 0 0-.586-1.414l-2-2A2 2 0 0 0 17 2h-3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1z",
  key: "1hyeo0"
}]];
var FileSymlink = [["path", {
  d: "M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h7",
  key: "huwfnr"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m10 18 3-3-3-3",
  key: "18f6ys"
}]];
var FileTerminal = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m8 16 2-2-2-2",
  key: "10vzyd"
}], ["path", {
  d: "M12 18h4",
  key: "1wd2n7"
}]];
var FileText = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10 9H8",
  key: "b1mrlr"
}], ["path", {
  d: "M16 13H8",
  key: "t4e002"
}], ["path", {
  d: "M16 17H8",
  key: "z1uh3a"
}]];
var FileTypeCorner = [["path", {
  d: "M12 22h6a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v6",
  key: "15usau"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M3 16v-1.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5V16",
  key: "s1gz5"
}], ["path", {
  d: "M6 22h2",
  key: "194x9m"
}], ["path", {
  d: "M7 14v8",
  key: "11ixej"
}]];
var FileType = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M11 18h2",
  key: "12mj7e"
}], ["path", {
  d: "M12 12v6",
  key: "3ahymv"
}], ["path", {
  d: "M9 13v-.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v.5",
  key: "qbrxap"
}]];
var FileUp = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M12 12v6",
  key: "3ahymv"
}], ["path", {
  d: "m15 15-3-3-3 3",
  key: "15xj92"
}]];
var FileVideoCamera = [["path", {
  d: "M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2",
  key: "jrl274"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m10 17.843 3.033-1.755a.64.64 0 0 1 .967.56v4.704a.65.65 0 0 1-.967.56L10 20.157",
  key: "17aeo9"
}], ["rect", {
  width: "7",
  height: "6",
  x: "3",
  y: "16",
  rx: "1",
  key: "s27ndx"
}]];
var FileVolume = [["path", {
  d: "M4 11.55V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-1.95",
  key: "44gpjv"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M12 15a5 5 0 0 1 0 6",
  key: "oxg87a"
}], ["path", {
  d: "M8 14.502a.5.5 0 0 0-.826-.381l-1.893 1.631a1 1 0 0 1-.651.243H3.5a.5.5 0 0 0-.5.501v3.006a.5.5 0 0 0 .5.501h1.129a1 1 0 0 1 .652.243l1.893 1.633a.5.5 0 0 0 .826-.38z",
  key: "8rtoi1"
}]];
var FileUser = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M16 22a4 4 0 0 0-8 0",
  key: "7a83pg"
}], ["circle", {
  cx: "12",
  cy: "15",
  r: "3",
  key: "g36mzq"
}]];
var FileXCorner = [["path", {
  d: "M11 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5",
  key: "1jo35a"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m15 17 5 5",
  key: "36xl1x"
}], ["path", {
  d: "m20 17-5 5",
  key: "vdz27y"
}]];
var FileX = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "m14.5 12.5-5 5",
  key: "b62r18"
}], ["path", {
  d: "m9.5 12.5 5 5",
  key: "1rk7el"
}]];
var File = [["path", {
  d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
  key: "1oefj6"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}]];
var Files = [["path", {
  d: "M15 2h-4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8",
  key: "14sh0y"
}], ["path", {
  d: "M16.706 2.706A2.4 2.4 0 0 0 15 2v5a1 1 0 0 0 1 1h5a2.4 2.4 0 0 0-.706-1.706z",
  key: "1970lx"
}], ["path", {
  d: "M5 7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 1.732-1",
  key: "l4dndm"
}]];
var Film = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 3v18",
  key: "bbkbws"
}], ["path", {
  d: "M3 7.5h4",
  key: "zfgn84"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}], ["path", {
  d: "M3 16.5h4",
  key: "1230mu"
}], ["path", {
  d: "M17 3v18",
  key: "in4fa5"
}], ["path", {
  d: "M17 7.5h4",
  key: "myr1c1"
}], ["path", {
  d: "M17 16.5h4",
  key: "go4c1d"
}]];
var FingerprintPattern = [["path", {
  d: "M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4",
  key: "1nerag"
}], ["path", {
  d: "M14 13.12c0 2.38 0 6.38-1 8.88",
  key: "o46ks0"
}], ["path", {
  d: "M17.29 21.02c.12-.6.43-2.3.5-3.02",
  key: "ptglia"
}], ["path", {
  d: "M2 12a10 10 0 0 1 18-6",
  key: "ydlgp0"
}], ["path", {
  d: "M2 16h.01",
  key: "1gqxmh"
}], ["path", {
  d: "M21.8 16c.2-2 .131-5.354 0-6",
  key: "drycrb"
}], ["path", {
  d: "M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2",
  key: "1tidbn"
}], ["path", {
  d: "M8.65 22c.21-.66.45-1.32.57-2",
  key: "13wd9y"
}], ["path", {
  d: "M9 6.8a6 6 0 0 1 9 5.2v2",
  key: "1fr1j5"
}]];
var FireExtinguisher = [["path", {
  d: "M15 6.5V3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3.5",
  key: "sqyvz"
}], ["path", {
  d: "M9 18h8",
  key: "i7pszb"
}], ["path", {
  d: "M18 3h-3",
  key: "7idoqj"
}], ["path", {
  d: "M11 3a6 6 0 0 0-6 6v11",
  key: "1v5je3"
}], ["path", {
  d: "M5 13h4",
  key: "svpcxo"
}], ["path", {
  d: "M17 10a4 4 0 0 0-8 0v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2Z",
  key: "vsjego"
}]];
var FishOff = [["path", {
  d: "M18 12.47v.03m0-.5v.47m-.475 5.056A6.744 6.744 0 0 1 15 18c-3.56 0-7.56-2.53-8.5-6 .348-1.28 1.114-2.433 2.121-3.38m3.444-2.088A8.802 8.802 0 0 1 15 6c3.56 0 6.06 2.54 7 6-.309 1.14-.786 2.177-1.413 3.058",
  key: "1j1hse"
}], ["path", {
  d: "M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.33m7.48-4.372A9.77 9.77 0 0 1 16 6.07m0 11.86a9.77 9.77 0 0 1-1.728-3.618",
  key: "1q46z8"
}], ["path", {
  d: "m16.01 17.93-.23 1.4A2 2 0 0 1 13.8 21H9.5a5.96 5.96 0 0 0 1.49-3.98M8.53 3h5.27a2 2 0 0 1 1.98 1.67l.23 1.4M2 2l20 20",
  key: "1407gh"
}]];
var Fish = [["path", {
  d: "M6.5 12c.94-3.46 4.94-6 8.5-6 3.56 0 6.06 2.54 7 6-.94 3.47-3.44 6-7 6s-7.56-2.53-8.5-6Z",
  key: "15baut"
}], ["path", {
  d: "M18 12v.5",
  key: "18hhni"
}], ["path", {
  d: "M16 17.93a9.77 9.77 0 0 1 0-11.86",
  key: "16dt7o"
}], ["path", {
  d: "M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.33",
  key: "l9di03"
}], ["path", {
  d: "M10.46 7.26C10.2 5.88 9.17 4.24 8 3h5.8a2 2 0 0 1 1.98 1.67l.23 1.4",
  key: "1kjonw"
}], ["path", {
  d: "m16.01 17.93-.23 1.4A2 2 0 0 1 13.8 21H9.5a5.96 5.96 0 0 0 1.49-3.98",
  key: "1zlm23"
}]];
var FishSymbol = [["path", {
  d: "M2 16s9-15 20-4C11 23 2 8 2 8",
  key: "h4oh4o"
}]];
var FishingHook = [["path", {
  d: "m17.586 11.414-5.93 5.93a1 1 0 0 1-8-8l3.137-3.137a.707.707 0 0 1 1.207.5V10",
  key: "157y8s"
}], ["path", {
  d: "M20.414 8.586 22 7",
  key: "5g2s34"
}], ["circle", {
  cx: "19",
  cy: "10",
  r: "2",
  key: "7363ft"
}]];
var FishingRod = [["path", {
  d: "M4 11h1",
  key: "13eipc"
}], ["path", {
  d: "M8 15a2 2 0 0 1-4 0V3a1 1 0 0 1 1-1h.5C14 2 20 9 20 18v4",
  key: "1hs3im"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "2",
  key: "1emm8v"
}]];
var FlagOff = [["path", {
  d: "M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528",
  key: "1q158e"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M4 22V4",
  key: "1plyxx"
}], ["path", {
  d: "M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347",
  key: "xj1b71"
}]];
var FlagTriangleLeft = [["path", {
  d: "M18 22V2.8a.8.8 0 0 0-1.17-.71L5.45 7.78a.8.8 0 0 0 0 1.44L18 15.5",
  key: "rbbtmw"
}]];
var FlagTriangleRight = [["path", {
  d: "M6 22V2.8a.8.8 0 0 1 1.17-.71l11.38 5.69a.8.8 0 0 1 0 1.44L6 15.5",
  key: "kfjsu0"
}]];
var Flag = [["path", {
  d: "M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528",
  key: "1jaruq"
}]];
var FlameKindling = [["path", {
  d: "M12 2c1 3 2.5 3.5 3.5 4.5A5 5 0 0 1 17 10a5 5 0 1 1-10 0c0-.3 0-.6.1-.9a2 2 0 1 0 3.3-2C8 4.5 11 2 12 2Z",
  key: "1ir223"
}], ["path", {
  d: "m5 22 14-4",
  key: "1brv4h"
}], ["path", {
  d: "m5 18 14 4",
  key: "lgyyje"
}]];
var Flame = [["path", {
  d: "M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",
  key: "1slcih"
}]];
var Flashlight = [["path", {
  d: "M12 13v1",
  key: "176q98"
}], ["path", {
  d: "M17 2a1 1 0 0 1 1 1v4a3 3 0 0 1-.6 1.8l-.6.8A4 4 0 0 0 16 12v8a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-8a4 4 0 0 0-.8-2.4l-.6-.8A3 3 0 0 1 6 7V3a1 1 0 0 1 1-1z",
  key: "17vh7j"
}], ["path", {
  d: "M6 6h12",
  key: "n6hhss"
}]];
var FlashlightOff = [["path", {
  d: "M11.652 6H18",
  key: "voqkpr"
}], ["path", {
  d: "M12 13v1",
  key: "176q98"
}], ["path", {
  d: "M16 16v4a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-8a4 4 0 0 0-.8-2.4l-.6-.8A3 3 0 0 1 6 7V6",
  key: "dzyf92"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M7.649 2H17a1 1 0 0 1 1 1v4a3 3 0 0 1-.6 1.8l-.6.8a4 4 0 0 0-.55 1.007",
  key: "1hvcfn"
}]];
var FlaskConicalOff = [["path", {
  d: "M10 2v2.343",
  key: "15t272"
}], ["path", {
  d: "M14 2v6.343",
  key: "sxr80q"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20 20a2 2 0 0 1-2 2H6a2 2 0 0 1-1.755-2.96l5.227-9.563",
  key: "k0duyd"
}], ["path", {
  d: "M6.453 15H15",
  key: "1f0z33"
}], ["path", {
  d: "M8.5 2h7",
  key: "csnxdl"
}]];
var FlaskConical = [["path", {
  d: "M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2",
  key: "18mbvz"
}], ["path", {
  d: "M6.453 15h11.094",
  key: "3shlmq"
}], ["path", {
  d: "M8.5 2h7",
  key: "csnxdl"
}]];
var FlaskRound = [["path", {
  d: "M10 2v6.292a7 7 0 1 0 4 0V2",
  key: "1s42pc"
}], ["path", {
  d: "M5 15h14",
  key: "m0yey3"
}], ["path", {
  d: "M8.5 2h7",
  key: "csnxdl"
}]];
var FlipHorizontal2 = [["path", {
  d: "m3 7 5 5-5 5V7",
  key: "couhi7"
}], ["path", {
  d: "m21 7-5 5 5 5V7",
  key: "6ouia7"
}], ["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "M12 14v2",
  key: "8jcxud"
}], ["path", {
  d: "M12 8v2",
  key: "1woqiv"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}]];
var FlipVertical2 = [["path", {
  d: "m17 3-5 5-5-5h10",
  key: "1ftt6x"
}], ["path", {
  d: "m17 21-5-5-5 5h10",
  key: "1m0wmu"
}], ["path", {
  d: "M4 12H2",
  key: "rhcxmi"
}], ["path", {
  d: "M10 12H8",
  key: "s88cx1"
}], ["path", {
  d: "M16 12h-2",
  key: "10asgb"
}], ["path", {
  d: "M22 12h-2",
  key: "14jgyd"
}]];
var Flower2 = [["path", {
  d: "M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1",
  key: "3pnvol"
}], ["circle", {
  cx: "12",
  cy: "8",
  r: "2",
  key: "1822b1"
}], ["path", {
  d: "M12 10v12",
  key: "6ubwww"
}], ["path", {
  d: "M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z",
  key: "9hd38g"
}], ["path", {
  d: "M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z",
  key: "ufn41s"
}]];
var Flower = [["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["path", {
  d: "M12 16.5A4.5 4.5 0 1 1 7.5 12 4.5 4.5 0 1 1 12 7.5a4.5 4.5 0 1 1 4.5 4.5 4.5 4.5 0 1 1-4.5 4.5",
  key: "14wa3c"
}], ["path", {
  d: "M12 7.5V9",
  key: "1oy5b0"
}], ["path", {
  d: "M7.5 12H9",
  key: "eltsq1"
}], ["path", {
  d: "M16.5 12H15",
  key: "vk5kw4"
}], ["path", {
  d: "M12 16.5V15",
  key: "k7eayi"
}], ["path", {
  d: "m8 8 1.88 1.88",
  key: "nxy4qf"
}], ["path", {
  d: "M14.12 9.88 16 8",
  key: "1lst6k"
}], ["path", {
  d: "m8 16 1.88-1.88",
  key: "h2eex1"
}], ["path", {
  d: "M14.12 14.12 16 16",
  key: "uqkrx3"
}]];
var Focus = [["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}]];
var FoldHorizontal = [["path", {
  d: "M2 12h6",
  key: "1wqiqv"
}], ["path", {
  d: "M22 12h-6",
  key: "1eg9hc"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M12 8v2",
  key: "1woqiv"
}], ["path", {
  d: "M12 14v2",
  key: "8jcxud"
}], ["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "m19 9-3 3 3 3",
  key: "12ol22"
}], ["path", {
  d: "m5 15 3-3-3-3",
  key: "1kdhjc"
}]];
var FoldVertical = [["path", {
  d: "M12 22v-6",
  key: "6o8u61"
}], ["path", {
  d: "M12 8V2",
  key: "1wkif3"
}], ["path", {
  d: "M4 12H2",
  key: "rhcxmi"
}], ["path", {
  d: "M10 12H8",
  key: "s88cx1"
}], ["path", {
  d: "M16 12h-2",
  key: "10asgb"
}], ["path", {
  d: "M22 12h-2",
  key: "14jgyd"
}], ["path", {
  d: "m15 19-3-3-3 3",
  key: "e37ymu"
}], ["path", {
  d: "m15 5-3 3-3-3",
  key: "19d6lf"
}]];
var FolderCheck = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "m9 13 2 2 4-4",
  key: "6343dt"
}]];
var FolderArchive = [["circle", {
  cx: "15",
  cy: "19",
  r: "2",
  key: "u2pros"
}], ["path", {
  d: "M20.9 19.8A2 2 0 0 0 22 18V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h5.1",
  key: "1jj40k"
}], ["path", {
  d: "M15 11v-1",
  key: "cntcp"
}], ["path", {
  d: "M15 17v-2",
  key: "1279jj"
}]];
var FolderClock = [["path", {
  d: "M16 14v2.2l1.6 1",
  key: "fo4ql5"
}], ["path", {
  d: "M7 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2",
  key: "1urifu"
}], ["circle", {
  cx: "16",
  cy: "16",
  r: "6",
  key: "qoo3c4"
}]];
var FolderClosed = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "M2 10h20",
  key: "1ir3d8"
}]];
var FolderCode = [["path", {
  d: "M10 10.5 8 13l2 2.5",
  key: "m4t9c1"
}], ["path", {
  d: "m14 10.5 2 2.5-2 2.5",
  key: "14w2eb"
}], ["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z",
  key: "1u1bxd"
}]];
var FolderCog = [["path", {
  d: "M10.3 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.98a2 2 0 0 1 1.69.9l.66 1.2A2 2 0 0 0 12 6h8a2 2 0 0 1 2 2v3.3",
  key: "128dxu"
}], ["path", {
  d: "m14.305 19.53.923-.382",
  key: "3m78fa"
}], ["path", {
  d: "m15.228 16.852-.923-.383",
  key: "npixar"
}], ["path", {
  d: "m16.852 15.228-.383-.923",
  key: "5xggr7"
}], ["path", {
  d: "m16.852 20.772-.383.924",
  key: "dpfhf9"
}], ["path", {
  d: "m19.148 15.228.383-.923",
  key: "1reyyz"
}], ["path", {
  d: "m19.53 21.696-.382-.924",
  key: "1goivc"
}], ["path", {
  d: "m20.772 16.852.924-.383",
  key: "htqkph"
}], ["path", {
  d: "m20.772 19.148.924.383",
  key: "9w9pjp"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var FolderDot = [["path", {
  d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
  key: "1fr9dc"
}], ["circle", {
  cx: "12",
  cy: "13",
  r: "1",
  key: "49l61u"
}]];
var FolderDown = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "M12 10v6",
  key: "1bos4e"
}], ["path", {
  d: "m15 13-3 3-3-3",
  key: "6j2sf0"
}]];
var FolderGit2 = [["path", {
  d: "M18 19a5 5 0 0 1-5-5v8",
  key: "sz5oeg"
}], ["path", {
  d: "M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5",
  key: "1w6njk"
}], ["circle", {
  cx: "13",
  cy: "12",
  r: "2",
  key: "1j92g6"
}], ["circle", {
  cx: "20",
  cy: "19",
  r: "2",
  key: "1obnsp"
}]];
var FolderHeart = [["path", {
  d: "M10.638 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v3.417",
  key: "10r6g4"
}], ["path", {
  d: "M14.62 18.8A2.25 2.25 0 1 1 18 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
  key: "15cy7q"
}]];
var FolderGit = [["circle", {
  cx: "12",
  cy: "13",
  r: "2",
  key: "1c1ljs"
}], ["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "M14 13h3",
  key: "1dgedf"
}], ["path", {
  d: "M7 13h3",
  key: "1pygq7"
}]];
var FolderInput = [["path", {
  d: "M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1",
  key: "fm4g5t"
}], ["path", {
  d: "M2 13h10",
  key: "pgb2dq"
}], ["path", {
  d: "m9 16 3-3-3-3",
  key: "6m91ic"
}]];
var FolderKanban = [["path", {
  d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
  key: "1fr9dc"
}], ["path", {
  d: "M8 10v4",
  key: "tgpxqk"
}], ["path", {
  d: "M12 10v2",
  key: "hh53o1"
}], ["path", {
  d: "M16 10v6",
  key: "1d6xys"
}]];
var FolderKey = [["path", {
  d: "M13 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v1.36",
  key: "1shsnm"
}], ["path", {
  d: "M19 12v6",
  key: "kflna4"
}], ["path", {
  d: "M19 14h2",
  key: "wp2qbk"
}], ["circle", {
  cx: "19",
  cy: "20",
  r: "2",
  key: "1jfyz6"
}]];
var FolderLock = [["rect", {
  width: "8",
  height: "5",
  x: "14",
  y: "17",
  rx: "1",
  key: "19aais"
}], ["path", {
  d: "M10 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v2.5",
  key: "1w6v7t"
}], ["path", {
  d: "M20 17v-2a2 2 0 1 0-4 0v2",
  key: "pwaxnr"
}]];
var FolderMinus = [["path", {
  d: "M9 13h6",
  key: "1uhe8q"
}], ["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}]];
var FolderOpenDot = [["path", {
  d: "m6 14 1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2",
  key: "1nmvlm"
}], ["circle", {
  cx: "14",
  cy: "15",
  r: "1",
  key: "1gm4qj"
}]];
var FolderOpen = [["path", {
  d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
  key: "usdka0"
}]];
var FolderOutput = [["path", {
  d: "M2 7.5V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-1.5",
  key: "1yk7aj"
}], ["path", {
  d: "M2 13h10",
  key: "pgb2dq"
}], ["path", {
  d: "m5 10-3 3 3 3",
  key: "1r8ie0"
}]];
var FolderPen = [["path", {
  d: "M2 11.5V5a2 2 0 0 1 2-2h3.9c.7 0 1.3.3 1.7.9l.8 1.2c.4.6 1 .9 1.7.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-9.5",
  key: "a8xqs0"
}], ["path", {
  d: "M11.378 13.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "1saktj"
}]];
var FolderPlus = [["path", {
  d: "M12 10v6",
  key: "1bos4e"
}], ["path", {
  d: "M9 13h6",
  key: "1uhe8q"
}], ["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}]];
var FolderRoot = [["path", {
  d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
  key: "1fr9dc"
}], ["circle", {
  cx: "12",
  cy: "13",
  r: "2",
  key: "1c1ljs"
}], ["path", {
  d: "M12 15v5",
  key: "11xva1"
}]];
var FolderSearch2 = [["circle", {
  cx: "11.5",
  cy: "12.5",
  r: "2.5",
  key: "1ea5ju"
}], ["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "M13.3 14.3 15 16",
  key: "1y4v1n"
}]];
var FolderSearch = [["path", {
  d: "M10.7 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v4.1",
  key: "1bw5m7"
}], ["path", {
  d: "m21 21-1.9-1.9",
  key: "1g2n9r"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "3",
  key: "18b49y"
}]];
var FolderSymlink = [["path", {
  d: "M2 9.35V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h7",
  key: "y8kt7d"
}], ["path", {
  d: "m8 16 3-3-3-3",
  key: "rlqrt1"
}]];
var FolderSync = [["path", {
  d: "M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v.5",
  key: "1dkoa9"
}], ["path", {
  d: "M12 10v4h4",
  key: "1czhmt"
}], ["path", {
  d: "m12 14 1.535-1.605a5 5 0 0 1 8 1.5",
  key: "lvuxfi"
}], ["path", {
  d: "M22 22v-4h-4",
  key: "1ewp4q"
}], ["path", {
  d: "m22 18-1.535 1.605a5 5 0 0 1-8-1.5",
  key: "14ync0"
}]];
var FolderTree = [["path", {
  d: "M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",
  key: "hod4my"
}], ["path", {
  d: "M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",
  key: "w4yl2u"
}], ["path", {
  d: "M3 5a2 2 0 0 0 2 2h3",
  key: "f2jnh7"
}], ["path", {
  d: "M3 3v13a2 2 0 0 0 2 2h3",
  key: "k8epm1"
}]];
var FolderUp = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "M12 10v6",
  key: "1bos4e"
}], ["path", {
  d: "m9 13 3-3 3 3",
  key: "1pxg3c"
}]];
var FolderX = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}], ["path", {
  d: "m9.5 10.5 5 5",
  key: "ra9qjz"
}], ["path", {
  d: "m14.5 10.5-5 5",
  key: "l2rkpq"
}]];
var Folder = [["path", {
  d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
  key: "1kt360"
}]];
var Folders = [["path", {
  d: "M20 5a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h2.5a1.5 1.5 0 0 1 1.2.6l.6.8a1.5 1.5 0 0 0 1.2.6z",
  key: "a4852j"
}], ["path", {
  d: "M3 8.268a2 2 0 0 0-1 1.738V19a2 2 0 0 0 2 2h11a2 2 0 0 0 1.732-1",
  key: "yxbcw3"
}]];
var Footprints = [["path", {
  d: "M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",
  key: "1dudjm"
}], ["path", {
  d: "M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",
  key: "l2t8xc"
}], ["path", {
  d: "M16 17h4",
  key: "1dejxt"
}], ["path", {
  d: "M4 13h4",
  key: "1bwh8b"
}]];
var Forklift = [["path", {
  d: "M12 12H5a2 2 0 0 0-2 2v5",
  key: "7zsz91"
}], ["path", {
  d: "M15 19h7",
  key: "1askl3"
}], ["path", {
  d: "M16 19V2",
  key: "1gf9nk"
}], ["path", {
  d: "M6 12V7a2 2 0 0 1 2-2h2.172a2 2 0 0 1 1.414.586l3.828 3.828A2 2 0 0 1 16 10.828",
  key: "enx9tf"
}], ["path", {
  d: "M7 19h4",
  key: "fumhkk"
}], ["circle", {
  cx: "13",
  cy: "19",
  r: "2",
  key: "wjnkru"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "2",
  key: "v8kfzx"
}]];
var Form = [["path", {
  d: "M4 14h6",
  key: "77gv2w"
}], ["path", {
  d: "M4 2h10",
  key: "a2b314"
}], ["rect", {
  x: "4",
  y: "18",
  width: "16",
  height: "4",
  rx: "1",
  key: "sybzq6"
}], ["rect", {
  x: "4",
  y: "6",
  width: "16",
  height: "4",
  rx: "1",
  key: "1osc9e"
}]];
var Forward = [["path", {
  d: "m15 17 5-5-5-5",
  key: "nf172w"
}], ["path", {
  d: "M4 18v-2a4 4 0 0 1 4-4h12",
  key: "jmiej9"
}]];
var Frame = [["line", {
  x1: "22",
  x2: "2",
  y1: "6",
  y2: "6",
  key: "15w7dq"
}], ["line", {
  x1: "22",
  x2: "2",
  y1: "18",
  y2: "18",
  key: "1ip48p"
}], ["line", {
  x1: "6",
  x2: "6",
  y1: "2",
  y2: "22",
  key: "a2lnyx"
}], ["line", {
  x1: "18",
  x2: "18",
  y1: "2",
  y2: "22",
  key: "8vb6jd"
}]];
var Framer = [["path", {
  d: "M5 16V9h14V2H5l14 14h-7m-7 0 7 7v-7m-7 0h7",
  key: "1a2nng"
}]];
var Frown = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M16 16s-1.5-2-4-2-4 2-4 2",
  key: "epbg0q"
}], ["line", {
  x1: "9",
  x2: "9.01",
  y1: "9",
  y2: "9",
  key: "yxxnd0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "9",
  y2: "9",
  key: "1p4y9e"
}]];
var Fuel = [["path", {
  d: "M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 4 0v-6.998a2 2 0 0 0-.59-1.42L18 5",
  key: "1wtuz0"
}], ["path", {
  d: "M14 21V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v16",
  key: "e09ifn"
}], ["path", {
  d: "M2 21h13",
  key: "1x0fut"
}], ["path", {
  d: "M3 9h11",
  key: "1p7c0w"
}]];
var Fullscreen = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["rect", {
  width: "10",
  height: "8",
  x: "7",
  y: "8",
  rx: "1",
  key: "vys8me"
}]];
var FunnelPlus = [["path", {
  d: "M13.354 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14v6a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341l1.218-1.348",
  key: "8mvsmf"
}], ["path", {
  d: "M16 6h6",
  key: "1dogtp"
}], ["path", {
  d: "M19 3v6",
  key: "1ytpjt"
}]];
var FunnelX = [["path", {
  d: "M12.531 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14v6a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341l.427-.473",
  key: "ol2ft2"
}], ["path", {
  d: "m16.5 3.5 5 5",
  key: "15e6fa"
}], ["path", {
  d: "m21.5 3.5-5 5",
  key: "m0lwru"
}]];
var Funnel = [["path", {
  d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
  key: "sc7q7i"
}]];
var GalleryHorizontalEnd = [["path", {
  d: "M2 7v10",
  key: "a2pl2d"
}], ["path", {
  d: "M6 5v14",
  key: "1kq3d7"
}], ["rect", {
  width: "12",
  height: "18",
  x: "10",
  y: "3",
  rx: "2",
  key: "13i7bc"
}]];
var GalleryHorizontal = [["path", {
  d: "M2 3v18",
  key: "pzttux"
}], ["rect", {
  width: "12",
  height: "18",
  x: "6",
  y: "3",
  rx: "2",
  key: "btr8bg"
}], ["path", {
  d: "M22 3v18",
  key: "6jf3v"
}]];
var GalleryVerticalEnd = [["path", {
  d: "M7 2h10",
  key: "nczekb"
}], ["path", {
  d: "M5 6h14",
  key: "u2x4p"
}], ["rect", {
  width: "18",
  height: "12",
  x: "3",
  y: "10",
  rx: "2",
  key: "l0tzu3"
}]];
var GalleryThumbnails = [["rect", {
  width: "18",
  height: "14",
  x: "3",
  y: "3",
  rx: "2",
  key: "74y24f"
}], ["path", {
  d: "M4 21h1",
  key: "16zlid"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}], ["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "M19 21h1",
  key: "edywat"
}]];
var GalleryVertical = [["path", {
  d: "M3 2h18",
  key: "15qxfx"
}], ["rect", {
  width: "18",
  height: "12",
  x: "3",
  y: "6",
  rx: "2",
  key: "1439r6"
}], ["path", {
  d: "M3 22h18",
  key: "8prr45"
}]];
var Gamepad2 = [["line", {
  x1: "6",
  x2: "10",
  y1: "11",
  y2: "11",
  key: "1gktln"
}], ["line", {
  x1: "8",
  x2: "8",
  y1: "9",
  y2: "13",
  key: "qnk9ow"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "12",
  y2: "12",
  key: "krot7o"
}], ["line", {
  x1: "18",
  x2: "18.01",
  y1: "10",
  y2: "10",
  key: "1lcuu1"
}], ["path", {
  d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
  key: "mfqc10"
}]];
var GamepadDirectional = [["path", {
  d: "M11.146 15.854a1.207 1.207 0 0 1 1.708 0l1.56 1.56A2 2 0 0 1 15 18.828V21a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-2.172a2 2 0 0 1 .586-1.414z",
  key: "1re2og"
}], ["path", {
  d: "M18.828 15a2 2 0 0 1-1.414-.586l-1.56-1.56a1.207 1.207 0 0 1 0-1.708l1.56-1.56A2 2 0 0 1 18.828 9H21a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1z",
  key: "1pchrj"
}], ["path", {
  d: "M6.586 14.414A2 2 0 0 1 5.172 15H3a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h2.172a2 2 0 0 1 1.414.586l1.56 1.56a1.207 1.207 0 0 1 0 1.708z",
  key: "16mt4c"
}], ["path", {
  d: "M9 3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2.172a2 2 0 0 1-.586 1.414l-1.56 1.56a1.207 1.207 0 0 1-1.708 0l-1.56-1.56A2 2 0 0 1 9 5.172z",
  key: "19ox6c"
}]];
var Gamepad = [["line", {
  x1: "6",
  x2: "10",
  y1: "12",
  y2: "12",
  key: "161bw2"
}], ["line", {
  x1: "8",
  x2: "8",
  y1: "10",
  y2: "14",
  key: "1i6ji0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "13",
  y2: "13",
  key: "dqpgro"
}], ["line", {
  x1: "18",
  x2: "18.01",
  y1: "11",
  y2: "11",
  key: "meh2c"
}], ["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "6",
  rx: "2",
  key: "9lu3g6"
}]];
var Gavel = [["path", {
  d: "m14 13-8.381 8.38a1 1 0 0 1-3.001-3l8.384-8.381",
  key: "pgg06f"
}], ["path", {
  d: "m16 16 6-6",
  key: "vzrcl6"
}], ["path", {
  d: "m21.5 10.5-8-8",
  key: "a17d9x"
}], ["path", {
  d: "m8 8 6-6",
  key: "18bi4p"
}], ["path", {
  d: "m8.5 7.5 8 8",
  key: "1oyaui"
}]];
var Gauge = [["path", {
  d: "m12 14 4-4",
  key: "9kzdfg"
}], ["path", {
  d: "M3.34 19a10 10 0 1 1 17.32 0",
  key: "19p75a"
}]];
var Gem = [["path", {
  d: "M10.5 3 8 9l4 13 4-13-2.5-6",
  key: "b3dvk1"
}], ["path", {
  d: "M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",
  key: "7w4byz"
}], ["path", {
  d: "M2 9h20",
  key: "16fsjt"
}]];
var GeorgianLari = [["path", {
  d: "M11.5 21a7.5 7.5 0 1 1 7.35-9",
  key: "1gyj8k"
}], ["path", {
  d: "M13 12V3",
  key: "18om2a"
}], ["path", {
  d: "M4 21h16",
  key: "1h09gz"
}], ["path", {
  d: "M9 12V3",
  key: "geutu0"
}]];
var Ghost = [["path", {
  d: "M9 10h.01",
  key: "qbtxuw"
}], ["path", {
  d: "M15 10h.01",
  key: "1qmjsl"
}], ["path", {
  d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
  key: "uwwb07"
}]];
var Gift = [["path", {
  d: "M12 7v14",
  key: "1akyts"
}], ["path", {
  d: "M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8",
  key: "1sqzm4"
}], ["path", {
  d: "M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5",
  key: "kc0143"
}], ["rect", {
  x: "3",
  y: "7",
  width: "18",
  height: "4",
  rx: "1",
  key: "1hberx"
}]];
var GitBranchMinus = [["path", {
  d: "M15 6a9 9 0 0 0-9 9V3",
  key: "1cii5b"
}], ["path", {
  d: "M21 18h-6",
  key: "139f0c"
}], ["circle", {
  cx: "18",
  cy: "6",
  r: "3",
  key: "1h7g24"
}], ["circle", {
  cx: "6",
  cy: "18",
  r: "3",
  key: "fqmcym"
}]];
var GitBranchPlus = [["path", {
  d: "M6 3v12",
  key: "qpgusn"
}], ["path", {
  d: "M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  key: "1d02ji"
}], ["path", {
  d: "M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  key: "chk6ph"
}], ["path", {
  d: "M15 6a9 9 0 0 0-9 9",
  key: "or332x"
}], ["path", {
  d: "M18 15v6",
  key: "9wciyi"
}], ["path", {
  d: "M21 18h-6",
  key: "139f0c"
}]];
var GitBranch = [["path", {
  d: "M15 6a9 9 0 0 0-9 9V3",
  key: "1cii5b"
}], ["circle", {
  cx: "18",
  cy: "6",
  r: "3",
  key: "1h7g24"
}], ["circle", {
  cx: "6",
  cy: "18",
  r: "3",
  key: "fqmcym"
}]];
var GitCommitHorizontal = [["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["line", {
  x1: "3",
  x2: "9",
  y1: "12",
  y2: "12",
  key: "1dyftd"
}], ["line", {
  x1: "15",
  x2: "21",
  y1: "12",
  y2: "12",
  key: "oup4p8"
}]];
var GitCommitVertical = [["path", {
  d: "M12 3v6",
  key: "1holv5"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["path", {
  d: "M12 15v6",
  key: "a9ows0"
}]];
var GitCompareArrows = [["circle", {
  cx: "5",
  cy: "6",
  r: "3",
  key: "1qnov2"
}], ["path", {
  d: "M12 6h5a2 2 0 0 1 2 2v7",
  key: "1yj91y"
}], ["path", {
  d: "m15 9-3-3 3-3",
  key: "1lwv8l"
}], ["circle", {
  cx: "19",
  cy: "18",
  r: "3",
  key: "1qljk2"
}], ["path", {
  d: "M12 18H7a2 2 0 0 1-2-2V9",
  key: "16sdep"
}], ["path", {
  d: "m9 15 3 3-3 3",
  key: "1m3kbl"
}]];
var GitCompare = [["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M13 6h3a2 2 0 0 1 2 2v7",
  key: "1yeb86"
}], ["path", {
  d: "M11 18H8a2 2 0 0 1-2-2V9",
  key: "19pyzm"
}]];
var GitFork = [["circle", {
  cx: "12",
  cy: "18",
  r: "3",
  key: "1mpf1b"
}], ["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["circle", {
  cx: "18",
  cy: "6",
  r: "3",
  key: "1h7g24"
}], ["path", {
  d: "M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9",
  key: "1uq4wg"
}], ["path", {
  d: "M12 12v3",
  key: "158kv8"
}]];
var GitGraph = [["circle", {
  cx: "5",
  cy: "6",
  r: "3",
  key: "1qnov2"
}], ["path", {
  d: "M5 9v6",
  key: "158jrl"
}], ["circle", {
  cx: "5",
  cy: "18",
  r: "3",
  key: "104gr9"
}], ["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["circle", {
  cx: "19",
  cy: "6",
  r: "3",
  key: "108a5v"
}], ["path", {
  d: "M16 15.7A9 9 0 0 0 19 9",
  key: "1e3vqb"
}]];
var GitMergeConflict = [["path", {
  d: "M12 6h4a2 2 0 0 1 2 2v7",
  key: "18ej7s"
}], ["path", {
  d: "M6 12v9",
  key: "9e33v1"
}], ["path", {
  d: "M9 3 3 9",
  key: "ahyygn"
}], ["path", {
  d: "M9 9 3 3",
  key: "v551iv"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var GitMerge = [["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M6 21V9a9 9 0 0 0 9 9",
  key: "7kw0sc"
}]];
var GitPullRequestArrow = [["circle", {
  cx: "5",
  cy: "6",
  r: "3",
  key: "1qnov2"
}], ["path", {
  d: "M5 9v12",
  key: "ih889a"
}], ["circle", {
  cx: "19",
  cy: "18",
  r: "3",
  key: "1qljk2"
}], ["path", {
  d: "m15 9-3-3 3-3",
  key: "1lwv8l"
}], ["path", {
  d: "M12 6h5a2 2 0 0 1 2 2v7",
  key: "1yj91y"
}]];
var GitPullRequestClosed = [["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M6 9v12",
  key: "1sc30k"
}], ["path", {
  d: "m21 3-6 6",
  key: "16nqsk"
}], ["path", {
  d: "m21 9-6-6",
  key: "9j17rh"
}], ["path", {
  d: "M18 11.5V15",
  key: "65xf6f"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var GitPullRequestCreateArrow = [["circle", {
  cx: "5",
  cy: "6",
  r: "3",
  key: "1qnov2"
}], ["path", {
  d: "M5 9v12",
  key: "ih889a"
}], ["path", {
  d: "m15 9-3-3 3-3",
  key: "1lwv8l"
}], ["path", {
  d: "M12 6h5a2 2 0 0 1 2 2v3",
  key: "1rbwk6"
}], ["path", {
  d: "M19 15v6",
  key: "10aioa"
}], ["path", {
  d: "M22 18h-6",
  key: "1d5gi5"
}]];
var GitPullRequestCreate = [["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M6 9v12",
  key: "1sc30k"
}], ["path", {
  d: "M13 6h3a2 2 0 0 1 2 2v3",
  key: "1jb6z3"
}], ["path", {
  d: "M18 15v6",
  key: "9wciyi"
}], ["path", {
  d: "M21 18h-6",
  key: "139f0c"
}]];
var GitPullRequestDraft = [["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M18 6V5",
  key: "1oao2s"
}], ["path", {
  d: "M18 11v-1",
  key: "11c8tz"
}], ["line", {
  x1: "6",
  x2: "6",
  y1: "9",
  y2: "21",
  key: "rroup"
}]];
var GitPullRequest = [["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M13 6h3a2 2 0 0 1 2 2v7",
  key: "1yeb86"
}], ["line", {
  x1: "6",
  x2: "6",
  y1: "9",
  y2: "21",
  key: "rroup"
}]];
var Github = [["path", {
  d: "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",
  key: "tonef"
}], ["path", {
  d: "M9 18c-4.51 2-5-2-7-2",
  key: "9comsn"
}]];
var Gitlab = [["path", {
  d: "m22 13.29-3.33-10a.42.42 0 0 0-.14-.18.38.38 0 0 0-.22-.11.39.39 0 0 0-.23.07.42.42 0 0 0-.14.18l-2.26 6.67H8.32L6.1 3.26a.42.42 0 0 0-.1-.18.38.38 0 0 0-.26-.08.39.39 0 0 0-.23.07.42.42 0 0 0-.14.18L2 13.29a.74.74 0 0 0 .27.83L12 21l9.69-6.88a.71.71 0 0 0 .31-.83Z",
  key: "148pdi"
}]];
var Glasses = [["circle", {
  cx: "6",
  cy: "15",
  r: "4",
  key: "vux9w4"
}], ["circle", {
  cx: "18",
  cy: "15",
  r: "4",
  key: "18o8ve"
}], ["path", {
  d: "M14 15a2 2 0 0 0-2-2 2 2 0 0 0-2 2",
  key: "1ag4bs"
}], ["path", {
  d: "M2.5 13 5 7c.7-1.3 1.4-2 3-2",
  key: "1hm1gs"
}], ["path", {
  d: "M21.5 13 19 7c-.7-1.3-1.5-2-3-2",
  key: "1r31ai"
}]];
var GlassWater = [["path", {
  d: "M5.116 4.104A1 1 0 0 1 6.11 3h11.78a1 1 0 0 1 .994 1.105L17.19 20.21A2 2 0 0 1 15.2 22H8.8a2 2 0 0 1-2-1.79z",
  key: "p55z4y"
}], ["path", {
  d: "M6 12a5 5 0 0 1 6 0 5 5 0 0 0 6 0",
  key: "mjntcy"
}]];
var GlobeLock = [["path", {
  d: "M15.686 15A14.5 14.5 0 0 1 12 22a14.5 14.5 0 0 1 0-20 10 10 0 1 0 9.542 13",
  key: "qkt0x6"
}], ["path", {
  d: "M2 12h8.5",
  key: "ovaggd"
}], ["path", {
  d: "M20 6V4a2 2 0 1 0-4 0v2",
  key: "1of5e8"
}], ["rect", {
  width: "8",
  height: "5",
  x: "14",
  y: "6",
  rx: "1",
  key: "1fmf51"
}]];
var GlobeX = [["path", {
  d: "m16 3 5 5",
  key: "1husv6"
}], ["path", {
  d: "M2 12h20A10 10 0 1 1 12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 4-10",
  key: "46evmv"
}], ["path", {
  d: "m21 3-5 5",
  key: "1g5oa7"
}]];
var Globe = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",
  key: "13o1zl"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}]];
var GlobeOff = [["path", {
  d: "M10.114 4.462A14.5 14.5 0 0 1 12 2a10 10 0 0 1 9.313 13.643",
  key: "1jq2r7"
}], ["path", {
  d: "M15.557 15.556A14.5 14.5 0 0 1 12 22 10 10 0 0 1 4.929 4.929",
  key: "1ohfya"
}], ["path", {
  d: "M15.892 10.234A14.5 14.5 0 0 0 12 2a10 10 0 0 0-3.643.687",
  key: "1fyh9w"
}], ["path", {
  d: "M17.656 12H22",
  key: "1ttse4"
}], ["path", {
  d: "M19.071 19.071A10 10 0 0 1 12 22 14.5 14.5 0 0 1 8.44 8.45",
  key: "rmtjzo"
}], ["path", {
  d: "M2 12h10",
  key: "19562f"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Goal = [["path", {
  d: "M12 13V2l8 4-8 4",
  key: "5wlwwj"
}], ["path", {
  d: "M20.561 10.222a9 9 0 1 1-12.55-5.29",
  key: "1c0wjv"
}], ["path", {
  d: "M8.002 9.997a5 5 0 1 0 8.9 2.02",
  key: "gb1g7m"
}]];
var Gpu = [["path", {
  d: "M2 17h18a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H2",
  key: "hpo31w"
}], ["path", {
  d: "M2 21V3",
  key: "1bzk4w"
}], ["path", {
  d: "M7 17v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-3",
  key: "5hbqbf"
}], ["circle", {
  cx: "16",
  cy: "11",
  r: "2",
  key: "qt15rb"
}], ["circle", {
  cx: "8",
  cy: "11",
  r: "2",
  key: "ssideg"
}]];
var GraduationCap = [["path", {
  d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
  key: "j76jl0"
}], ["path", {
  d: "M22 10v6",
  key: "1lu8f3"
}], ["path", {
  d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5",
  key: "1r8lef"
}]];
var Grape = [["path", {
  d: "M22 5V2l-5.89 5.89",
  key: "1eenpo"
}], ["circle", {
  cx: "16.6",
  cy: "15.89",
  r: "3",
  key: "xjtalx"
}], ["circle", {
  cx: "8.11",
  cy: "7.4",
  r: "3",
  key: "u2fv6i"
}], ["circle", {
  cx: "12.35",
  cy: "11.65",
  r: "3",
  key: "i6i8g7"
}], ["circle", {
  cx: "13.91",
  cy: "5.85",
  r: "3",
  key: "6ye0dv"
}], ["circle", {
  cx: "18.15",
  cy: "10.09",
  r: "3",
  key: "snx9no"
}], ["circle", {
  cx: "6.56",
  cy: "13.2",
  r: "3",
  key: "17x4xg"
}], ["circle", {
  cx: "10.8",
  cy: "17.44",
  r: "3",
  key: "1hogw9"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "3",
  key: "1sn6vo"
}]];
var Grid2x2Check = [["path", {
  d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
  key: "11za1p"
}], ["path", {
  d: "m16 19 2 2 4-4",
  key: "1b14m6"
}]];
var Grid2x2Plus = [["path", {
  d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
  key: "11za1p"
}], ["path", {
  d: "M16 19h6",
  key: "xwg31i"
}], ["path", {
  d: "M19 22v-6",
  key: "qhmiwi"
}]];
var Grid2x2X = [["path", {
  d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
  key: "11za1p"
}], ["path", {
  d: "m16 16 5 5",
  key: "8tpb07"
}], ["path", {
  d: "m16 21 5-5",
  key: "193jll"
}]];
var Grid2x2 = [["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var Grid3x2 = [["path", {
  d: "M15 3v18",
  key: "14nvp0"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var Grid3x3 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}]];
var GripHorizontal = [["circle", {
  cx: "12",
  cy: "9",
  r: "1",
  key: "124mty"
}], ["circle", {
  cx: "19",
  cy: "9",
  r: "1",
  key: "1ruzo2"
}], ["circle", {
  cx: "5",
  cy: "9",
  r: "1",
  key: "1a8b28"
}], ["circle", {
  cx: "12",
  cy: "15",
  r: "1",
  key: "1e56xg"
}], ["circle", {
  cx: "19",
  cy: "15",
  r: "1",
  key: "1a92ep"
}], ["circle", {
  cx: "5",
  cy: "15",
  r: "1",
  key: "5r1jwy"
}]];
var GripVertical = [["circle", {
  cx: "9",
  cy: "12",
  r: "1",
  key: "1vctgf"
}], ["circle", {
  cx: "9",
  cy: "5",
  r: "1",
  key: "hp0tcf"
}], ["circle", {
  cx: "9",
  cy: "19",
  r: "1",
  key: "fkjjf6"
}], ["circle", {
  cx: "15",
  cy: "12",
  r: "1",
  key: "1tmaij"
}], ["circle", {
  cx: "15",
  cy: "5",
  r: "1",
  key: "19l28e"
}], ["circle", {
  cx: "15",
  cy: "19",
  r: "1",
  key: "f4zoj3"
}]];
var Grip = [["circle", {
  cx: "12",
  cy: "5",
  r: "1",
  key: "gxeob9"
}], ["circle", {
  cx: "19",
  cy: "5",
  r: "1",
  key: "w8mnmm"
}], ["circle", {
  cx: "5",
  cy: "5",
  r: "1",
  key: "lttvr7"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["circle", {
  cx: "19",
  cy: "12",
  r: "1",
  key: "1wjl8i"
}], ["circle", {
  cx: "5",
  cy: "12",
  r: "1",
  key: "1pcz8c"
}], ["circle", {
  cx: "12",
  cy: "19",
  r: "1",
  key: "lyex9k"
}], ["circle", {
  cx: "19",
  cy: "19",
  r: "1",
  key: "shf9b7"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "1",
  key: "bfqh0e"
}]];
var Group = [["path", {
  d: "M3 7V5c0-1.1.9-2 2-2h2",
  key: "adw53z"
}], ["path", {
  d: "M17 3h2c1.1 0 2 .9 2 2v2",
  key: "an4l38"
}], ["path", {
  d: "M21 17v2c0 1.1-.9 2-2 2h-2",
  key: "144t0e"
}], ["path", {
  d: "M7 21H5c-1.1 0-2-.9-2-2v-2",
  key: "rtnfgi"
}], ["rect", {
  width: "7",
  height: "5",
  x: "7",
  y: "7",
  rx: "1",
  key: "1eyiv7"
}], ["rect", {
  width: "7",
  height: "5",
  x: "10",
  y: "12",
  rx: "1",
  key: "1qlmkx"
}]];
var Guitar = [["path", {
  d: "m11.9 12.1 4.514-4.514",
  key: "109xqo"
}], ["path", {
  d: "M20.1 2.3a1 1 0 0 0-1.4 0l-1.114 1.114A2 2 0 0 0 17 4.828v1.344a2 2 0 0 1-.586 1.414A2 2 0 0 1 17.828 7h1.344a2 2 0 0 0 1.414-.586L21.7 5.3a1 1 0 0 0 0-1.4z",
  key: "txyc8t"
}], ["path", {
  d: "m6 16 2 2",
  key: "16qmzd"
}], ["path", {
  d: "M8.23 9.85A3 3 0 0 1 11 8a5 5 0 0 1 5 5 3 3 0 0 1-1.85 2.77l-.92.38A2 2 0 0 0 12 18a4 4 0 0 1-4 4 6 6 0 0 1-6-6 4 4 0 0 1 4-4 2 2 0 0 0 1.85-1.23z",
  key: "1de1vg"
}]];
var Ham = [["path", {
  d: "M13.144 21.144A7.274 10.445 45 1 0 2.856 10.856",
  key: "1k1t7q"
}], ["path", {
  d: "M13.144 21.144A7.274 4.365 45 0 0 2.856 10.856a7.274 4.365 45 0 0 10.288 10.288",
  key: "153t1g"
}], ["path", {
  d: "M16.565 10.435 18.6 8.4a2.501 2.501 0 1 0 1.65-4.65 2.5 2.5 0 1 0-4.66 1.66l-2.024 2.025",
  key: "gzrt0n"
}], ["path", {
  d: "m8.5 16.5-1-1",
  key: "otr954"
}]];
var Hamburger = [["path", {
  d: "M12 16H4a2 2 0 1 1 0-4h16a2 2 0 1 1 0 4h-4.25",
  key: "5dloqd"
}], ["path", {
  d: "M5 12a2 2 0 0 1-2-2 9 7 0 0 1 18 0 2 2 0 0 1-2 2",
  key: "1vl3my"
}], ["path", {
  d: "M5 16a2 2 0 0 0-2 2 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 2 2 0 0 0-2-2q0 0 0 0",
  key: "1us75o"
}], ["path", {
  d: "m6.67 12 6.13 4.6a2 2 0 0 0 2.8-.4l3.15-4.2",
  key: "qqzweh"
}]];
var Hammer = [["path", {
  d: "m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9",
  key: "1hayfq"
}], ["path", {
  d: "m18 15 4-4",
  key: "16gjal"
}], ["path", {
  d: "m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5",
  key: "15ts47"
}]];
var HandCoins = [["path", {
  d: "M11 15h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 17",
  key: "geh8rc"
}], ["path", {
  d: "m7 21 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9",
  key: "1fto5m"
}], ["path", {
  d: "m2 16 6 6",
  key: "1pfhp9"
}], ["circle", {
  cx: "16",
  cy: "9",
  r: "2.9",
  key: "1n0dlu"
}], ["circle", {
  cx: "6",
  cy: "5",
  r: "3",
  key: "151irh"
}]];
var HandGrab = [["path", {
  d: "M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4",
  key: "edstyy"
}], ["path", {
  d: "M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2",
  key: "19wdwo"
}], ["path", {
  d: "M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5",
  key: "1lugqo"
}], ["path", {
  d: "M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2",
  key: "1hbeus"
}], ["path", {
  d: "M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0",
  key: "1etffm"
}]];
var HandFist = [["path", {
  d: "M12.035 17.012a3 3 0 0 0-3-3l-.311-.002a.72.72 0 0 1-.505-1.229l1.195-1.195A2 2 0 0 1 10.828 11H12a2 2 0 0 0 0-4H9.243a3 3 0 0 0-2.122.879l-2.707 2.707A4.83 4.83 0 0 0 3 14a8 8 0 0 0 8 8h2a8 8 0 0 0 8-8V7a2 2 0 1 0-4 0v2a2 2 0 1 0 4 0",
  key: "1ff7rl"
}], ["path", {
  d: "M13.888 9.662A2 2 0 0 0 17 8V5A2 2 0 1 0 13 5",
  key: "1xmd21"
}], ["path", {
  d: "M9 5A2 2 0 1 0 5 5V10",
  key: "f3wfjw"
}], ["path", {
  d: "M9 7V4A2 2 0 1 1 13 4V7.268",
  key: "eaoucv"
}]];
var HandHeart = [["path", {
  d: "M11 14h2a2 2 0 0 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 16",
  key: "1v1a37"
}], ["path", {
  d: "m14.45 13.39 5.05-4.694C20.196 8 21 6.85 21 5.75a2.75 2.75 0 0 0-4.797-1.837.276.276 0 0 1-.406 0A2.75 2.75 0 0 0 11 5.75c0 1.2.802 2.248 1.5 2.946L16 11.95",
  key: "fhfbnt"
}], ["path", {
  d: "m2 15 6 6",
  key: "10dquu"
}], ["path", {
  d: "m7 20 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a1 1 0 0 0-2.75-2.91",
  key: "1x6kdw"
}]];
var HandMetal = [["path", {
  d: "M18 12.5V10a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4",
  key: "wc6myp"
}], ["path", {
  d: "M14 11V9a2 2 0 1 0-4 0v2",
  key: "94qvcw"
}], ["path", {
  d: "M10 10.5V5a2 2 0 1 0-4 0v9",
  key: "m1ah89"
}], ["path", {
  d: "m7 15-1.76-1.76a2 2 0 0 0-2.83 2.82l3.6 3.6C7.5 21.14 9.2 22 12 22h2a8 8 0 0 0 8-8V7a2 2 0 1 0-4 0v5",
  key: "t1skq1"
}]];
var HandHelping = [["path", {
  d: "M11 12h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 14",
  key: "1j4xps"
}], ["path", {
  d: "m7 18 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9",
  key: "uospg8"
}], ["path", {
  d: "m2 13 6 6",
  key: "16e5sb"
}]];
var HandPlatter = [["path", {
  d: "M12 3V2",
  key: "ar7q03"
}], ["path", {
  d: "m15.4 17.4 3.2-2.8a2 2 0 1 1 2.8 2.9l-3.6 3.3c-.7.8-1.7 1.2-2.8 1.2h-4c-1.1 0-2.1-.4-2.8-1.2l-1.302-1.464A1 1 0 0 0 6.151 19H5",
  key: "n2g93r"
}], ["path", {
  d: "M2 14h12a2 2 0 0 1 0 4h-2",
  key: "1o2jem"
}], ["path", {
  d: "M4 10h16",
  key: "img6z1"
}], ["path", {
  d: "M5 10a7 7 0 0 1 14 0",
  key: "1ega1o"
}], ["path", {
  d: "M5 14v6a1 1 0 0 1-1 1H2",
  key: "1hescx"
}]];
var Hand = [["path", {
  d: "M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2",
  key: "1fvzgz"
}], ["path", {
  d: "M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2",
  key: "1kc0my"
}], ["path", {
  d: "M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8",
  key: "10h0bg"
}], ["path", {
  d: "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
  key: "1s1gnw"
}]];
var Handbag = [["path", {
  d: "M2.048 18.566A2 2 0 0 0 4 21h16a2 2 0 0 0 1.952-2.434l-2-9A2 2 0 0 0 18 8H6a2 2 0 0 0-1.952 1.566z",
  key: "1qbui5"
}], ["path", {
  d: "M8 11V6a4 4 0 0 1 8 0v5",
  key: "tcht90"
}]];
var Handshake = [["path", {
  d: "m11 17 2 2a1 1 0 1 0 3-3",
  key: "efffak"
}], ["path", {
  d: "m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4",
  key: "9pr0kb"
}], ["path", {
  d: "m21 3 1 11h-2",
  key: "1tisrp"
}], ["path", {
  d: "M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3",
  key: "1uvwmv"
}], ["path", {
  d: "M3 4h8",
  key: "1ep09j"
}]];
var HardDriveDownload = [["path", {
  d: "M12 2v8",
  key: "1q4o3n"
}], ["path", {
  d: "m16 6-4 4-4-4",
  key: "6wukr"
}], ["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "14",
  rx: "2",
  key: "w68u3i"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "M10 18h.01",
  key: "h775k"
}]];
var HardDriveUpload = [["path", {
  d: "m16 6-4-4-4 4",
  key: "13yo43"
}], ["path", {
  d: "M12 2v8",
  key: "1q4o3n"
}], ["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "14",
  rx: "2",
  key: "w68u3i"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "M10 18h.01",
  key: "h775k"
}]];
var HardDrive = [["path", {
  d: "M10 16h.01",
  key: "1bzywj"
}], ["path", {
  d: "M2.212 11.577a2 2 0 0 0-.212.896V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5.527a2 2 0 0 0-.212-.896L18.55 5.11A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
  key: "18tbho"
}], ["path", {
  d: "M21.946 12.013H2.054",
  key: "zqlbp7"
}], ["path", {
  d: "M6 16h.01",
  key: "1pmjb7"
}]];
var HardHat = [["path", {
  d: "M10 10V5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v5",
  key: "1p9q5i"
}], ["path", {
  d: "M14 6a6 6 0 0 1 6 6v3",
  key: "1hnv84"
}], ["path", {
  d: "M4 15v-3a6 6 0 0 1 6-6",
  key: "9ciidu"
}], ["rect", {
  x: "2",
  y: "15",
  width: "20",
  height: "4",
  rx: "1",
  key: "g3x8cw"
}]];
var HatGlasses = [["path", {
  d: "M14 18a2 2 0 0 0-4 0",
  key: "1v8fkw"
}], ["path", {
  d: "m19 11-2.11-6.657a2 2 0 0 0-2.752-1.148l-1.276.61A2 2 0 0 1 12 4H8.5a2 2 0 0 0-1.925 1.456L5 11",
  key: "1fkr7p"
}], ["path", {
  d: "M2 11h20",
  key: "3eubbj"
}], ["circle", {
  cx: "17",
  cy: "18",
  r: "3",
  key: "82mm0e"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "3",
  key: "lvkj7j"
}]];
var Hash = [["line", {
  x1: "4",
  x2: "20",
  y1: "9",
  y2: "9",
  key: "4lhtct"
}], ["line", {
  x1: "4",
  x2: "20",
  y1: "15",
  y2: "15",
  key: "vyu0kd"
}], ["line", {
  x1: "10",
  x2: "8",
  y1: "3",
  y2: "21",
  key: "1ggp8o"
}], ["line", {
  x1: "16",
  x2: "14",
  y1: "3",
  y2: "21",
  key: "weycgp"
}]];
var Haze = [["path", {
  d: "m5.2 6.2 1.4 1.4",
  key: "17imol"
}], ["path", {
  d: "M2 13h2",
  key: "13gyu8"
}], ["path", {
  d: "M20 13h2",
  key: "16rner"
}], ["path", {
  d: "m17.4 7.6 1.4-1.4",
  key: "t4xlah"
}], ["path", {
  d: "M22 17H2",
  key: "1gtaj3"
}], ["path", {
  d: "M22 21H2",
  key: "1gy6en"
}], ["path", {
  d: "M16 13a4 4 0 0 0-8 0",
  key: "1dyczq"
}], ["path", {
  d: "M12 5V2.5",
  key: "1vytko"
}]];
var Hd = [["path", {
  d: "M10 12H6",
  key: "15f2ro"
}], ["path", {
  d: "M10 15V9",
  key: "1lckn7"
}], ["path", {
  d: "M14 14.5a.5.5 0 0 0 .5.5h1a2.5 2.5 0 0 0 2.5-2.5v-1A2.5 2.5 0 0 0 15.5 9h-1a.5.5 0 0 0-.5.5z",
  key: "b3f847"
}], ["path", {
  d: "M6 15V9",
  key: "12stmj"
}], ["rect", {
  x: "2",
  y: "5",
  width: "20",
  height: "14",
  rx: "2",
  key: "qneu4z"
}]];
var HdmiPort = [["path", {
  d: "M22 9a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h1l2 2h12l2-2h1a1 1 0 0 0 1-1Z",
  key: "2128wb"
}], ["path", {
  d: "M7.5 12h9",
  key: "1t0ckc"
}]];
var Heading1 = [["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["path", {
  d: "m17 12 3-2v8",
  key: "1hhhft"
}]];
var Heading2 = [["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["path", {
  d: "M21 18h-4c0-4 4-3 4-6 0-1.5-2-2.5-4-1",
  key: "9jr5yi"
}]];
var Heading3 = [["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["path", {
  d: "M17.5 10.5c1.7-1 3.5 0 3.5 1.5a2 2 0 0 1-2 2",
  key: "68ncm8"
}], ["path", {
  d: "M17 17.5c2 1.5 4 .3 4-1.5a2 2 0 0 0-2-2",
  key: "1ejuhz"
}]];
var Heading4 = [["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["path", {
  d: "M17 10v3a1 1 0 0 0 1 1h3",
  key: "tj5zdr"
}], ["path", {
  d: "M21 10v8",
  key: "1kdml4"
}], ["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}]];
var Heading5 = [["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["path", {
  d: "M17 13v-3h4",
  key: "1nvgqp"
}], ["path", {
  d: "M17 17.7c.4.2.8.3 1.3.3 1.5 0 2.7-1.1 2.7-2.5S19.8 13 18.3 13H17",
  key: "2nebdn"
}]];
var Heading6 = [["path", {
  d: "M4 12h8",
  key: "17cfdx"
}], ["path", {
  d: "M4 18V6",
  key: "1rz3zl"
}], ["path", {
  d: "M12 18V6",
  key: "zqpxq5"
}], ["circle", {
  cx: "19",
  cy: "16",
  r: "2",
  key: "15mx69"
}], ["path", {
  d: "M20 10c-2 2-3 3.5-3 6",
  key: "f35dl0"
}]];
var Heading = [["path", {
  d: "M6 12h12",
  key: "8npq4p"
}], ["path", {
  d: "M6 20V4",
  key: "1w1bmo"
}], ["path", {
  d: "M18 20V4",
  key: "o2hl4u"
}]];
var HeadphoneOff = [["path", {
  d: "M21 14h-1.343",
  key: "1jdnxi"
}], ["path", {
  d: "M9.128 3.47A9 9 0 0 1 21 12v3.343",
  key: "6kipu2"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20.414 20.414A2 2 0 0 1 19 21h-1a2 2 0 0 1-2-2v-3",
  key: "9x50f4"
}], ["path", {
  d: "M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 2.636-6.364",
  key: "1bkxnm"
}]];
var Headphones = [["path", {
  d: "M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3",
  key: "1xhozi"
}]];
var Headset = [["path", {
  d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z",
  key: "12oyoe"
}], ["path", {
  d: "M21 16v2a4 4 0 0 1-4 4h-5",
  key: "1x7m43"
}]];
var HeartCrack = [["path", {
  d: "M12.409 5.824c-.702.792-1.15 1.496-1.415 2.166l2.153 2.156a.5.5 0 0 1 0 .707l-2.293 2.293a.5.5 0 0 0 0 .707L12 15",
  key: "idzbju"
}], ["path", {
  d: "M13.508 20.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.677.6.6 0 0 0 .818.001A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5z",
  key: "1su70f"
}]];
var HeartHandshake = [["path", {
  d: "M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762",
  key: "17lmqv"
}]];
var HeartMinus = [["path", {
  d: "m14.876 18.99-1.368 1.323a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5a5.2 5.2 0 0 1-.244 1.572",
  key: "15yztm"
}], ["path", {
  d: "M15 15h6",
  key: "1u4692"
}]];
var HeartOff = [["path", {
  d: "M10.5 4.893a5.5 5.5 0 0 1 1.091.931.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 1.872-1.002 3.356-2.187 4.655",
  key: "1inpfl"
}], ["path", {
  d: "m16.967 16.967-3.459 3.346a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 2.747-4.761",
  key: "vbc6x7"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var HeartPlus = [["path", {
  d: "m14.479 19.374-.971.939a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5a5.2 5.2 0 0 1-.219 1.49",
  key: "wg5jx"
}], ["path", {
  d: "M15 15h6",
  key: "1u4692"
}], ["path", {
  d: "M18 12v6",
  key: "1houu1"
}]];
var HeartPulse = [["path", {
  d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
  key: "mvr1a0"
}], ["path", {
  d: "M3.22 13H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27",
  key: "auskq0"
}]];
var Heart = [["path", {
  d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
  key: "mvr1a0"
}]];
var Heater = [["path", {
  d: "M11 8c2-3-2-3 0-6",
  key: "1ldv5m"
}], ["path", {
  d: "M15.5 8c2-3-2-3 0-6",
  key: "1otqoz"
}], ["path", {
  d: "M6 10h.01",
  key: "1lbq93"
}], ["path", {
  d: "M6 14h.01",
  key: "zudwn7"
}], ["path", {
  d: "M10 16v-4",
  key: "1c25yv"
}], ["path", {
  d: "M14 16v-4",
  key: "1dkbt8"
}], ["path", {
  d: "M18 16v-4",
  key: "1yg9me"
}], ["path", {
  d: "M20 6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3",
  key: "1ubg90"
}], ["path", {
  d: "M5 20v2",
  key: "1abpe8"
}], ["path", {
  d: "M19 20v2",
  key: "kqn6ft"
}]];
var Helicopter = [["path", {
  d: "M11 17v4",
  key: "14wq8k"
}], ["path", {
  d: "M14 3v8a2 2 0 0 0 2 2h5.865",
  key: "12oo5h"
}], ["path", {
  d: "M17 17v4",
  key: "hdt4hh"
}], ["path", {
  d: "M18 17a4 4 0 0 0 4-4 8 6 0 0 0-8-6 6 5 0 0 0-6 5v3a2 2 0 0 0 2 2z",
  key: "yynif"
}], ["path", {
  d: "M2 10v5",
  key: "sa5akn"
}], ["path", {
  d: "M6 3h16",
  key: "27qw71"
}], ["path", {
  d: "M7 21h14",
  key: "1ugz0u"
}], ["path", {
  d: "M8 13H2",
  key: "1thz1o"
}]];
var Hexagon = [["path", {
  d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
  key: "yt0hxn"
}]];
var Highlighter = [["path", {
  d: "m9 11-6 6v3h9l3-3",
  key: "1a3l36"
}], ["path", {
  d: "m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4",
  key: "14a9rk"
}]];
var History = [["path", {
  d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
  key: "1357e3"
}], ["path", {
  d: "M3 3v5h5",
  key: "1xhq8a"
}], ["path", {
  d: "M12 7v5l4 2",
  key: "1fdv2h"
}]];
var HopOff = [["path", {
  d: "M10.82 16.12c1.69.6 3.91.79 5.18.85.28.01.53-.09.7-.27",
  key: "qyzcap"
}], ["path", {
  d: "M11.14 20.57c.52.24 2.44 1.12 4.08 1.37.46.06.86-.25.9-.71.12-1.52-.3-3.43-.5-4.28",
  key: "y078lb"
}], ["path", {
  d: "M16.13 21.05c1.65.63 3.68.84 4.87.91a.9.9 0 0 0 .7-.26",
  key: "1utre3"
}], ["path", {
  d: "M17.99 5.52a20.83 20.83 0 0 1 3.15 4.5.8.8 0 0 1-.68 1.13c-1.17.1-2.5.02-3.9-.25",
  key: "17o9hm"
}], ["path", {
  d: "M20.57 11.14c.24.52 1.12 2.44 1.37 4.08.04.3-.08.59-.31.75",
  key: "1d1n4p"
}], ["path", {
  d: "M4.93 4.93a10 10 0 0 0-.67 13.4c.35.43.96.4 1.17-.12.69-1.71 1.07-5.07 1.07-6.71 1.34.45 3.1.9 4.88.62a.85.85 0 0 0 .48-.24",
  key: "9uv3tt"
}], ["path", {
  d: "M5.52 17.99c1.05.95 2.91 2.42 4.5 3.15a.8.8 0 0 0 1.13-.68c.2-2.34-.33-5.3-1.57-8.28",
  key: "1292wz"
}], ["path", {
  d: "M8.35 2.68a10 10 0 0 1 9.98 1.58c.43.35.4.96-.12 1.17-1.5.6-4.3.98-6.07 1.05",
  key: "7ozu9p"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Hospital = [["path", {
  d: "M12 7v4",
  key: "xawao1"
}], ["path", {
  d: "M14 21v-3a2 2 0 0 0-4 0v3",
  key: "1rgiei"
}], ["path", {
  d: "M14 9h-4",
  key: "1w2s2s"
}], ["path", {
  d: "M18 11h2a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2h2",
  key: "1tthqt"
}], ["path", {
  d: "M18 21V5a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16",
  key: "dw4p4i"
}]];
var Hop = [["path", {
  d: "M10.82 16.12c1.69.6 3.91.79 5.18.85.55.03 1-.42.97-.97-.06-1.27-.26-3.5-.85-5.18",
  key: "18lxf1"
}], ["path", {
  d: "M11.5 6.5c1.64 0 5-.38 6.71-1.07.52-.2.55-.82.12-1.17A10 10 0 0 0 4.26 18.33c.35.43.96.4 1.17-.12.69-1.71 1.07-5.07 1.07-6.71 1.34.45 3.1.9 4.88.62a.88.88 0 0 0 .73-.74c.3-2.14-.15-3.5-.61-4.88",
  key: "vtfxrw"
}], ["path", {
  d: "M15.62 16.95c.2.85.62 2.76.5 4.28a.77.77 0 0 1-.9.7 16.64 16.64 0 0 1-4.08-1.36",
  key: "13hl71"
}], ["path", {
  d: "M16.13 21.05c1.65.63 3.68.84 4.87.91a.9.9 0 0 0 .96-.96 17.68 17.68 0 0 0-.9-4.87",
  key: "1sl8oj"
}], ["path", {
  d: "M16.94 15.62c.86.2 2.77.62 4.29.5a.77.77 0 0 0 .7-.9 16.64 16.64 0 0 0-1.36-4.08",
  key: "19c6kt"
}], ["path", {
  d: "M17.99 5.52a20.82 20.82 0 0 1 3.15 4.5.8.8 0 0 1-.68 1.13c-2.33.2-5.3-.32-8.27-1.57",
  key: "85ghs3"
}], ["path", {
  d: "M4.93 4.93 3 3a.7.7 0 0 1 0-1",
  key: "x087yj"
}], ["path", {
  d: "M9.58 12.18c1.24 2.98 1.77 5.95 1.57 8.28a.8.8 0 0 1-1.13.68 20.82 20.82 0 0 1-4.5-3.15",
  key: "11xdqo"
}]];
var Hotel = [["path", {
  d: "M10 22v-6.57",
  key: "1wmca3"
}], ["path", {
  d: "M12 11h.01",
  key: "z322tv"
}], ["path", {
  d: "M12 7h.01",
  key: "1ivr5q"
}], ["path", {
  d: "M14 15.43V22",
  key: "1q2vjd"
}], ["path", {
  d: "M15 16a5 5 0 0 0-6 0",
  key: "o9wqvi"
}], ["path", {
  d: "M16 11h.01",
  key: "xkw8gn"
}], ["path", {
  d: "M16 7h.01",
  key: "1kdx03"
}], ["path", {
  d: "M8 11h.01",
  key: "1dfujw"
}], ["path", {
  d: "M8 7h.01",
  key: "1vti4s"
}], ["rect", {
  x: "4",
  y: "2",
  width: "16",
  height: "20",
  rx: "2",
  key: "1uxh74"
}]];
var Hourglass = [["path", {
  d: "M5 22h14",
  key: "ehvnwv"
}], ["path", {
  d: "M5 2h14",
  key: "pdyrp9"
}], ["path", {
  d: "M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22",
  key: "1d314k"
}], ["path", {
  d: "M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2",
  key: "1vvvr6"
}]];
var HouseHeart = [["path", {
  d: "M8.62 13.8A2.25 2.25 0 1 1 12 10.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
  key: "n9s7kx"
}], ["path", {
  d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  key: "r6nss1"
}]];
var HousePlug = [["path", {
  d: "M10 12V8.964",
  key: "1vll13"
}], ["path", {
  d: "M14 12V8.964",
  key: "1x3qvg"
}], ["path", {
  d: "M15 12a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-2a1 1 0 0 1 1-1z",
  key: "ppykja"
}], ["path", {
  d: "M8.5 21H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2v-2",
  key: "365xoy"
}]];
var HousePlus = [["path", {
  d: "M12.35 21H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 .71-1.53l7-6a2 2 0 0 1 2.58 0l7 6A2 2 0 0 1 21 10v2.35",
  key: "8ek5ge"
}], ["path", {
  d: "M14.8 12.4A1 1 0 0 0 14 12h-4a1 1 0 0 0-1 1v8",
  key: "1rbg29"
}], ["path", {
  d: "M15 18h6",
  key: "3b3c90"
}], ["path", {
  d: "M18 15v6",
  key: "9wciyi"
}]];
var HouseWifi = [["path", {
  d: "M9.5 13.866a4 4 0 0 1 5 .01",
  key: "1wy54i"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}], ["path", {
  d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  key: "r6nss1"
}], ["path", {
  d: "M7 10.754a8 8 0 0 1 10 0",
  key: "exoy2g"
}]];
var House = [["path", {
  d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",
  key: "5wwlr5"
}], ["path", {
  d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  key: "r6nss1"
}]];
var IceCreamBowl = [["path", {
  d: "M12 17c5 0 8-2.69 8-6H4c0 3.31 3 6 8 6m-4 4h8m-4-3v3M5.14 11a3.5 3.5 0 1 1 6.71 0",
  key: "1uxfcu"
}], ["path", {
  d: "M12.14 11a3.5 3.5 0 1 1 6.71 0",
  key: "4k3m1s"
}], ["path", {
  d: "M15.5 6.5a3.5 3.5 0 1 0-7 0",
  key: "zmuahr"
}]];
var IceCreamCone = [["path", {
  d: "m7 11 4.08 10.35a1 1 0 0 0 1.84 0L17 11",
  key: "1v6356"
}], ["path", {
  d: "M17 7A5 5 0 0 0 7 7",
  key: "151p3v"
}], ["path", {
  d: "M17 7a2 2 0 0 1 0 4H7a2 2 0 0 1 0-4",
  key: "1sdaij"
}]];
var IdCardLanyard = [["path", {
  d: "M13.5 8h-3",
  key: "xvov4w"
}], ["path", {
  d: "m15 2-1 2h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h3",
  key: "16uttc"
}], ["path", {
  d: "M16.899 22A5 5 0 0 0 7.1 22",
  key: "1d0ppr"
}], ["path", {
  d: "m9 2 3 6",
  key: "1o7bd9"
}], ["circle", {
  cx: "12",
  cy: "15",
  r: "3",
  key: "g36mzq"
}]];
var IdCard = [["path", {
  d: "M16 10h2",
  key: "8sgtl7"
}], ["path", {
  d: "M16 14h2",
  key: "epxaof"
}], ["path", {
  d: "M6.17 15a3 3 0 0 1 5.66 0",
  key: "n6f512"
}], ["circle", {
  cx: "9",
  cy: "11",
  r: "2",
  key: "yxgjnd"
}], ["rect", {
  x: "2",
  y: "5",
  width: "20",
  height: "14",
  rx: "2",
  key: "qneu4z"
}]];
var ImageDown = [["path", {
  d: "M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",
  key: "9csbqa"
}], ["path", {
  d: "m14 19 3 3v-5.5",
  key: "9ldu5r"
}], ["path", {
  d: "m17 22 3-3",
  key: "1nkfve"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}]];
var ImageMinus = [["path", {
  d: "M21 9v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7",
  key: "m87ecr"
}], ["line", {
  x1: "16",
  x2: "22",
  y1: "5",
  y2: "5",
  key: "ez7e4s"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}], ["path", {
  d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",
  key: "1xmnt7"
}]];
var ImageOff = [["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}], ["path", {
  d: "M10.41 10.41a2 2 0 1 1-2.83-2.83",
  key: "1bzlo9"
}], ["line", {
  x1: "13.5",
  x2: "6",
  y1: "13.5",
  y2: "21",
  key: "1q0aeu"
}], ["line", {
  x1: "18",
  x2: "21",
  y1: "12",
  y2: "15",
  key: "5mozeu"
}], ["path", {
  d: "M3.59 3.59A1.99 1.99 0 0 0 3 5v14a2 2 0 0 0 2 2h14c.55 0 1.052-.22 1.41-.59",
  key: "mmje98"
}], ["path", {
  d: "M21 15V5a2 2 0 0 0-2-2H9",
  key: "43el77"
}]];
var ImagePlay = [["path", {
  d: "M15 15.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
  key: "nrt1m3"
}], ["path", {
  d: "M21 12.17V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6",
  key: "99hgts"
}], ["path", {
  d: "m6 21 5-5",
  key: "1wyjai"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}]];
var ImagePlus = [["path", {
  d: "M16 5h6",
  key: "1vod17"
}], ["path", {
  d: "M19 2v6",
  key: "4bpg5p"
}], ["path", {
  d: "M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5",
  key: "1ue2ih"
}], ["path", {
  d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",
  key: "1xmnt7"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}]];
var ImageUp = [["path", {
  d: "M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",
  key: "9csbqa"
}], ["path", {
  d: "m14 19.5 3-3 3 3",
  key: "9vmjn0"
}], ["path", {
  d: "M17 22v-5.5",
  key: "1aa6fl"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}]];
var ImageUpscale = [["path", {
  d: "M16 3h5v5",
  key: "1806ms"
}], ["path", {
  d: "M17 21h2a2 2 0 0 0 2-2",
  key: "130fy9"
}], ["path", {
  d: "M21 12v3",
  key: "1wzk3p"
}], ["path", {
  d: "m21 3-5 5",
  key: "1g5oa7"
}], ["path", {
  d: "M3 7V5a2 2 0 0 1 2-2",
  key: "kk3yz1"
}], ["path", {
  d: "m5 21 4.144-4.144a1.21 1.21 0 0 1 1.712 0L13 19",
  key: "fyekpt"
}], ["path", {
  d: "M9 3h3",
  key: "d52fa"
}], ["rect", {
  x: "3",
  y: "11",
  width: "10",
  height: "10",
  rx: "1",
  key: "1wpmix"
}]];
var Image = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["circle", {
  cx: "9",
  cy: "9",
  r: "2",
  key: "af1f0g"
}], ["path", {
  d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",
  key: "1xmnt7"
}]];
var Images = [["path", {
  d: "m22 11-1.296-1.296a2.4 2.4 0 0 0-3.408 0L11 16",
  key: "9kzy35"
}], ["path", {
  d: "M4 8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2",
  key: "1t0f0t"
}], ["circle", {
  cx: "13",
  cy: "7",
  r: "1",
  fill: "currentColor",
  key: "1obus6"
}], ["rect", {
  x: "8",
  y: "2",
  width: "14",
  height: "14",
  rx: "2",
  key: "1gvhby"
}]];
var Import = [["path", {
  d: "M12 3v12",
  key: "1x0j5s"
}], ["path", {
  d: "m8 11 4 4 4-4",
  key: "1dohi6"
}], ["path", {
  d: "M8 5H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-4",
  key: "1ywtjm"
}]];
var Inbox = [["polyline", {
  points: "22 12 16 12 14 15 10 15 8 12 2 12",
  key: "o97t9d"
}], ["path", {
  d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
  key: "oot6mr"
}]];
var IndianRupee = [["path", {
  d: "M6 3h12",
  key: "ggurg9"
}], ["path", {
  d: "M6 8h12",
  key: "6g4wlu"
}], ["path", {
  d: "m6 13 8.5 8",
  key: "u1kupk"
}], ["path", {
  d: "M6 13h3",
  key: "wdp6ag"
}], ["path", {
  d: "M9 13c6.667 0 6.667-10 0-10",
  key: "1nkvk2"
}]];
var Infinity = [["path", {
  d: "M6 16c5 0 7-8 12-8a4 4 0 0 1 0 8c-5 0-7-8-12-8a4 4 0 1 0 0 8",
  key: "18ogeb"
}]];
var Info = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M12 16v-4",
  key: "1dtifu"
}], ["path", {
  d: "M12 8h.01",
  key: "e9boi3"
}]];
var InspectionPanel = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 7h.01",
  key: "7u93v4"
}], ["path", {
  d: "M17 7h.01",
  key: "14a9sn"
}], ["path", {
  d: "M7 17h.01",
  key: "19xn7k"
}], ["path", {
  d: "M17 17h.01",
  key: "1sd3ek"
}]];
var Instagram = [["rect", {
  width: "20",
  height: "20",
  x: "2",
  y: "2",
  rx: "5",
  ry: "5",
  key: "2e1cvw"
}], ["path", {
  d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",
  key: "9exkf1"
}], ["line", {
  x1: "17.5",
  x2: "17.51",
  y1: "6.5",
  y2: "6.5",
  key: "r4j83e"
}]];
var IterationCcw = [["path", {
  d: "m16 14 4 4-4 4",
  key: "hkso8o"
}], ["path", {
  d: "M20 10a8 8 0 1 0-8 8h8",
  key: "1bik7b"
}]];
var Italic = [["line", {
  x1: "19",
  x2: "10",
  y1: "4",
  y2: "4",
  key: "15jd3p"
}], ["line", {
  x1: "14",
  x2: "5",
  y1: "20",
  y2: "20",
  key: "bu0au3"
}], ["line", {
  x1: "15",
  x2: "9",
  y1: "4",
  y2: "20",
  key: "uljnxc"
}]];
var IterationCw = [["path", {
  d: "M4 10a8 8 0 1 1 8 8H4",
  key: "svv66n"
}], ["path", {
  d: "m8 22-4-4 4-4",
  key: "6g7gki"
}]];
var JapaneseYen = [["path", {
  d: "M12 9.5V21m0-11.5L6 3m6 6.5L18 3",
  key: "2ej80x"
}], ["path", {
  d: "M6 15h12",
  key: "1hwgt5"
}], ["path", {
  d: "M6 11h12",
  key: "wf4gp6"
}]];
var Joystick = [["path", {
  d: "M21 17a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2Z",
  key: "jg2n2t"
}], ["path", {
  d: "M6 15v-2",
  key: "gd6mvg"
}], ["path", {
  d: "M12 15V9",
  key: "8c7uyn"
}], ["circle", {
  cx: "12",
  cy: "6",
  r: "3",
  key: "1gm2ql"
}]];
var Kanban = [["path", {
  d: "M5 3v14",
  key: "9nsxs2"
}], ["path", {
  d: "M12 3v8",
  key: "1h2ygw"
}], ["path", {
  d: "M19 3v18",
  key: "1sk56x"
}]];
var Kayak = [["path", {
  d: "M18 17a1 1 0 0 0-1 1v1a2 2 0 1 0 2-2z",
  key: "skzb1g"
}], ["path", {
  d: "M20.97 3.61a.45.45 0 0 0-.58-.58C10.2 6.6 6.6 10.2 3.03 20.39a.45.45 0 0 0 .58.58C13.8 17.4 17.4 13.8 20.97 3.61",
  key: "cv9jm7"
}], ["path", {
  d: "m6.707 6.707 10.586 10.586",
  key: "d2l993"
}], ["path", {
  d: "M7 5a2 2 0 1 0-2 2h1a1 1 0 0 0 1-1z",
  key: "i0et4n"
}]];
var KeyRound = [["path", {
  d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
  key: "1s6t7t"
}], ["circle", {
  cx: "16.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "w0ekpg"
}]];
var KeySquare = [["path", {
  d: "M12.4 2.7a2.5 2.5 0 0 1 3.4 0l5.5 5.5a2.5 2.5 0 0 1 0 3.4l-3.7 3.7a2.5 2.5 0 0 1-3.4 0L8.7 9.8a2.5 2.5 0 0 1 0-3.4z",
  key: "165ttr"
}], ["path", {
  d: "m14 7 3 3",
  key: "1r5n42"
}], ["path", {
  d: "m9.4 10.6-6.814 6.814A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814",
  key: "1ubxi2"
}]];
var Key = [["path", {
  d: "m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",
  key: "g0fldk"
}], ["path", {
  d: "m21 2-9.6 9.6",
  key: "1j0ho8"
}], ["circle", {
  cx: "7.5",
  cy: "15.5",
  r: "5.5",
  key: "yqb3hr"
}]];
var KeyboardOff = [["path", {
  d: "M 20 4 A2 2 0 0 1 22 6",
  key: "1g1fkt"
}], ["path", {
  d: "M 22 6 L 22 16.41",
  key: "1qjg3w"
}], ["path", {
  d: "M 7 16 L 16 16",
  key: "n0yqwb"
}], ["path", {
  d: "M 9.69 4 L 20 4",
  key: "kbpcgx"
}], ["path", {
  d: "M14 8h.01",
  key: "1primd"
}], ["path", {
  d: "M18 8h.01",
  key: "emo2bl"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2",
  key: "s23sx2"
}], ["path", {
  d: "M6 8h.01",
  key: "x9i8wu"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}]];
var KeyboardMusic = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M6 8h4",
  key: "utf9t1"
}], ["path", {
  d: "M14 8h.01",
  key: "1primd"
}], ["path", {
  d: "M18 8h.01",
  key: "emo2bl"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "M6 12v4",
  key: "dy92yo"
}], ["path", {
  d: "M10 12v4",
  key: "1fxnav"
}], ["path", {
  d: "M14 12v4",
  key: "1hft58"
}], ["path", {
  d: "M18 12v4",
  key: "tjjnbz"
}]];
var LampCeiling = [["path", {
  d: "M12 2v5",
  key: "nd4vlx"
}], ["path", {
  d: "M14.829 15.998a3 3 0 1 1-5.658 0",
  key: "1pybiy"
}], ["path", {
  d: "M20.92 14.606A1 1 0 0 1 20 16H4a1 1 0 0 1-.92-1.394l3-7A1 1 0 0 1 7 7h10a1 1 0 0 1 .92.606z",
  key: "ma1wor"
}]];
var Keyboard = [["path", {
  d: "M10 8h.01",
  key: "1r9ogq"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M14 8h.01",
  key: "1primd"
}], ["path", {
  d: "M16 12h.01",
  key: "1l6xoz"
}], ["path", {
  d: "M18 8h.01",
  key: "emo2bl"
}], ["path", {
  d: "M6 8h.01",
  key: "x9i8wu"
}], ["path", {
  d: "M7 16h10",
  key: "wp8him"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}], ["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}]];
var LampFloor = [["path", {
  d: "M12 10v12",
  key: "6ubwww"
}], ["path", {
  d: "M17.929 7.629A1 1 0 0 1 17 9H7a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 9 2h6a1 1 0 0 1 .928.629z",
  key: "1o95gh"
}], ["path", {
  d: "M9 22h6",
  key: "1rlq3v"
}]];
var LampDesk = [["path", {
  d: "M10.293 2.293a1 1 0 0 1 1.414 0l2.5 2.5 5.994 1.227a1 1 0 0 1 .506 1.687l-7 7a1 1 0 0 1-1.687-.506l-1.227-5.994-2.5-2.5a1 1 0 0 1 0-1.414z",
  key: "sb8slu"
}], ["path", {
  d: "m14.207 4.793-3.414 3.414",
  key: "m2x3oj"
}], ["path", {
  d: "M3 20a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z",
  key: "8b3myj"
}], ["path", {
  d: "m9.086 6.5-4.793 4.793a1 1 0 0 0-.18 1.17L7 18",
  key: "43s6cu"
}]];
var LampWallDown = [["path", {
  d: "M19.929 18.629A1 1 0 0 1 19 20H9a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 11 13h6a1 1 0 0 1 .928.629z",
  key: "u4w2d7"
}], ["path", {
  d: "M6 3a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z",
  key: "15356w"
}], ["path", {
  d: "M8 6h4a2 2 0 0 1 2 2v5",
  key: "1m6m7x"
}]];
var LampWallUp = [["path", {
  d: "M19.929 9.629A1 1 0 0 1 19 11H9a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 11 4h6a1 1 0 0 1 .928.629z",
  key: "1uvrbf"
}], ["path", {
  d: "M6 15a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z",
  key: "154r2a"
}], ["path", {
  d: "M8 18h4a2 2 0 0 0 2-2v-5",
  key: "z9mbu0"
}]];
var Lamp = [["path", {
  d: "M12 12v6",
  key: "3ahymv"
}], ["path", {
  d: "M4.077 10.615A1 1 0 0 0 5 12h14a1 1 0 0 0 .923-1.385l-3.077-7.384A2 2 0 0 0 15 2H9a2 2 0 0 0-1.846 1.23Z",
  key: "1l7kg2"
}], ["path", {
  d: "M8 20a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1z",
  key: "1mmzpi"
}]];
var LandPlot = [["path", {
  d: "m12 8 6-3-6-3v10",
  key: "mvpnpy"
}], ["path", {
  d: "m8 11.99-5.5 3.14a1 1 0 0 0 0 1.74l8.5 4.86a2 2 0 0 0 2 0l8.5-4.86a1 1 0 0 0 0-1.74L16 12",
  key: "ek95tt"
}], ["path", {
  d: "m6.49 12.85 11.02 6.3",
  key: "1kt42w"
}], ["path", {
  d: "M17.51 12.85 6.5 19.15",
  key: "v55bdg"
}]];
var Landmark = [["path", {
  d: "M10 18v-7",
  key: "wt116b"
}], ["path", {
  d: "M11.12 2.198a2 2 0 0 1 1.76.006l7.866 3.847c.476.233.31.949-.22.949H3.474c-.53 0-.695-.716-.22-.949z",
  key: "1m329m"
}], ["path", {
  d: "M14 18v-7",
  key: "vav6t3"
}], ["path", {
  d: "M18 18v-7",
  key: "aexdmj"
}], ["path", {
  d: "M3 22h18",
  key: "8prr45"
}], ["path", {
  d: "M6 18v-7",
  key: "1ivflk"
}]];
var Languages = [["path", {
  d: "m5 8 6 6",
  key: "1wu5hv"
}], ["path", {
  d: "m4 14 6-6 2-3",
  key: "1k1g8d"
}], ["path", {
  d: "M2 5h12",
  key: "or177f"
}], ["path", {
  d: "M7 2h1",
  key: "1t2jsx"
}], ["path", {
  d: "m22 22-5-10-5 10",
  key: "don7ne"
}], ["path", {
  d: "M14 18h6",
  key: "1m8k6r"
}]];
var LaptopMinimalCheck = [["path", {
  d: "M2 20h20",
  key: "owomy5"
}], ["path", {
  d: "m9 10 2 2 4-4",
  key: "1gnqz4"
}], ["rect", {
  x: "3",
  y: "4",
  width: "18",
  height: "12",
  rx: "2",
  key: "8ur36m"
}]];
var LaptopMinimal = [["rect", {
  width: "18",
  height: "12",
  x: "3",
  y: "4",
  rx: "2",
  ry: "2",
  key: "1qhy41"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "20",
  y2: "20",
  key: "ni3hll"
}]];
var Laptop = [["path", {
  d: "M18 5a2 2 0 0 1 2 2v8.526a2 2 0 0 0 .212.897l1.068 2.127a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45l1.068-2.127A2 2 0 0 0 4 15.526V7a2 2 0 0 1 2-2z",
  key: "1pdavp"
}], ["path", {
  d: "M20.054 15.987H3.946",
  key: "14rxg9"
}]];
var LassoSelect = [["path", {
  d: "M7 22a5 5 0 0 1-2-4",
  key: "umushi"
}], ["path", {
  d: "M7 16.93c.96.43 1.96.74 2.99.91",
  key: "ybbtv3"
}], ["path", {
  d: "M3.34 14A6.8 6.8 0 0 1 2 10c0-4.42 4.48-8 10-8s10 3.58 10 8a7.19 7.19 0 0 1-.33 2",
  key: "gt5e1w"
}], ["path", {
  d: "M5 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z",
  key: "bq3ynw"
}], ["path", {
  d: "M14.33 22h-.09a.35.35 0 0 1-.24-.32v-10a.34.34 0 0 1 .33-.34c.08 0 .15.03.21.08l7.34 6a.33.33 0 0 1-.21.59h-4.49l-2.57 3.85a.35.35 0 0 1-.28.14z",
  key: "72q637"
}]];
var Lasso = [["path", {
  d: "M3.704 14.467a10 8 0 1 1 3.115 2.375",
  key: "wxgc5m"
}], ["path", {
  d: "M7 22a5 5 0 0 1-2-3.994",
  key: "1xp6a4"
}], ["circle", {
  cx: "5",
  cy: "16",
  r: "2",
  key: "18csp3"
}]];
var Laugh = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M18 13a6 6 0 0 1-6 5 6 6 0 0 1-6-5h12Z",
  key: "b2q4dd"
}], ["line", {
  x1: "9",
  x2: "9.01",
  y1: "9",
  y2: "9",
  key: "yxxnd0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "9",
  y2: "9",
  key: "1p4y9e"
}]];
var Layers2 = [["path", {
  d: "M13 13.74a2 2 0 0 1-2 0L2.5 8.87a1 1 0 0 1 0-1.74L11 2.26a2 2 0 0 1 2 0l8.5 4.87a1 1 0 0 1 0 1.74z",
  key: "15q6uc"
}], ["path", {
  d: "m20 14.285 1.5.845a1 1 0 0 1 0 1.74L13 21.74a2 2 0 0 1-2 0l-8.5-4.87a1 1 0 0 1 0-1.74l1.5-.845",
  key: "byia6g"
}]];
var LayersPlus = [["path", {
  d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 .83.18 2 2 0 0 0 .83-.18l8.58-3.9a1 1 0 0 0 0-1.831z",
  key: "zzgyd3"
}], ["path", {
  d: "M16 17h6",
  key: "1ook5g"
}], ["path", {
  d: "M19 14v6",
  key: "1ckrd5"
}], ["path", {
  d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 .825.178",
  key: "1ia9y3"
}], ["path", {
  d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l2.116-.962",
  key: "jksky3"
}]];
var Layers = [["path", {
  d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
  key: "zw3jo"
}], ["path", {
  d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
  key: "1wduqc"
}], ["path", {
  d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
  key: "kqbvx6"
}]];
var LayoutDashboard = [["rect", {
  width: "7",
  height: "9",
  x: "3",
  y: "3",
  rx: "1",
  key: "10lvy0"
}], ["rect", {
  width: "7",
  height: "5",
  x: "14",
  y: "3",
  rx: "1",
  key: "16une8"
}], ["rect", {
  width: "7",
  height: "9",
  x: "14",
  y: "12",
  rx: "1",
  key: "1hutg5"
}], ["rect", {
  width: "7",
  height: "5",
  x: "3",
  y: "16",
  rx: "1",
  key: "ldoo1y"
}]];
var LayoutGrid = [["rect", {
  width: "7",
  height: "7",
  x: "3",
  y: "3",
  rx: "1",
  key: "1g98yp"
}], ["rect", {
  width: "7",
  height: "7",
  x: "14",
  y: "3",
  rx: "1",
  key: "6d4xhi"
}], ["rect", {
  width: "7",
  height: "7",
  x: "14",
  y: "14",
  rx: "1",
  key: "nxv5o0"
}], ["rect", {
  width: "7",
  height: "7",
  x: "3",
  y: "14",
  rx: "1",
  key: "1bb6yr"
}]];
var LayoutList = [["rect", {
  width: "7",
  height: "7",
  x: "3",
  y: "3",
  rx: "1",
  key: "1g98yp"
}], ["rect", {
  width: "7",
  height: "7",
  x: "3",
  y: "14",
  rx: "1",
  key: "1bb6yr"
}], ["path", {
  d: "M14 4h7",
  key: "3xa0d5"
}], ["path", {
  d: "M14 9h7",
  key: "1icrd9"
}], ["path", {
  d: "M14 15h7",
  key: "1mj8o2"
}], ["path", {
  d: "M14 20h7",
  key: "11slyb"
}]];
var LayoutPanelLeft = [["rect", {
  width: "7",
  height: "18",
  x: "3",
  y: "3",
  rx: "1",
  key: "2obqm"
}], ["rect", {
  width: "7",
  height: "7",
  x: "14",
  y: "3",
  rx: "1",
  key: "6d4xhi"
}], ["rect", {
  width: "7",
  height: "7",
  x: "14",
  y: "14",
  rx: "1",
  key: "nxv5o0"
}]];
var LayoutPanelTop = [["rect", {
  width: "18",
  height: "7",
  x: "3",
  y: "3",
  rx: "1",
  key: "f1a2em"
}], ["rect", {
  width: "7",
  height: "7",
  x: "3",
  y: "14",
  rx: "1",
  key: "1bb6yr"
}], ["rect", {
  width: "7",
  height: "7",
  x: "14",
  y: "14",
  rx: "1",
  key: "nxv5o0"
}]];
var LayoutTemplate = [["rect", {
  width: "18",
  height: "7",
  x: "3",
  y: "3",
  rx: "1",
  key: "f1a2em"
}], ["rect", {
  width: "9",
  height: "7",
  x: "3",
  y: "14",
  rx: "1",
  key: "jqznyg"
}], ["rect", {
  width: "5",
  height: "7",
  x: "16",
  y: "14",
  rx: "1",
  key: "q5h2i8"
}]];
var Leaf = [["path", {
  d: "M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",
  key: "nnexq3"
}], ["path", {
  d: "M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12",
  key: "mt58a7"
}]];
var LeafyGreen = [["path", {
  d: "M2 22c1.25-.987 2.27-1.975 3.9-2.2a5.56 5.56 0 0 1 3.8 1.5 4 4 0 0 0 6.187-2.353 3.5 3.5 0 0 0 3.69-5.116A3.5 3.5 0 0 0 20.95 8 3.5 3.5 0 1 0 16 3.05a3.5 3.5 0 0 0-5.831 1.373 3.5 3.5 0 0 0-5.116 3.69 4 4 0 0 0-2.348 6.155C3.499 15.42 4.409 16.712 4.2 18.1 3.926 19.743 3.014 20.732 2 22",
  key: "1134nt"
}], ["path", {
  d: "M2 22 17 7",
  key: "1q7jp2"
}]];
var Lectern = [["path", {
  d: "M16 12h3a2 2 0 0 0 1.902-1.38l1.056-3.333A1 1 0 0 0 21 6H3a1 1 0 0 0-.958 1.287l1.056 3.334A2 2 0 0 0 5 12h3",
  key: "13jjxg"
}], ["path", {
  d: "M18 6V3a1 1 0 0 0-1-1h-3",
  key: "1550fe"
}], ["rect", {
  width: "8",
  height: "12",
  x: "8",
  y: "10",
  rx: "1",
  key: "qmu8b6"
}]];
var LensConcave = [["path", {
  d: "M7 2a1 1 0 0 0-.8 1.6 14 14 0 0 1 0 16.8A1 1 0 0 0 7 22h10a1 1 0 0 0 .8-1.6 14 14 0 0 1 0-16.8A1 1 0 0 0 17 2z",
  key: "109j23"
}]];
var LensConvex = [["path", {
  d: "M13.433 2a1 1 0 0 1 .824.448 18 18 0 0 1 0 19.104 1 1 0 0 1-.824.448h-2.866a1 1 0 0 1-.824-.448 18 18 0 0 1 0-19.104A1 1 0 0 1 10.567 2z",
  key: "cq67go"
}]];
var LibraryBig = [["rect", {
  width: "8",
  height: "18",
  x: "3",
  y: "3",
  rx: "1",
  key: "oynpb5"
}], ["path", {
  d: "M7 3v18",
  key: "bbkbws"
}], ["path", {
  d: "M20.4 18.9c.2.5-.1 1.1-.6 1.3l-1.9.7c-.5.2-1.1-.1-1.3-.6L11.1 5.1c-.2-.5.1-1.1.6-1.3l1.9-.7c.5-.2 1.1.1 1.3.6Z",
  key: "1qboyk"
}]];
var Library = [["path", {
  d: "m16 6 4 14",
  key: "ji33uf"
}], ["path", {
  d: "M12 6v14",
  key: "1n7gus"
}], ["path", {
  d: "M8 8v12",
  key: "1gg7y9"
}], ["path", {
  d: "M4 4v16",
  key: "6qkkli"
}]];
var LifeBuoy = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "m4.93 4.93 4.24 4.24",
  key: "1ymg45"
}], ["path", {
  d: "m14.83 9.17 4.24-4.24",
  key: "1cb5xl"
}], ["path", {
  d: "m14.83 14.83 4.24 4.24",
  key: "q42g0n"
}], ["path", {
  d: "m9.17 14.83-4.24 4.24",
  key: "bqpfvv"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}]];
var Ligature = [["path", {
  d: "M14 12h2v8",
  key: "c1fccl"
}], ["path", {
  d: "M14 20h4",
  key: "lzx1xo"
}], ["path", {
  d: "M6 12h4",
  key: "a4o3ry"
}], ["path", {
  d: "M6 20h4",
  key: "1i6q5t"
}], ["path", {
  d: "M8 20V8a4 4 0 0 1 7.464-2",
  key: "wk9t6r"
}]];
var LightbulbOff = [["path", {
  d: "M16.8 11.2c.8-.9 1.2-2 1.2-3.2a6 6 0 0 0-9.3-5",
  key: "1fkcox"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M6.3 6.3a4.67 4.67 0 0 0 1.2 5.2c.7.7 1.3 1.5 1.5 2.5",
  key: "10m8kw"
}], ["path", {
  d: "M9 18h6",
  key: "x1upvd"
}], ["path", {
  d: "M10 22h4",
  key: "ceow96"
}]];
var Lightbulb = [["path", {
  d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",
  key: "1gvzjb"
}], ["path", {
  d: "M9 18h6",
  key: "x1upvd"
}], ["path", {
  d: "M10 22h4",
  key: "ceow96"
}]];
var LineDotRightHorizontal = [["path", {
  d: "M 3 12 L 15 12",
  key: "ymhu98"
}], ["circle", {
  cx: "18",
  cy: "12",
  r: "3",
  key: "1kchzo"
}]];
var LineSquiggle = [["path", {
  d: "M7 3.5c5-2 7 2.5 3 4C1.5 10 2 15 5 16c5 2 9-10 14-7s.5 13.5-4 12c-5-2.5.5-11 6-2",
  key: "1lrphd"
}]];
var Link2Off = [["path", {
  d: "M9 17H7A5 5 0 0 1 7 7",
  key: "10o201"
}], ["path", {
  d: "M15 7h2a5 5 0 0 1 4 8",
  key: "1d3206"
}], ["line", {
  x1: "8",
  x2: "12",
  y1: "12",
  y2: "12",
  key: "rvw6j4"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Link2 = [["path", {
  d: "M9 17H7A5 5 0 0 1 7 7h2",
  key: "8i5ue5"
}], ["path", {
  d: "M15 7h2a5 5 0 1 1 0 10h-2",
  key: "1b9ql8"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "12",
  y2: "12",
  key: "1jonct"
}]];
var Link = [["path", {
  d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",
  key: "1cjeqo"
}], ["path", {
  d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",
  key: "19qd67"
}]];
var Linkedin = [["path", {
  d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",
  key: "c2jq9f"
}], ["rect", {
  width: "4",
  height: "12",
  x: "2",
  y: "9",
  key: "mk3on5"
}], ["circle", {
  cx: "4",
  cy: "4",
  r: "2",
  key: "bt5ra8"
}]];
var ListCheck = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M16 12H3",
  key: "1a2rj7"
}], ["path", {
  d: "M11 19H3",
  key: "zflm78"
}], ["path", {
  d: "m15 18 2 2 4-4",
  key: "1szwhi"
}]];
var ListChecks = [["path", {
  d: "M13 5h8",
  key: "a7qcls"
}], ["path", {
  d: "M13 12h8",
  key: "h98zly"
}], ["path", {
  d: "M13 19h8",
  key: "c3s6r1"
}], ["path", {
  d: "m3 17 2 2 4-4",
  key: "1jhpwq"
}], ["path", {
  d: "m3 7 2 2 4-4",
  key: "1obspn"
}]];
var ListChevronsDownUp = [["path", {
  d: "M3 5h8",
  key: "18g2rq"
}], ["path", {
  d: "M3 12h8",
  key: "1xfjp6"
}], ["path", {
  d: "M3 19h8",
  key: "fpbke4"
}], ["path", {
  d: "m15 5 3 3 3-3",
  key: "1t4thf"
}], ["path", {
  d: "m15 19 3-3 3 3",
  key: "y4ckd2"
}]];
var ListChevronsUpDown = [["path", {
  d: "M3 5h8",
  key: "18g2rq"
}], ["path", {
  d: "M3 12h8",
  key: "1xfjp6"
}], ["path", {
  d: "M3 19h8",
  key: "fpbke4"
}], ["path", {
  d: "m15 8 3-3 3 3",
  key: "bc4io6"
}], ["path", {
  d: "m15 16 3 3 3-3",
  key: "9wmg1l"
}]];
var ListCollapse = [["path", {
  d: "M10 5h11",
  key: "1hkqpe"
}], ["path", {
  d: "M10 12h11",
  key: "6m4ad9"
}], ["path", {
  d: "M10 19h11",
  key: "14g2nv"
}], ["path", {
  d: "m3 10 3-3-3-3",
  key: "i7pm08"
}], ["path", {
  d: "m3 20 3-3-3-3",
  key: "20gx1n"
}]];
var ListEnd = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M16 12H3",
  key: "1a2rj7"
}], ["path", {
  d: "M9 19H3",
  key: "s61nz1"
}], ["path", {
  d: "m16 16-3 3 3 3",
  key: "117b85"
}], ["path", {
  d: "M21 5v12a2 2 0 0 1-2 2h-6",
  key: "hey24a"
}]];
var ListFilterPlus = [["path", {
  d: "M12 5H2",
  key: "1o22fu"
}], ["path", {
  d: "M6 12h12",
  key: "8npq4p"
}], ["path", {
  d: "M9 19h6",
  key: "456am0"
}], ["path", {
  d: "M16 5h6",
  key: "1vod17"
}], ["path", {
  d: "M19 8V2",
  key: "1wcffq"
}]];
var ListFilter = [["path", {
  d: "M2 5h20",
  key: "1fs1ex"
}], ["path", {
  d: "M6 12h12",
  key: "8npq4p"
}], ["path", {
  d: "M9 19h6",
  key: "456am0"
}]];
var ListIndentDecrease = [["path", {
  d: "M21 5H11",
  key: "us1j55"
}], ["path", {
  d: "M21 12H11",
  key: "wd7e0v"
}], ["path", {
  d: "M21 19H11",
  key: "saa85w"
}], ["path", {
  d: "m7 8-4 4 4 4",
  key: "o5hrat"
}]];
var ListIndentIncrease = [["path", {
  d: "M21 5H11",
  key: "us1j55"
}], ["path", {
  d: "M21 12H11",
  key: "wd7e0v"
}], ["path", {
  d: "M21 19H11",
  key: "saa85w"
}], ["path", {
  d: "m3 8 4 4-4 4",
  key: "1a3j6y"
}]];
var ListMinus = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M11 12H3",
  key: "51ecnj"
}], ["path", {
  d: "M16 19H3",
  key: "zzsher"
}], ["path", {
  d: "M21 12h-6",
  key: "bt1uis"
}]];
var ListMusic = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M11 12H3",
  key: "51ecnj"
}], ["path", {
  d: "M11 19H3",
  key: "zflm78"
}], ["path", {
  d: "M21 16V5",
  key: "yxg4q8"
}], ["circle", {
  cx: "18",
  cy: "16",
  r: "3",
  key: "1hluhg"
}]];
var ListOrdered = [["path", {
  d: "M11 5h10",
  key: "1cz7ny"
}], ["path", {
  d: "M11 12h10",
  key: "1438ji"
}], ["path", {
  d: "M11 19h10",
  key: "11t30w"
}], ["path", {
  d: "M4 4h1v5",
  key: "10yrso"
}], ["path", {
  d: "M4 9h2",
  key: "r1h2o0"
}], ["path", {
  d: "M6.5 20H3.4c0-1 2.6-1.925 2.6-3.5a1.5 1.5 0 0 0-2.6-1.02",
  key: "xtkcd5"
}]];
var ListRestart = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M7 12H3",
  key: "13ou7f"
}], ["path", {
  d: "M7 19H3",
  key: "wbqt3n"
}], ["path", {
  d: "M12 18a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5c-1.33 0-2.54.54-3.41 1.41L11 14",
  key: "qth677"
}], ["path", {
  d: "M11 10v4h4",
  key: "172dkj"
}]];
var ListPlus = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M11 12H3",
  key: "51ecnj"
}], ["path", {
  d: "M16 19H3",
  key: "zzsher"
}], ["path", {
  d: "M18 9v6",
  key: "1twb98"
}], ["path", {
  d: "M21 12h-6",
  key: "bt1uis"
}]];
var ListTodo = [["path", {
  d: "M13 5h8",
  key: "a7qcls"
}], ["path", {
  d: "M13 12h8",
  key: "h98zly"
}], ["path", {
  d: "M13 19h8",
  key: "c3s6r1"
}], ["path", {
  d: "m3 17 2 2 4-4",
  key: "1jhpwq"
}], ["rect", {
  x: "3",
  y: "4",
  width: "6",
  height: "6",
  rx: "1",
  key: "cif1o7"
}]];
var ListStart = [["path", {
  d: "M3 5h6",
  key: "1ltk0q"
}], ["path", {
  d: "M3 12h13",
  key: "ppymz1"
}], ["path", {
  d: "M3 19h13",
  key: "bpdczq"
}], ["path", {
  d: "m16 8-3-3 3-3",
  key: "1pjpp6"
}], ["path", {
  d: "M21 19V7a2 2 0 0 0-2-2h-6",
  key: "4zzq67"
}]];
var ListTree = [["path", {
  d: "M8 5h13",
  key: "1pao27"
}], ["path", {
  d: "M13 12h8",
  key: "h98zly"
}], ["path", {
  d: "M13 19h8",
  key: "c3s6r1"
}], ["path", {
  d: "M3 10a2 2 0 0 0 2 2h3",
  key: "1npucw"
}], ["path", {
  d: "M3 5v12a2 2 0 0 0 2 2h3",
  key: "x1gjn2"
}]];
var ListVideo = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M10 12H3",
  key: "1ulcyk"
}], ["path", {
  d: "M10 19H3",
  key: "108z41"
}], ["path", {
  d: "M15 12.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
  key: "ms4nik"
}]];
var ListX = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M11 12H3",
  key: "51ecnj"
}], ["path", {
  d: "M16 19H3",
  key: "zzsher"
}], ["path", {
  d: "m15.5 9.5 5 5",
  key: "ytk86i"
}], ["path", {
  d: "m20.5 9.5-5 5",
  key: "17o44f"
}]];
var List = [["path", {
  d: "M3 5h.01",
  key: "18ugdj"
}], ["path", {
  d: "M3 12h.01",
  key: "nlz23k"
}], ["path", {
  d: "M3 19h.01",
  key: "noohij"
}], ["path", {
  d: "M8 5h13",
  key: "1pao27"
}], ["path", {
  d: "M8 12h13",
  key: "1za7za"
}], ["path", {
  d: "M8 19h13",
  key: "m83p4d"
}]];
var LoaderCircle = [["path", {
  d: "M21 12a9 9 0 1 1-6.219-8.56",
  key: "13zald"
}]];
var LoaderPinwheel = [["path", {
  d: "M22 12a1 1 0 0 1-10 0 1 1 0 0 0-10 0",
  key: "1lzz15"
}], ["path", {
  d: "M7 20.7a1 1 0 1 1 5-8.7 1 1 0 1 0 5-8.6",
  key: "1gnrpi"
}], ["path", {
  d: "M7 3.3a1 1 0 1 1 5 8.6 1 1 0 1 0 5 8.6",
  key: "u9yy5q"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var Loader = [["path", {
  d: "M12 2v4",
  key: "3427ic"
}], ["path", {
  d: "m16.2 7.8 2.9-2.9",
  key: "r700ao"
}], ["path", {
  d: "M18 12h4",
  key: "wj9ykh"
}], ["path", {
  d: "m16.2 16.2 2.9 2.9",
  key: "1bxg5t"
}], ["path", {
  d: "M12 18v4",
  key: "jadmvz"
}], ["path", {
  d: "m4.9 19.1 2.9-2.9",
  key: "bwix9q"
}], ["path", {
  d: "M2 12h4",
  key: "j09sii"
}], ["path", {
  d: "m4.9 4.9 2.9 2.9",
  key: "giyufr"
}]];
var LocateFixed = [["line", {
  x1: "2",
  x2: "5",
  y1: "12",
  y2: "12",
  key: "bvdh0s"
}], ["line", {
  x1: "19",
  x2: "22",
  y1: "12",
  y2: "12",
  key: "1tbv5k"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "2",
  y2: "5",
  key: "11lu5j"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "19",
  y2: "22",
  key: "x3vr5v"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "7",
  key: "fim9np"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}]];
var LocateOff = [["path", {
  d: "M12 19v3",
  key: "npa21l"
}], ["path", {
  d: "M12 2v3",
  key: "qbqxhf"
}], ["path", {
  d: "M18.89 13.24a7 7 0 0 0-8.13-8.13",
  key: "1v9jrh"
}], ["path", {
  d: "M19 12h3",
  key: "osuazr"
}], ["path", {
  d: "M2 12h3",
  key: "1wrr53"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M7.05 7.05a7 7 0 0 0 9.9 9.9",
  key: "rc5l2e"
}]];
var Locate = [["line", {
  x1: "2",
  x2: "5",
  y1: "12",
  y2: "12",
  key: "bvdh0s"
}], ["line", {
  x1: "19",
  x2: "22",
  y1: "12",
  y2: "12",
  key: "1tbv5k"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "2",
  y2: "5",
  key: "11lu5j"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "19",
  y2: "22",
  key: "x3vr5v"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "7",
  key: "fim9np"
}]];
var LockKeyholeOpen = [["circle", {
  cx: "12",
  cy: "16",
  r: "1",
  key: "1au0dj"
}], ["rect", {
  width: "18",
  height: "12",
  x: "3",
  y: "10",
  rx: "2",
  key: "l0tzu3"
}], ["path", {
  d: "M7 10V7a5 5 0 0 1 9.33-2.5",
  key: "car5b7"
}]];
var LockKeyhole = [["circle", {
  cx: "12",
  cy: "16",
  r: "1",
  key: "1au0dj"
}], ["rect", {
  x: "3",
  y: "10",
  width: "18",
  height: "12",
  rx: "2",
  key: "6s8ecr"
}], ["path", {
  d: "M7 10V7a5 5 0 0 1 10 0v3",
  key: "1pqi11"
}]];
var LockOpen = [["rect", {
  width: "18",
  height: "11",
  x: "3",
  y: "11",
  rx: "2",
  ry: "2",
  key: "1w4ew1"
}], ["path", {
  d: "M7 11V7a5 5 0 0 1 9.9-1",
  key: "1mm8w8"
}]];
var Lock = [["rect", {
  width: "18",
  height: "11",
  x: "3",
  y: "11",
  rx: "2",
  ry: "2",
  key: "1w4ew1"
}], ["path", {
  d: "M7 11V7a5 5 0 0 1 10 0v4",
  key: "fwvmzm"
}]];
var LogIn = [["path", {
  d: "m10 17 5-5-5-5",
  key: "1bsop3"
}], ["path", {
  d: "M15 12H3",
  key: "6jk70r"
}], ["path", {
  d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
  key: "u53s6r"
}]];
var LogOut = [["path", {
  d: "m16 17 5-5-5-5",
  key: "1bji2h"
}], ["path", {
  d: "M21 12H9",
  key: "dn1m92"
}], ["path", {
  d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
  key: "1uf3rs"
}]];
var Logs = [["path", {
  d: "M3 5h1",
  key: "1mv5vm"
}], ["path", {
  d: "M3 12h1",
  key: "lp3yf2"
}], ["path", {
  d: "M3 19h1",
  key: "w6f3n9"
}], ["path", {
  d: "M8 5h1",
  key: "1nxr5w"
}], ["path", {
  d: "M8 12h1",
  key: "1con00"
}], ["path", {
  d: "M8 19h1",
  key: "k7p10e"
}], ["path", {
  d: "M13 5h8",
  key: "a7qcls"
}], ["path", {
  d: "M13 12h8",
  key: "h98zly"
}], ["path", {
  d: "M13 19h8",
  key: "c3s6r1"
}]];
var Lollipop = [["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}], ["path", {
  d: "M11 11a2 2 0 0 0 4 0 4 4 0 0 0-8 0 6 6 0 0 0 12 0",
  key: "107gwy"
}]];
var Luggage = [["path", {
  d: "M6 20a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2",
  key: "1m57jg"
}], ["path", {
  d: "M8 18V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v14",
  key: "1l99gc"
}], ["path", {
  d: "M10 20h4",
  key: "ni2waw"
}], ["circle", {
  cx: "16",
  cy: "20",
  r: "2",
  key: "1vifvg"
}], ["circle", {
  cx: "8",
  cy: "20",
  r: "2",
  key: "ckkr5m"
}]];
var Magnet = [["path", {
  d: "m12 15 4 4",
  key: "lnac28"
}], ["path", {
  d: "M2.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.029-6.029a1 1 0 1 1 3 3l-6.029 6.029a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.365-6.367A1 1 0 0 0 8.716 4.282z",
  key: "nlhkjb"
}], ["path", {
  d: "m5 8 4 4",
  key: "j6kj7e"
}]];
var MailCheck = [["path", {
  d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",
  key: "12jkf8"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "m16 19 2 2 4-4",
  key: "1b14m6"
}]];
var MailMinus = [["path", {
  d: "M22 15V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",
  key: "fuxbkv"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "M16 19h6",
  key: "xwg31i"
}]];
var MailOpen = [["path", {
  d: "M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z",
  key: "1jhwl8"
}], ["path", {
  d: "m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10",
  key: "1qfld7"
}]];
var MailPlus = [["path", {
  d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",
  key: "12jkf8"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "M19 16v6",
  key: "tddt3s"
}], ["path", {
  d: "M16 19h6",
  key: "xwg31i"
}]];
var MailQuestionMark = [["path", {
  d: "M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5",
  key: "e61zoh"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "M18 15.28c.2-.4.5-.8.9-1a2.1 2.1 0 0 1 2.6.4c.3.4.5.8.5 1.3 0 1.3-2 2-2 2",
  key: "7z9rxb"
}], ["path", {
  d: "M20 22v.01",
  key: "12bgn6"
}]];
var MailSearch = [["path", {
  d: "M22 12.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h7.5",
  key: "w80f2v"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "M18 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  key: "8lzu5m"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["path", {
  d: "m22 22-1.5-1.5",
  key: "1x83k4"
}]];
var MailWarning = [["path", {
  d: "M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5",
  key: "e61zoh"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "M20 14v4",
  key: "1hm744"
}], ["path", {
  d: "M20 22v.01",
  key: "12bgn6"
}]];
var MailX = [["path", {
  d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h9",
  key: "1j9vog"
}], ["path", {
  d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
  key: "1ocrg3"
}], ["path", {
  d: "m17 17 4 4",
  key: "1b3523"
}], ["path", {
  d: "m21 17-4 4",
  key: "uinynz"
}]];
var Mail = [["path", {
  d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
  key: "132q7q"
}], ["rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2",
  key: "izxlao"
}]];
var Mails = [["path", {
  d: "M17 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 1-1.732",
  key: "1vyzll"
}], ["path", {
  d: "m22 5.5-6.419 4.179a2 2 0 0 1-2.162 0L7 5.5",
  key: "k7ramc"
}], ["rect", {
  x: "7",
  y: "3",
  width: "15",
  height: "12",
  rx: "2",
  key: "17196g"
}]];
var Mailbox = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9.5C2 7 4 5 6.5 5H18c2.2 0 4 1.8 4 4v8Z",
  key: "1lbycx"
}], ["polyline", {
  points: "15,9 18,9 18,11",
  key: "1pm9c0"
}], ["path", {
  d: "M6.5 5C9 5 11 7 11 9.5V17a2 2 0 0 1-2 2",
  key: "15i455"
}], ["line", {
  x1: "6",
  x2: "7",
  y1: "10",
  y2: "10",
  key: "1e2scm"
}]];
var MapMinus = [["path", {
  d: "m11 19-1.106-.552a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0l4.212 2.106a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619V14",
  key: "40pylx"
}], ["path", {
  d: "M15 5.764V14",
  key: "1bab71"
}], ["path", {
  d: "M21 18h-6",
  key: "139f0c"
}], ["path", {
  d: "M9 3.236v15",
  key: "1uimfh"
}]];
var MapPinCheckInside = [["path", {
  d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
  key: "1r0f0z"
}], ["path", {
  d: "m9 10 2 2 4-4",
  key: "1gnqz4"
}]];
var MapPinCheck = [["path", {
  d: "M19.43 12.935c.357-.967.57-1.955.57-2.935a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32.197 32.197 0 0 0 .813-.728",
  key: "1dq61d"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "m16 18 2 2 4-4",
  key: "1mkfmb"
}]];
var MapPinHouse = [["path", {
  d: "M15 22a1 1 0 0 1-1-1v-4a1 1 0 0 1 .445-.832l3-2a1 1 0 0 1 1.11 0l3 2A1 1 0 0 1 22 17v4a1 1 0 0 1-1 1z",
  key: "1p1rcz"
}], ["path", {
  d: "M18 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 .601.2",
  key: "mcbcs9"
}], ["path", {
  d: "M18 22v-3",
  key: "1t1ugv"
}], ["circle", {
  cx: "10",
  cy: "10",
  r: "3",
  key: "1ns7v1"
}]];
var MapPinMinusInside = [["path", {
  d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
  key: "1r0f0z"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}]];
var MapPinMinus = [["path", {
  d: "M18.977 14C19.6 12.701 20 11.343 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32 32 0 0 0 .824-.738",
  key: "11uxia"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "M16 18h6",
  key: "987eiv"
}]];
var MapPinOff = [["path", {
  d: "M12.75 7.09a3 3 0 0 1 2.16 2.16",
  key: "1d4wjd"
}], ["path", {
  d: "M17.072 17.072c-1.634 2.17-3.527 3.912-4.471 4.727a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 1.432-4.568",
  key: "12yil7"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.475 2.818A8 8 0 0 1 20 10c0 1.183-.31 2.377-.81 3.533",
  key: "lhrkcz"
}], ["path", {
  d: "M9.13 9.13a3 3 0 0 0 3.74 3.74",
  key: "13wojd"
}]];
var MapPinPen = [["path", {
  d: "M17.97 9.304A8 8 0 0 0 2 10c0 4.69 4.887 9.562 7.022 11.468",
  key: "1fahp3"
}], ["path", {
  d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "1817ys"
}], ["circle", {
  cx: "10",
  cy: "10",
  r: "3",
  key: "1ns7v1"
}]];
var MapPinPlusInside = [["path", {
  d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
  key: "1r0f0z"
}], ["path", {
  d: "M12 7v6",
  key: "lw1j43"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}]];
var MapPinPlus = [["path", {
  d: "M19.914 11.105A7.298 7.298 0 0 0 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32 32 0 0 0 .824-.738",
  key: "fcdtly"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "M16 18h6",
  key: "987eiv"
}], ["path", {
  d: "M19 15v6",
  key: "10aioa"
}]];
var MapPinXInside = [["path", {
  d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
  key: "1r0f0z"
}], ["path", {
  d: "m14.5 7.5-5 5",
  key: "3lb6iw"
}], ["path", {
  d: "m9.5 7.5 5 5",
  key: "ko136h"
}]];
var MapPinX = [["path", {
  d: "M19.752 11.901A7.78 7.78 0 0 0 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 19 19 0 0 0 .09-.077",
  key: "y0ewhp"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "m21.5 15.5-5 5",
  key: "11iqnx"
}], ["path", {
  d: "m21.5 20.5-5-5",
  key: "1bylgx"
}]];
var MapPin = [["path", {
  d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
  key: "1r0f0z"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}]];
var MapPinned = [["path", {
  d: "M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 0 1-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0 1 12 0",
  key: "11u0oz"
}], ["circle", {
  cx: "12",
  cy: "8",
  r: "2",
  key: "1822b1"
}], ["path", {
  d: "M8.714 14h-3.71a1 1 0 0 0-.948.683l-2.004 6A1 1 0 0 0 3 22h18a1 1 0 0 0 .948-1.316l-2-6a1 1 0 0 0-.949-.684h-3.712",
  key: "q8zwxj"
}]];
var MapPlus = [["path", {
  d: "m11 19-1.106-.552a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0l4.212 2.106a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619V12",
  key: "svfegj"
}], ["path", {
  d: "M15 5.764V12",
  key: "1ocw4k"
}], ["path", {
  d: "M18 15v6",
  key: "9wciyi"
}], ["path", {
  d: "M21 18h-6",
  key: "139f0c"
}], ["path", {
  d: "M9 3.236v15",
  key: "1uimfh"
}]];
var Map = [["path", {
  d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
  key: "169xi5"
}], ["path", {
  d: "M15 5.764v15",
  key: "1pn4in"
}], ["path", {
  d: "M9 3.236v15",
  key: "1uimfh"
}]];
var MarsStroke = [["path", {
  d: "m14 6 4 4",
  key: "1q72g9"
}], ["path", {
  d: "M17 3h4v4",
  key: "19p9u1"
}], ["path", {
  d: "m21 3-7.75 7.75",
  key: "1cjbfd"
}], ["circle", {
  cx: "9",
  cy: "15",
  r: "6",
  key: "bx5svt"
}]];
var Mars = [["path", {
  d: "M16 3h5v5",
  key: "1806ms"
}], ["path", {
  d: "m21 3-6.75 6.75",
  key: "pv0uzu"
}], ["circle", {
  cx: "10",
  cy: "14",
  r: "6",
  key: "1qwbdc"
}]];
var Martini = [["path", {
  d: "M8 22h8",
  key: "rmew8v"
}], ["path", {
  d: "M12 11v11",
  key: "ur9y6a"
}], ["path", {
  d: "m19 3-7 8-7-8Z",
  key: "1sgpiw"
}]];
var Maximize2 = [["path", {
  d: "M15 3h6v6",
  key: "1q9fwt"
}], ["path", {
  d: "m21 3-7 7",
  key: "1l2asr"
}], ["path", {
  d: "m3 21 7-7",
  key: "tjx5ai"
}], ["path", {
  d: "M9 21H3v-6",
  key: "wtvkvv"
}]];
var Maximize = [["path", {
  d: "M8 3H5a2 2 0 0 0-2 2v3",
  key: "1dcmit"
}], ["path", {
  d: "M21 8V5a2 2 0 0 0-2-2h-3",
  key: "1e4gt3"
}], ["path", {
  d: "M3 16v3a2 2 0 0 0 2 2h3",
  key: "wsl5sc"
}], ["path", {
  d: "M16 21h3a2 2 0 0 0 2-2v-3",
  key: "18trek"
}]];
var Medal = [["path", {
  d: "M7.21 15 2.66 7.14a2 2 0 0 1 .13-2.2L4.4 2.8A2 2 0 0 1 6 2h12a2 2 0 0 1 1.6.8l1.6 2.14a2 2 0 0 1 .14 2.2L16.79 15",
  key: "143lza"
}], ["path", {
  d: "M11 12 5.12 2.2",
  key: "qhuxz6"
}], ["path", {
  d: "m13 12 5.88-9.8",
  key: "hbye0f"
}], ["path", {
  d: "M8 7h8",
  key: "i86dvs"
}], ["circle", {
  cx: "12",
  cy: "17",
  r: "5",
  key: "qbz8iq"
}], ["path", {
  d: "M12 18v-2h-.5",
  key: "fawc4q"
}]];
var MegaphoneOff = [["path", {
  d: "M11.636 6A13 13 0 0 0 19.4 3.2 1 1 0 0 1 21 4v11.344",
  key: "bycexp"
}], ["path", {
  d: "M14.378 14.357A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h1",
  key: "1t17s6"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14",
  key: "1853fq"
}], ["path", {
  d: "M8 8v6",
  key: "aieo6v"
}]];
var Megaphone = [["path", {
  d: "M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
  key: "q8bfy3"
}], ["path", {
  d: "M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14",
  key: "1853fq"
}], ["path", {
  d: "M8 6v8",
  key: "15ugcq"
}]];
var Meh = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "15",
  y2: "15",
  key: "1xb1d9"
}], ["line", {
  x1: "9",
  x2: "9.01",
  y1: "9",
  y2: "9",
  key: "yxxnd0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "9",
  y2: "9",
  key: "1p4y9e"
}]];
var MemoryStick = [["path", {
  d: "M12 12v-2",
  key: "fwoke6"
}], ["path", {
  d: "M12 18v-2",
  key: "qj6yno"
}], ["path", {
  d: "M16 12v-2",
  key: "heuere"
}], ["path", {
  d: "M16 18v-2",
  key: "s1ct0w"
}], ["path", {
  d: "M2 11h1.5",
  key: "15p63e"
}], ["path", {
  d: "M20 18v-2",
  key: "12ehxp"
}], ["path", {
  d: "M20.5 11H22",
  key: "khsy7a"
}], ["path", {
  d: "M4 18v-2",
  key: "1c3oqr"
}], ["path", {
  d: "M8 12v-2",
  key: "1mwtfd"
}], ["path", {
  d: "M8 18v-2",
  key: "qcmpov"
}], ["rect", {
  x: "2",
  y: "6",
  width: "20",
  height: "10",
  rx: "2",
  key: "1qcswk"
}]];
var Menu = [["path", {
  d: "M4 5h16",
  key: "1tepv9"
}], ["path", {
  d: "M4 12h16",
  key: "1lakjw"
}], ["path", {
  d: "M4 19h16",
  key: "1djgab"
}]];
var Merge = [["path", {
  d: "m8 6 4-4 4 4",
  key: "ybng9g"
}], ["path", {
  d: "M12 2v10.3a4 4 0 0 1-1.172 2.872L4 22",
  key: "1hyw0i"
}], ["path", {
  d: "m20 22-5-5",
  key: "1m27yz"
}]];
var MessageCircleCheck = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var MessageCircleCode = [["path", {
  d: "m10 9-3 3 3 3",
  key: "1oro0q"
}], ["path", {
  d: "m14 15 3-3-3-3",
  key: "bz13h7"
}], ["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}]];
var MessageCircleDashed = [["path", {
  d: "M10.1 2.182a10 10 0 0 1 3.8 0",
  key: "5ilxe3"
}], ["path", {
  d: "M13.9 21.818a10 10 0 0 1-3.8 0",
  key: "11zvb9"
}], ["path", {
  d: "M17.609 3.72a10 10 0 0 1 2.69 2.7",
  key: "jiglxs"
}], ["path", {
  d: "M2.182 13.9a10 10 0 0 1 0-3.8",
  key: "c0bmvh"
}], ["path", {
  d: "M20.28 17.61a10 10 0 0 1-2.7 2.69",
  key: "elg7ff"
}], ["path", {
  d: "M21.818 10.1a10 10 0 0 1 0 3.8",
  key: "qkgqxc"
}], ["path", {
  d: "M3.721 6.391a10 10 0 0 1 2.7-2.69",
  key: "1mcia2"
}], ["path", {
  d: "m6.163 21.117-2.906.85a1 1 0 0 1-1.236-1.169l.965-2.98",
  key: "1qsu07"
}]];
var MessageCircleHeart = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "M7.828 13.07A3 3 0 0 1 12 8.764a3 3 0 0 1 5.004 2.224 3 3 0 0 1-.832 2.083l-3.447 3.62a1 1 0 0 1-1.45-.001z",
  key: "hoo97p"
}]];
var MessageCircleMore = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M16 12h.01",
  key: "1l6xoz"
}]];
var MessageCircleOff = [["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M4.93 4.929a10 10 0 0 0-1.938 11.412 2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 0 0 11.302-1.989",
  key: "7il5tn"
}], ["path", {
  d: "M8.35 2.69A10 10 0 0 1 21.3 15.65",
  key: "1pfsoa"
}]];
var MessageCirclePlus = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}]];
var MessageCircleQuestionMark = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
  key: "1u773s"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}]];
var MessageCircleReply = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "m10 15-3-3 3-3",
  key: "1pgupc"
}], ["path", {
  d: "M7 12h8a2 2 0 0 1 2 2v1",
  key: "89sh1g"
}]];
var MessageCircleWarning = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "M12 8v4",
  key: "1got3b"
}], ["path", {
  d: "M12 16h.01",
  key: "1drbdi"
}]];
var MessageCircleX = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "m9 9 6 6",
  key: "z0biqf"
}]];
var MessageCircle = [["path", {
  d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
  key: "1sd12s"
}]];
var MessageSquareCheck = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.7.7 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "m0kn7k"
}], ["path", {
  d: "m9 11 2 2 4-4",
  key: "kz4plv"
}]];
var MessageSquareCode = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "m10 8-3 3 3 3",
  key: "fp6dz7"
}], ["path", {
  d: "m14 14 3-3-3-3",
  key: "1yrceu"
}]];
var MessageSquareDashed = [["path", {
  d: "M14 3h2",
  key: "1d12a5"
}], ["path", {
  d: "M16 19h-2",
  key: "1agirb"
}], ["path", {
  d: "M2 12v-2",
  key: "1ey295"
}], ["path", {
  d: "M2 16v5.286a.71.71 0 0 0 1.212.502l1.149-1.149",
  key: "120k8q"
}], ["path", {
  d: "M20 19a2 2 0 0 0 2-2v-1",
  key: "ior8tn"
}], ["path", {
  d: "M22 10v2",
  key: "rmlecy"
}], ["path", {
  d: "M22 6V5a2 2 0 0 0-2-2",
  key: "sp3k6r"
}], ["path", {
  d: "M4 3a2 2 0 0 0-2 2v1",
  key: "11zt7s"
}], ["path", {
  d: "M8 19h2",
  key: "jnunrx"
}], ["path", {
  d: "M8 3h2",
  key: "ysbsee"
}]];
var MessageSquareDiff = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M10 15h4",
  key: "192ueg"
}], ["path", {
  d: "M10 9h4",
  key: "u4k05v"
}], ["path", {
  d: "M12 7v4",
  key: "xawao1"
}]];
var MessageSquareDot = [["path", {
  d: "M12.7 3H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H20a2 2 0 0 0 2-2v-4.7",
  key: "wjb7ig"
}], ["circle", {
  cx: "19",
  cy: "6",
  r: "3",
  key: "108a5v"
}]];
var MessageSquareHeart = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M7.5 9.5c0 .687.265 1.383.697 1.844l3.009 3.264a1.14 1.14 0 0 0 .407.314 1 1 0 0 0 .783-.004 1.14 1.14 0 0 0 .398-.31l3.008-3.264A2.77 2.77 0 0 0 16.5 9.5 2.5 2.5 0 0 0 12 8a2.5 2.5 0 0 0-4.5 1.5",
  key: "1faxuh"
}]];
var MessageSquareLock = [["path", {
  d: "M22 8.5V5a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H10",
  key: "fu6chl"
}], ["path", {
  d: "M20 15v-2a2 2 0 0 0-4 0v2",
  key: "vl8a78"
}], ["rect", {
  x: "14",
  y: "15",
  width: "8",
  height: "5",
  rx: "1",
  key: "37aafw"
}]];
var MessageSquareMore = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M12 11h.01",
  key: "z322tv"
}], ["path", {
  d: "M16 11h.01",
  key: "xkw8gn"
}], ["path", {
  d: "M8 11h.01",
  key: "1dfujw"
}]];
var MessageSquareOff = [["path", {
  d: "M19 19H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.7.7 0 0 1 2 21.286V5a2 2 0 0 1 1.184-1.826",
  key: "1wyg69"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8.656 3H20a2 2 0 0 1 2 2v11.344",
  key: "mhl4k6"
}]];
var MessageSquarePlus = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M12 8v6",
  key: "1ib9pf"
}], ["path", {
  d: "M9 11h6",
  key: "1fldmi"
}]];
var MessageSquareQuote = [["path", {
  d: "M14 14a2 2 0 0 0 2-2V8h-2",
  key: "1r06pg"
}], ["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M8 14a2 2 0 0 0 2-2V8H8",
  key: "1jzu5j"
}]];
var MessageSquareReply = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "m10 8-3 3 3 3",
  key: "fp6dz7"
}], ["path", {
  d: "M17 14v-1a2 2 0 0 0-2-2H7",
  key: "1tkjnz"
}]];
var MessageSquareShare = [["path", {
  d: "M12 3H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H20a2 2 0 0 0 2-2v-4",
  key: "11da1y"
}], ["path", {
  d: "M16 3h6v6",
  key: "1bx56c"
}], ["path", {
  d: "m16 9 6-6",
  key: "m4dnic"
}]];
var MessageSquareText = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M7 11h10",
  key: "1twpyw"
}], ["path", {
  d: "M7 15h6",
  key: "d9of3u"
}], ["path", {
  d: "M7 7h8",
  key: "af5zfr"
}]];
var MessageSquareWarning = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "M12 15h.01",
  key: "q59x07"
}], ["path", {
  d: "M12 7v4",
  key: "xawao1"
}]];
var MessageSquareX = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}], ["path", {
  d: "m14.5 8.5-5 5",
  key: "19tnj2"
}], ["path", {
  d: "m9.5 8.5 5 5",
  key: "1oa8ql"
}]];
var MessageSquare = [["path", {
  d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
  key: "18887p"
}]];
var MessagesSquare = [["path", {
  d: "M16 10a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 14.286V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
  key: "1n2ejm"
}], ["path", {
  d: "M20 9a2 2 0 0 1 2 2v10.286a.71.71 0 0 1-1.212.502l-2.202-2.202A2 2 0 0 0 17.172 19H10a2 2 0 0 1-2-2v-1",
  key: "1qfcsi"
}]];
var Metronome = [["path", {
  d: "M12 11.4V9.1",
  key: "audfby"
}], ["path", {
  d: "m12 17 6.59-6.59",
  key: "c0sb7j"
}], ["path", {
  d: "m15.05 5.7-.218-.691a3 3 0 0 0-5.663 0L4.418 19.695A1 1 0 0 0 5.37 21h13.253a1 1 0 0 0 .951-1.31L18.45 16.2",
  key: "1pkfrk"
}], ["circle", {
  cx: "20",
  cy: "9",
  r: "2",
  key: "1udoqf"
}]];
var MicOff = [["path", {
  d: "M12 19v3",
  key: "npa21l"
}], ["path", {
  d: "M15 9.34V5a3 3 0 0 0-5.68-1.33",
  key: "1gzdoj"
}], ["path", {
  d: "M16.95 16.95A7 7 0 0 1 5 12v-2",
  key: "cqa7eg"
}], ["path", {
  d: "M18.89 13.23A7 7 0 0 0 19 12v-2",
  key: "16hl24"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M9 9v3a3 3 0 0 0 5.12 2.12",
  key: "r2i35w"
}]];
var MicVocal = [["path", {
  d: "m11 7.601-5.994 8.19a1 1 0 0 0 .1 1.298l.817.818a1 1 0 0 0 1.314.087L15.09 12",
  key: "80a601"
}], ["path", {
  d: "M16.5 21.174C15.5 20.5 14.372 20 13 20c-2.058 0-3.928 2.356-6 2-2.072-.356-2.775-3.369-1.5-4.5",
  key: "j0ngtp"
}], ["circle", {
  cx: "16",
  cy: "7",
  r: "5",
  key: "d08jfb"
}]];
var Mic = [["path", {
  d: "M12 19v3",
  key: "npa21l"
}], ["path", {
  d: "M19 10v2a7 7 0 0 1-14 0v-2",
  key: "1vc78b"
}], ["rect", {
  x: "9",
  y: "2",
  width: "6",
  height: "13",
  rx: "3",
  key: "s6n7sd"
}]];
var Microchip = [["path", {
  d: "M10 12h4",
  key: "a56b0p"
}], ["path", {
  d: "M10 17h4",
  key: "pvmtpo"
}], ["path", {
  d: "M10 7h4",
  key: "1vgcok"
}], ["path", {
  d: "M18 12h2",
  key: "quuxs7"
}], ["path", {
  d: "M18 18h2",
  key: "4scel"
}], ["path", {
  d: "M18 6h2",
  key: "1ptzki"
}], ["path", {
  d: "M4 12h2",
  key: "1ltxp0"
}], ["path", {
  d: "M4 18h2",
  key: "1xrofg"
}], ["path", {
  d: "M4 6h2",
  key: "1cx33n"
}], ["rect", {
  x: "6",
  y: "2",
  width: "12",
  height: "20",
  rx: "2",
  key: "749fme"
}]];
var Microscope = [["path", {
  d: "M6 18h8",
  key: "1borvv"
}], ["path", {
  d: "M3 22h18",
  key: "8prr45"
}], ["path", {
  d: "M14 22a7 7 0 1 0 0-14h-1",
  key: "1jwaiy"
}], ["path", {
  d: "M9 14h2",
  key: "197e7h"
}], ["path", {
  d: "M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z",
  key: "1bmzmy"
}], ["path", {
  d: "M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3",
  key: "1drr47"
}]];
var Microwave = [["rect", {
  width: "20",
  height: "15",
  x: "2",
  y: "4",
  rx: "2",
  key: "2no95f"
}], ["rect", {
  width: "8",
  height: "7",
  x: "6",
  y: "8",
  rx: "1",
  key: "zh9wx"
}], ["path", {
  d: "M18 8v7",
  key: "o5zi4n"
}], ["path", {
  d: "M6 19v2",
  key: "1loha6"
}], ["path", {
  d: "M18 19v2",
  key: "1dawf0"
}]];
var Milestone = [["path", {
  d: "M12 13v8",
  key: "1l5pq0"
}], ["path", {
  d: "M12 3v3",
  key: "1n5kay"
}], ["path", {
  d: "M4 6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h13a2 2 0 0 0 1.152-.365l3.424-2.317a1 1 0 0 0 0-1.635l-3.424-2.318A2 2 0 0 0 17 6z",
  key: "1btarq"
}]];
var MilkOff = [["path", {
  d: "M8 2h8",
  key: "1ssgc1"
}], ["path", {
  d: "M9 2v1.343M15 2v2.789a4 4 0 0 0 .672 2.219l.656.984a4 4 0 0 1 .672 2.22v1.131M7.8 7.8l-.128.192A4 4 0 0 0 7 10.212V20a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-3",
  key: "y0ejgx"
}], ["path", {
  d: "M7 15a6.47 6.47 0 0 1 5 0 6.472 6.472 0 0 0 3.435.435",
  key: "iaxqsy"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Minimize2 = [["path", {
  d: "m14 10 7-7",
  key: "oa77jy"
}], ["path", {
  d: "M20 10h-6V4",
  key: "mjg0md"
}], ["path", {
  d: "m3 21 7-7",
  key: "tjx5ai"
}], ["path", {
  d: "M4 14h6v6",
  key: "rmj7iw"
}]];
var Milk = [["path", {
  d: "M8 2h8",
  key: "1ssgc1"
}], ["path", {
  d: "M9 2v2.789a4 4 0 0 1-.672 2.219l-.656.984A4 4 0 0 0 7 10.212V20a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-9.789a4 4 0 0 0-.672-2.219l-.656-.984A4 4 0 0 1 15 4.788V2",
  key: "qtp12x"
}], ["path", {
  d: "M7 15a6.472 6.472 0 0 1 5 0 6.47 6.47 0 0 0 5 0",
  key: "ygeh44"
}]];
var Minimize = [["path", {
  d: "M8 3v3a2 2 0 0 1-2 2H3",
  key: "hohbtr"
}], ["path", {
  d: "M21 8h-3a2 2 0 0 1-2-2V3",
  key: "5jw1f3"
}], ["path", {
  d: "M3 16h3a2 2 0 0 1 2 2v3",
  key: "198tvr"
}], ["path", {
  d: "M16 21v-3a2 2 0 0 1 2-2h3",
  key: "ph8mxp"
}]];
var Minus = [["path", {
  d: "M5 12h14",
  key: "1ays0h"
}]];
var MirrorRectangular = [["path", {
  d: "M11 6 8 9",
  key: "7zt14w"
}], ["path", {
  d: "m16 7-8 8",
  key: "tkgtvu"
}], ["rect", {
  x: "4",
  y: "2",
  width: "16",
  height: "20",
  rx: "2",
  key: "1uxh74"
}]];
var MonitorCheck = [["path", {
  d: "m9 10 2 2 4-4",
  key: "1gnqz4"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}]];
var MirrorRound = [["path", {
  d: "M10 6.6 8.6 8",
  key: "itrr7k"
}], ["path", {
  d: "M12 18v4",
  key: "jadmvz"
}], ["path", {
  d: "M15 7.5 9.5 13",
  key: "1vyrsv"
}], ["path", {
  d: "M7 22h10",
  key: "10w4w3"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "8",
  key: "1gshiw"
}]];
var MonitorCog = [["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "m14.305 7.53.923-.382",
  key: "1mlnsw"
}], ["path", {
  d: "m15.228 4.852-.923-.383",
  key: "82mpwg"
}], ["path", {
  d: "m16.852 3.228-.383-.924",
  key: "ln4sir"
}], ["path", {
  d: "m16.852 8.772-.383.923",
  key: "1dejw0"
}], ["path", {
  d: "m19.148 3.228.383-.924",
  key: "192kgf"
}], ["path", {
  d: "m19.53 9.696-.382-.924",
  key: "fiavlr"
}], ["path", {
  d: "m20.772 4.852.924-.383",
  key: "1j8mgp"
}], ["path", {
  d: "m20.772 7.148.924.383",
  key: "zix9be"
}], ["path", {
  d: "M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7",
  key: "1tnzv8"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["circle", {
  cx: "18",
  cy: "6",
  r: "3",
  key: "1h7g24"
}]];
var MonitorCloud = [["path", {
  d: "M11 13a3 3 0 1 1 2.83-4H14a2 2 0 0 1 0 4z",
  key: "1da4q6"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["rect", {
  x: "2",
  y: "3",
  width: "20",
  height: "14",
  rx: "2",
  key: "x3v2xh"
}]];
var MonitorDot = [["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M22 12.307V15a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8.693",
  key: "1dx6ho"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["circle", {
  cx: "19",
  cy: "6",
  r: "3",
  key: "108a5v"
}]];
var MonitorDown = [["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["path", {
  d: "m15 10-3 3-3-3",
  key: "lzhmyn"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}]];
var MonitorOff = [["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M17 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 1.184-1.826",
  key: "cv7jms"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["path", {
  d: "M8.656 3H20a2 2 0 0 1 2 2v10a2 2 0 0 1-.293 1.042",
  key: "z8ni2w"
}]];
var MonitorPause = [["path", {
  d: "M10 13V7",
  key: "1u13u9"
}], ["path", {
  d: "M14 13V7",
  key: "1vj9om"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}]];
var MonitorPlay = [["path", {
  d: "M15.033 9.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56V7.648a.645.645 0 0 1 .967-.56z",
  key: "vbtd3f"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["rect", {
  x: "2",
  y: "3",
  width: "20",
  height: "14",
  rx: "2",
  key: "x3v2xh"
}]];
var MonitorSmartphone = [["path", {
  d: "M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8",
  key: "10dyio"
}], ["path", {
  d: "M10 19v-3.96 3.15",
  key: "1irgej"
}], ["path", {
  d: "M7 19h5",
  key: "qswx4l"
}], ["rect", {
  width: "6",
  height: "10",
  x: "16",
  y: "12",
  rx: "2",
  key: "1egngj"
}]];
var MonitorSpeaker = [["path", {
  d: "M5.5 20H8",
  key: "1k40s5"
}], ["path", {
  d: "M17 9h.01",
  key: "1j24nn"
}], ["rect", {
  width: "10",
  height: "16",
  x: "12",
  y: "4",
  rx: "2",
  key: "ixliua"
}], ["path", {
  d: "M8 6H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h4",
  key: "1mp6e1"
}], ["circle", {
  cx: "17",
  cy: "15",
  r: "1",
  key: "tqvash"
}]];
var MonitorStop = [["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["rect", {
  x: "2",
  y: "3",
  width: "20",
  height: "14",
  rx: "2",
  key: "x3v2xh"
}], ["rect", {
  x: "9",
  y: "7",
  width: "6",
  height: "6",
  rx: "1",
  key: "5m2oou"
}]];
var MonitorUp = [["path", {
  d: "m9 10 3-3 3 3",
  key: "11gsxs"
}], ["path", {
  d: "M12 13V7",
  key: "h0r20n"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}]];
var MonitorX = [["path", {
  d: "m14.5 12.5-5-5",
  key: "1jahn5"
}], ["path", {
  d: "m9.5 12.5 5-5",
  key: "1k2t7b"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}]];
var Monitor = [["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "21",
  y2: "21",
  key: "1svkeh"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "17",
  y2: "21",
  key: "vw1qmm"
}]];
var MoonStar = [["path", {
  d: "M18 5h4",
  key: "1lhgn2"
}], ["path", {
  d: "M20 3v4",
  key: "1olli1"
}], ["path", {
  d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
  key: "kfwtm"
}]];
var Moon = [["path", {
  d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
  key: "kfwtm"
}]];
var Motorbike = [["path", {
  d: "m18 14-1-3",
  key: "bdajw9"
}], ["path", {
  d: "m3 9 6 2a2 2 0 0 1 2-2h2a2 2 0 0 1 1.99 1.81",
  key: "f5fotj"
}], ["path", {
  d: "M8 17h3a1 1 0 0 0 1-1 6 6 0 0 1 6-6 1 1 0 0 0 1-1v-.75A5 5 0 0 0 17 5",
  key: "3i90e2"
}], ["circle", {
  cx: "19",
  cy: "17",
  r: "3",
  key: "1otbdv"
}], ["circle", {
  cx: "5",
  cy: "17",
  r: "3",
  key: "1d8p0c"
}]];
var MountainSnow = [["path", {
  d: "m8 3 4 8 5-5 5 15H2L8 3z",
  key: "otkl63"
}], ["path", {
  d: "M4.14 15.08c2.62-1.57 5.24-1.43 7.86.42 2.74 1.94 5.49 2 8.23.19",
  key: "1pvmmp"
}]];
var Mountain = [["path", {
  d: "m8 3 4 8 5-5 5 15H2L8 3z",
  key: "otkl63"
}]];
var MouseOff = [["path", {
  d: "M12 6v.343",
  key: "1gyhex"
}], ["path", {
  d: "M18.218 18.218A7 7 0 0 1 5 15V9a7 7 0 0 1 .782-3.218",
  key: "ukzz01"
}], ["path", {
  d: "M19 13.343V9A7 7 0 0 0 8.56 2.902",
  key: "104jy9"
}], ["path", {
  d: "M22 22 2 2",
  key: "1r8tn9"
}]];
var MouseLeft = [["path", {
  d: "M12 7.318V10",
  key: "17s7lh"
}], ["path", {
  d: "M5 10v5a7 7 0 0 0 14 0V9c0-3.527-2.608-6.515-6-7",
  key: "imk5ea"
}], ["circle", {
  cx: "7",
  cy: "4",
  r: "2",
  key: "ra7k3"
}]];
var MousePointer2Off = [["path", {
  d: "m15.55 8.45 5.138 2.087a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063L8.45 15.551",
  key: "1qoshx"
}], ["path", {
  d: "M22 2 2 22",
  key: "y4kqgn"
}], ["path", {
  d: "m6.816 11.528-2.779-6.84a.495.495 0 0 1 .651-.651l6.84 2.779",
  key: "mymuvk"
}]];
var MousePointer2 = [["path", {
  d: "M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z",
  key: "edeuup"
}]];
var MousePointerBan = [["path", {
  d: "M2.034 2.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.944L8.204 7.545a1 1 0 0 0-.66.66l-1.066 3.443a.5.5 0 0 1-.944.033z",
  key: "11pp1i"
}], ["circle", {
  cx: "16",
  cy: "16",
  r: "6",
  key: "qoo3c4"
}], ["path", {
  d: "m11.8 11.8 8.4 8.4",
  key: "oogvdj"
}]];
var MousePointer = [["path", {
  d: "M12.586 12.586 19 19",
  key: "ea5xo7"
}], ["path", {
  d: "M3.688 3.037a.497.497 0 0 0-.651.651l6.5 15.999a.501.501 0 0 0 .947-.062l1.569-6.083a2 2 0 0 1 1.448-1.479l6.124-1.579a.5.5 0 0 0 .063-.947z",
  key: "277e5u"
}]];
var MousePointerClick = [["path", {
  d: "M14 4.1 12 6",
  key: "ita8i4"
}], ["path", {
  d: "m5.1 8-2.9-.8",
  key: "1go3kf"
}], ["path", {
  d: "m6 12-1.9 2",
  key: "mnht97"
}], ["path", {
  d: "M7.2 2.2 8 5.1",
  key: "1cfko1"
}], ["path", {
  d: "M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z",
  key: "s0h3yz"
}]];
var MouseRight = [["path", {
  d: "M12 7.318V10",
  key: "17s7lh"
}], ["path", {
  d: "M19 10v5a7 7 0 0 1-14 0V9c0-3.527 2.608-6.515 6-7",
  key: "2es5nn"
}], ["circle", {
  cx: "17",
  cy: "4",
  r: "2",
  key: "y5j2s2"
}]];
var Mouse = [["rect", {
  x: "5",
  y: "2",
  width: "14",
  height: "20",
  rx: "7",
  key: "11ol66"
}], ["path", {
  d: "M12 6v4",
  key: "16clxf"
}]];
var Move3d = [["path", {
  d: "M5 3v16h16",
  key: "1mqmf9"
}], ["path", {
  d: "m5 19 6-6",
  key: "jh6hbb"
}], ["path", {
  d: "m2 6 3-3 3 3",
  key: "tkyvxa"
}], ["path", {
  d: "m18 16 3 3-3 3",
  key: "1d4glt"
}]];
var MoveDiagonal2 = [["path", {
  d: "M19 13v6h-6",
  key: "1hxl6d"
}], ["path", {
  d: "M5 11V5h6",
  key: "12e2xe"
}], ["path", {
  d: "m5 5 14 14",
  key: "11anup"
}]];
var MoveDiagonal = [["path", {
  d: "M11 19H5v-6",
  key: "8awifj"
}], ["path", {
  d: "M13 5h6v6",
  key: "7voy1q"
}], ["path", {
  d: "M19 5 5 19",
  key: "wwaj1z"
}]];
var MoveDownLeft = [["path", {
  d: "M11 19H5V13",
  key: "1akmht"
}], ["path", {
  d: "M19 5L5 19",
  key: "72u4yj"
}]];
var MoveDownRight = [["path", {
  d: "M19 13V19H13",
  key: "10vkzq"
}], ["path", {
  d: "M5 5L19 19",
  key: "5zm2fv"
}]];
var MoveDown = [["path", {
  d: "M8 18L12 22L16 18",
  key: "cskvfv"
}], ["path", {
  d: "M12 2V22",
  key: "r89rzk"
}]];
var MoveHorizontal = [["path", {
  d: "m18 8 4 4-4 4",
  key: "1ak13k"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "m6 8-4 4 4 4",
  key: "15zrgr"
}]];
var MoveLeft = [["path", {
  d: "M6 8L2 12L6 16",
  key: "kyvwex"
}], ["path", {
  d: "M2 12H22",
  key: "1m8cig"
}]];
var MoveRight = [["path", {
  d: "M18 8L22 12L18 16",
  key: "1r0oui"
}], ["path", {
  d: "M2 12H22",
  key: "1m8cig"
}]];
var MoveUpLeft = [["path", {
  d: "M5 11V5H11",
  key: "3q78g9"
}], ["path", {
  d: "M5 5L19 19",
  key: "5zm2fv"
}]];
var MoveUp = [["path", {
  d: "M8 6L12 2L16 6",
  key: "1yvkyx"
}], ["path", {
  d: "M12 2V22",
  key: "r89rzk"
}]];
var MoveUpRight = [["path", {
  d: "M13 5H19V11",
  key: "1n1gyv"
}], ["path", {
  d: "M19 5L5 19",
  key: "72u4yj"
}]];
var MoveVertical = [["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}], ["path", {
  d: "m8 18 4 4 4-4",
  key: "bh5tu3"
}], ["path", {
  d: "m8 6 4-4 4 4",
  key: "ybng9g"
}]];
var Move = [["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}], ["path", {
  d: "m15 19-3 3-3-3",
  key: "11eu04"
}], ["path", {
  d: "m19 9 3 3-3 3",
  key: "1mg7y2"
}], ["path", {
  d: "M2 12h20",
  key: "9i4pu4"
}], ["path", {
  d: "m5 9-3 3 3 3",
  key: "j64kie"
}], ["path", {
  d: "m9 5 3-3 3 3",
  key: "l8vdw6"
}]];
var Music2 = [["circle", {
  cx: "8",
  cy: "18",
  r: "4",
  key: "1fc0mg"
}], ["path", {
  d: "M12 18V2l7 4",
  key: "g04rme"
}]];
var Music3 = [["circle", {
  cx: "12",
  cy: "18",
  r: "4",
  key: "m3r9ws"
}], ["path", {
  d: "M16 18V2",
  key: "40x2m5"
}]];
var Music4 = [["path", {
  d: "M9 18V5l12-2v13",
  key: "1jmyc2"
}], ["path", {
  d: "m9 9 12-2",
  key: "1e64n2"
}], ["circle", {
  cx: "6",
  cy: "18",
  r: "3",
  key: "fqmcym"
}], ["circle", {
  cx: "18",
  cy: "16",
  r: "3",
  key: "1hluhg"
}]];
var Music = [["path", {
  d: "M9 18V5l12-2v13",
  key: "1jmyc2"
}], ["circle", {
  cx: "6",
  cy: "18",
  r: "3",
  key: "fqmcym"
}], ["circle", {
  cx: "18",
  cy: "16",
  r: "3",
  key: "1hluhg"
}]];
var Navigation2Off = [["path", {
  d: "M9.31 9.31 5 21l7-4 7 4-1.17-3.17",
  key: "qoq2o2"
}], ["path", {
  d: "M14.53 8.88 12 2l-1.17 3.17",
  key: "k3sjzy"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Navigation2 = [["polygon", {
  points: "12 2 19 21 12 17 5 21 12 2",
  key: "x8c0qg"
}]];
var NavigationOff = [["path", {
  d: "M8.43 8.43 3 11l8 2 2 8 2.57-5.43",
  key: "1vdtb7"
}], ["path", {
  d: "M17.39 11.73 22 2l-9.73 4.61",
  key: "tya3r6"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Navigation = [["polygon", {
  points: "3 11 22 2 13 21 11 13 3 11",
  key: "1ltx0t"
}]];
var Network = [["rect", {
  x: "16",
  y: "16",
  width: "6",
  height: "6",
  rx: "1",
  key: "4q2zg0"
}], ["rect", {
  x: "2",
  y: "16",
  width: "6",
  height: "6",
  rx: "1",
  key: "8cvhb9"
}], ["rect", {
  x: "9",
  y: "2",
  width: "6",
  height: "6",
  rx: "1",
  key: "1egb70"
}], ["path", {
  d: "M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",
  key: "1jsf9p"
}], ["path", {
  d: "M12 12V8",
  key: "2874zd"
}]];
var Nfc = [["path", {
  d: "M6 8.32a7.43 7.43 0 0 1 0 7.36",
  key: "9iaqei"
}], ["path", {
  d: "M9.46 6.21a11.76 11.76 0 0 1 0 11.58",
  key: "1yha7l"
}], ["path", {
  d: "M12.91 4.1a15.91 15.91 0 0 1 .01 15.8",
  key: "4iu2gk"
}], ["path", {
  d: "M16.37 2a20.16 20.16 0 0 1 0 20",
  key: "sap9u2"
}]];
var NonBinary = [["path", {
  d: "M12 2v10",
  key: "mnfbl"
}], ["path", {
  d: "m8.5 4 7 4",
  key: "m1xjk3"
}], ["path", {
  d: "m8.5 8 7-4",
  key: "t0m5j6"
}], ["circle", {
  cx: "12",
  cy: "17",
  r: "5",
  key: "qbz8iq"
}]];
var Newspaper = [["path", {
  d: "M15 18h-5",
  key: "95g1m2"
}], ["path", {
  d: "M18 14h-8",
  key: "sponae"
}], ["path", {
  d: "M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",
  key: "39pd36"
}], ["rect", {
  width: "8",
  height: "4",
  x: "10",
  y: "6",
  rx: "1",
  key: "aywv1n"
}]];
var NotebookPen = [["path", {
  d: "M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4",
  key: "re6nr2"
}], ["path", {
  d: "M2 6h4",
  key: "aawbzj"
}], ["path", {
  d: "M2 10h4",
  key: "l0bgd4"
}], ["path", {
  d: "M2 14h4",
  key: "1gsvsf"
}], ["path", {
  d: "M2 18h4",
  key: "1bu2t1"
}], ["path", {
  d: "M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "pqwjuv"
}]];
var NotebookTabs = [["path", {
  d: "M2 6h4",
  key: "aawbzj"
}], ["path", {
  d: "M2 10h4",
  key: "l0bgd4"
}], ["path", {
  d: "M2 14h4",
  key: "1gsvsf"
}], ["path", {
  d: "M2 18h4",
  key: "1bu2t1"
}], ["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "1nb95v"
}], ["path", {
  d: "M15 2v20",
  key: "dcj49h"
}], ["path", {
  d: "M15 7h5",
  key: "1xj5lc"
}], ["path", {
  d: "M15 12h5",
  key: "w5shd9"
}], ["path", {
  d: "M15 17h5",
  key: "1qaofu"
}]];
var NotebookText = [["path", {
  d: "M2 6h4",
  key: "aawbzj"
}], ["path", {
  d: "M2 10h4",
  key: "l0bgd4"
}], ["path", {
  d: "M2 14h4",
  key: "1gsvsf"
}], ["path", {
  d: "M2 18h4",
  key: "1bu2t1"
}], ["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "1nb95v"
}], ["path", {
  d: "M9.5 8h5",
  key: "11mslq"
}], ["path", {
  d: "M9.5 12H16",
  key: "ktog6x"
}], ["path", {
  d: "M9.5 16H14",
  key: "p1seyn"
}]];
var NotepadTextDashed = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M12 2v4",
  key: "3427ic"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["path", {
  d: "M16 4h2a2 2 0 0 1 2 2v2",
  key: "j91f56"
}], ["path", {
  d: "M20 12v2",
  key: "w8o0tu"
}], ["path", {
  d: "M20 18v2a2 2 0 0 1-2 2h-1",
  key: "1c9ggx"
}], ["path", {
  d: "M13 22h-2",
  key: "191ugt"
}], ["path", {
  d: "M7 22H6a2 2 0 0 1-2-2v-2",
  key: "1rt9px"
}], ["path", {
  d: "M4 14v-2",
  key: "1v0sqh"
}], ["path", {
  d: "M4 8V6a2 2 0 0 1 2-2h2",
  key: "1mwabg"
}], ["path", {
  d: "M8 10h6",
  key: "3oa6kw"
}], ["path", {
  d: "M8 14h8",
  key: "1fgep2"
}], ["path", {
  d: "M8 18h5",
  key: "17enja"
}]];
var Notebook = [["path", {
  d: "M2 6h4",
  key: "aawbzj"
}], ["path", {
  d: "M2 10h4",
  key: "l0bgd4"
}], ["path", {
  d: "M2 14h4",
  key: "1gsvsf"
}], ["path", {
  d: "M2 18h4",
  key: "1bu2t1"
}], ["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "1nb95v"
}], ["path", {
  d: "M16 2v20",
  key: "rotuqe"
}]];
var NotepadText = [["path", {
  d: "M8 2v4",
  key: "1cmpym"
}], ["path", {
  d: "M12 2v4",
  key: "3427ic"
}], ["path", {
  d: "M16 2v4",
  key: "4m81vk"
}], ["rect", {
  width: "16",
  height: "18",
  x: "4",
  y: "4",
  rx: "2",
  key: "1u9h20"
}], ["path", {
  d: "M8 10h6",
  key: "3oa6kw"
}], ["path", {
  d: "M8 14h8",
  key: "1fgep2"
}], ["path", {
  d: "M8 18h5",
  key: "17enja"
}]];
var NutOff = [["path", {
  d: "M12 4V2",
  key: "1k5q1u"
}], ["path", {
  d: "M5 10v4a7.004 7.004 0 0 0 5.277 6.787c.412.104.802.292 1.102.592L12 22l.621-.621c.3-.3.69-.488 1.102-.592a7.01 7.01 0 0 0 4.125-2.939",
  key: "1xcvy9"
}], ["path", {
  d: "M19 10v3.343",
  key: "163tfc"
}], ["path", {
  d: "M12 12c-1.349-.573-1.905-1.005-2.5-2-.546.902-1.048 1.353-2.5 2-1.018-.644-1.46-1.08-2-2-1.028.71-1.69.918-3 1 1.081-1.048 1.757-2.03 2-3 .194-.776.84-1.551 1.79-2.21m11.654 5.997c.887-.457 1.28-.891 1.556-1.787 1.032.916 1.683 1.157 3 1-1.297-1.036-1.758-2.03-2-3-.5-2-4-4-8-4-.74 0-1.461.068-2.15.192",
  key: "17914v"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Nut = [["path", {
  d: "M12 4V2",
  key: "1k5q1u"
}], ["path", {
  d: "M5 10v4a7.004 7.004 0 0 0 5.277 6.787c.412.104.802.292 1.102.592L12 22l.621-.621c.3-.3.69-.488 1.102-.592A7.003 7.003 0 0 0 19 14v-4",
  key: "1tgyif"
}], ["path", {
  d: "M12 4C8 4 4.5 6 4 8c-.243.97-.919 1.952-2 3 1.31-.082 1.972-.29 3-1 .54.92.982 1.356 2 2 1.452-.647 1.954-1.098 2.5-2 .595.995 1.151 1.427 2.5 2 1.31-.621 1.862-1.058 2.5-2 .629.977 1.162 1.423 2.5 2 1.209-.548 1.68-.967 2-2 1.032.916 1.683 1.157 3 1-1.297-1.036-1.758-2.03-2-3-.5-2-4-4-8-4Z",
  key: "tnsqj"
}]];
var OctagonAlert = [["path", {
  d: "M12 16h.01",
  key: "1drbdi"
}], ["path", {
  d: "M12 8v4",
  key: "1got3b"
}], ["path", {
  d: "M15.312 2a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586l-4.688-4.688A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2z",
  key: "1fd625"
}]];
var OctagonMinus = [["path", {
  d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
  key: "2d38gg"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var OctagonPause = [["path", {
  d: "M10 15V9",
  key: "1lckn7"
}], ["path", {
  d: "M14 15V9",
  key: "1muqhk"
}], ["path", {
  d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
  key: "2d38gg"
}]];
var OctagonX = [["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
  key: "2d38gg"
}], ["path", {
  d: "m9 9 6 6",
  key: "z0biqf"
}]];
var Octagon = [["path", {
  d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
  key: "2d38gg"
}]];
var Option = [["path", {
  d: "M3 3h6l6 18h6",
  key: "ph9rgk"
}], ["path", {
  d: "M14 3h7",
  key: "16f0ms"
}]];
var Orbit = [["path", {
  d: "M20.341 6.484A10 10 0 0 1 10.266 21.85",
  key: "1enhxb"
}], ["path", {
  d: "M3.659 17.516A10 10 0 0 1 13.74 2.152",
  key: "1crzgf"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["circle", {
  cx: "19",
  cy: "5",
  r: "2",
  key: "mhkx31"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "2",
  key: "v8kfzx"
}]];
var Omega = [["path", {
  d: "M3 20h4.5a.5.5 0 0 0 .5-.5v-.282a.52.52 0 0 0-.247-.437 8 8 0 1 1 8.494-.001.52.52 0 0 0-.247.438v.282a.5.5 0 0 0 .5.5H21",
  key: "1x94xo"
}]];
var Origami = [["path", {
  d: "M12 12V4a1 1 0 0 1 1-1h6.297a1 1 0 0 1 .651 1.759l-4.696 4.025",
  key: "1bx4vc"
}], ["path", {
  d: "m12 21-7.414-7.414A2 2 0 0 1 4 12.172V6.415a1.002 1.002 0 0 1 1.707-.707L20 20.009",
  key: "1h3km6"
}], ["path", {
  d: "m12.214 3.381 8.414 14.966a1 1 0 0 1-.167 1.199l-1.168 1.163a1 1 0 0 1-.706.291H6.351a1 1 0 0 1-.625-.219L3.25 18.8a1 1 0 0 1 .631-1.781l4.165.027",
  key: "1hj4wg"
}]];
var Package2 = [["path", {
  d: "M12 3v6",
  key: "1holv5"
}], ["path", {
  d: "M16.76 3a2 2 0 0 1 1.8 1.1l2.23 4.479a2 2 0 0 1 .21.891V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9.472a2 2 0 0 1 .211-.894L5.45 4.1A2 2 0 0 1 7.24 3z",
  key: "187q7i"
}], ["path", {
  d: "M3.054 9.013h17.893",
  key: "grwhos"
}]];
var PackageMinus = [["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["path", {
  d: "M16 17h6",
  key: "1ook5g"
}], ["path", {
  d: "M21 13V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.729l7 4a2 2 0 0 0 2 .001l1.675-.955",
  key: "zu9avd"
}], ["path", {
  d: "M3.29 7 12 12l8.71-5",
  key: "19ckod"
}], ["path", {
  d: "m7.5 4.27 8.997 5.148",
  key: "9yrvtv"
}]];
var PackageCheck = [["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["path", {
  d: "m16 17 2 2 4-4",
  key: "uh5qu3"
}], ["path", {
  d: "M21 11.127V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.729l7 4a2 2 0 0 0 2 .001l1.32-.753",
  key: "kpkbpo"
}], ["path", {
  d: "M3.29 7 12 12l8.71-5",
  key: "19ckod"
}], ["path", {
  d: "m7.5 4.27 8.997 5.148",
  key: "9yrvtv"
}]];
var PackageOpen = [["path", {
  d: "M12 22v-9",
  key: "x3hkom"
}], ["path", {
  d: "M15.17 2.21a1.67 1.67 0 0 1 1.63 0L21 4.57a1.93 1.93 0 0 1 0 3.36L8.82 14.79a1.655 1.655 0 0 1-1.64 0L3 12.43a1.93 1.93 0 0 1 0-3.36z",
  key: "2ntwy6"
}], ["path", {
  d: "M20 13v3.87a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13",
  key: "1pmm1c"
}], ["path", {
  d: "M21 12.43a1.93 1.93 0 0 0 0-3.36L8.83 2.2a1.64 1.64 0 0 0-1.63 0L3 4.57a1.93 1.93 0 0 0 0 3.36l12.18 6.86a1.636 1.636 0 0 0 1.63 0z",
  key: "12ttoo"
}]];
var PackagePlus = [["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["path", {
  d: "M16 17h6",
  key: "1ook5g"
}], ["path", {
  d: "M19 14v6",
  key: "1ckrd5"
}], ["path", {
  d: "M21 10.535V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.729l7 4a2 2 0 0 0 2 .001l1.675-.955",
  key: "28k6lz"
}], ["path", {
  d: "M3.29 7 12 12l8.71-5",
  key: "19ckod"
}], ["path", {
  d: "m7.5 4.27 8.997 5.148",
  key: "9yrvtv"
}]];
var PackageSearch = [["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["path", {
  d: "M20.27 18.27 22 20",
  key: "er2am"
}], ["path", {
  d: "M21 10.498V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.729l7 4a2 2 0 0 0 2 .001l.98-.559",
  key: "tok1h1"
}], ["path", {
  d: "M3.29 7 12 12l8.71-5",
  key: "19ckod"
}], ["path", {
  d: "m7.5 4.27 8.997 5.148",
  key: "9yrvtv"
}], ["circle", {
  cx: "18.5",
  cy: "16.5",
  r: "2.5",
  key: "ke13xx"
}]];
var PackageX = [["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["path", {
  d: "m16.5 14.5 5 5",
  key: "ozpm51"
}], ["path", {
  d: "m16.5 19.5 5-5",
  key: "syf6b9"
}], ["path", {
  d: "M21 10.5V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.729l7 4a2 2 0 0 0 2 .001l.13-.074",
  key: "isw6gs"
}], ["path", {
  d: "M3.29 7 12 12l8.71-5",
  key: "19ckod"
}], ["path", {
  d: "m7.5 4.27 8.997 5.148",
  key: "9yrvtv"
}]];
var Package = [["path", {
  d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
  key: "1a0edw"
}], ["path", {
  d: "M12 22V12",
  key: "d0xqtd"
}], ["polyline", {
  points: "3.29 7 12 12 20.71 7",
  key: "ousv84"
}], ["path", {
  d: "m7.5 4.27 9 5.15",
  key: "1c824w"
}]];
var PaintBucket = [["path", {
  d: "M11 7 6 2",
  key: "1jwth8"
}], ["path", {
  d: "M18.992 12H2.041",
  key: "xw1gg"
}], ["path", {
  d: "M21.145 18.38A3.34 3.34 0 0 1 20 16.5a3.3 3.3 0 0 1-1.145 1.88c-.575.46-.855 1.02-.855 1.595A2 2 0 0 0 20 22a2 2 0 0 0 2-2.025c0-.58-.285-1.13-.855-1.595",
  key: "1nkol4"
}], ["path", {
  d: "m8.5 4.5 2.148-2.148a1.205 1.205 0 0 1 1.704 0l7.296 7.296a1.205 1.205 0 0 1 0 1.704l-7.592 7.592a3.615 3.615 0 0 1-5.112 0l-3.888-3.888a3.615 3.615 0 0 1 0-5.112L5.67 7.33",
  key: "1nk1rd"
}]];
var PaintRoller = [["rect", {
  width: "16",
  height: "6",
  x: "2",
  y: "2",
  rx: "2",
  key: "jcyz7m"
}], ["path", {
  d: "M10 16v-2a2 2 0 0 1 2-2h8a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2",
  key: "1b9h7c"
}], ["rect", {
  width: "4",
  height: "6",
  x: "8",
  y: "16",
  rx: "1",
  key: "d6e7yl"
}]];
var PaintbrushVertical = [["path", {
  d: "M10 2v2",
  key: "7u0qdc"
}], ["path", {
  d: "M14 2v4",
  key: "qmzblu"
}], ["path", {
  d: "M17 2a1 1 0 0 1 1 1v9H6V3a1 1 0 0 1 1-1z",
  key: "ycvu00"
}], ["path", {
  d: "M6 12a1 1 0 0 0-1 1v1a2 2 0 0 0 2 2h2a1 1 0 0 1 1 1v2.9a2 2 0 1 0 4 0V17a1 1 0 0 1 1-1h2a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1",
  key: "iw4wnp"
}]];
var Paintbrush = [["path", {
  d: "m14.622 17.897-10.68-2.913",
  key: "vj2p1u"
}], ["path", {
  d: "M18.376 2.622a1 1 0 1 1 3.002 3.002L17.36 9.643a.5.5 0 0 0 0 .707l.944.944a2.41 2.41 0 0 1 0 3.408l-.944.944a.5.5 0 0 1-.707 0L8.354 7.348a.5.5 0 0 1 0-.707l.944-.944a2.41 2.41 0 0 1 3.408 0l.944.944a.5.5 0 0 0 .707 0z",
  key: "18tc5c"
}], ["path", {
  d: "M9 8c-1.804 2.71-3.97 3.46-6.583 3.948a.507.507 0 0 0-.302.819l7.32 8.883a1 1 0 0 0 1.185.204C12.735 20.405 16 16.792 16 15",
  key: "ytzfxy"
}]];
var Palette = [["path", {
  d: "M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",
  key: "e79jfc"
}], ["circle", {
  cx: "13.5",
  cy: "6.5",
  r: ".5",
  fill: "currentColor",
  key: "1okk4w"
}], ["circle", {
  cx: "17.5",
  cy: "10.5",
  r: ".5",
  fill: "currentColor",
  key: "f64h9f"
}], ["circle", {
  cx: "6.5",
  cy: "12.5",
  r: ".5",
  fill: "currentColor",
  key: "qy21gx"
}], ["circle", {
  cx: "8.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "fotxhn"
}]];
var Panda = [["path", {
  d: "M11.25 17.25h1.5L12 18z",
  key: "1wmwwj"
}], ["path", {
  d: "m15 12 2 2",
  key: "k60wz4"
}], ["path", {
  d: "M18 6.5a.5.5 0 0 0-.5-.5",
  key: "1ch4h4"
}], ["path", {
  d: "M20.69 9.67a4.5 4.5 0 1 0-7.04-5.5 8.35 8.35 0 0 0-3.3 0 4.5 4.5 0 1 0-7.04 5.5C2.49 11.2 2 12.88 2 14.5 2 19.47 6.48 22 12 22s10-2.53 10-7.5c0-1.62-.48-3.3-1.3-4.83",
  key: "1c660l"
}], ["path", {
  d: "M6 6.5a.495.495 0 0 1 .5-.5",
  key: "eviuep"
}], ["path", {
  d: "m9 12-2 2",
  key: "326nkw"
}]];
var PanelBottomClose = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "m15 8-3 3-3-3",
  key: "1oxy1z"
}]];
var PanelBottomDashed = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M14 15h1",
  key: "171nev"
}], ["path", {
  d: "M19 15h2",
  key: "1vnucp"
}], ["path", {
  d: "M3 15h2",
  key: "8bym0q"
}], ["path", {
  d: "M9 15h1",
  key: "1tg3ks"
}]];
var PanelBottomOpen = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "m9 10 3-3 3 3",
  key: "11gsxs"
}]];
var PanelBottom = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}]];
var PanelLeftClose = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["path", {
  d: "m16 15-3-3 3-3",
  key: "14y99z"
}]];
var PanelLeftDashed = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 14v1",
  key: "askpd8"
}], ["path", {
  d: "M9 19v2",
  key: "16tejx"
}], ["path", {
  d: "M9 3v2",
  key: "1noubl"
}], ["path", {
  d: "M9 9v1",
  key: "19ebxg"
}]];
var PanelLeftOpen = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["path", {
  d: "m14 9 3 3-3 3",
  key: "8010ee"
}]];
var PanelLeftRightDashed = [["path", {
  d: "M15 10V9",
  key: "4dkmfx"
}], ["path", {
  d: "M15 15v-1",
  key: "6a4afx"
}], ["path", {
  d: "M15 21v-2",
  key: "1qshmc"
}], ["path", {
  d: "M15 5V3",
  key: "1fk0mb"
}], ["path", {
  d: "M9 10V9",
  key: "1lazqi"
}], ["path", {
  d: "M9 15v-1",
  key: "9lx740"
}], ["path", {
  d: "M9 21v-2",
  key: "1fwk0n"
}], ["path", {
  d: "M9 5V3",
  key: "2q8zi6"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var PanelLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}]];
var PanelRightClose = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}], ["path", {
  d: "m8 9 3 3-3 3",
  key: "12hl5m"
}]];
var PanelRightDashed = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M15 14v1",
  key: "ilsfch"
}], ["path", {
  d: "M15 19v2",
  key: "1fst2f"
}], ["path", {
  d: "M15 3v2",
  key: "z204g4"
}], ["path", {
  d: "M15 9v1",
  key: "z2a8b1"
}]];
var PanelRightOpen = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}], ["path", {
  d: "m10 15-3-3 3-3",
  key: "1pgupc"
}]];
var PanelRight = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}]];
var PanelTopBottomDashed = [["path", {
  d: "M14 15h1",
  key: "171nev"
}], ["path", {
  d: "M14 9h1",
  key: "l0svgy"
}], ["path", {
  d: "M19 15h2",
  key: "1vnucp"
}], ["path", {
  d: "M19 9h2",
  key: "te2zfg"
}], ["path", {
  d: "M3 15h2",
  key: "8bym0q"
}], ["path", {
  d: "M3 9h2",
  key: "1h4ldw"
}], ["path", {
  d: "M9 15h1",
  key: "1tg3ks"
}], ["path", {
  d: "M9 9h1",
  key: "15jzuz"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var PanelTopClose = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "m9 16 3-3 3 3",
  key: "1idcnm"
}]];
var PanelTopDashed = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M14 9h1",
  key: "l0svgy"
}], ["path", {
  d: "M19 9h2",
  key: "te2zfg"
}], ["path", {
  d: "M3 9h2",
  key: "1h4ldw"
}], ["path", {
  d: "M9 9h1",
  key: "15jzuz"
}]];
var PanelTop = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}]];
var PanelTopOpen = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "m15 14-3 3-3-3",
  key: "g215vf"
}]];
var PanelsLeftBottom = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 3v18",
  key: "fh3hqa"
}], ["path", {
  d: "M9 15h12",
  key: "5ijen5"
}]];
var PanelsRightBottom = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 15h12",
  key: "1wkqb3"
}], ["path", {
  d: "M15 3v18",
  key: "14nvp0"
}]];
var PanelsTopLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "M9 21V9",
  key: "1oto5p"
}]];
var Paperclip = [["path", {
  d: "m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551",
  key: "1miecu"
}]];
var Parentheses = [["path", {
  d: "M8 21s-4-3-4-9 4-9 4-9",
  key: "uto9ud"
}], ["path", {
  d: "M16 3s4 3 4 9-4 9-4 9",
  key: "4w2vsq"
}]];
var ParkingMeter = [["path", {
  d: "M11 15h2",
  key: "199qp6"
}], ["path", {
  d: "M12 12v3",
  key: "158kv8"
}], ["path", {
  d: "M12 19v3",
  key: "npa21l"
}], ["path", {
  d: "M15.282 19a1 1 0 0 0 .948-.68l2.37-6.988a7 7 0 1 0-13.2 0l2.37 6.988a1 1 0 0 0 .948.68z",
  key: "1jofit"
}], ["path", {
  d: "M9 9a3 3 0 1 1 6 0",
  key: "jdoeu8"
}]];
var PartyPopper = [["path", {
  d: "M5.8 11.3 2 22l10.7-3.79",
  key: "gwxi1d"
}], ["path", {
  d: "M4 3h.01",
  key: "1vcuye"
}], ["path", {
  d: "M22 8h.01",
  key: "1mrtc2"
}], ["path", {
  d: "M15 2h.01",
  key: "1cjtqr"
}], ["path", {
  d: "M22 20h.01",
  key: "1mrys2"
}], ["path", {
  d: "m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10",
  key: "hbicv8"
}], ["path", {
  d: "m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17",
  key: "1i94pl"
}], ["path", {
  d: "m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7",
  key: "1cofks"
}], ["path", {
  d: "M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z",
  key: "4kbmks"
}]];
var Pause = [["rect", {
  x: "14",
  y: "3",
  width: "5",
  height: "18",
  rx: "1",
  key: "kaeet6"
}], ["rect", {
  x: "5",
  y: "3",
  width: "5",
  height: "18",
  rx: "1",
  key: "1wsw3u"
}]];
var PawPrint = [["circle", {
  cx: "11",
  cy: "4",
  r: "2",
  key: "vol9p0"
}], ["circle", {
  cx: "18",
  cy: "8",
  r: "2",
  key: "17gozi"
}], ["circle", {
  cx: "20",
  cy: "16",
  r: "2",
  key: "1v9bxh"
}], ["path", {
  d: "M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z",
  key: "1ydw1z"
}]];
var PcCase = [["rect", {
  width: "14",
  height: "20",
  x: "5",
  y: "2",
  rx: "2",
  key: "1uq1d7"
}], ["path", {
  d: "M15 14h.01",
  key: "1kp3bh"
}], ["path", {
  d: "M9 6h6",
  key: "dgm16u"
}], ["path", {
  d: "M9 10h6",
  key: "9gxzsh"
}]];
var PenLine = [["path", {
  d: "M13 21h8",
  key: "1jsn5i"
}], ["path", {
  d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
  key: "1a8usu"
}]];
var PenOff = [["path", {
  d: "m10 10-6.157 6.162a2 2 0 0 0-.5.833l-1.322 4.36a.5.5 0 0 0 .622.624l4.358-1.323a2 2 0 0 0 .83-.5L14 13.982",
  key: "bjo8r8"
}], ["path", {
  d: "m12.829 7.172 4.359-4.346a1 1 0 1 1 3.986 3.986l-4.353 4.353",
  key: "16h5ne"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var PenTool = [["path", {
  d: "M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",
  key: "nt11vn"
}], ["path", {
  d: "m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",
  key: "15qc1e"
}], ["path", {
  d: "m2.3 2.3 7.286 7.286",
  key: "1wuzzi"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "2",
  key: "xmgehs"
}]];
var Pen = [["path", {
  d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
  key: "1a8usu"
}]];
var PencilLine = [["path", {
  d: "M13 21h8",
  key: "1jsn5i"
}], ["path", {
  d: "m15 5 4 4",
  key: "1mk7zo"
}], ["path", {
  d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
  key: "1a8usu"
}]];
var PencilOff = [["path", {
  d: "m10 10-6.157 6.162a2 2 0 0 0-.5.833l-1.322 4.36a.5.5 0 0 0 .622.624l4.358-1.323a2 2 0 0 0 .83-.5L14 13.982",
  key: "bjo8r8"
}], ["path", {
  d: "m12.829 7.172 4.359-4.346a1 1 0 1 1 3.986 3.986l-4.353 4.353",
  key: "16h5ne"
}], ["path", {
  d: "m15 5 4 4",
  key: "1mk7zo"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var PencilRuler = [["path", {
  d: "M13 7 8.7 2.7a2.41 2.41 0 0 0-3.4 0L2.7 5.3a2.41 2.41 0 0 0 0 3.4L7 13",
  key: "orapub"
}], ["path", {
  d: "m8 6 2-2",
  key: "115y1s"
}], ["path", {
  d: "m18 16 2-2",
  key: "ee94s4"
}], ["path", {
  d: "m17 11 4.3 4.3c.94.94.94 2.46 0 3.4l-2.6 2.6c-.94.94-2.46.94-3.4 0L11 17",
  key: "cfq27r"
}], ["path", {
  d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
  key: "1a8usu"
}], ["path", {
  d: "m15 5 4 4",
  key: "1mk7zo"
}]];
var Pencil = [["path", {
  d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
  key: "1a8usu"
}], ["path", {
  d: "m15 5 4 4",
  key: "1mk7zo"
}]];
var Pentagon = [["path", {
  d: "M10.83 2.38a2 2 0 0 1 2.34 0l8 5.74a2 2 0 0 1 .73 2.25l-3.04 9.26a2 2 0 0 1-1.9 1.37H7.04a2 2 0 0 1-1.9-1.37L2.1 10.37a2 2 0 0 1 .73-2.25z",
  key: "2hea0t"
}]];
var Percent = [["line", {
  x1: "19",
  x2: "5",
  y1: "5",
  y2: "19",
  key: "1x9vlm"
}], ["circle", {
  cx: "6.5",
  cy: "6.5",
  r: "2.5",
  key: "4mh3h7"
}], ["circle", {
  cx: "17.5",
  cy: "17.5",
  r: "2.5",
  key: "1mdrzq"
}]];
var PersonStanding = [["circle", {
  cx: "12",
  cy: "5",
  r: "1",
  key: "gxeob9"
}], ["path", {
  d: "m9 20 3-6 3 6",
  key: "se2kox"
}], ["path", {
  d: "m6 8 6 2 6-2",
  key: "4o3us4"
}], ["path", {
  d: "M12 10v4",
  key: "1kjpxc"
}]];
var PhilippinePeso = [["path", {
  d: "M20 11H4",
  key: "6ut86h"
}], ["path", {
  d: "M20 7H4",
  key: "zbl0bi"
}], ["path", {
  d: "M7 21V4a1 1 0 0 1 1-1h4a1 1 0 0 1 0 12H7",
  key: "1ana5r"
}]];
var PhoneCall = [["path", {
  d: "M13 2a9 9 0 0 1 9 9",
  key: "1itnx2"
}], ["path", {
  d: "M13 6a5 5 0 0 1 5 5",
  key: "11nki7"
}], ["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var PhoneForwarded = [["path", {
  d: "M14 6h8",
  key: "yd68k4"
}], ["path", {
  d: "m18 2 4 4-4 4",
  key: "pucp1d"
}], ["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var PhoneIncoming = [["path", {
  d: "M16 2v6h6",
  key: "1mfrl5"
}], ["path", {
  d: "m22 2-6 6",
  key: "6f0sa0"
}], ["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var PhoneMissed = [["path", {
  d: "m16 2 6 6",
  key: "1gw87d"
}], ["path", {
  d: "m22 2-6 6",
  key: "6f0sa0"
}], ["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var PhoneOff = [["path", {
  d: "M10.1 13.9a14 14 0 0 0 3.732 2.668 1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2 18 18 0 0 1-12.728-5.272",
  key: "1wngk7"
}], ["path", {
  d: "M22 2 2 22",
  key: "y4kqgn"
}], ["path", {
  d: "M4.76 13.582A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 .244.473",
  key: "10hv5p"
}]];
var PhoneOutgoing = [["path", {
  d: "m16 8 6-6",
  key: "oawc05"
}], ["path", {
  d: "M22 8V2h-6",
  key: "oqy2zc"
}], ["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var Phone = [["path", {
  d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
  key: "9njp5v"
}]];
var Piano = [["path", {
  d: "M18.5 8c-1.4 0-2.6-.8-3.2-2A6.87 6.87 0 0 0 2 9v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-8.5C22 9.6 20.4 8 18.5 8",
  key: "lag0yf"
}], ["path", {
  d: "M2 14h20",
  key: "myj16y"
}], ["path", {
  d: "M6 14v4",
  key: "9ng0ue"
}], ["path", {
  d: "M10 14v4",
  key: "1v8uk5"
}], ["path", {
  d: "M14 14v4",
  key: "1tqops"
}], ["path", {
  d: "M18 14v4",
  key: "18uqwm"
}]];
var Pi = [["line", {
  x1: "9",
  x2: "9",
  y1: "4",
  y2: "20",
  key: "ovs5a5"
}], ["path", {
  d: "M4 7c0-1.7 1.3-3 3-3h13",
  key: "10pag4"
}], ["path", {
  d: "M18 20c-1.7 0-3-1.3-3-3V4",
  key: "1gaosr"
}]];
var Pickaxe = [["path", {
  d: "m14 13-8.381 8.38a1 1 0 0 1-3.001-3L11 9.999",
  key: "1lw9ds"
}], ["path", {
  d: "M15.973 4.027A13 13 0 0 0 5.902 2.373c-1.398.342-1.092 2.158.277 2.601a19.9 19.9 0 0 1 5.822 3.024",
  key: "ffj4ej"
}], ["path", {
  d: "M16.001 11.999a19.9 19.9 0 0 1 3.024 5.824c.444 1.369 2.26 1.676 2.603.278A13 13 0 0 0 20 8.069",
  key: "8tj4zw"
}], ["path", {
  d: "M18.352 3.352a1.205 1.205 0 0 0-1.704 0l-5.296 5.296a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l5.296-5.296a1.205 1.205 0 0 0 0-1.704z",
  key: "hh6h97"
}]];
var PictureInPicture2 = [["path", {
  d: "M21 9V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10c0 1.1.9 2 2 2h4",
  key: "daa4of"
}], ["rect", {
  width: "10",
  height: "7",
  x: "12",
  y: "13",
  rx: "2",
  key: "1nb8gs"
}]];
var PictureInPicture = [["path", {
  d: "M2 10h6V4",
  key: "zwrco"
}], ["path", {
  d: "m2 4 6 6",
  key: "ug085t"
}], ["path", {
  d: "M21 10V7a2 2 0 0 0-2-2h-7",
  key: "git5jr"
}], ["path", {
  d: "M3 14v2a2 2 0 0 0 2 2h3",
  key: "1f7fh3"
}], ["rect", {
  x: "12",
  y: "14",
  width: "10",
  height: "7",
  rx: "1",
  key: "1wjs3o"
}]];
var PiggyBank = [["path", {
  d: "M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-4V3a4 4 0 0 0-3.2 1.6l-.3.4H11a6 6 0 0 0-6 6v1a5 5 0 0 0 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1z",
  key: "1piglc"
}], ["path", {
  d: "M16 10h.01",
  key: "1m94wz"
}], ["path", {
  d: "M2 8v1a2 2 0 0 0 2 2h1",
  key: "1env43"
}]];
var PilcrowLeft = [["path", {
  d: "M14 3v11",
  key: "mlfb7b"
}], ["path", {
  d: "M14 9h-3a3 3 0 0 1 0-6h9",
  key: "1ulc19"
}], ["path", {
  d: "M18 3v11",
  key: "1phi0r"
}], ["path", {
  d: "M22 18H2l4-4",
  key: "yt65j9"
}], ["path", {
  d: "m6 22-4-4",
  key: "6jgyf5"
}]];
var PilcrowRight = [["path", {
  d: "M10 3v11",
  key: "o3l5kj"
}], ["path", {
  d: "M10 9H7a1 1 0 0 1 0-6h8",
  key: "1wb1nc"
}], ["path", {
  d: "M14 3v11",
  key: "mlfb7b"
}], ["path", {
  d: "m18 14 4 4H2",
  key: "4r8io1"
}], ["path", {
  d: "m22 18-4 4",
  key: "1hjjrd"
}]];
var Pilcrow = [["path", {
  d: "M13 4v16",
  key: "8vvj80"
}], ["path", {
  d: "M17 4v16",
  key: "7dpous"
}], ["path", {
  d: "M19 4H9.5a4.5 4.5 0 0 0 0 9H13",
  key: "sh4n9v"
}]];
var PillBottle = [["path", {
  d: "M18 11h-4a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h4",
  key: "17ldeb"
}], ["path", {
  d: "M6 7v13a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7",
  key: "nc37y6"
}], ["rect", {
  width: "16",
  height: "5",
  x: "4",
  y: "2",
  rx: "1",
  key: "3jeezo"
}]];
var Pill = [["path", {
  d: "m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z",
  key: "wa1lgi"
}], ["path", {
  d: "m8.5 8.5 7 7",
  key: "rvfmvr"
}]];
var PinOff = [["path", {
  d: "M12 17v5",
  key: "bb1du9"
}], ["path", {
  d: "M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89",
  key: "znwnzq"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11",
  key: "c9qhm2"
}]];
var Pin = [["path", {
  d: "M12 17v5",
  key: "bb1du9"
}], ["path", {
  d: "M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",
  key: "1nkz8b"
}]];
var Pipette = [["path", {
  d: "m12 9-8.414 8.414A2 2 0 0 0 3 18.828v1.344a2 2 0 0 1-.586 1.414A2 2 0 0 1 3.828 21h1.344a2 2 0 0 0 1.414-.586L15 12",
  key: "1y3wsu"
}], ["path", {
  d: "m18 9 .4.4a1 1 0 1 1-3 3l-3.8-3.8a1 1 0 1 1 3-3l.4.4 3.4-3.4a1 1 0 1 1 3 3z",
  key: "110lr1"
}], ["path", {
  d: "m2 22 .414-.414",
  key: "jhxm08"
}]];
var Pizza = [["path", {
  d: "m12 14-1 1",
  key: "11onhr"
}], ["path", {
  d: "m13.75 18.25-1.25 1.42",
  key: "1yisr3"
}], ["path", {
  d: "M17.775 5.654a15.68 15.68 0 0 0-12.121 12.12",
  key: "1qtqk6"
}], ["path", {
  d: "M18.8 9.3a1 1 0 0 0 2.1 7.7",
  key: "fbbbr2"
}], ["path", {
  d: "M21.964 20.732a1 1 0 0 1-1.232 1.232l-18-5a1 1 0 0 1-.695-1.232A19.68 19.68 0 0 1 15.732 2.037a1 1 0 0 1 1.232.695z",
  key: "1hyfdd"
}]];
var PlaneLanding = [["path", {
  d: "M2 22h20",
  key: "272qi7"
}], ["path", {
  d: "M3.77 10.77 2 9l2-4.5 1.1.55c.55.28.9.84.9 1.45s.35 1.17.9 1.45L8 8.5l3-6 1.05.53a2 2 0 0 1 1.09 1.52l.72 5.4a2 2 0 0 0 1.09 1.52l4.4 2.2c.42.22.78.55 1.01.96l.6 1.03c.49.88-.06 1.98-1.06 2.1l-1.18.15c-.47.06-.95-.02-1.37-.24L4.29 11.15a2 2 0 0 1-.52-.38Z",
  key: "1ma21e"
}]];
var PlaneTakeoff = [["path", {
  d: "M2 22h20",
  key: "272qi7"
}], ["path", {
  d: "M6.36 17.4 4 17l-2-4 1.1-.55a2 2 0 0 1 1.8 0l.17.1a2 2 0 0 0 1.8 0L8 12 5 6l.9-.45a2 2 0 0 1 2.09.2l4.02 3a2 2 0 0 0 2.1.2l4.19-2.06a2.41 2.41 0 0 1 1.73-.17L21 7a1.4 1.4 0 0 1 .87 1.99l-.38.76c-.23.46-.6.84-1.07 1.08L7.58 17.2a2 2 0 0 1-1.22.18Z",
  key: "fkigj9"
}]];
var Plane = [["path", {
  d: "M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z",
  key: "1v9wt8"
}]];
var Play = [["path", {
  d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
  key: "10ikf1"
}]];
var Plug2 = [["path", {
  d: "M9 2v6",
  key: "17ngun"
}], ["path", {
  d: "M15 2v6",
  key: "s7yy2p"
}], ["path", {
  d: "M12 17v5",
  key: "bb1du9"
}], ["path", {
  d: "M5 8h14",
  key: "pcz4l3"
}], ["path", {
  d: "M6 11V8h12v3a6 6 0 1 1-12 0Z",
  key: "wtfw2c"
}]];
var PlugZap = [["path", {
  d: "M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z",
  key: "goz73y"
}], ["path", {
  d: "m2 22 3-3",
  key: "19mgm9"
}], ["path", {
  d: "M7.5 13.5 10 11",
  key: "7xgeeb"
}], ["path", {
  d: "M10.5 16.5 13 14",
  key: "10btkg"
}], ["path", {
  d: "m18 3-4 4h6l-4 4",
  key: "16psg9"
}]];
var Plug = [["path", {
  d: "M12 22v-5",
  key: "1ega77"
}], ["path", {
  d: "M15 8V2",
  key: "18g5xt"
}], ["path", {
  d: "M17 8a1 1 0 0 1 1 1v4a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1z",
  key: "1xoxul"
}], ["path", {
  d: "M9 8V2",
  key: "14iosj"
}]];
var Plus = [["path", {
  d: "M5 12h14",
  key: "1ays0h"
}], ["path", {
  d: "M12 5v14",
  key: "s699le"
}]];
var PocketKnife = [["path", {
  d: "M3 2v1c0 1 2 1 2 2S3 6 3 7s2 1 2 2-2 1-2 2 2 1 2 2",
  key: "19w3oe"
}], ["path", {
  d: "M18 6h.01",
  key: "1v4wsw"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "M20.83 8.83a4 4 0 0 0-5.66-5.66l-12 12a4 4 0 1 0 5.66 5.66Z",
  key: "6fykxj"
}], ["path", {
  d: "M18 11.66V22a4 4 0 0 0 4-4V6",
  key: "1utzek"
}]];
var Pocket = [["path", {
  d: "M20 3a2 2 0 0 1 2 2v6a1 1 0 0 1-20 0V5a2 2 0 0 1 2-2z",
  key: "1uodqw"
}], ["path", {
  d: "m8 10 4 4 4-4",
  key: "1mxd5q"
}]];
var Podcast = [["path", {
  d: "M13 17a1 1 0 1 0-2 0l.5 4.5a0.5 0.5 0 0 0 1 0z",
  fill: "currentColor",
  key: "x1mxqr"
}], ["path", {
  d: "M16.85 18.58a9 9 0 1 0-9.7 0",
  key: "d71mpg"
}], ["path", {
  d: "M8 14a5 5 0 1 1 8 0",
  key: "fc81rn"
}], ["circle", {
  cx: "12",
  cy: "11",
  r: "1",
  fill: "currentColor",
  key: "vqiwd"
}]];
var Pointer = [["path", {
  d: "M22 14a8 8 0 0 1-8 8",
  key: "56vcr3"
}], ["path", {
  d: "M18 11v-1a2 2 0 0 0-2-2a2 2 0 0 0-2 2",
  key: "1agjmk"
}], ["path", {
  d: "M14 10V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1",
  key: "wdbh2u"
}], ["path", {
  d: "M10 9.5V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v10",
  key: "1ibuk9"
}], ["path", {
  d: "M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
  key: "g6ys72"
}]];
var PointerOff = [["path", {
  d: "M10 4.5V4a2 2 0 0 0-2.41-1.957",
  key: "jsi14n"
}], ["path", {
  d: "M13.9 8.4a2 2 0 0 0-1.26-1.295",
  key: "hirc7f"
}], ["path", {
  d: "M21.7 16.2A8 8 0 0 0 22 14v-3a2 2 0 1 0-4 0v-1a2 2 0 0 0-3.63-1.158",
  key: "1jxb2e"
}], ["path", {
  d: "m7 15-1.8-1.8a2 2 0 0 0-2.79 2.86L6 19.7a7.74 7.74 0 0 0 6 2.3h2a8 8 0 0 0 5.657-2.343",
  key: "10r7hm"
}], ["path", {
  d: "M6 6v8",
  key: "tv5xkp"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Popcorn = [["path", {
  d: "M18 8a2 2 0 0 0 0-4 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0 0 4",
  key: "10td1f"
}], ["path", {
  d: "M10 22 9 8",
  key: "yjptiv"
}], ["path", {
  d: "m14 22 1-14",
  key: "8jwc8b"
}], ["path", {
  d: "M20 8c.5 0 .9.4.8 1l-2.6 12c-.1.5-.7 1-1.2 1H7c-.6 0-1.1-.4-1.2-1L3.2 9c-.1-.6.3-1 .8-1Z",
  key: "1qo33t"
}]];
var Popsicle = [["path", {
  d: "M18.6 14.4c.8-.8.8-2 0-2.8l-8.1-8.1a4.95 4.95 0 1 0-7.1 7.1l8.1 8.1c.9.7 2.1.7 2.9-.1Z",
  key: "1o68ps"
}], ["path", {
  d: "m22 22-5.5-5.5",
  key: "17o70y"
}]];
var PoundSterling = [["path", {
  d: "M18 7c0-5.333-8-5.333-8 0",
  key: "1prm2n"
}], ["path", {
  d: "M10 7v14",
  key: "18tmcs"
}], ["path", {
  d: "M6 21h12",
  key: "4dkmi1"
}], ["path", {
  d: "M6 13h10",
  key: "ybwr4a"
}]];
var PowerOff = [["path", {
  d: "M18.36 6.64A9 9 0 0 1 20.77 15",
  key: "dxknvb"
}], ["path", {
  d: "M6.16 6.16a9 9 0 1 0 12.68 12.68",
  key: "1x7qb5"
}], ["path", {
  d: "M12 2v4",
  key: "3427ic"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Power = [["path", {
  d: "M12 2v10",
  key: "mnfbl"
}], ["path", {
  d: "M18.4 6.6a9 9 0 1 1-12.77.04",
  key: "obofu9"
}]];
var Presentation = [["path", {
  d: "M2 3h20",
  key: "91anmk"
}], ["path", {
  d: "M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3",
  key: "2k9sn8"
}], ["path", {
  d: "m7 21 5-5 5 5",
  key: "bip4we"
}]];
var PrinterCheck = [["path", {
  d: "M13.5 22H7a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v.5",
  key: "qeb09x"
}], ["path", {
  d: "m16 19 2 2 4-4",
  key: "1b14m6"
}], ["path", {
  d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v2",
  key: "1md90i"
}], ["path", {
  d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",
  key: "1itne7"
}]];
var PrinterX = [["path", {
  d: "M12.531 22H7a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h6.377",
  key: "1w39xo"
}], ["path", {
  d: "m16.5 16.5 5 5",
  key: "zc9lw7"
}], ["path", {
  d: "m16.5 21.5 5-5",
  key: "1fr29m"
}], ["path", {
  d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1.5",
  key: "18he39"
}], ["path", {
  d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",
  key: "1itne7"
}]];
var Projector = [["path", {
  d: "M5 7 3 5",
  key: "1yys58"
}], ["path", {
  d: "M9 6V3",
  key: "1ptz9u"
}], ["path", {
  d: "m13 7 2-2",
  key: "1w3vmq"
}], ["circle", {
  cx: "9",
  cy: "13",
  r: "3",
  key: "1mma13"
}], ["path", {
  d: "M11.83 12H20a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h2.17",
  key: "2frwzc"
}], ["path", {
  d: "M16 16h2",
  key: "dnq2od"
}]];
var Printer = [["path", {
  d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
  key: "143wyd"
}], ["path", {
  d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",
  key: "1itne7"
}], ["rect", {
  x: "6",
  y: "14",
  width: "12",
  height: "8",
  rx: "1",
  key: "1ue0tg"
}]];
var Proportions = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M12 9v11",
  key: "1fnkrn"
}], ["path", {
  d: "M2 9h13a2 2 0 0 1 2 2v9",
  key: "11z3ex"
}]];
var Puzzle = [["path", {
  d: "M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",
  key: "w46dr5"
}]];
var Pyramid = [["path", {
  d: "M2.5 16.88a1 1 0 0 1-.32-1.43l9-13.02a1 1 0 0 1 1.64 0l9 13.01a1 1 0 0 1-.32 1.44l-8.51 4.86a2 2 0 0 1-1.98 0Z",
  key: "aenxs0"
}], ["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}]];
var QrCode = [["rect", {
  width: "5",
  height: "5",
  x: "3",
  y: "3",
  rx: "1",
  key: "1tu5fj"
}], ["rect", {
  width: "5",
  height: "5",
  x: "16",
  y: "3",
  rx: "1",
  key: "1v8r4q"
}], ["rect", {
  width: "5",
  height: "5",
  x: "3",
  y: "16",
  rx: "1",
  key: "1x03jg"
}], ["path", {
  d: "M21 16h-3a2 2 0 0 0-2 2v3",
  key: "177gqh"
}], ["path", {
  d: "M21 21v.01",
  key: "ents32"
}], ["path", {
  d: "M12 7v3a2 2 0 0 1-2 2H7",
  key: "8crl2c"
}], ["path", {
  d: "M3 12h.01",
  key: "nlz23k"
}], ["path", {
  d: "M12 3h.01",
  key: "n36tog"
}], ["path", {
  d: "M12 16v.01",
  key: "133mhm"
}], ["path", {
  d: "M16 12h1",
  key: "1slzba"
}], ["path", {
  d: "M21 12v.01",
  key: "1lwtk9"
}], ["path", {
  d: "M12 21v-1",
  key: "1880an"
}]];
var Quote = [["path", {
  d: "M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",
  key: "rib7q0"
}], ["path", {
  d: "M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",
  key: "1ymkrd"
}]];
var Rabbit = [["path", {
  d: "M13 16a3 3 0 0 1 2.24 5",
  key: "1epib5"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}], ["path", {
  d: "M18 21h-8a4 4 0 0 1-4-4 7 7 0 0 1 7-7h.2L9.6 6.4a1 1 0 1 1 2.8-2.8L15.8 7h.2c3.3 0 6 2.7 6 6v1a2 2 0 0 1-2 2h-1a3 3 0 0 0-3 3",
  key: "ue9ozu"
}], ["path", {
  d: "M20 8.54V4a2 2 0 1 0-4 0v3",
  key: "49iql8"
}], ["path", {
  d: "M7.612 12.524a3 3 0 1 0-1.6 4.3",
  key: "1e33i0"
}]];
var Radar = [["path", {
  d: "M19.07 4.93A10 10 0 0 0 6.99 3.34",
  key: "z3du51"
}], ["path", {
  d: "M4 6h.01",
  key: "oypzma"
}], ["path", {
  d: "M2.29 9.62A10 10 0 1 0 21.31 8.35",
  key: "qzzz0"
}], ["path", {
  d: "M16.24 7.76A6 6 0 1 0 8.23 16.67",
  key: "1yjesh"
}], ["path", {
  d: "M12 18h.01",
  key: "mhygvu"
}], ["path", {
  d: "M17.99 11.66A6 6 0 0 1 15.77 16.67",
  key: "1u2y91"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}], ["path", {
  d: "m13.41 10.59 5.66-5.66",
  key: "mhq4k0"
}]];
var Radiation = [["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M14 15.4641a4 4 0 0 1-4 0L7.52786 19.74597 A 1 1 0 0 0 7.99303 21.16211 10 10 0 0 0 16.00697 21.16211 1 1 0 0 0 16.47214 19.74597z",
  key: "1y4lzb"
}], ["path", {
  d: "M16 12a4 4 0 0 0-2-3.464l2.472-4.282a1 1 0 0 1 1.46-.305 10 10 0 0 1 4.006 6.94A1 1 0 0 1 21 12z",
  key: "163ggk"
}], ["path", {
  d: "M8 12a4 4 0 0 1 2-3.464L7.528 4.254a1 1 0 0 0-1.46-.305 10 10 0 0 0-4.006 6.94A1 1 0 0 0 3 12z",
  key: "1l9i0b"
}]];
var Radical = [["path", {
  d: "M3 12h3.28a1 1 0 0 1 .948.684l2.298 7.934a.5.5 0 0 0 .96-.044L13.82 4.771A1 1 0 0 1 14.792 4H21",
  key: "1mqj8i"
}]];
var RadioReceiver = [["path", {
  d: "M5 16v2",
  key: "g5qcv5"
}], ["path", {
  d: "M19 16v2",
  key: "1gbaio"
}], ["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "8",
  rx: "2",
  key: "vjsjur"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}]];
var RadioTower = [["path", {
  d: "M4.9 16.1C1 12.2 1 5.8 4.9 1.9",
  key: "s0qx1y"
}], ["path", {
  d: "M7.8 4.7a6.14 6.14 0 0 0-.8 7.5",
  key: "1idnkw"
}], ["circle", {
  cx: "12",
  cy: "9",
  r: "2",
  key: "1092wv"
}], ["path", {
  d: "M16.2 4.8c2 2 2.26 5.11.8 7.47",
  key: "ojru2q"
}], ["path", {
  d: "M19.1 1.9a9.96 9.96 0 0 1 0 14.1",
  key: "rhi7fg"
}], ["path", {
  d: "M9.5 18h5",
  key: "mfy3pd"
}], ["path", {
  d: "m8 22 4-11 4 11",
  key: "25yftu"
}]];
var Radio = [["path", {
  d: "M16.247 7.761a6 6 0 0 1 0 8.478",
  key: "1fwjs5"
}], ["path", {
  d: "M19.075 4.933a10 10 0 0 1 0 14.134",
  key: "ehdyv1"
}], ["path", {
  d: "M4.925 19.067a10 10 0 0 1 0-14.134",
  key: "1q22gi"
}], ["path", {
  d: "M7.753 16.239a6 6 0 0 1 0-8.478",
  key: "r2q7qm"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var Radius = [["path", {
  d: "M20.34 17.52a10 10 0 1 0-2.82 2.82",
  key: "fydyku"
}], ["circle", {
  cx: "19",
  cy: "19",
  r: "2",
  key: "17f5cg"
}], ["path", {
  d: "m13.41 13.41 4.18 4.18",
  key: "1gqbwc"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var RailSymbol = [["path", {
  d: "M5 15h14",
  key: "m0yey3"
}], ["path", {
  d: "M5 9h14",
  key: "7tsvo6"
}], ["path", {
  d: "m14 20-5-5 6-6-5-5",
  key: "1jo42i"
}]];
var Rainbow = [["path", {
  d: "M22 17a10 10 0 0 0-20 0",
  key: "ozegv"
}], ["path", {
  d: "M6 17a6 6 0 0 1 12 0",
  key: "5giftw"
}], ["path", {
  d: "M10 17a2 2 0 0 1 4 0",
  key: "gnsikk"
}]];
var Rat = [["path", {
  d: "M13 22H4a2 2 0 0 1 0-4h12",
  key: "bt3f23"
}], ["path", {
  d: "M13.236 18a3 3 0 0 0-2.2-5",
  key: "1tbvmo"
}], ["path", {
  d: "M16 9h.01",
  key: "1bdo4e"
}], ["path", {
  d: "M16.82 3.94a3 3 0 1 1 3.237 4.868l1.815 2.587a1.5 1.5 0 0 1-1.5 2.1l-2.872-.453a3 3 0 0 0-3.5 3",
  key: "9ch7kn"
}], ["path", {
  d: "M17 4.988a3 3 0 1 0-5.2 2.052A7 7 0 0 0 4 14.015 4 4 0 0 0 8 18",
  key: "3s7e9i"
}]];
var Ratio = [["rect", {
  width: "12",
  height: "20",
  x: "6",
  y: "2",
  rx: "2",
  key: "1oxtiu"
}], ["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "6",
  rx: "2",
  key: "9lu3g6"
}]];
var ReceiptCent = [["path", {
  d: "M12 7v10",
  key: "jspqdw"
}], ["path", {
  d: "M14.828 14.829a4 4 0 0 1-5.656 0 4 4 0 0 1 0-5.657 4 4 0 0 1 5.656 0",
  key: "qvqont"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}]];
var ReceiptEuro = [["path", {
  d: "M15.828 14.829a4 4 0 0 1-5.656 0 4 4 0 0 1 0-5.657 4 4 0 0 1 5.656 0",
  key: "16zdw4"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M8 12h5",
  key: "1g6qi8"
}]];
var ReceiptIndianRupee = [["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M8 11h8",
  key: "vwpz6n"
}], ["path", {
  d: "M8 7h8",
  key: "i86dvs"
}], ["path", {
  d: "M9 7a4 4 0 0 1 0 8H8l3 2",
  key: "1xaco0"
}]];
var ReceiptJapaneseYen = [["path", {
  d: "m12 10 3-3",
  key: "1mc12w"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M9 11h6",
  key: "1fldmi"
}], ["path", {
  d: "M9 15h6",
  key: "cctwl0"
}], ["path", {
  d: "m9 7 3 3v7",
  key: "1x0cue"
}]];
var ReceiptPoundSterling = [["path", {
  d: "M10 17V9.5a1 1 0 0 1 5 0",
  key: "td22vl"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M8 13h5",
  key: "1k9z8w"
}], ["path", {
  d: "M8 17h7",
  key: "8mjdqu"
}]];
var ReceiptRussianRuble = [["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M8 11h5a2 2 0 0 0 0-4h-3v10",
  key: "agnv0r"
}], ["path", {
  d: "M8 15h5",
  key: "vxg57a"
}]];
var ReceiptSwissFranc = [["path", {
  d: "M10 11h4",
  key: "1i0mka"
}], ["path", {
  d: "M10 17V7h5",
  key: "k7jq18"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}], ["path", {
  d: "M8 15h5",
  key: "vxg57a"
}]];
var ReceiptText = [["path", {
  d: "M13 16H8",
  key: "wsln4y"
}], ["path", {
  d: "M14 8H8",
  key: "1l3xfs"
}], ["path", {
  d: "M16 12H8",
  key: "1fr5h0"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}]];
var ReceiptTurkishLira = [["path", {
  d: "M10 7v10a5 5 0 0 0 5-5",
  key: "1blmz7"
}], ["path", {
  d: "m14 8-6 3",
  key: "2tb98i"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}]];
var Receipt = [["path", {
  d: "M12 17V7",
  key: "pyj7ub"
}], ["path", {
  d: "M16 8h-6a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H8",
  key: "1elt7d"
}], ["path", {
  d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
  key: "ycz6yz"
}]];
var RectangleCircle = [["path", {
  d: "M14 4v16H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z",
  key: "1m5n7q"
}], ["circle", {
  cx: "14",
  cy: "12",
  r: "8",
  key: "1pag6k"
}]];
var RectangleEllipsis = [["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "6",
  rx: "2",
  key: "9lu3g6"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M17 12h.01",
  key: "1m0b6t"
}], ["path", {
  d: "M7 12h.01",
  key: "eqddd0"
}]];
var RectangleGoggles = [["path", {
  d: "M20 6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-4a2 2 0 0 1-1.6-.8l-1.6-2.13a1 1 0 0 0-1.6 0L9.6 17.2A2 2 0 0 1 8 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
  key: "d5y1f"
}]];
var RectangleHorizontal = [["rect", {
  width: "20",
  height: "12",
  x: "2",
  y: "6",
  rx: "2",
  key: "9lu3g6"
}]];
var RectangleVertical = [["rect", {
  width: "12",
  height: "20",
  x: "6",
  y: "2",
  rx: "2",
  key: "1oxtiu"
}]];
var Recycle = [["path", {
  d: "M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5",
  key: "x6z5xu"
}], ["path", {
  d: "M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775l-1.226-2.12",
  key: "1x4zh5"
}], ["path", {
  d: "m14 16-3 3 3 3",
  key: "f6jyew"
}], ["path", {
  d: "M8.293 13.596 7.196 9.5 3.1 10.598",
  key: "wf1obh"
}], ["path", {
  d: "m9.344 5.811 1.093-1.892A1.83 1.83 0 0 1 11.985 3a1.784 1.784 0 0 1 1.546.888l3.943 6.843",
  key: "9tzpgr"
}], ["path", {
  d: "m13.378 9.633 4.096 1.098 1.097-4.096",
  key: "1oe83g"
}]];
var Redo2 = [["path", {
  d: "m15 14 5-5-5-5",
  key: "12vg1m"
}], ["path", {
  d: "M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13",
  key: "6uklza"
}]];
var RedoDot = [["circle", {
  cx: "12",
  cy: "17",
  r: "1",
  key: "1ixnty"
}], ["path", {
  d: "M21 7v6h-6",
  key: "3ptur4"
}], ["path", {
  d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7",
  key: "1kgawr"
}]];
var Redo = [["path", {
  d: "M21 7v6h-6",
  key: "3ptur4"
}], ["path", {
  d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7",
  key: "1kgawr"
}]];
var RefreshCcwDot = [["path", {
  d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
  key: "14sxne"
}], ["path", {
  d: "M3 3v5h5",
  key: "1xhq8a"
}], ["path", {
  d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",
  key: "1hlbsb"
}], ["path", {
  d: "M16 16h5v5",
  key: "ccwih5"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}]];
var RefreshCcw = [["path", {
  d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
  key: "14sxne"
}], ["path", {
  d: "M3 3v5h5",
  key: "1xhq8a"
}], ["path", {
  d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",
  key: "1hlbsb"
}], ["path", {
  d: "M16 16h5v5",
  key: "ccwih5"
}]];
var RefreshCwOff = [["path", {
  d: "M21 8L18.74 5.74A9.75 9.75 0 0 0 12 3C11 3 10.03 3.16 9.13 3.47",
  key: "1krf6h"
}], ["path", {
  d: "M8 16H3v5",
  key: "1cv678"
}], ["path", {
  d: "M3 12C3 9.51 4 7.26 5.64 5.64",
  key: "ruvoct"
}], ["path", {
  d: "m3 16 2.26 2.26A9.75 9.75 0 0 0 12 21c2.49 0 4.74-1 6.36-2.64",
  key: "19q130"
}], ["path", {
  d: "M21 12c0 1-.16 1.97-.47 2.87",
  key: "4w8emr"
}], ["path", {
  d: "M21 3v5h-5",
  key: "1q7to0"
}], ["path", {
  d: "M22 22 2 2",
  key: "1r8tn9"
}]];
var RefreshCw = [["path", {
  d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
  key: "v9h5vc"
}], ["path", {
  d: "M21 3v5h-5",
  key: "1q7to0"
}], ["path", {
  d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
  key: "3uifl3"
}], ["path", {
  d: "M8 16H3v5",
  key: "1cv678"
}]];
var Refrigerator = [["path", {
  d: "M5 6a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6Z",
  key: "fpq118"
}], ["path", {
  d: "M5 10h14",
  key: "elsbfy"
}], ["path", {
  d: "M15 7v6",
  key: "1nx30x"
}]];
var Regex = [["path", {
  d: "M17 3v10",
  key: "15fgeh"
}], ["path", {
  d: "m12.67 5.5 8.66 5",
  key: "1gpheq"
}], ["path", {
  d: "m12.67 10.5 8.66-5",
  key: "1dkfa6"
}], ["path", {
  d: "M9 17a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2z",
  key: "swwfx4"
}]];
var RemoveFormatting = [["path", {
  d: "M4 7V4h16v3",
  key: "9msm58"
}], ["path", {
  d: "M5 20h6",
  key: "1h6pxn"
}], ["path", {
  d: "M13 4 8 20",
  key: "kqq6aj"
}], ["path", {
  d: "m15 15 5 5",
  key: "me55sn"
}], ["path", {
  d: "m20 15-5 5",
  key: "11p7ol"
}]];
var Repeat1 = [["path", {
  d: "m17 2 4 4-4 4",
  key: "nntrym"
}], ["path", {
  d: "M3 11v-1a4 4 0 0 1 4-4h14",
  key: "84bu3i"
}], ["path", {
  d: "m7 22-4-4 4-4",
  key: "1wqhfi"
}], ["path", {
  d: "M21 13v1a4 4 0 0 1-4 4H3",
  key: "1rx37r"
}], ["path", {
  d: "M11 10h1v4",
  key: "70cz1p"
}]];
var Repeat2 = [["path", {
  d: "m2 9 3-3 3 3",
  key: "1ltn5i"
}], ["path", {
  d: "M13 18H7a2 2 0 0 1-2-2V6",
  key: "1r6tfw"
}], ["path", {
  d: "m22 15-3 3-3-3",
  key: "4rnwn2"
}], ["path", {
  d: "M11 6h6a2 2 0 0 1 2 2v10",
  key: "2f72bc"
}]];
var Repeat = [["path", {
  d: "m17 2 4 4-4 4",
  key: "nntrym"
}], ["path", {
  d: "M3 11v-1a4 4 0 0 1 4-4h14",
  key: "84bu3i"
}], ["path", {
  d: "m7 22-4-4 4-4",
  key: "1wqhfi"
}], ["path", {
  d: "M21 13v1a4 4 0 0 1-4 4H3",
  key: "1rx37r"
}]];
var ReplaceAll = [["path", {
  d: "M14 14a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1",
  key: "zg1ipl"
}], ["path", {
  d: "M14 4a1 1 0 0 1 1-1",
  key: "dhj8ez"
}], ["path", {
  d: "M15 10a1 1 0 0 1-1-1",
  key: "1mnyi5"
}], ["path", {
  d: "M19 14a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1",
  key: "txt6k4"
}], ["path", {
  d: "M21 4a1 1 0 0 0-1-1",
  key: "sfs9ap"
}], ["path", {
  d: "M21 9a1 1 0 0 1-1 1",
  key: "mp6qeo"
}], ["path", {
  d: "m3 7 3 3 3-3",
  key: "x25e72"
}], ["path", {
  d: "M6 10V5a2 2 0 0 1 2-2h2",
  key: "15xut4"
}], ["rect", {
  x: "3",
  y: "14",
  width: "7",
  height: "7",
  rx: "1",
  key: "1bkyp8"
}]];
var Replace = [["path", {
  d: "M14 4a1 1 0 0 1 1-1",
  key: "dhj8ez"
}], ["path", {
  d: "M15 10a1 1 0 0 1-1-1",
  key: "1mnyi5"
}], ["path", {
  d: "M21 4a1 1 0 0 0-1-1",
  key: "sfs9ap"
}], ["path", {
  d: "M21 9a1 1 0 0 1-1 1",
  key: "mp6qeo"
}], ["path", {
  d: "m3 7 3 3 3-3",
  key: "x25e72"
}], ["path", {
  d: "M6 10V5a2 2 0 0 1 2-2h2",
  key: "15xut4"
}], ["rect", {
  x: "3",
  y: "14",
  width: "7",
  height: "7",
  rx: "1",
  key: "1bkyp8"
}]];
var Reply = [["path", {
  d: "M20 18v-2a4 4 0 0 0-4-4H4",
  key: "5vmcpk"
}], ["path", {
  d: "m9 17-5-5 5-5",
  key: "nvlc11"
}]];
var ReplyAll = [["path", {
  d: "m12 17-5-5 5-5",
  key: "1s3y5u"
}], ["path", {
  d: "M22 18v-2a4 4 0 0 0-4-4H7",
  key: "1fcyog"
}], ["path", {
  d: "m7 17-5-5 5-5",
  key: "1ed8i2"
}]];
var Rewind = [["path", {
  d: "M12 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 12 18z",
  key: "2a1g8i"
}], ["path", {
  d: "M22 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 22 18z",
  key: "rg3s36"
}]];
var Ribbon = [["path", {
  d: "M12 11.22C11 9.997 10 9 10 8a2 2 0 0 1 4 0c0 1-.998 2.002-2.01 3.22",
  key: "1rnhq3"
}], ["path", {
  d: "m12 18 2.57-3.5",
  key: "116vt7"
}], ["path", {
  d: "M6.243 9.016a7 7 0 0 1 11.507-.009",
  key: "10dq0b"
}], ["path", {
  d: "M9.35 14.53 12 11.22",
  key: "tdsyp2"
}], ["path", {
  d: "M9.35 14.53C7.728 12.246 6 10.221 6 7a6 5 0 0 1 12 0c-.005 3.22-1.778 5.235-3.43 7.5l3.557 4.527a1 1 0 0 1-.203 1.43l-1.894 1.36a1 1 0 0 1-1.384-.215L12 18l-2.679 3.593a1 1 0 0 1-1.39.213l-1.865-1.353a1 1 0 0 1-.203-1.422z",
  key: "nmifey"
}]];
var Rocket = [["path", {
  d: "M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",
  key: "qeys4"
}], ["path", {
  d: "M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09",
  key: "u4xsad"
}], ["path", {
  d: "M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z",
  key: "676m9"
}], ["path", {
  d: "M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05",
  key: "92ym6u"
}]];
var RockingChair = [["path", {
  d: "m15 13 3.708 7.416",
  key: "1edxn9"
}], ["path", {
  d: "M3 19a15 15 0 0 0 18 0",
  key: "d0d1c4"
}], ["path", {
  d: "m3 2 3.21 9.633A2 2 0 0 0 8.109 13H18",
  key: "tpa4et"
}], ["path", {
  d: "m9 13-3.708 7.416",
  key: "1oplxx"
}]];
var RollerCoaster = [["path", {
  d: "M6 19V5",
  key: "1r845m"
}], ["path", {
  d: "M10 19V6.8",
  key: "9j2tfs"
}], ["path", {
  d: "M14 19v-7.8",
  key: "10s8qv"
}], ["path", {
  d: "M18 5v4",
  key: "1tajlv"
}], ["path", {
  d: "M18 19v-6",
  key: "ielfq3"
}], ["path", {
  d: "M22 19V9",
  key: "158nzp"
}], ["path", {
  d: "M2 19V9a4 4 0 0 1 4-4c2 0 4 1.33 6 4s4 4 6 4a4 4 0 1 0-3-6.65",
  key: "1930oh"
}]];
var Rose = [["path", {
  d: "M17 10h-1a4 4 0 1 1 4-4v.534",
  key: "7qf5zm"
}], ["path", {
  d: "M17 6h1a4 4 0 0 1 1.42 7.74l-2.29.87a6 6 0 0 1-5.339-10.68l2.069-1.31",
  key: "1et29u"
}], ["path", {
  d: "M4.5 17c2.8-.5 4.4 0 5.5.8s1.8 2.2 2.3 3.7c-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2",
  key: "kiv2lz"
}], ["path", {
  d: "M9.77 12C4 15 2 22 2 22",
  key: "h28rw0"
}], ["circle", {
  cx: "17",
  cy: "8",
  r: "2",
  key: "1330xn"
}]];
var Rotate3d = [["path", {
  d: "M16.466 7.5C15.643 4.237 13.952 2 12 2 9.239 2 7 6.477 7 12s2.239 10 5 10c.342 0 .677-.069 1-.2",
  key: "10n0gc"
}], ["path", {
  d: "m15.194 13.707 3.814 1.86-1.86 3.814",
  key: "16shm9"
}], ["path", {
  d: "M19 15.57c-1.804.885-4.274 1.43-7 1.43-5.523 0-10-2.239-10-5s4.477-5 10-5c4.838 0 8.873 1.718 9.8 4",
  key: "1lxi77"
}]];
var RotateCcwKey = [["path", {
  d: "M12 7v6",
  key: "lw1j43"
}], ["path", {
  d: "M12 9h2",
  key: "1lpap9"
}], ["path", {
  d: "M3 12a9 9 0 1 0 9-9 9.74 9.74 0 0 0-6.74 2.74L3 8",
  key: "g2jlw"
}], ["path", {
  d: "M3 3v5h5",
  key: "1xhq8a"
}], ["circle", {
  cx: "12",
  cy: "15",
  r: "2",
  key: "1vpstw"
}]];
var RotateCcwSquare = [["path", {
  d: "M20 9V7a2 2 0 0 0-2-2h-6",
  key: "19z8uc"
}], ["path", {
  d: "m15 2-3 3 3 3",
  key: "177bxs"
}], ["path", {
  d: "M20 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2",
  key: "d36hnl"
}]];
var RotateCcw = [["path", {
  d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
  key: "1357e3"
}], ["path", {
  d: "M3 3v5h5",
  key: "1xhq8a"
}]];
var RotateCwSquare = [["path", {
  d: "M12 5H6a2 2 0 0 0-2 2v3",
  key: "l96uqu"
}], ["path", {
  d: "m9 8 3-3-3-3",
  key: "1gzgc3"
}], ["path", {
  d: "M4 14v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2",
  key: "1w2k5h"
}]];
var RotateCw = [["path", {
  d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",
  key: "1p45f6"
}], ["path", {
  d: "M21 3v5h-5",
  key: "1q7to0"
}]];
var RouteOff = [["circle", {
  cx: "6",
  cy: "19",
  r: "3",
  key: "1kj8tv"
}], ["path", {
  d: "M9 19h8.5c.4 0 .9-.1 1.3-.2",
  key: "1effex"
}], ["path", {
  d: "M5.2 5.2A3.5 3.53 0 0 0 6.5 12H12",
  key: "k9y2ds"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M21 15.3a3.5 3.5 0 0 0-3.3-3.3",
  key: "11nlu2"
}], ["path", {
  d: "M15 5h-4.3",
  key: "6537je"
}], ["circle", {
  cx: "18",
  cy: "5",
  r: "3",
  key: "gq8acd"
}]];
var Route = [["circle", {
  cx: "6",
  cy: "19",
  r: "3",
  key: "1kj8tv"
}], ["path", {
  d: "M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15",
  key: "1d8sl"
}], ["circle", {
  cx: "18",
  cy: "5",
  r: "3",
  key: "gq8acd"
}]];
var Router = [["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "14",
  rx: "2",
  key: "w68u3i"
}], ["path", {
  d: "M6.01 18H6",
  key: "19vcac"
}], ["path", {
  d: "M10.01 18H10",
  key: "uamcmx"
}], ["path", {
  d: "M15 10v4",
  key: "qjz1xs"
}], ["path", {
  d: "M17.84 7.17a4 4 0 0 0-5.66 0",
  key: "1rif40"
}], ["path", {
  d: "M20.66 4.34a8 8 0 0 0-11.31 0",
  key: "6a5xfq"
}]];
var Rows2 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}]];
var Rows3 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M21 9H3",
  key: "1338ky"
}], ["path", {
  d: "M21 15H3",
  key: "9uk58r"
}]];
var Rows4 = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M21 7.5H3",
  key: "1hm9pq"
}], ["path", {
  d: "M21 12H3",
  key: "2avoz0"
}], ["path", {
  d: "M21 16.5H3",
  key: "n7jzkj"
}]];
var Rss = [["path", {
  d: "M4 11a9 9 0 0 1 9 9",
  key: "pv89mb"
}], ["path", {
  d: "M4 4a16 16 0 0 1 16 16",
  key: "k0647b"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "1",
  key: "bfqh0e"
}]];
var RulerDimensionLine = [["path", {
  d: "M10 15v-3",
  key: "1pjskw"
}], ["path", {
  d: "M14 15v-3",
  key: "1o1mqj"
}], ["path", {
  d: "M18 15v-3",
  key: "cws6he"
}], ["path", {
  d: "M2 8V4",
  key: "3jv1jz"
}], ["path", {
  d: "M22 6H2",
  key: "1iqbfk"
}], ["path", {
  d: "M22 8V4",
  key: "16f4ou"
}], ["path", {
  d: "M6 15v-3",
  key: "1ij1qe"
}], ["rect", {
  x: "2",
  y: "12",
  width: "20",
  height: "8",
  rx: "2",
  key: "1tqiko"
}]];
var RussianRuble = [["path", {
  d: "M6 11h8a4 4 0 0 0 0-8H9v18",
  key: "18ai8t"
}], ["path", {
  d: "M6 15h8",
  key: "1y8f6l"
}]];
var Ruler = [["path", {
  d: "M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",
  key: "icamh8"
}], ["path", {
  d: "m14.5 12.5 2-2",
  key: "inckbg"
}], ["path", {
  d: "m11.5 9.5 2-2",
  key: "fmmyf7"
}], ["path", {
  d: "m8.5 6.5 2-2",
  key: "vc6u1g"
}], ["path", {
  d: "m17.5 15.5 2-2",
  key: "wo5hmg"
}]];
var Sailboat = [["path", {
  d: "M10 2v15",
  key: "1qf71f"
}], ["path", {
  d: "M7 22a4 4 0 0 1-4-4 1 1 0 0 1 1-1h16a1 1 0 0 1 1 1 4 4 0 0 1-4 4z",
  key: "1pxcvx"
}], ["path", {
  d: "M9.159 2.46a1 1 0 0 1 1.521-.193l9.977 8.98A1 1 0 0 1 20 13H4a1 1 0 0 1-.824-1.567z",
  key: "5oog16"
}]];
var Salad = [["path", {
  d: "M7 21h10",
  key: "1b0cd5"
}], ["path", {
  d: "M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z",
  key: "4rw317"
}], ["path", {
  d: "M11.38 12a2.4 2.4 0 0 1-.4-4.77 2.4 2.4 0 0 1 3.2-2.77 2.4 2.4 0 0 1 3.47-.63 2.4 2.4 0 0 1 3.37 3.37 2.4 2.4 0 0 1-1.1 3.7 2.51 2.51 0 0 1 .03 1.1",
  key: "10xrj0"
}], ["path", {
  d: "m13 12 4-4",
  key: "1hckqy"
}], ["path", {
  d: "M10.9 7.25A3.99 3.99 0 0 0 4 10c0 .73.2 1.41.54 2",
  key: "1p4srx"
}]];
var Sandwich = [["path", {
  d: "m2.37 11.223 8.372-6.777a2 2 0 0 1 2.516 0l8.371 6.777",
  key: "f1wd0e"
}], ["path", {
  d: "M21 15a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-5.25",
  key: "1pfu07"
}], ["path", {
  d: "M3 15a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h9",
  key: "1oq9qw"
}], ["path", {
  d: "m6.67 15 6.13 4.6a2 2 0 0 0 2.8-.4l3.15-4.2",
  key: "1fnwu5"
}], ["rect", {
  width: "20",
  height: "4",
  x: "2",
  y: "11",
  rx: "1",
  key: "itshg"
}]];
var SatelliteDish = [["path", {
  d: "M4 10a7.31 7.31 0 0 0 10 10Z",
  key: "1fzpp3"
}], ["path", {
  d: "m9 15 3-3",
  key: "88sc13"
}], ["path", {
  d: "M17 13a6 6 0 0 0-6-6",
  key: "15cc6u"
}], ["path", {
  d: "M21 13A10 10 0 0 0 11 3",
  key: "11nf8s"
}]];
var Satellite = [["path", {
  d: "m13.5 6.5-3.148-3.148a1.205 1.205 0 0 0-1.704 0L6.352 5.648a1.205 1.205 0 0 0 0 1.704L9.5 10.5",
  key: "dzhfyz"
}], ["path", {
  d: "M16.5 7.5 19 5",
  key: "1ltcjm"
}], ["path", {
  d: "m17.5 10.5 3.148 3.148a1.205 1.205 0 0 1 0 1.704l-2.296 2.296a1.205 1.205 0 0 1-1.704 0L13.5 14.5",
  key: "nfoymv"
}], ["path", {
  d: "M9 21a6 6 0 0 0-6-6",
  key: "1iajcf"
}], ["path", {
  d: "M9.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l4.296-4.296a1.205 1.205 0 0 0 0-1.704l-2.296-2.296a1.205 1.205 0 0 0-1.704 0z",
  key: "nv9zqy"
}]];
var SaudiRiyal = [["path", {
  d: "m20 19.5-5.5 1.2",
  key: "1aenhr"
}], ["path", {
  d: "M14.5 4v11.22a1 1 0 0 0 1.242.97L20 15.2",
  key: "2rtezt"
}], ["path", {
  d: "m2.978 19.351 5.549-1.363A2 2 0 0 0 10 16V2",
  key: "1kbm92"
}], ["path", {
  d: "M20 10 4 13.5",
  key: "8nums9"
}]];
var SaveAll = [["path", {
  d: "M10 2v3a1 1 0 0 0 1 1h5",
  key: "1xspal"
}], ["path", {
  d: "M18 18v-6a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6",
  key: "1ra60u"
}], ["path", {
  d: "M18 22H4a2 2 0 0 1-2-2V6",
  key: "pblm9e"
}], ["path", {
  d: "M8 18a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9.172a2 2 0 0 1 1.414.586l2.828 2.828A2 2 0 0 1 22 6.828V16a2 2 0 0 1-2.01 2z",
  key: "1yve0x"
}]];
var SaveOff = [["path", {
  d: "M13 13H8a1 1 0 0 0-1 1v7",
  key: "h8g396"
}], ["path", {
  d: "M14 8h1",
  key: "1lfen6"
}], ["path", {
  d: "M17 21v-4",
  key: "1yknxs"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20.41 20.41A2 2 0 0 1 19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 .59-1.41",
  key: "1t4vdl"
}], ["path", {
  d: "M29.5 11.5s5 5 4 5",
  key: "zzn4i6"
}], ["path", {
  d: "M9 3h6.2a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V15",
  key: "24cby9"
}]];
var Save = [["path", {
  d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
  key: "1c8476"
}], ["path", {
  d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",
  key: "1ydtos"
}], ["path", {
  d: "M7 3v4a1 1 0 0 0 1 1h7",
  key: "t51u73"
}]];
var Scale3d = [["path", {
  d: "M5 7v11a1 1 0 0 0 1 1h11",
  key: "13dt1j"
}], ["path", {
  d: "M5.293 18.707 11 13",
  key: "ezgbsx"
}], ["circle", {
  cx: "19",
  cy: "19",
  r: "2",
  key: "17f5cg"
}], ["circle", {
  cx: "5",
  cy: "5",
  r: "2",
  key: "1gwv83"
}]];
var Scale = [["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["path", {
  d: "m19 8 3 8a5 5 0 0 1-6 0zV7",
  key: "zcdpyk"
}], ["path", {
  d: "M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1",
  key: "1yorad"
}], ["path", {
  d: "m5 8 3 8a5 5 0 0 1-6 0zV7",
  key: "eua70x"
}], ["path", {
  d: "M7 21h10",
  key: "1b0cd5"
}]];
var Scaling = [["path", {
  d: "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",
  key: "1m0v6g"
}], ["path", {
  d: "M14 15H9v-5",
  key: "pi4jk9"
}], ["path", {
  d: "M16 3h5v5",
  key: "1806ms"
}], ["path", {
  d: "M21 3 9 15",
  key: "15kdhq"
}]];
var ScanBarcode = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["path", {
  d: "M8 7v10",
  key: "23sfjj"
}], ["path", {
  d: "M12 7v10",
  key: "jspqdw"
}], ["path", {
  d: "M17 7v10",
  key: "578dap"
}]];
var ScanEye = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["path", {
  d: "M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0",
  key: "11ak4c"
}]];
var ScanFace = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["path", {
  d: "M8 14s1.5 2 4 2 4-2 4-2",
  key: "1y1vjs"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["path", {
  d: "M15 9h.01",
  key: "x1ddxp"
}]];
var ScanHeart = [["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["path", {
  d: "M7.828 13.07A3 3 0 0 1 12 8.764a3 3 0 0 1 4.172 4.306l-3.447 3.62a1 1 0 0 1-1.449 0z",
  key: "1ak1ef"
}]];
var ScanLine = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["path", {
  d: "M7 12h10",
  key: "b7w52i"
}]];
var ScanQrCode = [["path", {
  d: "M17 12v4a1 1 0 0 1-1 1h-4",
  key: "uk4fdo"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M17 8V7",
  key: "q2g9wo"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M7 17h.01",
  key: "19xn7k"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["rect", {
  x: "7",
  y: "7",
  width: "5",
  height: "5",
  rx: "1",
  key: "m9kyts"
}]];
var ScanSearch = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["path", {
  d: "m16 16-1.9-1.9",
  key: "1dq9hf"
}]];
var ScanText = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}], ["path", {
  d: "M7 8h8",
  key: "1jbsf9"
}], ["path", {
  d: "M7 12h10",
  key: "b7w52i"
}], ["path", {
  d: "M7 16h6",
  key: "1vyc9m"
}]];
var Scan = [["path", {
  d: "M3 7V5a2 2 0 0 1 2-2h2",
  key: "aa7l1z"
}], ["path", {
  d: "M17 3h2a2 2 0 0 1 2 2v2",
  key: "4qcy5o"
}], ["path", {
  d: "M21 17v2a2 2 0 0 1-2 2h-2",
  key: "6vwrx8"
}], ["path", {
  d: "M7 21H5a2 2 0 0 1-2-2v-2",
  key: "ioqczr"
}]];
var School = [["path", {
  d: "M14 21v-3a2 2 0 0 0-4 0v3",
  key: "1rgiei"
}], ["path", {
  d: "M18 4.933V21",
  key: "tjwmp4"
}], ["path", {
  d: "m4 6 7.106-3.79a2 2 0 0 1 1.788 0L20 6",
  key: "zywc2d"
}], ["path", {
  d: "m6 11-3.52 2.147a1 1 0 0 0-.48.854V19a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a1 1 0 0 0-.48-.853L18 11",
  key: "1d4ql0"
}], ["path", {
  d: "M6 4.933V21",
  key: "1ufz1j"
}], ["circle", {
  cx: "12",
  cy: "9",
  r: "2",
  key: "1092wv"
}]];
var ScissorsLineDashed = [["path", {
  d: "M5.42 9.42 8 12",
  key: "12pkuq"
}], ["circle", {
  cx: "4",
  cy: "8",
  r: "2",
  key: "107mxr"
}], ["path", {
  d: "m14 6-8.58 8.58",
  key: "gvzu5l"
}], ["circle", {
  cx: "4",
  cy: "16",
  r: "2",
  key: "1ehqvc"
}], ["path", {
  d: "M10.8 14.8 14 18",
  key: "ax7m9r"
}], ["path", {
  d: "M16 12h-2",
  key: "10asgb"
}], ["path", {
  d: "M22 12h-2",
  key: "14jgyd"
}]];
var Scissors = [["circle", {
  cx: "6",
  cy: "6",
  r: "3",
  key: "1lh9wr"
}], ["path", {
  d: "M8.12 8.12 12 12",
  key: "1alkpv"
}], ["path", {
  d: "M20 4 8.12 15.88",
  key: "xgtan2"
}], ["circle", {
  cx: "6",
  cy: "18",
  r: "3",
  key: "fqmcym"
}], ["path", {
  d: "M14.8 14.8 20 20",
  key: "ptml3r"
}]];
var Scooter = [["path", {
  d: "M21 4h-3.5l2 11.05",
  key: "1gktiw"
}], ["path", {
  d: "M6.95 17h5.142c.523 0 .95-.406 1.063-.916a6.5 6.5 0 0 1 5.345-5.009",
  key: "1bq3u3"
}], ["circle", {
  cx: "19.5",
  cy: "17.5",
  r: "2.5",
  key: "e4zhv9"
}], ["circle", {
  cx: "4.5",
  cy: "17.5",
  r: "2.5",
  key: "50vk4p"
}]];
var ScreenShare = [["path", {
  d: "M13 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3",
  key: "i8wdob"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "m17 8 5-5",
  key: "fqif7o"
}], ["path", {
  d: "M17 3h5v5",
  key: "1o3tu8"
}]];
var ScreenShareOff = [["path", {
  d: "M13 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3",
  key: "i8wdob"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "m22 3-5 5",
  key: "12jva0"
}], ["path", {
  d: "m17 3 5 5",
  key: "k36vhe"
}]];
var ScrollText = [["path", {
  d: "M15 12h-5",
  key: "r7krc0"
}], ["path", {
  d: "M15 8h-5",
  key: "1khuty"
}], ["path", {
  d: "M19 17V5a2 2 0 0 0-2-2H4",
  key: "zz82l3"
}], ["path", {
  d: "M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",
  key: "1ph1d7"
}]];
var Scroll = [["path", {
  d: "M19 17V5a2 2 0 0 0-2-2H4",
  key: "zz82l3"
}], ["path", {
  d: "M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",
  key: "1ph1d7"
}]];
var SearchAlert = [["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}], ["path", {
  d: "M11 7v4",
  key: "m2edmq"
}], ["path", {
  d: "M11 15h.01",
  key: "k85uqc"
}]];
var SearchCheck = [["path", {
  d: "m8 11 2 2 4-4",
  key: "1sed1v"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}]];
var SearchCode = [["path", {
  d: "m13 13.5 2-2.5-2-2.5",
  key: "1rvxrh"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}], ["path", {
  d: "M9 8.5 7 11l2 2.5",
  key: "6ffwbx"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}]];
var SearchX = [["path", {
  d: "m13.5 8.5-5 5",
  key: "1cs55j"
}], ["path", {
  d: "m8.5 8.5 5 5",
  key: "a8mexj"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}]];
var SearchSlash = [["path", {
  d: "m13.5 8.5-5 5",
  key: "1cs55j"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["path", {
  d: "m21 21-4.3-4.3",
  key: "1qie3q"
}]];
var Search = [["path", {
  d: "m21 21-4.34-4.34",
  key: "14j7rj"
}], ["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}]];
var Section = [["path", {
  d: "M16 5a4 3 0 0 0-8 0c0 4 8 3 8 7a4 3 0 0 1-8 0",
  key: "vqan6v"
}], ["path", {
  d: "M8 19a4 3 0 0 0 8 0c0-4-8-3-8-7a4 3 0 0 1 8 0",
  key: "wdjd8o"
}]];
var SendToBack = [["rect", {
  x: "14",
  y: "14",
  width: "8",
  height: "8",
  rx: "2",
  key: "1b0bso"
}], ["rect", {
  x: "2",
  y: "2",
  width: "8",
  height: "8",
  rx: "2",
  key: "1x09vl"
}], ["path", {
  d: "M7 14v1a2 2 0 0 0 2 2h1",
  key: "pao6x6"
}], ["path", {
  d: "M14 7h1a2 2 0 0 1 2 2v1",
  key: "19tdru"
}]];
var SendHorizontal = [["path", {
  d: "M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",
  key: "117uat"
}], ["path", {
  d: "M6 12h16",
  key: "s4cdu5"
}]];
var Send = [["path", {
  d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
  key: "1ffxy3"
}], ["path", {
  d: "m21.854 2.147-10.94 10.939",
  key: "12cjpa"
}]];
var SeparatorHorizontal = [["path", {
  d: "m16 16-4 4-4-4",
  key: "3dv8je"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}], ["path", {
  d: "m8 8 4-4 4 4",
  key: "2bscm2"
}]];
var SeparatorVertical = [["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["path", {
  d: "m16 16 4-4-4-4",
  key: "1js579"
}], ["path", {
  d: "m8 8-4 4 4 4",
  key: "1whems"
}]];
var ServerCrash = [["path", {
  d: "M6 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2",
  key: "4b9dqc"
}], ["path", {
  d: "M6 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2",
  key: "22nnkd"
}], ["path", {
  d: "M6 6h.01",
  key: "1utrut"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "m13 6-4 6h6l-4 6",
  key: "14hqih"
}]];
var ServerCog = [["path", {
  d: "m10.852 14.772-.383.923",
  key: "11vil6"
}], ["path", {
  d: "M13.148 14.772a3 3 0 1 0-2.296-5.544l-.383-.923",
  key: "1v3clb"
}], ["path", {
  d: "m13.148 9.228.383-.923",
  key: "t2zzyc"
}], ["path", {
  d: "m13.53 15.696-.382-.924a3 3 0 1 1-2.296-5.544",
  key: "1bxfiv"
}], ["path", {
  d: "m14.772 10.852.923-.383",
  key: "k9m8cz"
}], ["path", {
  d: "m14.772 13.148.923.383",
  key: "1xvhww"
}], ["path", {
  d: "M4.5 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-.5",
  key: "tn8das"
}], ["path", {
  d: "M4.5 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-.5",
  key: "1g2pve"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "M6 6h.01",
  key: "1utrut"
}], ["path", {
  d: "m9.228 10.852-.923-.383",
  key: "1wtb30"
}], ["path", {
  d: "m9.228 13.148-.923.383",
  key: "1a830x"
}]];
var ServerOff = [["path", {
  d: "M7 2h13a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-5",
  key: "bt2siv"
}], ["path", {
  d: "M10 10 2.5 2.5C2 2 2 2.5 2 5v3a2 2 0 0 0 2 2h6z",
  key: "1hjrv1"
}], ["path", {
  d: "M22 17v-1a2 2 0 0 0-2-2h-1",
  key: "1iynyr"
}], ["path", {
  d: "M4 14a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16.5l1-.5.5.5-8-8H4z",
  key: "161ggg"
}], ["path", {
  d: "M6 18h.01",
  key: "uhywen"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Server = [["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "2",
  rx: "2",
  ry: "2",
  key: "ngkwjq"
}], ["rect", {
  width: "20",
  height: "8",
  x: "2",
  y: "14",
  rx: "2",
  ry: "2",
  key: "iecqi9"
}], ["line", {
  x1: "6",
  x2: "6.01",
  y1: "6",
  y2: "6",
  key: "16zg32"
}], ["line", {
  x1: "6",
  x2: "6.01",
  y1: "18",
  y2: "18",
  key: "nzw8ys"
}]];
var Settings2 = [["path", {
  d: "M14 17H5",
  key: "gfn3mx"
}], ["path", {
  d: "M19 7h-9",
  key: "6i9tg"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "3",
  key: "18b49y"
}], ["circle", {
  cx: "7",
  cy: "7",
  r: "3",
  key: "dfmy0x"
}]];
var Settings = [["path", {
  d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
  key: "1i5ecw"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}]];
var Shapes = [["path", {
  d: "M8.3 10a.7.7 0 0 1-.626-1.079L11.4 3a.7.7 0 0 1 1.198-.043L16.3 8.9a.7.7 0 0 1-.572 1.1Z",
  key: "1bo67w"
}], ["rect", {
  x: "3",
  y: "14",
  width: "7",
  height: "7",
  rx: "1",
  key: "1bkyp8"
}], ["circle", {
  cx: "17.5",
  cy: "17.5",
  r: "3.5",
  key: "w3z12y"
}]];
var Share2 = [["circle", {
  cx: "18",
  cy: "5",
  r: "3",
  key: "gq8acd"
}], ["circle", {
  cx: "6",
  cy: "12",
  r: "3",
  key: "w7nqdw"
}], ["circle", {
  cx: "18",
  cy: "19",
  r: "3",
  key: "1xt0gg"
}], ["line", {
  x1: "8.59",
  x2: "15.42",
  y1: "13.51",
  y2: "17.49",
  key: "47mynk"
}], ["line", {
  x1: "15.41",
  x2: "8.59",
  y1: "6.51",
  y2: "10.49",
  key: "1n3mei"
}]];
var Share = [["path", {
  d: "M12 2v13",
  key: "1km8f5"
}], ["path", {
  d: "m16 6-4-4-4 4",
  key: "13yo43"
}], ["path", {
  d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8",
  key: "1b2hhj"
}]];
var Sheet = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["line", {
  x1: "3",
  x2: "21",
  y1: "9",
  y2: "9",
  key: "1vqk6q"
}], ["line", {
  x1: "3",
  x2: "21",
  y1: "15",
  y2: "15",
  key: "o2sbyz"
}], ["line", {
  x1: "9",
  x2: "9",
  y1: "9",
  y2: "21",
  key: "1ib60c"
}], ["line", {
  x1: "15",
  x2: "15",
  y1: "9",
  y2: "21",
  key: "1n26ft"
}]];
var Shell = [["path", {
  d: "M14 11a2 2 0 1 1-4 0 4 4 0 0 1 8 0 6 6 0 0 1-12 0 8 8 0 0 1 16 0 10 10 0 1 1-20 0 11.93 11.93 0 0 1 2.42-7.22 2 2 0 1 1 3.16 2.44",
  key: "1cn552"
}]];
var ShelvingUnit = [["path", {
  d: "M12 12V9a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3",
  key: "wiz68x"
}], ["path", {
  d: "M16 20v-3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3",
  key: "1b59c4"
}], ["path", {
  d: "M20 22V2",
  key: "1bnhr8"
}], ["path", {
  d: "M4 12h16",
  key: "1lakjw"
}], ["path", {
  d: "M4 20h16",
  key: "14thso"
}], ["path", {
  d: "M4 2v20",
  key: "gtpd5x"
}], ["path", {
  d: "M4 4h16",
  key: "1bkgr1"
}]];
var ShieldAlert = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M12 8v4",
  key: "1got3b"
}], ["path", {
  d: "M12 16h.01",
  key: "1drbdi"
}]];
var ShieldBan = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "m4.243 5.21 14.39 12.472",
  key: "1c9a7c"
}]];
var ShieldCheck = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var ShieldEllipsis = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M8 12h.01",
  key: "czm47f"
}], ["path", {
  d: "M12 12h.01",
  key: "1mp3jc"
}], ["path", {
  d: "M16 12h.01",
  key: "1l6xoz"
}]];
var ShieldHalf = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M12 22V2",
  key: "zs6s6o"
}]];
var ShieldMinus = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M9 12h6",
  key: "1c52cq"
}]];
var ShieldOff = [["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M5 5a1 1 0 0 0-1 1v7c0 5 3.5 7.5 7.67 8.94a1 1 0 0 0 .67.01c2.35-.82 4.48-1.97 5.9-3.71",
  key: "1jlk70"
}], ["path", {
  d: "M9.309 3.652A12.252 12.252 0 0 0 11.24 2.28a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1v7a9.784 9.784 0 0 1-.08 1.264",
  key: "18rp1v"
}]];
var ShieldPlus = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M9 12h6",
  key: "1c52cq"
}], ["path", {
  d: "M12 9v6",
  key: "199k2o"
}]];
var ShieldQuestionMark = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3",
  key: "mhlwft"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}]];
var ShieldUser = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "M6.376 18.91a6 6 0 0 1 11.249.003",
  key: "hnjrf2"
}], ["circle", {
  cx: "12",
  cy: "11",
  r: "4",
  key: "1gt34v"
}]];
var ShieldX = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}], ["path", {
  d: "m14.5 9.5-5 5",
  key: "17q4r4"
}], ["path", {
  d: "m9.5 9.5 5 5",
  key: "18nt4w"
}]];
var Shield = [["path", {
  d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
  key: "oel41y"
}]];
var ShipWheel = [["circle", {
  cx: "12",
  cy: "12",
  r: "8",
  key: "46899m"
}], ["path", {
  d: "M12 2v7.5",
  key: "1e5rl5"
}], ["path", {
  d: "m19 5-5.23 5.23",
  key: "1ezxxf"
}], ["path", {
  d: "M22 12h-7.5",
  key: "le1719"
}], ["path", {
  d: "m19 19-5.23-5.23",
  key: "p3fmgn"
}], ["path", {
  d: "M12 14.5V22",
  key: "dgcmos"
}], ["path", {
  d: "M10.23 13.77 5 19",
  key: "qwopd4"
}], ["path", {
  d: "M9.5 12H2",
  key: "r7bup8"
}], ["path", {
  d: "M10.23 10.23 5 5",
  key: "k2y7lj"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2.5",
  key: "ix0uyj"
}]];
var Ship = [["path", {
  d: "M12 10.189V14",
  key: "1p8cqu"
}], ["path", {
  d: "M12 2v3",
  key: "qbqxhf"
}], ["path", {
  d: "M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6",
  key: "qpkstq"
}], ["path", {
  d: "M19.38 20A11.6 11.6 0 0 0 21 14l-8.188-3.639a2 2 0 0 0-1.624 0L3 14a11.6 11.6 0 0 0 2.81 7.76",
  key: "7tigtc"
}], ["path", {
  d: "M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "1924j5"
}]];
var Shirt = [["path", {
  d: "M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z",
  key: "1wgbhj"
}]];
var ShoppingBag = [["path", {
  d: "M16 10a4 4 0 0 1-8 0",
  key: "1ltviw"
}], ["path", {
  d: "M3.103 6.034h17.794",
  key: "awc11p"
}], ["path", {
  d: "M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",
  key: "o988cm"
}]];
var ShoppingBasket = [["path", {
  d: "m15 11-1 9",
  key: "5wnq3a"
}], ["path", {
  d: "m19 11-4-7",
  key: "cnml18"
}], ["path", {
  d: "M2 11h20",
  key: "3eubbj"
}], ["path", {
  d: "m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4",
  key: "yiazzp"
}], ["path", {
  d: "M4.5 15.5h15",
  key: "13mye1"
}], ["path", {
  d: "m5 11 4-7",
  key: "116ra9"
}], ["path", {
  d: "m9 11 1 9",
  key: "1ojof7"
}]];
var ShoppingCart = [["circle", {
  cx: "8",
  cy: "21",
  r: "1",
  key: "jimo8o"
}], ["circle", {
  cx: "19",
  cy: "21",
  r: "1",
  key: "13723u"
}], ["path", {
  d: "M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",
  key: "9zh506"
}]];
var Shovel = [["path", {
  d: "M21.56 4.56a1.5 1.5 0 0 1 0 2.122l-.47.47a3 3 0 0 1-4.212-.03 3 3 0 0 1 0-4.243l.44-.44a1.5 1.5 0 0 1 2.121 0z",
  key: "1gcedi"
}], ["path", {
  d: "M3 22a1 1 0 0 1-1-1v-3.586a1 1 0 0 1 .293-.707l3.355-3.355a1.205 1.205 0 0 1 1.704 0l3.296 3.296a1.205 1.205 0 0 1 0 1.704l-3.355 3.355a1 1 0 0 1-.707.293z",
  key: "pg9kv3"
}], ["path", {
  d: "m9 15 7.879-7.878",
  key: "1o1zgh"
}]];
var ShowerHead = [["path", {
  d: "m4 4 2.5 2.5",
  key: "uv2vmf"
}], ["path", {
  d: "M13.5 6.5a4.95 4.95 0 0 0-7 7",
  key: "frdkwv"
}], ["path", {
  d: "M15 5 5 15",
  key: "1ag8rq"
}], ["path", {
  d: "M14 17v.01",
  key: "eokfpp"
}], ["path", {
  d: "M10 16v.01",
  key: "14uyyl"
}], ["path", {
  d: "M13 13v.01",
  key: "1v1k97"
}], ["path", {
  d: "M16 10v.01",
  key: "5169yg"
}], ["path", {
  d: "M11 20v.01",
  key: "cj92p8"
}], ["path", {
  d: "M17 14v.01",
  key: "11cswd"
}], ["path", {
  d: "M20 11v.01",
  key: "19e0od"
}]];
var Shredder = [["path", {
  d: "M4 13V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5",
  key: "1eob4r"
}], ["path", {
  d: "M14 2v5a1 1 0 0 0 1 1h5",
  key: "wfsgrz"
}], ["path", {
  d: "M10 22v-5",
  key: "sfixh4"
}], ["path", {
  d: "M14 19v-2",
  key: "pdve8j"
}], ["path", {
  d: "M18 20v-3",
  key: "uox2gk"
}], ["path", {
  d: "M2 13h20",
  key: "5evz65"
}], ["path", {
  d: "M6 20v-3",
  key: "c6pdcb"
}]];
var Shrimp = [["path", {
  d: "M11 12h.01",
  key: "1lr4k6"
}], ["path", {
  d: "M13 22c.5-.5 1.12-1 2.5-1-1.38 0-2-.5-2.5-1",
  key: "fatpdi"
}], ["path", {
  d: "M14 2a3.28 3.28 0 0 1-3.227 1.798l-6.17-.561A2.387 2.387 0 1 0 4.387 8H15.5a1 1 0 0 1 0 13 1 1 0 0 0 0-5H12a7 7 0 0 1-7-7V8",
  key: "kehrqe"
}], ["path", {
  d: "M14 8a8.5 8.5 0 0 1 0 8",
  key: "1imjx2"
}], ["path", {
  d: "M16 16c2 0 4.5-4 4-6",
  key: "z0nejz"
}]];
var Shrink = [["path", {
  d: "m15 15 6 6m-6-6v4.8m0-4.8h4.8",
  key: "17vawe"
}], ["path", {
  d: "M9 19.8V15m0 0H4.2M9 15l-6 6",
  key: "chjx8e"
}], ["path", {
  d: "M15 4.2V9m0 0h4.8M15 9l6-6",
  key: "lav6yq"
}], ["path", {
  d: "M9 4.2V9m0 0H4.2M9 9 3 3",
  key: "1pxi2q"
}]];
var Shrub = [["path", {
  d: "M12 22v-5.172a2 2 0 0 0-.586-1.414L9.5 13.5",
  key: "1p17fm"
}], ["path", {
  d: "M14.5 14.5 12 17",
  key: "dy5w4y"
}], ["path", {
  d: "M17 8.8A6 6 0 0 1 13.8 20H10A6.5 6.5 0 0 1 7 8a5 5 0 0 1 10 0z",
  key: "6z7b3o"
}]];
var Shuffle = [["path", {
  d: "m18 14 4 4-4 4",
  key: "10pe0f"
}], ["path", {
  d: "m18 2 4 4-4 4",
  key: "pucp1d"
}], ["path", {
  d: "M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22",
  key: "1ailkh"
}], ["path", {
  d: "M2 6h1.972a4 4 0 0 1 3.6 2.2",
  key: "km57vx"
}], ["path", {
  d: "M22 18h-6.041a4 4 0 0 1-3.3-1.8l-.359-.45",
  key: "os18l9"
}]];
var Sigma = [["path", {
  d: "M18 7V5a1 1 0 0 0-1-1H6.5a.5.5 0 0 0-.4.8l4.5 6a2 2 0 0 1 0 2.4l-4.5 6a.5.5 0 0 0 .4.8H17a1 1 0 0 0 1-1v-2",
  key: "wuwx1p"
}]];
var SignalLow = [["path", {
  d: "M2 20h.01",
  key: "4haj6o"
}], ["path", {
  d: "M7 20v-4",
  key: "j294jx"
}]];
var SignalHigh = [["path", {
  d: "M2 20h.01",
  key: "4haj6o"
}], ["path", {
  d: "M7 20v-4",
  key: "j294jx"
}], ["path", {
  d: "M12 20v-8",
  key: "i3yub9"
}], ["path", {
  d: "M17 20V8",
  key: "1tkaf5"
}]];
var SignalMedium = [["path", {
  d: "M2 20h.01",
  key: "4haj6o"
}], ["path", {
  d: "M7 20v-4",
  key: "j294jx"
}], ["path", {
  d: "M12 20v-8",
  key: "i3yub9"
}]];
var Signal = [["path", {
  d: "M2 20h.01",
  key: "4haj6o"
}], ["path", {
  d: "M7 20v-4",
  key: "j294jx"
}], ["path", {
  d: "M12 20v-8",
  key: "i3yub9"
}], ["path", {
  d: "M17 20V8",
  key: "1tkaf5"
}], ["path", {
  d: "M22 4v16",
  key: "sih9yq"
}]];
var SignalZero = [["path", {
  d: "M2 20h.01",
  key: "4haj6o"
}]];
var Signature = [["path", {
  d: "m21 17-2.156-1.868A.5.5 0 0 0 18 15.5v.5a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1c0-2.545-3.991-3.97-8.5-4a1 1 0 0 0 0 5c4.153 0 4.745-11.295 5.708-13.5a2.5 2.5 0 1 1 3.31 3.284",
  key: "y32ogt"
}], ["path", {
  d: "M3 21h18",
  key: "itz85i"
}]];
var SignpostBig = [["path", {
  d: "M10 9H4L2 7l2-2h6",
  key: "1hq7x2"
}], ["path", {
  d: "M14 5h6l2 2-2 2h-6",
  key: "bv62ej"
}], ["path", {
  d: "M10 22V4a2 2 0 1 1 4 0v18",
  key: "eqpcf2"
}], ["path", {
  d: "M8 22h8",
  key: "rmew8v"
}]];
var Signpost = [["path", {
  d: "M12 13v8",
  key: "1l5pq0"
}], ["path", {
  d: "M12 3v3",
  key: "1n5kay"
}], ["path", {
  d: "M18 6a2 2 0 0 1 1.387.56l2.307 2.22a1 1 0 0 1 0 1.44l-2.307 2.22A2 2 0 0 1 18 13H6a2 2 0 0 1-1.387-.56l-2.306-2.22a1 1 0 0 1 0-1.44l2.306-2.22A2 2 0 0 1 6 6z",
  key: "gqqp9m"
}]];
var Siren = [["path", {
  d: "M7 18v-6a5 5 0 1 1 10 0v6",
  key: "pcx96s"
}], ["path", {
  d: "M5 21a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2z",
  key: "1b4s83"
}], ["path", {
  d: "M21 12h1",
  key: "jtio3y"
}], ["path", {
  d: "M18.5 4.5 18 5",
  key: "g5sp9y"
}], ["path", {
  d: "M2 12h1",
  key: "1uaihz"
}], ["path", {
  d: "M12 2v1",
  key: "11qlp1"
}], ["path", {
  d: "m4.929 4.929.707.707",
  key: "1i51kw"
}], ["path", {
  d: "M12 12v6",
  key: "3ahymv"
}]];
var SkipBack = [["path", {
  d: "M17.971 4.285A2 2 0 0 1 21 6v12a2 2 0 0 1-3.029 1.715l-9.997-5.998a2 2 0 0 1-.003-3.432z",
  key: "15892j"
}], ["path", {
  d: "M3 20V4",
  key: "1ptbpl"
}]];
var SkipForward = [["path", {
  d: "M21 4v16",
  key: "7j8fe9"
}], ["path", {
  d: "M6.029 4.285A2 2 0 0 0 3 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z",
  key: "zs4d6"
}]];
var Skull = [["path", {
  d: "m12.5 17-.5-1-.5 1h1z",
  key: "3me087"
}], ["path", {
  d: "M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z",
  key: "1o5pge"
}], ["circle", {
  cx: "15",
  cy: "12",
  r: "1",
  key: "1tmaij"
}], ["circle", {
  cx: "9",
  cy: "12",
  r: "1",
  key: "1vctgf"
}]];
var Slack = [["rect", {
  width: "3",
  height: "8",
  x: "13",
  y: "2",
  rx: "1.5",
  key: "diqz80"
}], ["path", {
  d: "M19 8.5V10h1.5A1.5 1.5 0 1 0 19 8.5",
  key: "183iwg"
}], ["rect", {
  width: "3",
  height: "8",
  x: "8",
  y: "14",
  rx: "1.5",
  key: "hqg7r1"
}], ["path", {
  d: "M5 15.5V14H3.5A1.5 1.5 0 1 0 5 15.5",
  key: "76g71w"
}], ["rect", {
  width: "8",
  height: "3",
  x: "14",
  y: "13",
  rx: "1.5",
  key: "1kmz0a"
}], ["path", {
  d: "M15.5 19H14v1.5a1.5 1.5 0 1 0 1.5-1.5",
  key: "jc4sz0"
}], ["rect", {
  width: "8",
  height: "3",
  x: "2",
  y: "8",
  rx: "1.5",
  key: "1omvl4"
}], ["path", {
  d: "M8.5 5H10V3.5A1.5 1.5 0 1 0 8.5 5",
  key: "16f3cl"
}]];
var Slash = [["path", {
  d: "M22 2 2 22",
  key: "y4kqgn"
}]];
var Slice = [["path", {
  d: "M11 16.586V19a1 1 0 0 1-1 1H2L18.37 3.63a1 1 0 1 1 3 3l-9.663 9.663a1 1 0 0 1-1.414 0L8 14",
  key: "1sllp5"
}]];
var SlidersHorizontal = [["path", {
  d: "M10 5H3",
  key: "1qgfaw"
}], ["path", {
  d: "M12 19H3",
  key: "yhmn1j"
}], ["path", {
  d: "M14 3v4",
  key: "1sua03"
}], ["path", {
  d: "M16 17v4",
  key: "1q0r14"
}], ["path", {
  d: "M21 12h-9",
  key: "1o4lsq"
}], ["path", {
  d: "M21 19h-5",
  key: "1rlt1p"
}], ["path", {
  d: "M21 5h-7",
  key: "1oszz2"
}], ["path", {
  d: "M8 10v4",
  key: "tgpxqk"
}], ["path", {
  d: "M8 12H3",
  key: "a7s4jb"
}]];
var SlidersVertical = [["path", {
  d: "M10 8h4",
  key: "1sr2af"
}], ["path", {
  d: "M12 21v-9",
  key: "17s77i"
}], ["path", {
  d: "M12 8V3",
  key: "13r4qs"
}], ["path", {
  d: "M17 16h4",
  key: "h1uq16"
}], ["path", {
  d: "M19 12V3",
  key: "o1uvq1"
}], ["path", {
  d: "M19 21v-5",
  key: "qua636"
}], ["path", {
  d: "M3 14h4",
  key: "bcjad9"
}], ["path", {
  d: "M5 10V3",
  key: "cb8scm"
}], ["path", {
  d: "M5 21v-7",
  key: "1w1uti"
}]];
var SmartphoneCharging = [["rect", {
  width: "14",
  height: "20",
  x: "5",
  y: "2",
  rx: "2",
  ry: "2",
  key: "1yt0o3"
}], ["path", {
  d: "M12.667 8 10 12h4l-2.667 4",
  key: "h9lk2d"
}]];
var SmartphoneNfc = [["rect", {
  width: "7",
  height: "12",
  x: "2",
  y: "6",
  rx: "1",
  key: "5nje8w"
}], ["path", {
  d: "M13 8.32a7.43 7.43 0 0 1 0 7.36",
  key: "1g306n"
}], ["path", {
  d: "M16.46 6.21a11.76 11.76 0 0 1 0 11.58",
  key: "uqvjvo"
}], ["path", {
  d: "M19.91 4.1a15.91 15.91 0 0 1 .01 15.8",
  key: "ujntz3"
}]];
var Smartphone = [["rect", {
  width: "14",
  height: "20",
  x: "5",
  y: "2",
  rx: "2",
  ry: "2",
  key: "1yt0o3"
}], ["path", {
  d: "M12 18h.01",
  key: "mhygvu"
}]];
var SmilePlus = [["path", {
  d: "M22 11v1a10 10 0 1 1-9-10",
  key: "ew0xw9"
}], ["path", {
  d: "M8 14s1.5 2 4 2 4-2 4-2",
  key: "1y1vjs"
}], ["line", {
  x1: "9",
  x2: "9.01",
  y1: "9",
  y2: "9",
  key: "yxxnd0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "9",
  y2: "9",
  key: "1p4y9e"
}], ["path", {
  d: "M16 5h6",
  key: "1vod17"
}], ["path", {
  d: "M19 2v6",
  key: "4bpg5p"
}]];
var Smile = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["path", {
  d: "M8 14s1.5 2 4 2 4-2 4-2",
  key: "1y1vjs"
}], ["line", {
  x1: "9",
  x2: "9.01",
  y1: "9",
  y2: "9",
  key: "yxxnd0"
}], ["line", {
  x1: "15",
  x2: "15.01",
  y1: "9",
  y2: "9",
  key: "1p4y9e"
}]];
var Snail = [["path", {
  d: "M2 13a6 6 0 1 0 12 0 4 4 0 1 0-8 0 2 2 0 0 0 4 0",
  key: "hneq2s"
}], ["circle", {
  cx: "10",
  cy: "13",
  r: "8",
  key: "194lz3"
}], ["path", {
  d: "M2 21h12c4.4 0 8-3.6 8-8V7a2 2 0 1 0-4 0v6",
  key: "ixqyt7"
}], ["path", {
  d: "M18 3 19.1 5.2",
  key: "9tjm43"
}], ["path", {
  d: "M22 3 20.9 5.2",
  key: "j3odrs"
}]];
var Snowflake = [["path", {
  d: "m10 20-1.25-2.5L6 18",
  key: "18frcb"
}], ["path", {
  d: "M10 4 8.75 6.5 6 6",
  key: "7mghy3"
}], ["path", {
  d: "m14 20 1.25-2.5L18 18",
  key: "1chtki"
}], ["path", {
  d: "m14 4 1.25 2.5L18 6",
  key: "1b4wsy"
}], ["path", {
  d: "m17 21-3-6h-4",
  key: "15hhxa"
}], ["path", {
  d: "m17 3-3 6 1.5 3",
  key: "11697g"
}], ["path", {
  d: "M2 12h6.5L10 9",
  key: "kv9z4n"
}], ["path", {
  d: "m20 10-1.5 2 1.5 2",
  key: "1swlpi"
}], ["path", {
  d: "M22 12h-6.5L14 15",
  key: "1mxi28"
}], ["path", {
  d: "m4 10 1.5 2L4 14",
  key: "k9enpj"
}], ["path", {
  d: "m7 21 3-6-1.5-3",
  key: "j8hb9u"
}], ["path", {
  d: "m7 3 3 6h4",
  key: "1otusx"
}]];
var SoapDispenserDroplet = [["path", {
  d: "M10.5 2v4",
  key: "1xt6in"
}], ["path", {
  d: "M14 2H7a2 2 0 0 0-2 2",
  key: "e6xig3"
}], ["path", {
  d: "M19.29 14.76A6.67 6.67 0 0 1 17 11a6.6 6.6 0 0 1-2.29 3.76c-1.15.92-1.71 2.04-1.71 3.19 0 2.22 1.8 4.05 4 4.05s4-1.83 4-4.05c0-1.16-.57-2.26-1.71-3.19",
  key: "adq7uc"
}], ["path", {
  d: "M9.607 21H6a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h7V7a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3",
  key: "t9hm96"
}]];
var Sofa = [["path", {
  d: "M20 9V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v3",
  key: "1dgpiv"
}], ["path", {
  d: "M2 16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z",
  key: "xacw8m"
}], ["path", {
  d: "M4 18v2",
  key: "jwo5n2"
}], ["path", {
  d: "M20 18v2",
  key: "1ar1qi"
}], ["path", {
  d: "M12 4v9",
  key: "oqhhn3"
}]];
var SolarPanel = [["path", {
  d: "M11 2h2",
  key: "isr7bz"
}], ["path", {
  d: "m14.28 14-4.56 8",
  key: "4anwcf"
}], ["path", {
  d: "m21 22-1.558-4H4.558",
  key: "enk13h"
}], ["path", {
  d: "M3 10v2",
  key: "w8mti9"
}], ["path", {
  d: "M6.245 15.04A2 2 0 0 1 8 14h12a1 1 0 0 1 .864 1.505l-3.11 5.457A2 2 0 0 1 16 22H4a1 1 0 0 1-.863-1.506z",
  key: "pouggg"
}], ["path", {
  d: "M7 2a4 4 0 0 1-4 4",
  key: "78s8of"
}], ["path", {
  d: "m8.66 7.66 1.41 1.41",
  key: "1vaqj8"
}]];
var Soup = [["path", {
  d: "M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z",
  key: "4rw317"
}], ["path", {
  d: "M7 21h10",
  key: "1b0cd5"
}], ["path", {
  d: "M19.5 12 22 6",
  key: "shfsr5"
}], ["path", {
  d: "M16.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.73 1.62",
  key: "rpc6vp"
}], ["path", {
  d: "M11.25 3c.27.1.8.53.74 1.36-.05.83-.93 1.2-.98 2.02-.06.78.33 1.24.72 1.62",
  key: "1lf63m"
}], ["path", {
  d: "M6.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.74 1.62",
  key: "97tijn"
}]];
var Space = [["path", {
  d: "M22 17v1c0 .5-.5 1-1 1H3c-.5 0-1-.5-1-1v-1",
  key: "lt2kga"
}]];
var Spade = [["path", {
  d: "M12 18v4",
  key: "jadmvz"
}], ["path", {
  d: "M2 14.499a5.5 5.5 0 0 0 9.591 3.675.6.6 0 0 1 .818.001A5.5 5.5 0 0 0 22 14.5c0-2.29-1.5-4-3-5.5l-5.492-5.312a2 2 0 0 0-3-.02L5 8.999c-1.5 1.5-3 3.2-3 5.5",
  key: "1aw2pz"
}]];
var Sparkles = [["path", {
  d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
  key: "1s2grr"
}], ["path", {
  d: "M20 2v4",
  key: "1rf3ol"
}], ["path", {
  d: "M22 4h-4",
  key: "gwowj6"
}], ["circle", {
  cx: "4",
  cy: "20",
  r: "2",
  key: "6kqj1y"
}]];
var Sparkle = [["path", {
  d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
  key: "1s2grr"
}]];
var Speaker = [["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "1nb95v"
}], ["path", {
  d: "M12 6h.01",
  key: "1vi96p"
}], ["circle", {
  cx: "12",
  cy: "14",
  r: "4",
  key: "1jruaj"
}], ["path", {
  d: "M12 14h.01",
  key: "1etili"
}]];
var Speech = [["path", {
  d: "M8.8 20v-4.1l1.9.2a2.3 2.3 0 0 0 2.164-2.1V8.3A5.37 5.37 0 0 0 2 8.25c0 2.8.656 3.054 1 4.55a5.77 5.77 0 0 1 .029 2.758L2 20",
  key: "11atix"
}], ["path", {
  d: "M19.8 17.8a7.5 7.5 0 0 0 .003-10.603",
  key: "yol142"
}], ["path", {
  d: "M17 15a3.5 3.5 0 0 0-.025-4.975",
  key: "ssbmkc"
}]];
var SpellCheck2 = [["path", {
  d: "m6 16 6-12 6 12",
  key: "1b4byz"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "M4 21c1.1 0 1.1-1 2.3-1s1.1 1 2.3 1c1.1 0 1.1-1 2.3-1 1.1 0 1.1 1 2.3 1 1.1 0 1.1-1 2.3-1 1.1 0 1.1 1 2.3 1 1.1 0 1.1-1 2.3-1",
  key: "8mdmtu"
}]];
var SpellCheck = [["path", {
  d: "m6 16 6-12 6 12",
  key: "1b4byz"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "m16 20 2 2 4-4",
  key: "13tcca"
}]];
var SplinePointer = [["path", {
  d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
  key: "xwnzip"
}], ["path", {
  d: "M5 17A12 12 0 0 1 17 5",
  key: "1okkup"
}], ["circle", {
  cx: "19",
  cy: "5",
  r: "2",
  key: "mhkx31"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "2",
  key: "v8kfzx"
}]];
var Spline = [["circle", {
  cx: "19",
  cy: "5",
  r: "2",
  key: "mhkx31"
}], ["circle", {
  cx: "5",
  cy: "19",
  r: "2",
  key: "v8kfzx"
}], ["path", {
  d: "M5 17A12 12 0 0 1 17 5",
  key: "1okkup"
}]];
var Split = [["path", {
  d: "M16 3h5v5",
  key: "1806ms"
}], ["path", {
  d: "M8 3H3v5",
  key: "15dfkv"
}], ["path", {
  d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3",
  key: "1qrqzj"
}], ["path", {
  d: "m15 9 6-6",
  key: "ko1vev"
}]];
var Spool = [["path", {
  d: "M17 13.44 4.442 17.082A2 2 0 0 0 4.982 21H19a2 2 0 0 0 .558-3.921l-1.115-.32A2 2 0 0 1 17 14.837V7.66",
  key: "13vns8"
}], ["path", {
  d: "m7 10.56 12.558-3.642A2 2 0 0 0 19.018 3H5a2 2 0 0 0-.558 3.921l1.115.32A2 2 0 0 1 7 9.163v7.178",
  key: "s8x3u0"
}]];
var Spotlight = [["path", {
  d: "M15.295 19.562 16 22",
  key: "31jsb7"
}], ["path", {
  d: "m17 16 3.758 2.098",
  key: "121ar7"
}], ["path", {
  d: "m19 12.5 3.026-.598",
  key: "19ukd3"
}], ["path", {
  d: "M7.61 6.3a3 3 0 0 0-3.92 1.3l-1.38 2.79a3 3 0 0 0 1.3 3.91l6.89 3.597a1 1 0 0 0 1.342-.447l3.106-6.211a1 1 0 0 0-.447-1.341z",
  key: "lwb9l9"
}], ["path", {
  d: "M8 9V2",
  key: "1xa0v7"
}]];
var SprayCan = [["path", {
  d: "M3 3h.01",
  key: "159qn6"
}], ["path", {
  d: "M7 5h.01",
  key: "1hq22a"
}], ["path", {
  d: "M11 7h.01",
  key: "1osv80"
}], ["path", {
  d: "M3 7h.01",
  key: "1xzrh3"
}], ["path", {
  d: "M7 9h.01",
  key: "19b3jx"
}], ["path", {
  d: "M3 11h.01",
  key: "1eifu7"
}], ["rect", {
  width: "4",
  height: "4",
  x: "15",
  y: "5",
  key: "mri9e4"
}], ["path", {
  d: "m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2",
  key: "aib6hk"
}], ["path", {
  d: "m13 14 8-2",
  key: "1d7bmk"
}], ["path", {
  d: "m13 19 8-2",
  key: "1y2vml"
}]];
var Sprout = [["path", {
  d: "M14 9.536V7a4 4 0 0 1 4-4h1.5a.5.5 0 0 1 .5.5V5a4 4 0 0 1-4 4 4 4 0 0 0-4 4c0 2 1 3 1 5a5 5 0 0 1-1 3",
  key: "139s4v"
}], ["path", {
  d: "M4 9a5 5 0 0 1 8 4 5 5 0 0 1-8-4",
  key: "1dlkgp"
}], ["path", {
  d: "M5 21h14",
  key: "11awu3"
}]];
var SquareActivity = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M17 12h-2l-2 5-2-10-2 5H7",
  key: "15hlnc"
}]];
var SquareArrowDownLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m16 8-8 8",
  key: "166keh"
}], ["path", {
  d: "M16 16H8V8",
  key: "1w2ppm"
}]];
var SquareArrowDownRight = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m8 8 8 8",
  key: "1imecy"
}], ["path", {
  d: "M16 8v8H8",
  key: "1lbpgo"
}]];
var SquareArrowDown = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}], ["path", {
  d: "m8 12 4 4 4-4",
  key: "k98ssh"
}]];
var SquareArrowLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m12 8-4 4 4 4",
  key: "15vm53"
}], ["path", {
  d: "M16 12H8",
  key: "1fr5h0"
}]];
var SquareArrowOutDownLeft = [["path", {
  d: "M13 21h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v6",
  key: "14qz4y"
}], ["path", {
  d: "m3 21 9-9",
  key: "1jfql5"
}], ["path", {
  d: "M9 21H3v-6",
  key: "wtvkvv"
}]];
var SquareArrowOutDownRight = [["path", {
  d: "M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6",
  key: "14rsvq"
}], ["path", {
  d: "m21 21-9-9",
  key: "1et2py"
}], ["path", {
  d: "M21 15v6h-6",
  key: "1jko0i"
}]];
var SquareArrowOutUpLeft = [["path", {
  d: "M13 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6",
  key: "14mv1t"
}], ["path", {
  d: "m3 3 9 9",
  key: "rks13r"
}], ["path", {
  d: "M3 9V3h6",
  key: "ira0h2"
}]];
var SquareArrowOutUpRight = [["path", {
  d: "M21 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h6",
  key: "y09zxi"
}], ["path", {
  d: "m21 3-9 9",
  key: "mpx6sq"
}], ["path", {
  d: "M15 3h6v6",
  key: "1q9fwt"
}]];
var SquareArrowRightEnter = [["path", {
  d: "m10 16 4-4-4-4",
  key: "w9835o"
}], ["path", {
  d: "M3 12h11",
  key: "pmja8f"
}], ["path", {
  d: "M3 8V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3",
  key: "1bqs5q"
}]];
var SquareArrowRightExit = [["path", {
  d: "M10 12h11",
  key: "6m4ad9"
}], ["path", {
  d: "m17 16 4-4-4-4",
  key: "iin4zf"
}], ["path", {
  d: "M21 6.344V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-1.344",
  key: "1ojbhp"
}]];
var SquareArrowRight = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "m12 16 4-4-4-4",
  key: "1i9zcv"
}]];
var SquareArrowUpLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 16V8h8",
  key: "19xb1h"
}], ["path", {
  d: "M16 16 8 8",
  key: "1qdy8n"
}]];
var SquareArrowUpRight = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 8h8v8",
  key: "b65dnt"
}], ["path", {
  d: "m8 16 8-8",
  key: "13b9ih"
}]];
var SquareArrowUp = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m16 12-4-4-4 4",
  key: "177agl"
}], ["path", {
  d: "M12 16V8",
  key: "1sbj14"
}]];
var SquareAsterisk = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}], ["path", {
  d: "m8.5 14 7-4",
  key: "12hpby"
}], ["path", {
  d: "m8.5 10 7 4",
  key: "wwy2dy"
}]];
var SquareBottomDashedScissors = [["line", {
  x1: "5",
  y1: "3",
  x2: "19",
  y2: "3",
  key: "x74652"
}], ["line", {
  x1: "3",
  y1: "5",
  x2: "3",
  y2: "19",
  key: "31ivqu"
}], ["line", {
  x1: "21",
  y1: "5",
  x2: "21",
  y2: "19",
  key: "1am4cd"
}], ["line", {
  x1: "9",
  y1: "21",
  x2: "10",
  y2: "21",
  key: "sb02er"
}], ["line", {
  x1: "14",
  y1: "21",
  x2: "15",
  y2: "21",
  key: "1bvb1m"
}], ["path", {
  d: "M 3 5 A2 2 0 0 1 5 3",
  key: "dbypyf"
}], ["path", {
  d: "M 19 3 A2 2 0 0 1 21 5",
  key: "y6haui"
}], ["path", {
  d: "M 5 21 A2 2 0 0 1 3 19",
  key: "kb75wq"
}], ["path", {
  d: "M 21 19 A2 2 0 0 1 19 21",
  key: "1p3zbf"
}], ["circle", {
  cx: "8.5",
  cy: "8.5",
  r: "1.5",
  key: "cn5opk"
}], ["line", {
  x1: "9.56066",
  y1: "9.56066",
  x2: "12",
  y2: "12",
  key: "mksg6j"
}], ["line", {
  x1: "17",
  y1: "17",
  x2: "14.82",
  y2: "14.82",
  key: "1lwi1d"
}], ["circle", {
  cx: "8.5",
  cy: "15.5",
  r: "1.5",
  key: "12hfy1"
}], ["line", {
  x1: "9.56066",
  y1: "14.43934",
  x2: "17",
  y2: "7",
  key: "4jyfgs"
}]];
var SquareCenterlineDashedHorizontal = [["path", {
  d: "M8 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h3",
  key: "1i73f7"
}], ["path", {
  d: "M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3",
  key: "saxlbk"
}], ["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "M12 14v2",
  key: "8jcxud"
}], ["path", {
  d: "M12 8v2",
  key: "1woqiv"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}]];
var SquareCenterlineDashedVertical = [["path", {
  d: "M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3",
  key: "14bfxa"
}], ["path", {
  d: "M21 16v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3",
  key: "14rx03"
}], ["path", {
  d: "M4 12H2",
  key: "rhcxmi"
}], ["path", {
  d: "M10 12H8",
  key: "s88cx1"
}], ["path", {
  d: "M16 12h-2",
  key: "10asgb"
}], ["path", {
  d: "M22 12h-2",
  key: "14jgyd"
}]];
var SquareCheckBig = [["path", {
  d: "M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344",
  key: "2acyp4"
}], ["path", {
  d: "m9 11 3 3L22 4",
  key: "1pflzl"
}]];
var SquareChartGantt = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 8h7",
  key: "kbo1nt"
}], ["path", {
  d: "M8 12h6",
  key: "ikassy"
}], ["path", {
  d: "M11 16h5",
  key: "oq65wt"
}]];
var SquareCheck = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var SquareChevronDown = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m16 10-4 4-4-4",
  key: "894hmk"
}]];
var SquareChevronRight = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m10 8 4 4-4 4",
  key: "1wy4r4"
}]];
var SquareChevronLeft = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m14 16-4-4 4-4",
  key: "ojs7w8"
}]];
var SquareChevronUp = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m8 14 4-4 4 4",
  key: "fy2ptz"
}]];
var SquareCode = [["path", {
  d: "m10 9-3 3 3 3",
  key: "1oro0q"
}], ["path", {
  d: "m14 15 3-3-3-3",
  key: "bz13h7"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var SquareDashedBottomCode = [["path", {
  d: "M10 9.5 8 12l2 2.5",
  key: "3mjy60"
}], ["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "m14 9.5 2 2.5-2 2.5",
  key: "1bir2l"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2",
  key: "as5y1o"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}]];
var SquareDashedBottom = [["path", {
  d: "M5 21a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2",
  key: "as5y1o"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}], ["path", {
  d: "M14 21h1",
  key: "v9vybs"
}]];
var SquareDashedKanban = [["path", {
  d: "M8 7v7",
  key: "1x2jlm"
}], ["path", {
  d: "M12 7v4",
  key: "xawao1"
}], ["path", {
  d: "M16 7v9",
  key: "1hp2iy"
}], ["path", {
  d: "M5 3a2 2 0 0 0-2 2",
  key: "y57alp"
}], ["path", {
  d: "M9 3h1",
  key: "1yesri"
}], ["path", {
  d: "M14 3h1",
  key: "1ec4yj"
}], ["path", {
  d: "M19 3a2 2 0 0 1 2 2",
  key: "18rm91"
}], ["path", {
  d: "M21 9v1",
  key: "mxsmne"
}], ["path", {
  d: "M21 14v1",
  key: "169vum"
}], ["path", {
  d: "M21 19a2 2 0 0 1-2 2",
  key: "1j7049"
}], ["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2",
  key: "sbafld"
}], ["path", {
  d: "M3 14v1",
  key: "vnatye"
}], ["path", {
  d: "M3 9v1",
  key: "1r0deq"
}]];
var SquareDashedTopSolid = [["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "M21 14v1",
  key: "169vum"
}], ["path", {
  d: "M21 19a2 2 0 0 1-2 2",
  key: "1j7049"
}], ["path", {
  d: "M21 9v1",
  key: "mxsmne"
}], ["path", {
  d: "M3 14v1",
  key: "vnatye"
}], ["path", {
  d: "M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2",
  key: "89voep"
}], ["path", {
  d: "M3 9v1",
  key: "1r0deq"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2",
  key: "sbafld"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}]];
var SquareDashedMousePointer = [["path", {
  d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
  key: "xwnzip"
}], ["path", {
  d: "M5 3a2 2 0 0 0-2 2",
  key: "y57alp"
}], ["path", {
  d: "M19 3a2 2 0 0 1 2 2",
  key: "18rm91"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2",
  key: "sbafld"
}], ["path", {
  d: "M9 3h1",
  key: "1yesri"
}], ["path", {
  d: "M9 21h2",
  key: "1qve2z"
}], ["path", {
  d: "M14 3h1",
  key: "1ec4yj"
}], ["path", {
  d: "M3 9v1",
  key: "1r0deq"
}], ["path", {
  d: "M21 9v2",
  key: "p14lih"
}], ["path", {
  d: "M3 14v1",
  key: "vnatye"
}]];
var SquareDashed = [["path", {
  d: "M5 3a2 2 0 0 0-2 2",
  key: "y57alp"
}], ["path", {
  d: "M19 3a2 2 0 0 1 2 2",
  key: "18rm91"
}], ["path", {
  d: "M21 19a2 2 0 0 1-2 2",
  key: "1j7049"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2",
  key: "sbafld"
}], ["path", {
  d: "M9 3h1",
  key: "1yesri"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}], ["path", {
  d: "M14 3h1",
  key: "1ec4yj"
}], ["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "M3 9v1",
  key: "1r0deq"
}], ["path", {
  d: "M21 9v1",
  key: "mxsmne"
}], ["path", {
  d: "M3 14v1",
  key: "vnatye"
}], ["path", {
  d: "M21 14v1",
  key: "169vum"
}]];
var SquareDivide = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["line", {
  x1: "8",
  x2: "16",
  y1: "12",
  y2: "12",
  key: "1jonct"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "16",
  y2: "16",
  key: "aqc6ln"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "8",
  y2: "8",
  key: "1mkcni"
}]];
var SquareDot = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}]];
var SquareEqual = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 10h10",
  key: "1101jm"
}], ["path", {
  d: "M7 14h10",
  key: "1mhdw3"
}]];
var SquareFunction = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3",
  key: "m1af9g"
}], ["path", {
  d: "M9 11.2h5.7",
  key: "3zgcl2"
}]];
var SquareKanban = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 7v7",
  key: "1x2jlm"
}], ["path", {
  d: "M12 7v4",
  key: "xawao1"
}], ["path", {
  d: "M16 7v9",
  key: "1hp2iy"
}]];
var SquareM = [["path", {
  d: "M8 16V8.5a.5.5 0 0 1 .9-.3l2.7 3.599a.5.5 0 0 0 .8 0l2.7-3.6a.5.5 0 0 1 .9.3V16",
  key: "1ywlsj"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var SquareMenu = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 8h10",
  key: "1jw688"
}], ["path", {
  d: "M7 12h10",
  key: "b7w52i"
}], ["path", {
  d: "M7 16h10",
  key: "wp8him"
}]];
var SquareLibrary = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 7v10",
  key: "d5nglc"
}], ["path", {
  d: "M11 7v10",
  key: "pptsnr"
}], ["path", {
  d: "m15 7 2 10",
  key: "1m7qm5"
}]];
var SquareMinus = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}]];
var SquareMousePointer = [["path", {
  d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
  key: "xwnzip"
}], ["path", {
  d: "M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6",
  key: "14rsvq"
}]];
var SquareParkingOff = [["path", {
  d: "M3.6 3.6A2 2 0 0 1 5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-.59 1.41",
  key: "9l1ft6"
}], ["path", {
  d: "M3 8.7V19a2 2 0 0 0 2 2h10.3",
  key: "17knke"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M13 13a3 3 0 1 0 0-6H9v2",
  key: "uoagbd"
}], ["path", {
  d: "M9 17v-2.3",
  key: "1jxgo2"
}]];
var SquareParking = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M9 17V7h4a3 3 0 0 1 0 6H9",
  key: "1dfk2c"
}]];
var SquarePause = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["line", {
  x1: "10",
  x2: "10",
  y1: "15",
  y2: "9",
  key: "c1nkhi"
}], ["line", {
  x1: "14",
  x2: "14",
  y1: "15",
  y2: "9",
  key: "h65svq"
}]];
var SquarePercent = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["path", {
  d: "M15 15h.01",
  key: "lqbp3k"
}]];
var SquarePen = [["path", {
  d: "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",
  key: "1m0v6g"
}], ["path", {
  d: "M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",
  key: "ohrbg2"
}]];
var SquarePi = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M7 7h10",
  key: "udp07y"
}], ["path", {
  d: "M10 7v10",
  key: "i1d9ee"
}], ["path", {
  d: "M16 17a2 2 0 0 1-2-2V7",
  key: "ftwdc7"
}]];
var SquarePilcrow = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M12 12H9.5a2.5 2.5 0 0 1 0-5H17",
  key: "1l9586"
}], ["path", {
  d: "M12 7v10",
  key: "jspqdw"
}], ["path", {
  d: "M16 7v10",
  key: "lavkr4"
}]];
var SquarePlay = [["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}], ["path", {
  d: "M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z",
  key: "kmsa83"
}]];
var SquarePlus = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["path", {
  d: "M12 8v8",
  key: "napkw2"
}]];
var SquarePower = [["path", {
  d: "M12 7v4",
  key: "xawao1"
}], ["path", {
  d: "M7.998 9.003a5 5 0 1 0 8-.005",
  key: "1pek45"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var SquareRadical = [["path", {
  d: "M7 12h2l2 5 2-10h4",
  key: "1fxv6h"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var SquareRoundCorner = [["path", {
  d: "M21 11a8 8 0 0 0-8-8",
  key: "1lxwo5"
}], ["path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
  key: "1dv2y5"
}]];
var SquareScissors = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["circle", {
  cx: "8.5",
  cy: "8.5",
  r: "1.5",
  key: "cn5opk"
}], ["line", {
  x1: "9.56066",
  y1: "9.56066",
  x2: "12",
  y2: "12",
  key: "mksg6j"
}], ["line", {
  x1: "17",
  y1: "17",
  x2: "14.82",
  y2: "14.82",
  key: "1lwi1d"
}], ["circle", {
  cx: "8.5",
  cy: "15.5",
  r: "1.5",
  key: "12hfy1"
}], ["line", {
  x1: "9.56066",
  y1: "14.43934",
  x2: "17",
  y2: "7",
  key: "4jyfgs"
}]];
var SquareSigma = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M16 8.9V7H8l4 5-4 5h8v-1.9",
  key: "9nih0i"
}]];
var SquareSlash = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["line", {
  x1: "9",
  x2: "15",
  y1: "15",
  y2: "9",
  key: "1dfufj"
}]];
var SquareSplitHorizontal = [["path", {
  d: "M8 19H5c-1 0-2-1-2-2V7c0-1 1-2 2-2h3",
  key: "lubmu8"
}], ["path", {
  d: "M16 5h3c1 0 2 1 2 2v10c0 1-1 2-2 2h-3",
  key: "1ag34g"
}], ["line", {
  x1: "12",
  x2: "12",
  y1: "4",
  y2: "20",
  key: "1tx1rr"
}]];
var SquareSplitVertical = [["path", {
  d: "M5 8V5c0-1 1-2 2-2h10c1 0 2 1 2 2v3",
  key: "1pi83i"
}], ["path", {
  d: "M19 16v3c0 1-1 2-2 2H7c-1 0-2-1-2-2v-3",
  key: "ido5k7"
}], ["line", {
  x1: "4",
  x2: "20",
  y1: "12",
  y2: "12",
  key: "1e0a9i"
}]];
var SquareSquare = [["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}], ["rect", {
  x: "8",
  y: "8",
  width: "8",
  height: "8",
  rx: "1",
  key: "z9xiuo"
}]];
var SquareStack = [["path", {
  d: "M4 10c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2",
  key: "4i38lg"
}], ["path", {
  d: "M10 16c-1.1 0-2-.9-2-2v-4c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2",
  key: "mlte4a"
}], ["rect", {
  width: "8",
  height: "8",
  x: "14",
  y: "14",
  rx: "2",
  key: "1fa9i4"
}]];
var SquareStar = [["path", {
  d: "M11.035 7.69a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.866l-1.156-1.153a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
  key: "13edca"
}], ["rect", {
  x: "3",
  y: "3",
  width: "18",
  height: "18",
  rx: "2",
  key: "h1oib"
}]];
var SquareStop = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["rect", {
  x: "9",
  y: "9",
  width: "6",
  height: "6",
  rx: "1",
  key: "1ssd4o"
}]];
var SquareTerminal = [["path", {
  d: "m7 11 2-2-2-2",
  key: "1lz0vl"
}], ["path", {
  d: "M11 13h4",
  key: "1p7l4v"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}]];
var SquareUserRound = [["path", {
  d: "M18 21a6 6 0 0 0-12 0",
  key: "kaz2du"
}], ["circle", {
  cx: "12",
  cy: "11",
  r: "4",
  key: "1gt34v"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}]];
var SquareUser = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "M7 21v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2",
  key: "1m6ac2"
}]];
var SquareX = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "m9 9 6 6",
  key: "z0biqf"
}]];
var Square = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}]];
var SquaresExclude = [["path", {
  d: "M16 12v2a2 2 0 0 1-2 2H9a1 1 0 0 0-1 1v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2h0",
  key: "1mcohs"
}], ["path", {
  d: "M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3a1 1 0 0 1-1 1h-5a2 2 0 0 0-2 2v2",
  key: "1r1efp"
}]];
var SquaresIntersect = [["path", {
  d: "M10 22a2 2 0 0 1-2-2",
  key: "i7yj1i"
}], ["path", {
  d: "M14 2a2 2 0 0 1 2 2",
  key: "170a0m"
}], ["path", {
  d: "M16 22h-2",
  key: "18d249"
}], ["path", {
  d: "M2 10V8",
  key: "7yj4fe"
}], ["path", {
  d: "M2 4a2 2 0 0 1 2-2",
  key: "ddgnws"
}], ["path", {
  d: "M20 8a2 2 0 0 1 2 2",
  key: "1770vt"
}], ["path", {
  d: "M22 14v2",
  key: "iot8ja"
}], ["path", {
  d: "M22 20a2 2 0 0 1-2 2",
  key: "qj8q6g"
}], ["path", {
  d: "M4 16a2 2 0 0 1-2-2",
  key: "1dnafg"
}], ["path", {
  d: "M8 10a2 2 0 0 1 2-2h5a1 1 0 0 1 1 1v5a2 2 0 0 1-2 2H9a1 1 0 0 1-1-1z",
  key: "ci6f0b"
}], ["path", {
  d: "M8 2h2",
  key: "1gmkwm"
}]];
var SquaresSubtract = [["path", {
  d: "M10 22a2 2 0 0 1-2-2",
  key: "i7yj1i"
}], ["path", {
  d: "M16 22h-2",
  key: "18d249"
}], ["path", {
  d: "M16 4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-5a2 2 0 0 1 2-2h5a1 1 0 0 0 1-1z",
  key: "1njgbb"
}], ["path", {
  d: "M20 8a2 2 0 0 1 2 2",
  key: "1770vt"
}], ["path", {
  d: "M22 14v2",
  key: "iot8ja"
}], ["path", {
  d: "M22 20a2 2 0 0 1-2 2",
  key: "qj8q6g"
}]];
var SquaresUnite = [["path", {
  d: "M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3a1 1 0 0 0 1 1h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-3a1 1 0 0 0-1-1z",
  key: "17jnth"
}]];
var SquircleDashed = [["path", {
  d: "M13.77 3.043a34 34 0 0 0-3.54 0",
  key: "1oaobr"
}], ["path", {
  d: "M13.771 20.956a33 33 0 0 1-3.541.001",
  key: "95iq0j"
}], ["path", {
  d: "M20.18 17.74c-.51 1.15-1.29 1.93-2.439 2.44",
  key: "1u6qty"
}], ["path", {
  d: "M20.18 6.259c-.51-1.148-1.291-1.929-2.44-2.438",
  key: "1ew6g6"
}], ["path", {
  d: "M20.957 10.23a33 33 0 0 1 0 3.54",
  key: "1l9npr"
}], ["path", {
  d: "M3.043 10.23a34 34 0 0 0 .001 3.541",
  key: "1it6jm"
}], ["path", {
  d: "M6.26 20.179c-1.15-.508-1.93-1.29-2.44-2.438",
  key: "14uchd"
}], ["path", {
  d: "M6.26 3.82c-1.149.51-1.93 1.291-2.44 2.44",
  key: "8k4agb"
}]];
var Squircle = [["path", {
  d: "M12 3c7.2 0 9 1.8 9 9s-1.8 9-9 9-9-1.8-9-9 1.8-9 9-9",
  key: "garfkc"
}]];
var Squirrel = [["path", {
  d: "M15.236 22a3 3 0 0 0-2.2-5",
  key: "21bitc"
}], ["path", {
  d: "M16 20a3 3 0 0 1 3-3h1a2 2 0 0 0 2-2v-2a4 4 0 0 0-4-4V4",
  key: "oh0fg0"
}], ["path", {
  d: "M18 13h.01",
  key: "9veqaj"
}], ["path", {
  d: "M18 6a4 4 0 0 0-4 4 7 7 0 0 0-7 7c0-5 4-5 4-10.5a4.5 4.5 0 1 0-9 0 2.5 2.5 0 0 0 5 0C7 10 3 11 3 17c0 2.8 2.2 5 5 5h10",
  key: "980v8a"
}]];
var Stamp = [["path", {
  d: "M14 13V8.5C14 7 15 7 15 5a3 3 0 0 0-6 0c0 2 1 2 1 3.5V13",
  key: "i9gjdv"
}], ["path", {
  d: "M20 15.5a2.5 2.5 0 0 0-2.5-2.5h-11A2.5 2.5 0 0 0 4 15.5V17a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1z",
  key: "1vzg3v"
}], ["path", {
  d: "M5 22h14",
  key: "ehvnwv"
}]];
var StarHalf = [["path", {
  d: "M12 18.338a2.1 2.1 0 0 0-.987.244L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.12 2.12 0 0 0 1.597-1.16l2.309-4.679A.53.53 0 0 1 12 2",
  key: "2ksp49"
}]];
var StarOff = [["path", {
  d: "m10.344 4.688 1.181-2.393a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.237 3.152",
  key: "19ctli"
}], ["path", {
  d: "m17.945 17.945.43 2.505a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a8 8 0 0 0 .4-.099",
  key: "ptqqvy"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Star = [["path", {
  d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
  key: "r04s7s"
}]];
var StepBack = [["path", {
  d: "M13.971 4.285A2 2 0 0 1 17 6v12a2 2 0 0 1-3.029 1.715l-9.997-5.998a2 2 0 0 1-.003-3.432z",
  key: "19qhus"
}], ["path", {
  d: "M21 20V4",
  key: "cb8qj8"
}]];
var StepForward = [["path", {
  d: "M10.029 4.285A2 2 0 0 0 7 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z",
  key: "1ystz2"
}], ["path", {
  d: "M3 4v16",
  key: "1ph11n"
}]];
var Stethoscope = [["path", {
  d: "M11 2v2",
  key: "1539x4"
}], ["path", {
  d: "M5 2v2",
  key: "1yf1q8"
}], ["path", {
  d: "M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1",
  key: "rb5t3r"
}], ["path", {
  d: "M8 15a6 6 0 0 0 12 0v-3",
  key: "x18d4x"
}], ["circle", {
  cx: "20",
  cy: "10",
  r: "2",
  key: "ts1r5v"
}]];
var Sticker = [["path", {
  d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
  key: "1dfntj"
}], ["path", {
  d: "M15 3v5a1 1 0 0 0 1 1h5",
  key: "6s6qgf"
}], ["path", {
  d: "M8 13h.01",
  key: "1sbv64"
}], ["path", {
  d: "M16 13h.01",
  key: "wip0gl"
}], ["path", {
  d: "M10 16s.8 1 2 1c1.3 0 2-1 2-1",
  key: "1vvgv3"
}]];
var StickyNote = [["path", {
  d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
  key: "1dfntj"
}], ["path", {
  d: "M15 3v5a1 1 0 0 0 1 1h5",
  key: "6s6qgf"
}]];
var Stone = [["path", {
  d: "M11.264 2.205A4 4 0 0 0 6.42 4.211l-4 8a4 4 0 0 0 1.359 5.117l6 4a4 4 0 0 0 4.438 0l6-4a4 4 0 0 0 1.576-4.592l-2-6a4 4 0 0 0-2.53-2.53z",
  key: "1si4ox"
}], ["path", {
  d: "M11.99 22 14 12l7.822 3.184",
  key: "1u8to0"
}], ["path", {
  d: "M14 12 8.47 2.302",
  key: "guo3d5"
}]];
var Store = [["path", {
  d: "M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5",
  key: "slp6dd"
}], ["path", {
  d: "M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244",
  key: "o0xfot"
}], ["path", {
  d: "M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05",
  key: "wn3emo"
}]];
var StretchHorizontal = [["rect", {
  width: "20",
  height: "6",
  x: "2",
  y: "4",
  rx: "2",
  key: "qdearl"
}], ["rect", {
  width: "20",
  height: "6",
  x: "2",
  y: "14",
  rx: "2",
  key: "1xrn6j"
}]];
var StretchVertical = [["rect", {
  width: "6",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  key: "19qu7m"
}], ["rect", {
  width: "6",
  height: "20",
  x: "14",
  y: "2",
  rx: "2",
  key: "24v0nk"
}]];
var Strikethrough = [["path", {
  d: "M16 4H9a3 3 0 0 0-2.83 4",
  key: "43sutm"
}], ["path", {
  d: "M14 12a4 4 0 0 1 0 8H6",
  key: "nlfj13"
}], ["line", {
  x1: "4",
  x2: "20",
  y1: "12",
  y2: "12",
  key: "1e0a9i"
}]];
var Subscript = [["path", {
  d: "m4 5 8 8",
  key: "1eunvl"
}], ["path", {
  d: "m12 5-8 8",
  key: "1ah0jp"
}], ["path", {
  d: "M20 19h-4c0-1.5.44-2 1.5-2.5S20 15.33 20 14c0-.47-.17-.93-.48-1.29a2.11 2.11 0 0 0-2.62-.44c-.42.24-.74.62-.9 1.07",
  key: "e8ta8j"
}]];
var SunDim = [["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["path", {
  d: "M12 4h.01",
  key: "1ujb9j"
}], ["path", {
  d: "M20 12h.01",
  key: "1ykeid"
}], ["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M4 12h.01",
  key: "158zrr"
}], ["path", {
  d: "M17.657 6.343h.01",
  key: "31pqzk"
}], ["path", {
  d: "M17.657 17.657h.01",
  key: "jehnf4"
}], ["path", {
  d: "M6.343 17.657h.01",
  key: "gdk6ow"
}], ["path", {
  d: "M6.343 6.343h.01",
  key: "1uurf0"
}]];
var SunMedium = [["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["path", {
  d: "M12 3v1",
  key: "1asbbs"
}], ["path", {
  d: "M12 20v1",
  key: "1wcdkc"
}], ["path", {
  d: "M3 12h1",
  key: "lp3yf2"
}], ["path", {
  d: "M20 12h1",
  key: "1vloll"
}], ["path", {
  d: "m18.364 5.636-.707.707",
  key: "1hakh0"
}], ["path", {
  d: "m6.343 17.657-.707.707",
  key: "18m9nf"
}], ["path", {
  d: "m5.636 5.636.707.707",
  key: "1xv1c5"
}], ["path", {
  d: "m17.657 17.657.707.707",
  key: "vl76zb"
}]];
var SunMoon = [["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M14.837 16.385a6 6 0 1 1-7.223-7.222c.624-.147.97.66.715 1.248a4 4 0 0 0 5.26 5.259c.589-.255 1.396.09 1.248.715",
  key: "xlf6rm"
}], ["path", {
  d: "M16 12a4 4 0 0 0-4-4",
  key: "6vsxu"
}], ["path", {
  d: "m19 5-1.256 1.256",
  key: "1yg6a6"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}]];
var SunSnow = [["path", {
  d: "M10 21v-1",
  key: "1u8rkd"
}], ["path", {
  d: "M10 4V3",
  key: "pkzwkn"
}], ["path", {
  d: "M10 9a3 3 0 0 0 0 6",
  key: "gv75dk"
}], ["path", {
  d: "m14 20 1.25-2.5L18 18",
  key: "1chtki"
}], ["path", {
  d: "m14 4 1.25 2.5L18 6",
  key: "1b4wsy"
}], ["path", {
  d: "m17 21-3-6 1.5-3H22",
  key: "o5qa3v"
}], ["path", {
  d: "m17 3-3 6 1.5 3",
  key: "11697g"
}], ["path", {
  d: "M2 12h1",
  key: "1uaihz"
}], ["path", {
  d: "m20 10-1.5 2 1.5 2",
  key: "1swlpi"
}], ["path", {
  d: "m3.64 18.36.7-.7",
  key: "105rm9"
}], ["path", {
  d: "m4.34 6.34-.7-.7",
  key: "d3unjp"
}]];
var Sun = [["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "m4.93 4.93 1.41 1.41",
  key: "149t6j"
}], ["path", {
  d: "m17.66 17.66 1.41 1.41",
  key: "ptbguv"
}], ["path", {
  d: "M2 12h2",
  key: "1t8f8n"
}], ["path", {
  d: "M20 12h2",
  key: "1q8mjw"
}], ["path", {
  d: "m6.34 17.66-1.41 1.41",
  key: "1m8zz5"
}], ["path", {
  d: "m19.07 4.93-1.41 1.41",
  key: "1shlcs"
}]];
var Sunset = [["path", {
  d: "M12 10V2",
  key: "16sf7g"
}], ["path", {
  d: "m4.93 10.93 1.41 1.41",
  key: "2a7f42"
}], ["path", {
  d: "M2 18h2",
  key: "j10viu"
}], ["path", {
  d: "M20 18h2",
  key: "wocana"
}], ["path", {
  d: "m19.07 10.93-1.41 1.41",
  key: "15zs5n"
}], ["path", {
  d: "M22 22H2",
  key: "19qnx5"
}], ["path", {
  d: "m16 6-4 4-4-4",
  key: "6wukr"
}], ["path", {
  d: "M16 18a4 4 0 0 0-8 0",
  key: "1lzouq"
}]];
var Sunrise = [["path", {
  d: "M12 2v8",
  key: "1q4o3n"
}], ["path", {
  d: "m4.93 10.93 1.41 1.41",
  key: "2a7f42"
}], ["path", {
  d: "M2 18h2",
  key: "j10viu"
}], ["path", {
  d: "M20 18h2",
  key: "wocana"
}], ["path", {
  d: "m19.07 10.93-1.41 1.41",
  key: "15zs5n"
}], ["path", {
  d: "M22 22H2",
  key: "19qnx5"
}], ["path", {
  d: "m8 6 4-4 4 4",
  key: "ybng9g"
}], ["path", {
  d: "M16 18a4 4 0 0 0-8 0",
  key: "1lzouq"
}]];
var Superscript = [["path", {
  d: "m4 19 8-8",
  key: "hr47gm"
}], ["path", {
  d: "m12 19-8-8",
  key: "1dhhmo"
}], ["path", {
  d: "M20 12h-4c0-1.5.442-2 1.5-2.5S20 8.334 20 7.002c0-.472-.17-.93-.484-1.29a2.105 2.105 0 0 0-2.617-.436c-.42.239-.738.614-.899 1.06",
  key: "1dfcux"
}]];
var SwatchBook = [["path", {
  d: "M11 17a4 4 0 0 1-8 0V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2Z",
  key: "1ldrpk"
}], ["path", {
  d: "M16.7 13H19a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H7",
  key: "11i5po"
}], ["path", {
  d: "M 7 17h.01",
  key: "1euzgo"
}], ["path", {
  d: "m11 8 2.3-2.3a2.4 2.4 0 0 1 3.404.004L18.6 7.6a2.4 2.4 0 0 1 .026 3.434L9.9 19.8",
  key: "o2gii7"
}]];
var SwissFranc = [["path", {
  d: "M10 21V3h8",
  key: "br2l0g"
}], ["path", {
  d: "M6 16h9",
  key: "2py0wn"
}], ["path", {
  d: "M10 9.5h7",
  key: "13dmhz"
}]];
var SwitchCamera = [["path", {
  d: "M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5",
  key: "mtk2lu"
}], ["path", {
  d: "M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5",
  key: "120jsl"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "3",
  key: "1v7zrd"
}], ["path", {
  d: "m18 22-3-3 3-3",
  key: "kgdoj7"
}], ["path", {
  d: "m6 2 3 3-3 3",
  key: "1fnbkv"
}]];
var Sword = [["path", {
  d: "m11 19-6-6",
  key: "s7kpr"
}], ["path", {
  d: "m5 21-2-2",
  key: "1kw20b"
}], ["path", {
  d: "m8 16-4 4",
  key: "1oqv8h"
}], ["path", {
  d: "M9.5 17.5 21 6V3h-3L6.5 14.5",
  key: "pkxemp"
}]];
var Swords = [["polyline", {
  points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5",
  key: "1hfsw2"
}], ["line", {
  x1: "13",
  x2: "19",
  y1: "19",
  y2: "13",
  key: "1vrmhu"
}], ["line", {
  x1: "16",
  x2: "20",
  y1: "16",
  y2: "20",
  key: "1bron3"
}], ["line", {
  x1: "19",
  x2: "21",
  y1: "21",
  y2: "19",
  key: "13pww6"
}], ["polyline", {
  points: "14.5 6.5 18 3 21 3 21 6 17.5 9.5",
  key: "hbey2j"
}], ["line", {
  x1: "5",
  x2: "9",
  y1: "14",
  y2: "18",
  key: "1hf58s"
}], ["line", {
  x1: "7",
  x2: "4",
  y1: "17",
  y2: "20",
  key: "pidxm4"
}], ["line", {
  x1: "3",
  x2: "5",
  y1: "19",
  y2: "21",
  key: "1pehsh"
}]];
var Syringe = [["path", {
  d: "m18 2 4 4",
  key: "22kx64"
}], ["path", {
  d: "m17 7 3-3",
  key: "1w1zoj"
}], ["path", {
  d: "M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5",
  key: "1exhtz"
}], ["path", {
  d: "m9 11 4 4",
  key: "rovt3i"
}], ["path", {
  d: "m5 19-3 3",
  key: "59f2uf"
}], ["path", {
  d: "m14 4 6 6",
  key: "yqp9t2"
}]];
var Table2 = [["path", {
  d: "M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18",
  key: "gugj83"
}]];
var TableCellsMerge = [["path", {
  d: "M12 21v-6",
  key: "lihzve"
}], ["path", {
  d: "M12 9V3",
  key: "da5inc"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}]];
var TableCellsSplit = [["path", {
  d: "M12 15V9",
  key: "8c7uyn"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}]];
var TableColumnsSplit = [["path", {
  d: "M14 14v2",
  key: "w2a1xv"
}], ["path", {
  d: "M14 20v2",
  key: "1lq872"
}], ["path", {
  d: "M14 2v2",
  key: "6buw04"
}], ["path", {
  d: "M14 8v2",
  key: "i67w9a"
}], ["path", {
  d: "M2 15h8",
  key: "82wtch"
}], ["path", {
  d: "M2 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H2",
  key: "up0l64"
}], ["path", {
  d: "M2 9h8",
  key: "yelfik"
}], ["path", {
  d: "M22 15h-4",
  key: "1es58f"
}], ["path", {
  d: "M22 3h-2a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2",
  key: "pdjoqf"
}], ["path", {
  d: "M22 9h-4",
  key: "1luja7"
}], ["path", {
  d: "M5 3v18",
  key: "14hmio"
}]];
var TableOfContents = [["path", {
  d: "M16 5H3",
  key: "m91uny"
}], ["path", {
  d: "M16 12H3",
  key: "1a2rj7"
}], ["path", {
  d: "M16 19H3",
  key: "zzsher"
}], ["path", {
  d: "M21 5h.01",
  key: "wa75ra"
}], ["path", {
  d: "M21 12h.01",
  key: "msek7k"
}], ["path", {
  d: "M21 19h.01",
  key: "qvbq2j"
}]];
var TableProperties = [["path", {
  d: "M15 3v18",
  key: "14nvp0"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M21 9H3",
  key: "1338ky"
}], ["path", {
  d: "M21 15H3",
  key: "9uk58r"
}]];
var TableRowsSplit = [["path", {
  d: "M14 10h2",
  key: "1lstlu"
}], ["path", {
  d: "M15 22v-8",
  key: "1fwwgm"
}], ["path", {
  d: "M15 2v4",
  key: "1044rn"
}], ["path", {
  d: "M2 10h2",
  key: "1r8dkt"
}], ["path", {
  d: "M20 10h2",
  key: "1ug425"
}], ["path", {
  d: "M3 19h18",
  key: "awlh7x"
}], ["path", {
  d: "M3 22v-6a2 2 135 0 1 2-2h14a2 2 45 0 1 2 2v6",
  key: "ibqhof"
}], ["path", {
  d: "M3 2v2a2 2 45 0 0 2 2h14a2 2 135 0 0 2-2V2",
  key: "1uenja"
}], ["path", {
  d: "M8 10h2",
  key: "66od0"
}], ["path", {
  d: "M9 22v-8",
  key: "fmnu31"
}], ["path", {
  d: "M9 2v4",
  key: "j1yeou"
}]];
var Table = [["path", {
  d: "M12 3v18",
  key: "108xh3"
}], ["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9h18",
  key: "1pudct"
}], ["path", {
  d: "M3 15h18",
  key: "5xshup"
}]];
var Tablet = [["rect", {
  width: "16",
  height: "20",
  x: "4",
  y: "2",
  rx: "2",
  ry: "2",
  key: "76otgf"
}], ["line", {
  x1: "12",
  x2: "12.01",
  y1: "18",
  y2: "18",
  key: "1dp563"
}]];
var TabletSmartphone = [["rect", {
  width: "10",
  height: "14",
  x: "3",
  y: "8",
  rx: "2",
  key: "1vrsiq"
}], ["path", {
  d: "M5 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2h-2.4",
  key: "1j4zmg"
}], ["path", {
  d: "M8 18h.01",
  key: "lrp35t"
}]];
var Tablets = [["circle", {
  cx: "7",
  cy: "7",
  r: "5",
  key: "x29byf"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "5",
  key: "1op1d2"
}], ["path", {
  d: "M12 17h10",
  key: "ls21zv"
}], ["path", {
  d: "m3.46 10.54 7.08-7.08",
  key: "1rehiu"
}]];
var Tag = [["path", {
  d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
  key: "vktsd0"
}], ["circle", {
  cx: "7.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "kqv944"
}]];
var Tags = [["path", {
  d: "M13.172 2a2 2 0 0 1 1.414.586l6.71 6.71a2.4 2.4 0 0 1 0 3.408l-4.592 4.592a2.4 2.4 0 0 1-3.408 0l-6.71-6.71A2 2 0 0 1 6 9.172V3a1 1 0 0 1 1-1z",
  key: "16rjxf"
}], ["path", {
  d: "M2 7v6.172a2 2 0 0 0 .586 1.414l6.71 6.71a2.4 2.4 0 0 0 3.191.193",
  key: "178nd4"
}], ["circle", {
  cx: "10.5",
  cy: "6.5",
  r: ".5",
  fill: "currentColor",
  key: "12ikhr"
}]];
var Tally1 = [["path", {
  d: "M4 4v16",
  key: "6qkkli"
}]];
var Tally2 = [["path", {
  d: "M4 4v16",
  key: "6qkkli"
}], ["path", {
  d: "M9 4v16",
  key: "81ygyz"
}]];
var Tally3 = [["path", {
  d: "M4 4v16",
  key: "6qkkli"
}], ["path", {
  d: "M9 4v16",
  key: "81ygyz"
}], ["path", {
  d: "M14 4v16",
  key: "12vmem"
}]];
var Tally4 = [["path", {
  d: "M4 4v16",
  key: "6qkkli"
}], ["path", {
  d: "M9 4v16",
  key: "81ygyz"
}], ["path", {
  d: "M14 4v16",
  key: "12vmem"
}], ["path", {
  d: "M19 4v16",
  key: "8ij5ei"
}]];
var Tangent = [["circle", {
  cx: "17",
  cy: "4",
  r: "2",
  key: "y5j2s2"
}], ["path", {
  d: "M15.59 5.41 5.41 15.59",
  key: "l0vprr"
}], ["circle", {
  cx: "4",
  cy: "17",
  r: "2",
  key: "9p4efm"
}], ["path", {
  d: "M12 22s-4-9-1.5-11.5S22 12 22 12",
  key: "1twk4o"
}]];
var Tally5 = [["path", {
  d: "M4 4v16",
  key: "6qkkli"
}], ["path", {
  d: "M9 4v16",
  key: "81ygyz"
}], ["path", {
  d: "M14 4v16",
  key: "12vmem"
}], ["path", {
  d: "M19 4v16",
  key: "8ij5ei"
}], ["path", {
  d: "M22 6 2 18",
  key: "h9moai"
}]];
var Telescope = [["path", {
  d: "m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-.702l-.537-2.15a1.07 1.07 0 0 1 .691-1.265l13.504-4.44",
  key: "k4qptu"
}], ["path", {
  d: "m13.56 11.747 4.332-.924",
  key: "19l80z"
}], ["path", {
  d: "m16 21-3.105-6.21",
  key: "7oh9d"
}], ["path", {
  d: "M16.485 5.94a2 2 0 0 1 1.455-2.425l1.09-.272a1 1 0 0 1 1.212.727l1.515 6.06a1 1 0 0 1-.727 1.213l-1.09.272a2 2 0 0 1-2.425-1.455z",
  key: "m7xp4m"
}], ["path", {
  d: "m6.158 8.633 1.114 4.456",
  key: "74o979"
}], ["path", {
  d: "m8 21 3.105-6.21",
  key: "1fvxut"
}], ["circle", {
  cx: "12",
  cy: "13",
  r: "2",
  key: "1c1ljs"
}]];
var Target = [["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "6",
  key: "1vlfrh"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var TentTree = [["circle", {
  cx: "4",
  cy: "4",
  r: "2",
  key: "bt5ra8"
}], ["path", {
  d: "m14 5 3-3 3 3",
  key: "1sorif"
}], ["path", {
  d: "m14 10 3-3 3 3",
  key: "1jyi9h"
}], ["path", {
  d: "M17 14V2",
  key: "8ymqnk"
}], ["path", {
  d: "M17 14H7l-5 8h20Z",
  key: "13ar7p"
}], ["path", {
  d: "M8 14v8",
  key: "1ghmqk"
}], ["path", {
  d: "m9 14 5 8",
  key: "13pgi6"
}]];
var Terminal = [["path", {
  d: "M12 19h8",
  key: "baeox8"
}], ["path", {
  d: "m4 17 6-6-6-6",
  key: "1yngyt"
}]];
var Tent = [["path", {
  d: "M3.5 21 14 3",
  key: "1szst5"
}], ["path", {
  d: "M20.5 21 10 3",
  key: "1310c3"
}], ["path", {
  d: "M15.5 21 12 15l-3.5 6",
  key: "1ddtfw"
}], ["path", {
  d: "M2 21h20",
  key: "1nyx9w"
}]];
var TestTubeDiagonal = [["path", {
  d: "M21 7 6.82 21.18a2.83 2.83 0 0 1-3.99-.01a2.83 2.83 0 0 1 0-4L17 3",
  key: "1ub6xw"
}], ["path", {
  d: "m16 2 6 6",
  key: "1gw87d"
}], ["path", {
  d: "M12 16H4",
  key: "1cjfip"
}]];
var TestTubes = [["path", {
  d: "M9 2v17.5A2.5 2.5 0 0 1 6.5 22A2.5 2.5 0 0 1 4 19.5V2",
  key: "1hjrqt"
}], ["path", {
  d: "M20 2v17.5a2.5 2.5 0 0 1-2.5 2.5a2.5 2.5 0 0 1-2.5-2.5V2",
  key: "16lc8n"
}], ["path", {
  d: "M3 2h7",
  key: "7s29d5"
}], ["path", {
  d: "M14 2h7",
  key: "7sicin"
}], ["path", {
  d: "M9 16H4",
  key: "1bfye3"
}], ["path", {
  d: "M20 16h-5",
  key: "ddnjpe"
}]];
var TestTube = [["path", {
  d: "M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5c-1.4 0-2.5-1.1-2.5-2.5V2",
  key: "125lnx"
}], ["path", {
  d: "M8.5 2h7",
  key: "csnxdl"
}], ["path", {
  d: "M14.5 16h-5",
  key: "1ox875"
}]];
var TextAlignCenter = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M17 12H7",
  key: "16if0g"
}], ["path", {
  d: "M19 19H5",
  key: "vjpgq2"
}]];
var TextAlignEnd = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M21 12H9",
  key: "dn1m92"
}], ["path", {
  d: "M21 19H7",
  key: "4cu937"
}]];
var TextAlignJustify = [["path", {
  d: "M3 5h18",
  key: "1u36vt"
}], ["path", {
  d: "M3 12h18",
  key: "1i2n21"
}], ["path", {
  d: "M3 19h18",
  key: "awlh7x"
}]];
var TextAlignStart = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M15 12H3",
  key: "6jk70r"
}], ["path", {
  d: "M17 19H3",
  key: "z6ezky"
}]];
var TextCursorInput = [["path", {
  d: "M12 20h-1a2 2 0 0 1-2-2 2 2 0 0 1-2 2H6",
  key: "1528k5"
}], ["path", {
  d: "M13 8h7a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-7",
  key: "13ksps"
}], ["path", {
  d: "M5 16H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h1",
  key: "1n9rhb"
}], ["path", {
  d: "M6 4h1a2 2 0 0 1 2 2 2 2 0 0 1 2-2h1",
  key: "1mj8rg"
}], ["path", {
  d: "M9 6v12",
  key: "velyjx"
}]];
var TextCursor = [["path", {
  d: "M17 22h-1a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h1",
  key: "uvaxm9"
}], ["path", {
  d: "M7 22h1a4 4 0 0 0 4-4v-1",
  key: "11xy8d"
}], ["path", {
  d: "M7 2h1a4 4 0 0 1 4 4v1",
  key: "1uw06m"
}]];
var TextInitial = [["path", {
  d: "M15 5h6",
  key: "1pr8yx"
}], ["path", {
  d: "M15 12h6",
  key: "upa0zy"
}], ["path", {
  d: "M3 19h18",
  key: "awlh7x"
}], ["path", {
  d: "m3 12 3.553-7.724a.5.5 0 0 1 .894 0L11 12",
  key: "6lvno8"
}], ["path", {
  d: "M3.92 10h6.16",
  key: "1tl8ex"
}]];
var TextQuote = [["path", {
  d: "M17 5H3",
  key: "1cn7zz"
}], ["path", {
  d: "M21 12H8",
  key: "scolzb"
}], ["path", {
  d: "M21 19H8",
  key: "13qgcb"
}], ["path", {
  d: "M3 12v7",
  key: "1ri8j3"
}]];
var TextSearch = [["path", {
  d: "M21 5H3",
  key: "1fi0y6"
}], ["path", {
  d: "M10 12H3",
  key: "1ulcyk"
}], ["path", {
  d: "M10 19H3",
  key: "108z41"
}], ["circle", {
  cx: "17",
  cy: "15",
  r: "3",
  key: "1upz2a"
}], ["path", {
  d: "m21 19-1.9-1.9",
  key: "dwi7p8"
}]];
var TextSelect = [["path", {
  d: "M14 21h1",
  key: "v9vybs"
}], ["path", {
  d: "M14 3h1",
  key: "1ec4yj"
}], ["path", {
  d: "M19 3a2 2 0 0 1 2 2",
  key: "18rm91"
}], ["path", {
  d: "M21 14v1",
  key: "169vum"
}], ["path", {
  d: "M21 19a2 2 0 0 1-2 2",
  key: "1j7049"
}], ["path", {
  d: "M21 9v1",
  key: "mxsmne"
}], ["path", {
  d: "M3 14v1",
  key: "vnatye"
}], ["path", {
  d: "M3 9v1",
  key: "1r0deq"
}], ["path", {
  d: "M5 21a2 2 0 0 1-2-2",
  key: "sbafld"
}], ["path", {
  d: "M5 3a2 2 0 0 0-2 2",
  key: "y57alp"
}], ["path", {
  d: "M7 12h10",
  key: "b7w52i"
}], ["path", {
  d: "M7 16h6",
  key: "1vyc9m"
}], ["path", {
  d: "M7 8h8",
  key: "1jbsf9"
}], ["path", {
  d: "M9 21h1",
  key: "15o7lz"
}], ["path", {
  d: "M9 3h1",
  key: "1yesri"
}]];
var TextWrap = [["path", {
  d: "m16 16-3 3 3 3",
  key: "117b85"
}], ["path", {
  d: "M3 12h14.5a1 1 0 0 1 0 7H13",
  key: "18xa6z"
}], ["path", {
  d: "M3 19h6",
  key: "1ygdsz"
}], ["path", {
  d: "M3 5h18",
  key: "1u36vt"
}]];
var Theater = [["path", {
  d: "M2 10s3-3 3-8",
  key: "3xiif0"
}], ["path", {
  d: "M22 10s-3-3-3-8",
  key: "ioaa5q"
}], ["path", {
  d: "M10 2c0 4.4-3.6 8-8 8",
  key: "16fkpi"
}], ["path", {
  d: "M14 2c0 4.4 3.6 8 8 8",
  key: "b9eulq"
}], ["path", {
  d: "M2 10s2 2 2 5",
  key: "1au1lb"
}], ["path", {
  d: "M22 10s-2 2-2 5",
  key: "qi2y5e"
}], ["path", {
  d: "M8 15h8",
  key: "45n4r"
}], ["path", {
  d: "M2 22v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1",
  key: "1vsc2m"
}], ["path", {
  d: "M14 22v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1",
  key: "hrha4u"
}]];
var ThermometerSnowflake = [["path", {
  d: "m10 20-1.25-2.5L6 18",
  key: "18frcb"
}], ["path", {
  d: "M10 4 8.75 6.5 6 6",
  key: "7mghy3"
}], ["path", {
  d: "M10.585 15H10",
  key: "4nqulp"
}], ["path", {
  d: "M2 12h6.5L10 9",
  key: "kv9z4n"
}], ["path", {
  d: "M20 14.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0z",
  key: "yu0u2z"
}], ["path", {
  d: "m4 10 1.5 2L4 14",
  key: "k9enpj"
}], ["path", {
  d: "m7 21 3-6-1.5-3",
  key: "j8hb9u"
}], ["path", {
  d: "m7 3 3 6h2",
  key: "1bbqgq"
}]];
var ThermometerSun = [["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M12 8a4 4 0 0 0-1.645 7.647",
  key: "wz5p04"
}], ["path", {
  d: "M2 12h2",
  key: "1t8f8n"
}], ["path", {
  d: "M20 14.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0z",
  key: "yu0u2z"
}], ["path", {
  d: "m4.93 4.93 1.41 1.41",
  key: "149t6j"
}], ["path", {
  d: "m6.34 17.66-1.41 1.41",
  key: "1m8zz5"
}]];
var Thermometer = [["path", {
  d: "M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z",
  key: "17jzev"
}]];
var ThumbsDown = [["path", {
  d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
  key: "m61m77"
}], ["path", {
  d: "M17 14V2",
  key: "8ymqnk"
}]];
var TicketCheck = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}]];
var ThumbsUp = [["path", {
  d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
  key: "emmmcr"
}], ["path", {
  d: "M7 10v12",
  key: "1qc93n"
}]];
var TicketMinus = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "M9 12h6",
  key: "1c52cq"
}]];
var TicketPercent = [["path", {
  d: "M2 9a3 3 0 1 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 1 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "1l48ns"
}], ["path", {
  d: "M9 9h.01",
  key: "1q5me6"
}], ["path", {
  d: "m15 9-6 6",
  key: "1uzhvr"
}], ["path", {
  d: "M15 15h.01",
  key: "lqbp3k"
}]];
var TicketPlus = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "M9 12h6",
  key: "1c52cq"
}], ["path", {
  d: "M12 9v6",
  key: "199k2o"
}]];
var TicketSlash = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "m9.5 14.5 5-5",
  key: "qviqfa"
}]];
var TicketX = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "m9.5 14.5 5-5",
  key: "qviqfa"
}], ["path", {
  d: "m9.5 9.5 5 5",
  key: "18nt4w"
}]];
var Ticket = [["path", {
  d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
  key: "qn84l0"
}], ["path", {
  d: "M13 5v2",
  key: "dyzc3o"
}], ["path", {
  d: "M13 17v2",
  key: "1ont0d"
}], ["path", {
  d: "M13 11v2",
  key: "1wjjxi"
}]];
var TicketsPlane = [["path", {
  d: "M10.5 17h1.227a2 2 0 0 0 1.345-.52L18 12",
  key: "16muxl"
}], ["path", {
  d: "m12 13.5 3.794.506",
  key: "6v5z87"
}], ["path", {
  d: "m3.173 8.18 11-5a2 2 0 0 1 2.647.993L18.56 8",
  key: "15hfpj"
}], ["path", {
  d: "M6 10V8",
  key: "1y41hn"
}], ["path", {
  d: "M6 14v1",
  key: "cao2tf"
}], ["path", {
  d: "M6 19v2",
  key: "1loha6"
}], ["rect", {
  x: "2",
  y: "8",
  width: "20",
  height: "13",
  rx: "2",
  key: "p3bz5l"
}]];
var Tickets = [["path", {
  d: "m3.173 8.18 11-5a2 2 0 0 1 2.647.993L18.56 8",
  key: "15hfpj"
}], ["path", {
  d: "M6 10V8",
  key: "1y41hn"
}], ["path", {
  d: "M6 14v1",
  key: "cao2tf"
}], ["path", {
  d: "M6 19v2",
  key: "1loha6"
}], ["rect", {
  x: "2",
  y: "8",
  width: "20",
  height: "13",
  rx: "2",
  key: "p3bz5l"
}]];
var TimerOff = [["path", {
  d: "M10 2h4",
  key: "n1abiw"
}], ["path", {
  d: "M4.6 11a8 8 0 0 0 1.7 8.7 8 8 0 0 0 8.7 1.7",
  key: "10he05"
}], ["path", {
  d: "M7.4 7.4a8 8 0 0 1 10.3 1 8 8 0 0 1 .9 10.2",
  key: "15f7sh"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M12 12v-2",
  key: "fwoke6"
}]];
var TimerReset = [["path", {
  d: "M10 2h4",
  key: "n1abiw"
}], ["path", {
  d: "M12 14v-4",
  key: "1evpnu"
}], ["path", {
  d: "M4 13a8 8 0 0 1 8-7 8 8 0 1 1-5.3 14L4 17.6",
  key: "1ts96g"
}], ["path", {
  d: "M9 17H4v5",
  key: "8t5av"
}]];
var Timer = [["line", {
  x1: "10",
  x2: "14",
  y1: "2",
  y2: "2",
  key: "14vaq8"
}], ["line", {
  x1: "12",
  x2: "15",
  y1: "14",
  y2: "11",
  key: "17fdiu"
}], ["circle", {
  cx: "12",
  cy: "14",
  r: "8",
  key: "1e1u0o"
}]];
var ToggleLeft = [["circle", {
  cx: "9",
  cy: "12",
  r: "3",
  key: "u3jwor"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "5",
  rx: "7",
  key: "g7kal2"
}]];
var ToggleRight = [["circle", {
  cx: "15",
  cy: "12",
  r: "3",
  key: "1afu0r"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "5",
  rx: "7",
  key: "g7kal2"
}]];
var Toilet = [["path", {
  d: "M7 12h13a1 1 0 0 1 1 1 5 5 0 0 1-5 5h-.598a.5.5 0 0 0-.424.765l1.544 2.47a.5.5 0 0 1-.424.765H5.402a.5.5 0 0 1-.424-.765L7 18",
  key: "kc4kqr"
}], ["path", {
  d: "M8 18a5 5 0 0 1-5-5V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8",
  key: "1tqs57"
}]];
var ToolCase = [["path", {
  d: "M10 15h4",
  key: "192ueg"
}], ["path", {
  d: "m14.817 10.995-.971-1.45 1.034-1.232a2 2 0 0 0-2.025-3.238l-1.82.364L9.91 3.885a2 2 0 0 0-3.625.748L6.141 6.55l-1.725.426a2 2 0 0 0-.19 3.756l.657.27",
  key: "xbnumr"
}], ["path", {
  d: "m18.822 10.995 2.26-5.38a1 1 0 0 0-.557-1.318L16.954 2.9a1 1 0 0 0-1.281.533l-.924 2.122",
  key: "eaw7gc"
}], ["path", {
  d: "M4 12.006A1 1 0 0 1 4.994 11H19a1 1 0 0 1 1 1v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z",
  key: "1vaooh"
}]];
var Toolbox = [["path", {
  d: "M16 12v4",
  key: "vf1vip"
}], ["path", {
  d: "M16 6a2 2 0 0 1 1.414.586l4 4A2 2 0 0 1 22 12v7a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 .586-1.414l4-4A2 2 0 0 1 8 6z",
  key: "1h1rvn"
}], ["path", {
  d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",
  key: "1ksdt3"
}], ["path", {
  d: "M2 14h20",
  key: "myj16y"
}], ["path", {
  d: "M8 12v4",
  key: "1w4uao"
}]];
var Tornado = [["path", {
  d: "M21 4H3",
  key: "1hwok0"
}], ["path", {
  d: "M18 8H6",
  key: "41n648"
}], ["path", {
  d: "M19 12H9",
  key: "1g4lpz"
}], ["path", {
  d: "M16 16h-6",
  key: "1j5d54"
}], ["path", {
  d: "M11 20H9",
  key: "39obr8"
}]];
var Torus = [["ellipse", {
  cx: "12",
  cy: "11",
  rx: "3",
  ry: "2",
  key: "1b2qxu"
}], ["ellipse", {
  cx: "12",
  cy: "12.5",
  rx: "10",
  ry: "8.5",
  key: "h8emeu"
}]];
var TouchpadOff = [["path", {
  d: "M12 20v-6",
  key: "1rm09r"
}], ["path", {
  d: "M19.656 14H22",
  key: "170xzr"
}], ["path", {
  d: "M2 14h12",
  key: "d8icqz"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M20 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2",
  key: "s23sx2"
}], ["path", {
  d: "M9.656 4H20a2 2 0 0 1 2 2v10.344",
  key: "ovjcvl"
}]];
var Touchpad = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M2 14h20",
  key: "myj16y"
}], ["path", {
  d: "M12 20v-6",
  key: "1rm09r"
}]];
var TowelRack = [["path", {
  d: "M22 7h-2",
  key: "1okbx2"
}], ["path", {
  d: "M6.5 3h11A2.5 2.5 0 0 1 20 5.5V20a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1V5.5a1 1 0 0 0-5 0V17a1 1 0 0 0 1 1h4",
  key: "kc32tg"
}], ["path", {
  d: "M9 7H2",
  key: "ahf7b7"
}]];
var TowerControl = [["path", {
  d: "M18.2 12.27 20 6H4l1.8 6.27a1 1 0 0 0 .95.73h10.5a1 1 0 0 0 .96-.73Z",
  key: "1pledb"
}], ["path", {
  d: "M8 13v9",
  key: "hmv0ci"
}], ["path", {
  d: "M16 22v-9",
  key: "ylnf1u"
}], ["path", {
  d: "m9 6 1 7",
  key: "dpdgam"
}], ["path", {
  d: "m15 6-1 7",
  key: "ls7zgu"
}], ["path", {
  d: "M12 6V2",
  key: "1pj48d"
}], ["path", {
  d: "M13 2h-2",
  key: "mj6ths"
}]];
var ToyBrick = [["rect", {
  width: "18",
  height: "12",
  x: "3",
  y: "8",
  rx: "1",
  key: "158fvp"
}], ["path", {
  d: "M10 8V5c0-.6-.4-1-1-1H6a1 1 0 0 0-1 1v3",
  key: "s0042v"
}], ["path", {
  d: "M19 8V5c0-.6-.4-1-1-1h-3a1 1 0 0 0-1 1v3",
  key: "9wmeh2"
}]];
var Tractor = [["path", {
  d: "m10 11 11 .9a1 1 0 0 1 .8 1.1l-.665 4.158a1 1 0 0 1-.988.842H20",
  key: "she1j9"
}], ["path", {
  d: "M16 18h-5",
  key: "bq60fd"
}], ["path", {
  d: "M18 5a1 1 0 0 0-1 1v5.573",
  key: "1kv8ia"
}], ["path", {
  d: "M3 4h8.129a1 1 0 0 1 .99.863L13 11.246",
  key: "1q1ert"
}], ["path", {
  d: "M4 11V4",
  key: "9ft8pt"
}], ["path", {
  d: "M7 15h.01",
  key: "k5ht0j"
}], ["path", {
  d: "M8 10.1V4",
  key: "1jgyzo"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "2",
  key: "1emm8v"
}], ["circle", {
  cx: "7",
  cy: "15",
  r: "5",
  key: "ddtuc"
}]];
var TrafficCone = [["path", {
  d: "M16.05 10.966a5 2.5 0 0 1-8.1 0",
  key: "m5jpwb"
}], ["path", {
  d: "m16.923 14.049 4.48 2.04a1 1 0 0 1 .001 1.831l-8.574 3.9a2 2 0 0 1-1.66 0l-8.574-3.91a1 1 0 0 1 0-1.83l4.484-2.04",
  key: "rbg3g8"
}], ["path", {
  d: "M16.949 14.14a5 2.5 0 1 1-9.9 0L10.063 3.5a2 2 0 0 1 3.874 0z",
  key: "vap8c8"
}], ["path", {
  d: "M9.194 6.57a5 2.5 0 0 0 5.61 0",
  key: "15hn5c"
}]];
var TrainFrontTunnel = [["path", {
  d: "M2 22V12a10 10 0 1 1 20 0v10",
  key: "o0fyp0"
}], ["path", {
  d: "M15 6.8v1.4a3 2.8 0 1 1-6 0V6.8",
  key: "m8q3n9"
}], ["path", {
  d: "M10 15h.01",
  key: "44in9x"
}], ["path", {
  d: "M14 15h.01",
  key: "5mohn5"
}], ["path", {
  d: "M10 19a4 4 0 0 1-4-4v-3a6 6 0 1 1 12 0v3a4 4 0 0 1-4 4Z",
  key: "hckbmu"
}], ["path", {
  d: "m9 19-2 3",
  key: "iij7hm"
}], ["path", {
  d: "m15 19 2 3",
  key: "npx8sa"
}]];
var TrainFront = [["path", {
  d: "M8 3.1V7a4 4 0 0 0 8 0V3.1",
  key: "1v71zp"
}], ["path", {
  d: "m9 15-1-1",
  key: "1yrq24"
}], ["path", {
  d: "m15 15 1-1",
  key: "1t0d6s"
}], ["path", {
  d: "M9 19c-2.8 0-5-2.2-5-5v-4a8 8 0 0 1 16 0v4c0 2.8-2.2 5-5 5Z",
  key: "1p0hjs"
}], ["path", {
  d: "m8 19-2 3",
  key: "13i0xs"
}], ["path", {
  d: "m16 19 2 3",
  key: "xo31yx"
}]];
var TrainTrack = [["path", {
  d: "M2 17 17 2",
  key: "18b09t"
}], ["path", {
  d: "m2 14 8 8",
  key: "1gv9hu"
}], ["path", {
  d: "m5 11 8 8",
  key: "189pqp"
}], ["path", {
  d: "m8 8 8 8",
  key: "1imecy"
}], ["path", {
  d: "m11 5 8 8",
  key: "ummqn6"
}], ["path", {
  d: "m14 2 8 8",
  key: "1vk7dn"
}], ["path", {
  d: "M7 22 22 7",
  key: "15mb1i"
}]];
var Transgender = [["path", {
  d: "M12 16v6",
  key: "c8a4gj"
}], ["path", {
  d: "M14 20h-4",
  key: "m8m19d"
}], ["path", {
  d: "M18 2h4v4",
  key: "1341mj"
}], ["path", {
  d: "m2 2 7.17 7.17",
  key: "13q8l2"
}], ["path", {
  d: "M2 5.355V2h3.357",
  key: "18136r"
}], ["path", {
  d: "m22 2-7.17 7.17",
  key: "1epvy4"
}], ["path", {
  d: "M8 5 5 8",
  key: "mgbjhz"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "4",
  key: "4exip2"
}]];
var TramFront = [["rect", {
  width: "16",
  height: "16",
  x: "4",
  y: "3",
  rx: "2",
  key: "1wxw4b"
}], ["path", {
  d: "M4 11h16",
  key: "mpoxn0"
}], ["path", {
  d: "M12 3v8",
  key: "1h2ygw"
}], ["path", {
  d: "m8 19-2 3",
  key: "13i0xs"
}], ["path", {
  d: "m18 22-2-3",
  key: "1p0ohu"
}], ["path", {
  d: "M8 15h.01",
  key: "a7atzg"
}], ["path", {
  d: "M16 15h.01",
  key: "rnfrdf"
}]];
var Trash2 = [["path", {
  d: "M10 11v6",
  key: "nco0om"
}], ["path", {
  d: "M14 11v6",
  key: "outv1u"
}], ["path", {
  d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
  key: "miytrc"
}], ["path", {
  d: "M3 6h18",
  key: "d0wm0j"
}], ["path", {
  d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
  key: "e791ji"
}]];
var Trash = [["path", {
  d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
  key: "miytrc"
}], ["path", {
  d: "M3 6h18",
  key: "d0wm0j"
}], ["path", {
  d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
  key: "e791ji"
}]];
var TreeDeciduous = [["path", {
  d: "M8 19a4 4 0 0 1-2.24-7.32A3.5 3.5 0 0 1 9 6.03V6a3 3 0 1 1 6 0v.04a3.5 3.5 0 0 1 3.24 5.65A4 4 0 0 1 16 19Z",
  key: "oadzkq"
}], ["path", {
  d: "M12 19v3",
  key: "npa21l"
}]];
var TreePalm = [["path", {
  d: "M13 8c0-2.76-2.46-5-5.5-5S2 5.24 2 8h2l1-1 1 1h4",
  key: "foxbe7"
}], ["path", {
  d: "M13 7.14A5.82 5.82 0 0 1 16.5 6c3.04 0 5.5 2.24 5.5 5h-3l-1-1-1 1h-3",
  key: "18arnh"
}], ["path", {
  d: "M5.89 9.71c-2.15 2.15-2.3 5.47-.35 7.43l4.24-4.25.7-.7.71-.71 2.12-2.12c-1.95-1.96-5.27-1.8-7.42.35",
  key: "ywahnh"
}], ["path", {
  d: "M11 15.5c.5 2.5-.17 4.5-1 6.5h4c2-5.5-.5-12-1-14",
  key: "ft0feo"
}]];
var TreePine = [["path", {
  d: "m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z",
  key: "cpyugq"
}], ["path", {
  d: "M12 22v-3",
  key: "kmzjlo"
}]];
var Trees = [["path", {
  d: "M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z",
  key: "1l6gj6"
}], ["path", {
  d: "M7 16v6",
  key: "1a82de"
}], ["path", {
  d: "M13 19v3",
  key: "13sx9i"
}], ["path", {
  d: "M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5",
  key: "1sj9kv"
}]];
var Trello = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  ry: "2",
  key: "1m3agn"
}], ["rect", {
  width: "3",
  height: "9",
  x: "7",
  y: "7",
  key: "14n3xi"
}], ["rect", {
  width: "3",
  height: "5",
  x: "14",
  y: "7",
  key: "s4azjd"
}]];
var TrendingDown = [["path", {
  d: "M16 17h6v-6",
  key: "t6n2it"
}], ["path", {
  d: "m22 17-8.5-8.5-5 5L2 7",
  key: "x473p"
}]];
var TrendingUpDown = [["path", {
  d: "M14.828 14.828 21 21",
  key: "ar5fw7"
}], ["path", {
  d: "M21 16v5h-5",
  key: "1ck2sf"
}], ["path", {
  d: "m21 3-9 9-4-4-6 6",
  key: "1h02xo"
}], ["path", {
  d: "M21 8V3h-5",
  key: "1qoq8a"
}]];
var TriangleAlert = [["path", {
  d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
  key: "wmoenq"
}], ["path", {
  d: "M12 9v4",
  key: "juzpu7"
}], ["path", {
  d: "M12 17h.01",
  key: "p32p05"
}]];
var TrendingUp = [["path", {
  d: "M16 7h6v6",
  key: "box55l"
}], ["path", {
  d: "m22 7-8.5 8.5-5-5L2 17",
  key: "1t1m79"
}]];
var TriangleDashed = [["path", {
  d: "M10.17 4.193a2 2 0 0 1 3.666.013",
  key: "pltmmw"
}], ["path", {
  d: "M14 21h2",
  key: "v4qezv"
}], ["path", {
  d: "m15.874 7.743 1 1.732",
  key: "10m0iw"
}], ["path", {
  d: "m18.849 12.952 1 1.732",
  key: "zadnam"
}], ["path", {
  d: "M21.824 18.18a2 2 0 0 1-1.835 2.824",
  key: "fvwuk4"
}], ["path", {
  d: "M4.024 21a2 2 0 0 1-1.839-2.839",
  key: "1e1kah"
}], ["path", {
  d: "m5.136 12.952-1 1.732",
  key: "1u4ldi"
}], ["path", {
  d: "M8 21h2",
  key: "i9zjee"
}], ["path", {
  d: "m8.102 7.743-1 1.732",
  key: "1zzo4u"
}]];
var TriangleRight = [["path", {
  d: "M22 18a2 2 0 0 1-2 2H3c-1.1 0-1.3-.6-.4-1.3L20.4 4.3c.9-.7 1.6-.4 1.6.7Z",
  key: "183wce"
}]];
var Triangle = [["path", {
  d: "M13.73 4a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",
  key: "14u9p9"
}]];
var Trophy = [["path", {
  d: "M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978",
  key: "1n3hpd"
}], ["path", {
  d: "M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978",
  key: "rfe1zi"
}], ["path", {
  d: "M18 9h1.5a1 1 0 0 0 0-5H18",
  key: "7xy6bh"
}], ["path", {
  d: "M4 22h16",
  key: "57wxv0"
}], ["path", {
  d: "M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",
  key: "1mhfuq"
}], ["path", {
  d: "M6 9H4.5a1 1 0 0 1 0-5H6",
  key: "tex48p"
}]];
var TruckElectric = [["path", {
  d: "M14 19V7a2 2 0 0 0-2-2H9",
  key: "15peso"
}], ["path", {
  d: "M15 19H9",
  key: "18q6dt"
}], ["path", {
  d: "M19 19h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62L18.3 9.38a1 1 0 0 0-.78-.38H14",
  key: "1dkp3j"
}], ["path", {
  d: "M2 13v5a1 1 0 0 0 1 1h2",
  key: "pkmmzz"
}], ["path", {
  d: "M4 3 2.15 5.15a.495.495 0 0 0 .35.86h2.15a.47.47 0 0 1 .35.86L3 9.02",
  key: "1n26pd"
}], ["circle", {
  cx: "17",
  cy: "19",
  r: "2",
  key: "1nxcgd"
}], ["circle", {
  cx: "7",
  cy: "19",
  r: "2",
  key: "gzo7y7"
}]];
var Truck = [["path", {
  d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",
  key: "wrbu53"
}], ["path", {
  d: "M15 18H9",
  key: "1lyqi6"
}], ["path", {
  d: "M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",
  key: "lysw3i"
}], ["circle", {
  cx: "17",
  cy: "18",
  r: "2",
  key: "332jqn"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "2",
  key: "19iecd"
}]];
var TurkishLira = [["path", {
  d: "M15 4 5 9",
  key: "14bkc9"
}], ["path", {
  d: "m15 8.5-10 5",
  key: "1grtsx"
}], ["path", {
  d: "M18 12a9 9 0 0 1-9 9V3",
  key: "1sst7f"
}]];
var Turtle = [["path", {
  d: "m12 10 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a8 8 0 1 0-16 0v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3l2-4h4Z",
  key: "1lbbv7"
}], ["path", {
  d: "M4.82 7.9 8 10",
  key: "m9wose"
}], ["path", {
  d: "M15.18 7.9 12 10",
  key: "p8dp2u"
}], ["path", {
  d: "M16.93 10H20a2 2 0 0 1 0 4H2",
  key: "12nsm7"
}]];
var TvMinimalPlay = [["path", {
  d: "M15.033 9.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56V7.648a.645.645 0 0 1 .967-.56z",
  key: "vbtd3f"
}], ["path", {
  d: "M7 21h10",
  key: "1b0cd5"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}]];
var Turntable = [["path", {
  d: "M10 12.01h.01",
  key: "7rp0yl"
}], ["path", {
  d: "M18 8v4a8 8 0 0 1-1.07 4",
  key: "1st48v"
}], ["circle", {
  cx: "10",
  cy: "12",
  r: "4",
  key: "19levz"
}], ["rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2",
  key: "izxlao"
}]];
var TvMinimal = [["path", {
  d: "M7 21h10",
  key: "1b0cd5"
}], ["rect", {
  width: "20",
  height: "14",
  x: "2",
  y: "3",
  rx: "2",
  key: "48i651"
}]];
var Tv = [["path", {
  d: "m17 2-5 5-5-5",
  key: "16satq"
}], ["rect", {
  width: "20",
  height: "15",
  x: "2",
  y: "7",
  rx: "2",
  key: "1e6viu"
}]];
var Twitch = [["path", {
  d: "M21 2H3v16h5v4l4-4h5l4-4V2zm-10 9V7m5 4V7",
  key: "c0yzno"
}]];
var Twitter = [["path", {
  d: "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",
  key: "pff0z6"
}]];
var TypeOutline = [["path", {
  d: "M14 16.5a.5.5 0 0 0 .5.5h.5a2 2 0 0 1 0 4H9a2 2 0 0 1 0-4h.5a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5V8a2 2 0 0 1-4 0V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v3a2 2 0 0 1-4 0v-.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5Z",
  key: "1reda3"
}]];
var Type = [["path", {
  d: "M12 4v16",
  key: "1654pz"
}], ["path", {
  d: "M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2",
  key: "e0r10z"
}], ["path", {
  d: "M9 20h6",
  key: "s66wpe"
}]];
var UmbrellaOff = [["path", {
  d: "M12 13v7a2 2 0 0 0 4 0",
  key: "rpgb42"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M18.656 13h2.336a1 1 0 0 0 .97-1.274 10.284 10.284 0 0 0-12.07-7.51",
  key: "yawknk"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "M5.961 5.957a10.28 10.28 0 0 0-3.922 5.769A1 1 0 0 0 3 13h10",
  key: "5sfalc"
}]];
var Umbrella = [["path", {
  d: "M12 13v7a2 2 0 0 0 4 0",
  key: "rpgb42"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M20.992 13a1 1 0 0 0 .97-1.274 10.284 10.284 0 0 0-19.923 0A1 1 0 0 0 3 13z",
  key: "124nyo"
}]];
var Undo2 = [["path", {
  d: "M9 14 4 9l5-5",
  key: "102s5s"
}], ["path", {
  d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",
  key: "f3b9sd"
}]];
var Underline = [["path", {
  d: "M6 4v6a6 6 0 0 0 12 0V4",
  key: "9kb039"
}], ["line", {
  x1: "4",
  x2: "20",
  y1: "20",
  y2: "20",
  key: "nun2al"
}]];
var UndoDot = [["path", {
  d: "M21 17a9 9 0 0 0-15-6.7L3 13",
  key: "8mp6z9"
}], ["path", {
  d: "M3 7v6h6",
  key: "1v2h90"
}], ["circle", {
  cx: "12",
  cy: "17",
  r: "1",
  key: "1ixnty"
}]];
var Undo = [["path", {
  d: "M3 7v6h6",
  key: "1v2h90"
}], ["path", {
  d: "M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13",
  key: "1r6uu6"
}]];
var UnfoldHorizontal = [["path", {
  d: "M16 12h6",
  key: "15xry1"
}], ["path", {
  d: "M8 12H2",
  key: "1jqql6"
}], ["path", {
  d: "M12 2v2",
  key: "tus03m"
}], ["path", {
  d: "M12 8v2",
  key: "1woqiv"
}], ["path", {
  d: "M12 14v2",
  key: "8jcxud"
}], ["path", {
  d: "M12 20v2",
  key: "1lh1kg"
}], ["path", {
  d: "m19 15 3-3-3-3",
  key: "wjy7rq"
}], ["path", {
  d: "m5 9-3 3 3 3",
  key: "j64kie"
}]];
var UnfoldVertical = [["path", {
  d: "M12 22v-6",
  key: "6o8u61"
}], ["path", {
  d: "M12 8V2",
  key: "1wkif3"
}], ["path", {
  d: "M4 12H2",
  key: "rhcxmi"
}], ["path", {
  d: "M10 12H8",
  key: "s88cx1"
}], ["path", {
  d: "M16 12h-2",
  key: "10asgb"
}], ["path", {
  d: "M22 12h-2",
  key: "14jgyd"
}], ["path", {
  d: "m15 19-3 3-3-3",
  key: "11eu04"
}], ["path", {
  d: "m15 5-3-3-3 3",
  key: "itvq4r"
}]];
var University = [["path", {
  d: "M14 21v-3a2 2 0 0 0-4 0v3",
  key: "1rgiei"
}], ["path", {
  d: "M18 12h.01",
  key: "yjnet6"
}], ["path", {
  d: "M18 16h.01",
  key: "plv8zi"
}], ["path", {
  d: "M22 7a1 1 0 0 0-1-1h-2a2 2 0 0 1-1.143-.359L13.143 2.36a2 2 0 0 0-2.286-.001L6.143 5.64A2 2 0 0 1 5 6H3a1 1 0 0 0-1 1v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2z",
  key: "1ogmi3"
}], ["path", {
  d: "M6 12h.01",
  key: "c2rlol"
}], ["path", {
  d: "M6 16h.01",
  key: "1pmjb7"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "2",
  key: "1yojzk"
}]];
var Ungroup = [["rect", {
  width: "8",
  height: "6",
  x: "5",
  y: "4",
  rx: "1",
  key: "nzclkv"
}], ["rect", {
  width: "8",
  height: "6",
  x: "11",
  y: "14",
  rx: "1",
  key: "4tytwb"
}]];
var Unlink2 = [["path", {
  d: "M15 7h2a5 5 0 0 1 0 10h-2m-6 0H7A5 5 0 0 1 7 7h2",
  key: "1re2ne"
}]];
var Unplug = [["path", {
  d: "m19 5 3-3",
  key: "yk6iyv"
}], ["path", {
  d: "m2 22 3-3",
  key: "19mgm9"
}], ["path", {
  d: "M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z",
  key: "goz73y"
}], ["path", {
  d: "M7.5 13.5 10 11",
  key: "7xgeeb"
}], ["path", {
  d: "M10.5 16.5 13 14",
  key: "10btkg"
}], ["path", {
  d: "m12 6 6 6 2.3-2.3a2.4 2.4 0 0 0 0-3.4l-2.6-2.6a2.4 2.4 0 0 0-3.4 0Z",
  key: "1snsnr"
}]];
var Unlink = [["path", {
  d: "m18.84 12.25 1.72-1.71h-.02a5.004 5.004 0 0 0-.12-7.07 5.006 5.006 0 0 0-6.95 0l-1.72 1.71",
  key: "yqzxt4"
}], ["path", {
  d: "m5.17 11.75-1.71 1.71a5.004 5.004 0 0 0 .12 7.07 5.006 5.006 0 0 0 6.95 0l1.71-1.71",
  key: "4qinb0"
}], ["line", {
  x1: "8",
  x2: "8",
  y1: "2",
  y2: "5",
  key: "1041cp"
}], ["line", {
  x1: "2",
  x2: "5",
  y1: "8",
  y2: "8",
  key: "14m1p5"
}], ["line", {
  x1: "16",
  x2: "16",
  y1: "19",
  y2: "22",
  key: "rzdirn"
}], ["line", {
  x1: "19",
  x2: "22",
  y1: "16",
  y2: "16",
  key: "ox905f"
}]];
var Upload = [["path", {
  d: "M12 3v12",
  key: "1x0j5s"
}], ["path", {
  d: "m17 8-5-5-5 5",
  key: "7q97r8"
}], ["path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
  key: "ih7n3h"
}]];
var Usb = [["circle", {
  cx: "10",
  cy: "7",
  r: "1",
  key: "dypaad"
}], ["circle", {
  cx: "4",
  cy: "20",
  r: "1",
  key: "22iqad"
}], ["path", {
  d: "M4.7 19.3 19 5",
  key: "1enqfc"
}], ["path", {
  d: "m21 3-3 1 2 2Z",
  key: "d3ov82"
}], ["path", {
  d: "M9.26 7.68 5 12l2 5",
  key: "1esawj"
}], ["path", {
  d: "m10 14 5 2 3.5-3.5",
  key: "v8oal5"
}], ["path", {
  d: "m18 12 1-1 1 1-1 1Z",
  key: "1bh22v"
}]];
var UserCheck = [["path", {
  d: "m16 11 2 2 4-4",
  key: "9rsbq5"
}], ["path", {
  d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
  key: "1yyitq"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}]];
var UserCog = [["path", {
  d: "M10 15H6a4 4 0 0 0-4 4v2",
  key: "1nfge6"
}], ["path", {
  d: "m14.305 16.53.923-.382",
  key: "1itpsq"
}], ["path", {
  d: "m15.228 13.852-.923-.383",
  key: "eplpkm"
}], ["path", {
  d: "m16.852 12.228-.383-.923",
  key: "13v3q0"
}], ["path", {
  d: "m16.852 17.772-.383.924",
  key: "1i8mnm"
}], ["path", {
  d: "m19.148 12.228.383-.923",
  key: "1q8j1v"
}], ["path", {
  d: "m19.53 18.696-.382-.924",
  key: "vk1qj3"
}], ["path", {
  d: "m20.772 13.852.924-.383",
  key: "n880s0"
}], ["path", {
  d: "m20.772 16.148.924.383",
  key: "1g6xey"
}], ["circle", {
  cx: "18",
  cy: "15",
  r: "3",
  key: "gjjjvw"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}]];
var UserKey = [["path", {
  d: "M20 11v6",
  key: "d77pzp"
}], ["path", {
  d: "M20 13h2",
  key: "16rner"
}], ["path", {
  d: "M3 21v-2a4 4 0 0 1 4-4h6a4 4 0 0 1 2.072.578",
  key: "1yxgtw"
}], ["circle", {
  cx: "10",
  cy: "7",
  r: "4",
  key: "e45bow"
}], ["circle", {
  cx: "20",
  cy: "19",
  r: "2",
  key: "1obnsp"
}]];
var UserLock = [["path", {
  d: "M19 16v-2a2 2 0 0 0-4 0v2",
  key: "17sujf"
}], ["path", {
  d: "M9.5 15H7a4 4 0 0 0-4 4v2",
  key: "9it25y"
}], ["circle", {
  cx: "10",
  cy: "7",
  r: "4",
  key: "e45bow"
}], ["rect", {
  x: "13",
  y: "16",
  width: "8",
  height: "5",
  rx: ".899",
  key: "ur80nz"
}]];
var UserMinus = [["path", {
  d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
  key: "1yyitq"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}], ["line", {
  x1: "22",
  x2: "16",
  y1: "11",
  y2: "11",
  key: "1shjgl"
}]];
var UserPen = [["path", {
  d: "M11.5 15H7a4 4 0 0 0-4 4v2",
  key: "15lzij"
}], ["path", {
  d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "1817ys"
}], ["circle", {
  cx: "10",
  cy: "7",
  r: "4",
  key: "e45bow"
}]];
var UserPlus = [["path", {
  d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
  key: "1yyitq"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}], ["line", {
  x1: "19",
  x2: "19",
  y1: "8",
  y2: "14",
  key: "1bvyxn"
}], ["line", {
  x1: "22",
  x2: "16",
  y1: "11",
  y2: "11",
  key: "1shjgl"
}]];
var UserRoundCheck = [["path", {
  d: "M2 21a8 8 0 0 1 13.292-6",
  key: "bjp14o"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "m16 19 2 2 4-4",
  key: "1b14m6"
}]];
var UserRoundCog = [["path", {
  d: "m14.305 19.53.923-.382",
  key: "3m78fa"
}], ["path", {
  d: "m15.228 16.852-.923-.383",
  key: "npixar"
}], ["path", {
  d: "m16.852 15.228-.383-.923",
  key: "5xggr7"
}], ["path", {
  d: "m16.852 20.772-.383.924",
  key: "dpfhf9"
}], ["path", {
  d: "m19.148 15.228.383-.923",
  key: "1reyyz"
}], ["path", {
  d: "m19.53 21.696-.382-.924",
  key: "1goivc"
}], ["path", {
  d: "M2 21a8 8 0 0 1 10.434-7.62",
  key: "1yezr2"
}], ["path", {
  d: "m20.772 16.852.924-.383",
  key: "htqkph"
}], ["path", {
  d: "m20.772 19.148.924.383",
  key: "9w9pjp"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var UserRoundKey = [["path", {
  d: "M19 11v6",
  key: "rcqigv"
}], ["path", {
  d: "M19 13h2",
  key: "1gch44"
}], ["path", {
  d: "M2 21a8 8 0 0 1 12.868-6.349",
  key: "1lryzn"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["circle", {
  cx: "19",
  cy: "19",
  r: "2",
  key: "17f5cg"
}]];
var UserRoundMinus = [["path", {
  d: "M2 21a8 8 0 0 1 13.292-6",
  key: "bjp14o"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "M22 19h-6",
  key: "vcuq98"
}]];
var UserRoundPen = [["path", {
  d: "M2 21a8 8 0 0 1 10.821-7.487",
  key: "1c8h7z"
}], ["path", {
  d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "1817ys"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}]];
var UserRoundPlus = [["path", {
  d: "M2 21a8 8 0 0 1 13.292-6",
  key: "bjp14o"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "M19 16v6",
  key: "tddt3s"
}], ["path", {
  d: "M22 19h-6",
  key: "vcuq98"
}]];
var UserRoundSearch = [["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "M2 21a8 8 0 0 1 10.434-7.62",
  key: "1yezr2"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}], ["path", {
  d: "m22 22-1.9-1.9",
  key: "1e5ubv"
}]];
var UserRoundX = [["path", {
  d: "M2 21a8 8 0 0 1 11.873-7",
  key: "74fkxq"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "m17 17 5 5",
  key: "p7ous7"
}], ["path", {
  d: "m22 17-5 5",
  key: "gqnmv0"
}]];
var UserRound = [["circle", {
  cx: "12",
  cy: "8",
  r: "5",
  key: "1hypcn"
}], ["path", {
  d: "M20 21a8 8 0 0 0-16 0",
  key: "rfgkzh"
}]];
var UserSearch = [["circle", {
  cx: "10",
  cy: "7",
  r: "4",
  key: "e45bow"
}], ["path", {
  d: "M10.3 15H7a4 4 0 0 0-4 4v2",
  key: "3bnktk"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "3",
  key: "18b49y"
}], ["path", {
  d: "m21 21-1.9-1.9",
  key: "1g2n9r"
}]];
var UserStar = [["path", {
  d: "M16.051 12.616a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.866l-1.156-1.153a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
  key: "1m8t9f"
}], ["path", {
  d: "M8 15H7a4 4 0 0 0-4 4v2",
  key: "l9tmp8"
}], ["circle", {
  cx: "10",
  cy: "7",
  r: "4",
  key: "e45bow"
}]];
var UserX = [["path", {
  d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
  key: "1yyitq"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}], ["line", {
  x1: "17",
  x2: "22",
  y1: "8",
  y2: "13",
  key: "3nzzx3"
}], ["line", {
  x1: "22",
  x2: "17",
  y1: "8",
  y2: "13",
  key: "1swrse"
}]];
var User = [["path", {
  d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
  key: "975kel"
}], ["circle", {
  cx: "12",
  cy: "7",
  r: "4",
  key: "17ys0d"
}]];
var UsersRound = [["path", {
  d: "M18 21a8 8 0 0 0-16 0",
  key: "3ypg7q"
}], ["circle", {
  cx: "10",
  cy: "8",
  r: "5",
  key: "o932ke"
}], ["path", {
  d: "M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",
  key: "10s06x"
}]];
var Users = [["path", {
  d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
  key: "1yyitq"
}], ["path", {
  d: "M16 3.128a4 4 0 0 1 0 7.744",
  key: "16gr8j"
}], ["path", {
  d: "M22 21v-2a4 4 0 0 0-3-3.87",
  key: "kshegd"
}], ["circle", {
  cx: "9",
  cy: "7",
  r: "4",
  key: "nufk8"
}]];
var UtensilsCrossed = [["path", {
  d: "m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8",
  key: "n7qcjb"
}], ["path", {
  d: "M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7",
  key: "d0u48b"
}], ["path", {
  d: "m2.1 21.8 6.4-6.3",
  key: "yn04lh"
}], ["path", {
  d: "m19 5-7 7",
  key: "194lzd"
}]];
var Utensils = [["path", {
  d: "M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2",
  key: "cjf0a3"
}], ["path", {
  d: "M7 2v20",
  key: "1473qp"
}], ["path", {
  d: "M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7",
  key: "j28e5"
}]];
var Van = [["path", {
  d: "M13 6v5a1 1 0 0 0 1 1h6.102a1 1 0 0 1 .712.298l.898.91a1 1 0 0 1 .288.702V17a1 1 0 0 1-1 1h-3",
  key: "k3s650"
}], ["path", {
  d: "M5 18H3a1 1 0 0 1-1-1V8a2 2 0 0 1 2-2h12c1.1 0 2.1.8 2.4 1.8l1.176 4.2",
  key: "fnd93u"
}], ["path", {
  d: "M9 18h5",
  key: "lrx6i"
}], ["circle", {
  cx: "16",
  cy: "18",
  r: "2",
  key: "1v4tcr"
}], ["circle", {
  cx: "7",
  cy: "18",
  r: "2",
  key: "19iecd"
}]];
var Variable = [["path", {
  d: "M8 21s-4-3-4-9 4-9 4-9",
  key: "uto9ud"
}], ["path", {
  d: "M16 3s4 3 4 9-4 9-4 9",
  key: "4w2vsq"
}], ["line", {
  x1: "15",
  x2: "9",
  y1: "9",
  y2: "15",
  key: "f7djnv"
}], ["line", {
  x1: "9",
  x2: "15",
  y1: "9",
  y2: "15",
  key: "1shsy8"
}]];
var UtilityPole = [["path", {
  d: "M12 2v20",
  key: "t6zp3m"
}], ["path", {
  d: "M2 5h20",
  key: "1fs1ex"
}], ["path", {
  d: "M3 3v2",
  key: "9imdir"
}], ["path", {
  d: "M7 3v2",
  key: "n0os7"
}], ["path", {
  d: "M17 3v2",
  key: "1l2re6"
}], ["path", {
  d: "M21 3v2",
  key: "1duuac"
}], ["path", {
  d: "m19 5-7 7-7-7",
  key: "133zxf"
}]];
var Vault = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["circle", {
  cx: "7.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "kqv944"
}], ["path", {
  d: "m7.9 7.9 2.7 2.7",
  key: "hpeyl3"
}], ["circle", {
  cx: "16.5",
  cy: "7.5",
  r: ".5",
  fill: "currentColor",
  key: "w0ekpg"
}], ["path", {
  d: "m13.4 10.6 2.7-2.7",
  key: "264c1n"
}], ["circle", {
  cx: "7.5",
  cy: "16.5",
  r: ".5",
  fill: "currentColor",
  key: "nkw3mc"
}], ["path", {
  d: "m7.9 16.1 2.7-2.7",
  key: "p81g5e"
}], ["circle", {
  cx: "16.5",
  cy: "16.5",
  r: ".5",
  fill: "currentColor",
  key: "fubopw"
}], ["path", {
  d: "m13.4 13.4 2.7 2.7",
  key: "abhel3"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "2",
  key: "1c9p78"
}]];
var VectorSquare = [["path", {
  d: "M19.5 7a24 24 0 0 1 0 10",
  key: "8n60xe"
}], ["path", {
  d: "M4.5 7a24 24 0 0 0 0 10",
  key: "2lmadr"
}], ["path", {
  d: "M7 19.5a24 24 0 0 0 10 0",
  key: "1q94o2"
}], ["path", {
  d: "M7 4.5a24 24 0 0 1 10 0",
  key: "2z8ypa"
}], ["rect", {
  x: "17",
  y: "17",
  width: "5",
  height: "5",
  rx: "1",
  key: "1ac74s"
}], ["rect", {
  x: "17",
  y: "2",
  width: "5",
  height: "5",
  rx: "1",
  key: "1e7h5j"
}], ["rect", {
  x: "2",
  y: "17",
  width: "5",
  height: "5",
  rx: "1",
  key: "1t4eah"
}], ["rect", {
  x: "2",
  y: "2",
  width: "5",
  height: "5",
  rx: "1",
  key: "940dhs"
}]];
var Vegan = [["path", {
  d: "M16 8q6 0 6-6-6 0-6 6",
  key: "qsyyc4"
}], ["path", {
  d: "M17.41 3.59a10 10 0 1 0 3 3",
  key: "41m9h7"
}], ["path", {
  d: "M2 2a26.6 26.6 0 0 1 10 20c.9-6.82 1.5-9.5 4-14",
  key: "qiv7li"
}]];
var VenetianMask = [["path", {
  d: "M18 11c-1.5 0-2.5.5-3 2",
  key: "1fod00"
}], ["path", {
  d: "M4 6a2 2 0 0 0-2 2v4a5 5 0 0 0 5 5 8 8 0 0 1 5 2 8 8 0 0 1 5-2 5 5 0 0 0 5-5V8a2 2 0 0 0-2-2h-3a8 8 0 0 0-5 2 8 8 0 0 0-5-2z",
  key: "d70hit"
}], ["path", {
  d: "M6 11c1.5 0 2.5.5 3 2",
  key: "136fht"
}]];
var VenusAndMars = [["path", {
  d: "M10 20h4",
  key: "ni2waw"
}], ["path", {
  d: "M12 16v6",
  key: "c8a4gj"
}], ["path", {
  d: "M17 2h4v4",
  key: "vhe59"
}], ["path", {
  d: "m21 2-5.46 5.46",
  key: "19kypf"
}], ["circle", {
  cx: "12",
  cy: "11",
  r: "5",
  key: "16gxyc"
}]];
var Venus = [["path", {
  d: "M12 15v7",
  key: "t2xh3l"
}], ["path", {
  d: "M9 19h6",
  key: "456am0"
}], ["circle", {
  cx: "12",
  cy: "9",
  r: "6",
  key: "1nw4tq"
}]];
var VibrateOff = [["path", {
  d: "m2 8 2 2-2 2 2 2-2 2",
  key: "sv1b1"
}], ["path", {
  d: "m22 8-2 2 2 2-2 2 2 2",
  key: "101i4y"
}], ["path", {
  d: "M8 8v10c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2",
  key: "1hbad5"
}], ["path", {
  d: "M16 10.34V6c0-.55-.45-1-1-1h-4.34",
  key: "1x5tf0"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Vibrate = [["path", {
  d: "m2 8 2 2-2 2 2 2-2 2",
  key: "sv1b1"
}], ["path", {
  d: "m22 8-2 2 2 2-2 2 2 2",
  key: "101i4y"
}], ["rect", {
  width: "8",
  height: "14",
  x: "8",
  y: "5",
  rx: "1",
  key: "1oyrl4"
}]];
var VideoOff = [["path", {
  d: "M10.66 6H14a2 2 0 0 1 2 2v2.5l5.248-3.062A.5.5 0 0 1 22 7.87v8.196",
  key: "w8jjjt"
}], ["path", {
  d: "M16 16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2",
  key: "1xawa7"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Video = [["path", {
  d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
  key: "ftymec"
}], ["rect", {
  x: "2",
  y: "6",
  width: "14",
  height: "12",
  rx: "2",
  key: "158x01"
}]];
var Videotape = [["rect", {
  width: "20",
  height: "16",
  x: "2",
  y: "4",
  rx: "2",
  key: "18n3k1"
}], ["path", {
  d: "M2 8h20",
  key: "d11cs7"
}], ["circle", {
  cx: "8",
  cy: "14",
  r: "2",
  key: "1k2qr5"
}], ["path", {
  d: "M8 12h8",
  key: "1wcyev"
}], ["circle", {
  cx: "16",
  cy: "14",
  r: "2",
  key: "14k7lr"
}]];
var View = [["path", {
  d: "M21 17v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2",
  key: "mrq65r"
}], ["path", {
  d: "M21 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2",
  key: "be3xqs"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "1",
  key: "41hilf"
}], ["path", {
  d: "M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0",
  key: "11ak4c"
}]];
var Voicemail = [["circle", {
  cx: "6",
  cy: "12",
  r: "4",
  key: "1ehtga"
}], ["circle", {
  cx: "18",
  cy: "12",
  r: "4",
  key: "4vafl8"
}], ["line", {
  x1: "6",
  x2: "18",
  y1: "16",
  y2: "16",
  key: "pmt8us"
}]];
var Volleyball = [["path", {
  d: "M11.1 7.1a16.55 16.55 0 0 1 10.9 4",
  key: "2880wi"
}], ["path", {
  d: "M12 12a12.6 12.6 0 0 1-8.7 5",
  key: "113sja"
}], ["path", {
  d: "M16.8 13.6a16.55 16.55 0 0 1-9 7.5",
  key: "1qmsgl"
}], ["path", {
  d: "M20.7 17a12.8 12.8 0 0 0-8.7-5 13.3 13.3 0 0 1 0-10",
  key: "1bmeqp"
}], ["path", {
  d: "M6.3 3.8a16.55 16.55 0 0 0 1.9 11.5",
  key: "iekzv9"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "10",
  key: "1mglay"
}]];
var Volume1 = [["path", {
  d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  key: "uqj9uw"
}], ["path", {
  d: "M16 9a5 5 0 0 1 0 6",
  key: "1q6k2b"
}]];
var Volume2 = [["path", {
  d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  key: "uqj9uw"
}], ["path", {
  d: "M16 9a5 5 0 0 1 0 6",
  key: "1q6k2b"
}], ["path", {
  d: "M19.364 18.364a9 9 0 0 0 0-12.728",
  key: "ijwkga"
}]];
var VolumeOff = [["path", {
  d: "M16 9a5 5 0 0 1 .95 2.293",
  key: "1fgyg8"
}], ["path", {
  d: "M19.364 5.636a9 9 0 0 1 1.889 9.96",
  key: "l3zxae"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}], ["path", {
  d: "m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11",
  key: "1gbwow"
}], ["path", {
  d: "M9.828 4.172A.686.686 0 0 1 11 4.657v.686",
  key: "s2je0y"
}]];
var VolumeX = [["path", {
  d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  key: "uqj9uw"
}], ["line", {
  x1: "22",
  x2: "16",
  y1: "9",
  y2: "15",
  key: "1ewh16"
}], ["line", {
  x1: "16",
  x2: "22",
  y1: "9",
  y2: "15",
  key: "5ykzw1"
}]];
var Vote = [["path", {
  d: "m9 12 2 2 4-4",
  key: "dzmm74"
}], ["path", {
  d: "M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z",
  key: "1ezoue"
}], ["path", {
  d: "M22 19H2",
  key: "nuriw5"
}]];
var Volume = [["path", {
  d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
  key: "uqj9uw"
}]];
var WalletCards = [["rect", {
  width: "18",
  height: "18",
  x: "3",
  y: "3",
  rx: "2",
  key: "afitv7"
}], ["path", {
  d: "M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2",
  key: "4125el"
}], ["path", {
  d: "M3 11h3c.8 0 1.6.3 2.1.9l1.1.9c1.6 1.6 4.1 1.6 5.7 0l1.1-.9c.5-.5 1.3-.9 2.1-.9H21",
  key: "1dpki6"
}]];
var WalletMinimal = [["path", {
  d: "M17 14h.01",
  key: "7oqj8z"
}], ["path", {
  d: "M7 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14",
  key: "u1rqew"
}]];
var Wallet = [["path", {
  d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
  key: "18etb6"
}], ["path", {
  d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",
  key: "xoc0q4"
}]];
var Wallpaper = [["path", {
  d: "M12 17v4",
  key: "1riwvh"
}], ["path", {
  d: "M8 21h8",
  key: "1ev6f3"
}], ["path", {
  d: "m9 17 6.1-6.1a2 2 0 0 1 2.81.01L22 15",
  key: "1sl52q"
}], ["circle", {
  cx: "8",
  cy: "9",
  r: "2",
  key: "gjzl9d"
}], ["rect", {
  x: "2",
  y: "3",
  width: "20",
  height: "14",
  rx: "2",
  key: "x3v2xh"
}]];
var WandSparkles = [["path", {
  d: "m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",
  key: "ul74o6"
}], ["path", {
  d: "m14 7 3 3",
  key: "1r5n42"
}], ["path", {
  d: "M5 6v4",
  key: "ilb8ba"
}], ["path", {
  d: "M19 14v4",
  key: "blhpug"
}], ["path", {
  d: "M10 2v2",
  key: "7u0qdc"
}], ["path", {
  d: "M7 8H3",
  key: "zfb6yr"
}], ["path", {
  d: "M21 16h-4",
  key: "1cnmox"
}], ["path", {
  d: "M11 3H9",
  key: "1obp7u"
}]];
var Wand = [["path", {
  d: "M15 4V2",
  key: "z1p9b7"
}], ["path", {
  d: "M15 16v-2",
  key: "px0unx"
}], ["path", {
  d: "M8 9h2",
  key: "1g203m"
}], ["path", {
  d: "M20 9h2",
  key: "19tzq7"
}], ["path", {
  d: "M17.8 11.8 19 13",
  key: "yihg8r"
}], ["path", {
  d: "M15 9h.01",
  key: "x1ddxp"
}], ["path", {
  d: "M17.8 6.2 19 5",
  key: "fd4us0"
}], ["path", {
  d: "m3 21 9-9",
  key: "1jfql5"
}], ["path", {
  d: "M12.2 6.2 11 5",
  key: "i3da3b"
}]];
var Warehouse = [["path", {
  d: "M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11",
  key: "pb2vm6"
}], ["path", {
  d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z",
  key: "doq5xv"
}], ["path", {
  d: "M6 13h12",
  key: "yf64js"
}], ["path", {
  d: "M6 17h12",
  key: "1jwigz"
}]];
var WashingMachine = [["path", {
  d: "M3 6h3",
  key: "155dbl"
}], ["path", {
  d: "M17 6h.01",
  key: "e2y6kg"
}], ["rect", {
  width: "18",
  height: "20",
  x: "3",
  y: "2",
  rx: "2",
  key: "od3kk9"
}], ["circle", {
  cx: "12",
  cy: "13",
  r: "5",
  key: "nlbqau"
}], ["path", {
  d: "M12 18a2.5 2.5 0 0 0 0-5 2.5 2.5 0 0 1 0-5",
  key: "17lach"
}]];
var Watch = [["path", {
  d: "M12 10v2.2l1.6 1",
  key: "n3r21l"
}], ["path", {
  d: "m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05",
  key: "18k57s"
}], ["path", {
  d: "m7.88 16.36.8 4a2 2 0 0 0 2 1.61h2.72a2 2 0 0 0 2-1.61l.81-4.05",
  key: "16ny36"
}], ["circle", {
  cx: "12",
  cy: "12",
  r: "6",
  key: "1vlfrh"
}]];
var WavesArrowDown = [["path", {
  d: "M12 10L12 2",
  key: "jvb0aw"
}], ["path", {
  d: "M16 6L12 10L8 6",
  key: "9j6vje"
}], ["path", {
  d: "M2 15C2.6 15.5 3.2 16 4.5 16C7 16 7 14 9.5 14C12.1 14 11.9 16 14.5 16C17 16 17 14 19.5 14C20.8 14 21.4 14.5 22 15",
  key: "s2zepw"
}], ["path", {
  d: "M2 21C2.6 21.5 3.2 22 4.5 22C7 22 7 20 9.5 20C12.1 20 11.9 22 14.5 22C17 22 17 20 19.5 20C20.8 20 21.4 20.5 22 21",
  key: "u68omc"
}]];
var WavesArrowUp = [["path", {
  d: "M12 2v8",
  key: "1q4o3n"
}], ["path", {
  d: "M2 15c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "1p9f19"
}], ["path", {
  d: "M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "vbxynw"
}], ["path", {
  d: "m8 6 4-4 4 4",
  key: "ybng9g"
}]];
var WavesLadder = [["path", {
  d: "M19 5a2 2 0 0 0-2 2v11",
  key: "s41o68"
}], ["path", {
  d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "rd2r6e"
}], ["path", {
  d: "M7 13h10",
  key: "1rwob1"
}], ["path", {
  d: "M7 9h10",
  key: "12czzb"
}], ["path", {
  d: "M9 5a2 2 0 0 0-2 2v11",
  key: "x0q4gh"
}]];
var Waves = [["path", {
  d: "M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "knzxuh"
}], ["path", {
  d: "M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "2jd2cc"
}], ["path", {
  d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
  key: "rd2r6e"
}]];
var Waypoints = [["path", {
  d: "m10.586 5.414-5.172 5.172",
  key: "4mc350"
}], ["path", {
  d: "m18.586 13.414-5.172 5.172",
  key: "8c96vv"
}], ["path", {
  d: "M6 12h12",
  key: "8npq4p"
}], ["circle", {
  cx: "12",
  cy: "20",
  r: "2",
  key: "144qzu"
}], ["circle", {
  cx: "12",
  cy: "4",
  r: "2",
  key: "muu5ef"
}], ["circle", {
  cx: "20",
  cy: "12",
  r: "2",
  key: "1xzzfp"
}], ["circle", {
  cx: "4",
  cy: "12",
  r: "2",
  key: "1hvhnz"
}]];
var WebhookOff = [["path", {
  d: "M17 17h-5c-1.09-.02-1.94.92-2.5 1.9A3 3 0 1 1 2.57 15",
  key: "1tvl6x"
}], ["path", {
  d: "M9 3.4a4 4 0 0 1 6.52.66",
  key: "q04jfq"
}], ["path", {
  d: "m6 17 3.1-5.8a2.5 2.5 0 0 0 .057-2.05",
  key: "azowf0"
}], ["path", {
  d: "M20.3 20.3a4 4 0 0 1-2.3.7",
  key: "5joiws"
}], ["path", {
  d: "M18.6 13a4 4 0 0 1 3.357 3.414",
  key: "cangb8"
}], ["path", {
  d: "m12 6 .6 1",
  key: "tpjl1n"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Webcam = [["circle", {
  cx: "12",
  cy: "10",
  r: "8",
  key: "1gshiw"
}], ["circle", {
  cx: "12",
  cy: "10",
  r: "3",
  key: "ilqhr7"
}], ["path", {
  d: "M7 22h10",
  key: "10w4w3"
}], ["path", {
  d: "M12 22v-4",
  key: "1utk9m"
}]];
var Webhook = [["path", {
  d: "M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2",
  key: "q3hayz"
}], ["path", {
  d: "m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06",
  key: "1go1hn"
}], ["path", {
  d: "m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8",
  key: "qlwsc0"
}]];
var WeightTilde = [["path", {
  d: "M6.5 8a2 2 0 0 0-1.906 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8z",
  key: "1wl739"
}], ["path", {
  d: "M7.999 15a2.5 2.5 0 0 1 4 0 2.5 2.5 0 0 0 4 0",
  key: "1egezo"
}], ["circle", {
  cx: "12",
  cy: "5",
  r: "3",
  key: "rqqgnr"
}]];
var Weight = [["circle", {
  cx: "12",
  cy: "5",
  r: "3",
  key: "rqqgnr"
}], ["path", {
  d: "M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z",
  key: "56o5sh"
}]];
var WheatOff = [["path", {
  d: "m2 22 10-10",
  key: "28ilpk"
}], ["path", {
  d: "m16 8-1.17 1.17",
  key: "1qqm82"
}], ["path", {
  d: "M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
  key: "1rdhi6"
}], ["path", {
  d: "m8 8-.53.53a3.5 3.5 0 0 0 0 4.94L9 15l1.53-1.53c.55-.55.88-1.25.98-1.97",
  key: "4wz8re"
}], ["path", {
  d: "M10.91 5.26c.15-.26.34-.51.56-.73L13 3l1.53 1.53a3.5 3.5 0 0 1 .28 4.62",
  key: "rves66"
}], ["path", {
  d: "M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z",
  key: "19rau1"
}], ["path", {
  d: "M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
  key: "tc8ph9"
}], ["path", {
  d: "m16 16-.53.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.49 3.49 0 0 1 1.97-.98",
  key: "ak46r"
}], ["path", {
  d: "M18.74 13.09c.26-.15.51-.34.73-.56L21 11l-1.53-1.53a3.5 3.5 0 0 0-4.62-.28",
  key: "1tw520"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var WholeWord = [["circle", {
  cx: "7",
  cy: "12",
  r: "3",
  key: "12clwm"
}], ["path", {
  d: "M10 9v6",
  key: "17i7lo"
}], ["circle", {
  cx: "17",
  cy: "12",
  r: "3",
  key: "gl7c2s"
}], ["path", {
  d: "M14 7v8",
  key: "dl84cr"
}], ["path", {
  d: "M22 17v1c0 .5-.5 1-1 1H3c-.5 0-1-.5-1-1v-1",
  key: "lt2kga"
}]];
var Wheat = [["path", {
  d: "M2 22 16 8",
  key: "60hf96"
}], ["path", {
  d: "M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
  key: "1rdhi6"
}], ["path", {
  d: "M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
  key: "1sdzmb"
}], ["path", {
  d: "M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
  key: "eoatbi"
}], ["path", {
  d: "M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z",
  key: "19rau1"
}], ["path", {
  d: "M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
  key: "tc8ph9"
}], ["path", {
  d: "M15.47 13.47 17 15l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
  key: "2m8kc5"
}], ["path", {
  d: "M19.47 9.47 21 11l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L13 11l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
  key: "vex3ng"
}]];
var WifiHigh = [["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M5 12.859a10 10 0 0 1 14 0",
  key: "1x1e6c"
}], ["path", {
  d: "M8.5 16.429a5 5 0 0 1 7 0",
  key: "1bycff"
}]];
var WifiCog = [["path", {
  d: "m14.305 19.53.923-.382",
  key: "3m78fa"
}], ["path", {
  d: "m15.228 16.852-.923-.383",
  key: "npixar"
}], ["path", {
  d: "m16.852 15.228-.383-.923",
  key: "5xggr7"
}], ["path", {
  d: "m16.852 20.772-.383.924",
  key: "dpfhf9"
}], ["path", {
  d: "m19.148 15.228.383-.923",
  key: "1reyyz"
}], ["path", {
  d: "m19.53 21.696-.382-.924",
  key: "1goivc"
}], ["path", {
  d: "M2 7.82a15 15 0 0 1 20 0",
  key: "1ovjuk"
}], ["path", {
  d: "m20.772 16.852.924-.383",
  key: "htqkph"
}], ["path", {
  d: "m20.772 19.148.924.383",
  key: "9w9pjp"
}], ["path", {
  d: "M5 11.858a10 10 0 0 1 11.5-1.785",
  key: "3sn16i"
}], ["path", {
  d: "M8.5 15.429a5 5 0 0 1 2.413-1.31",
  key: "1pxovh"
}], ["circle", {
  cx: "18",
  cy: "18",
  r: "3",
  key: "1xkwt0"
}]];
var WifiLow = [["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M8.5 16.429a5 5 0 0 1 7 0",
  key: "1bycff"
}]];
var WifiOff = [["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M8.5 16.429a5 5 0 0 1 7 0",
  key: "1bycff"
}], ["path", {
  d: "M5 12.859a10 10 0 0 1 5.17-2.69",
  key: "1dl1wf"
}], ["path", {
  d: "M19 12.859a10 10 0 0 0-2.007-1.523",
  key: "4k23kn"
}], ["path", {
  d: "M2 8.82a15 15 0 0 1 4.177-2.643",
  key: "1grhjp"
}], ["path", {
  d: "M22 8.82a15 15 0 0 0-11.288-3.764",
  key: "z3jwby"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var WifiSync = [["path", {
  d: "M11.965 10.105v4L13.5 12.5a5 5 0 0 1 8 1.5",
  key: "1immaq"
}], ["path", {
  d: "M11.965 14.105h4",
  key: "uejny8"
}], ["path", {
  d: "M17.965 18.105h4L20.43 19.71a5 5 0 0 1-8-1.5",
  key: "1i3a7e"
}], ["path", {
  d: "M2 8.82a15 15 0 0 1 20 0",
  key: "dnpr2z"
}], ["path", {
  d: "M21.965 22.105v-4",
  key: "1ku6vx"
}], ["path", {
  d: "M5 12.86a10 10 0 0 1 3-2.032",
  key: "pemdtu"
}], ["path", {
  d: "M8.5 16.429h.01",
  key: "2bm739"
}]];
var WifiPen = [["path", {
  d: "M2 8.82a15 15 0 0 1 20 0",
  key: "dnpr2z"
}], ["path", {
  d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
  key: "1817ys"
}], ["path", {
  d: "M5 12.859a10 10 0 0 1 10.5-2.222",
  key: "rpb7oy"
}], ["path", {
  d: "M8.5 16.429a5 5 0 0 1 3-1.406",
  key: "r8bmzl"
}]];
var WifiZero = [["path", {
  d: "M12 20h.01",
  key: "zekei9"
}]];
var Wifi = [["path", {
  d: "M12 20h.01",
  key: "zekei9"
}], ["path", {
  d: "M2 8.82a15 15 0 0 1 20 0",
  key: "dnpr2z"
}], ["path", {
  d: "M5 12.859a10 10 0 0 1 14 0",
  key: "1x1e6c"
}], ["path", {
  d: "M8.5 16.429a5 5 0 0 1 7 0",
  key: "1bycff"
}]];
var WindArrowDown = [["path", {
  d: "M10 2v8",
  key: "d4bbey"
}], ["path", {
  d: "M12.8 21.6A2 2 0 1 0 14 18H2",
  key: "19kp1d"
}], ["path", {
  d: "M17.5 10a2.5 2.5 0 1 1 2 4H2",
  key: "19kpjc"
}], ["path", {
  d: "m6 6 4 4 4-4",
  key: "k13n16"
}]];
var Wind = [["path", {
  d: "M12.8 19.6A2 2 0 1 0 14 16H2",
  key: "148xed"
}], ["path", {
  d: "M17.5 8a2.5 2.5 0 1 1 2 4H2",
  key: "1u4tom"
}], ["path", {
  d: "M9.8 4.4A2 2 0 1 1 11 8H2",
  key: "75valh"
}]];
var WineOff = [["path", {
  d: "M8 22h8",
  key: "rmew8v"
}], ["path", {
  d: "M7 10h3m7 0h-1.343",
  key: "v48bem"
}], ["path", {
  d: "M12 15v7",
  key: "t2xh3l"
}], ["path", {
  d: "M7.307 7.307A12.33 12.33 0 0 0 7 10a5 5 0 0 0 7.391 4.391M8.638 2.981C8.75 2.668 8.872 2.34 9 2h6c1.5 4 2 6 2 8 0 .407-.05.809-.145 1.198",
  key: "1ymjlu"
}], ["line", {
  x1: "2",
  x2: "22",
  y1: "2",
  y2: "22",
  key: "a6p6uj"
}]];
var Workflow = [["rect", {
  width: "8",
  height: "8",
  x: "3",
  y: "3",
  rx: "2",
  key: "by2w9f"
}], ["path", {
  d: "M7 11v4a2 2 0 0 0 2 2h4",
  key: "xkn7yn"
}], ["rect", {
  width: "8",
  height: "8",
  x: "13",
  y: "13",
  rx: "2",
  key: "1cgmvn"
}]];
var Wine = [["path", {
  d: "M8 22h8",
  key: "rmew8v"
}], ["path", {
  d: "M7 10h10",
  key: "1101jm"
}], ["path", {
  d: "M12 15v7",
  key: "t2xh3l"
}], ["path", {
  d: "M12 15a5 5 0 0 0 5-5c0-2-.5-4-2-8H9c-1.5 4-2 6-2 8a5 5 0 0 0 5 5Z",
  key: "10ffi3"
}]];
var Worm = [["path", {
  d: "m19 12-1.5 3",
  key: "9bcu4o"
}], ["path", {
  d: "M19.63 18.81 22 20",
  key: "121v98"
}], ["path", {
  d: "M6.47 8.23a1.68 1.68 0 0 1 2.44 1.93l-.64 2.08a6.76 6.76 0 0 0 10.16 7.67l.42-.27a1 1 0 1 0-2.73-4.21l-.42.27a1.76 1.76 0 0 1-2.63-1.99l.64-2.08A6.66 6.66 0 0 0 3.94 3.9l-.7.4a1 1 0 1 0 2.55 4.34z",
  key: "1tij6q"
}]];
var XLineTop = [["path", {
  d: "M18 4H6",
  key: "1hsngl"
}], ["path", {
  d: "M18 8 6 20",
  key: "xspwia"
}], ["path", {
  d: "m6 8 12 12",
  key: "qb1veh"
}]];
var Wrench = [["path", {
  d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
  key: "1ngwbx"
}]];
var X = [["path", {
  d: "M18 6 6 18",
  key: "1bl5f8"
}], ["path", {
  d: "m6 6 12 12",
  key: "d8bk6v"
}]];
var Youtube = [["path", {
  d: "M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17",
  key: "1q2vi4"
}], ["path", {
  d: "m10 15 5-3-5-3z",
  key: "1jp15x"
}]];
var ZapOff = [["path", {
  d: "M10.513 4.856 13.12 2.17a.5.5 0 0 1 .86.46l-1.377 4.317",
  key: "193nxd"
}], ["path", {
  d: "M15.656 10H20a1 1 0 0 1 .78 1.63l-1.72 1.773",
  key: "27a7lr"
}], ["path", {
  d: "M16.273 16.273 10.88 21.83a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14H4a1 1 0 0 1-.78-1.63l4.507-4.643",
  key: "1e0qe9"
}], ["path", {
  d: "m2 2 20 20",
  key: "1ooewy"
}]];
var Zap = [["path", {
  d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
  key: "1xq2db"
}]];
var ZodiacAquarius = [["path", {
  d: "m2 10 2.456-3.684a.7.7 0 0 1 1.106-.013l2.39 3.413a.7.7 0 0 0 1.096-.001l2.402-3.432a.7.7 0 0 1 1.098 0l2.402 3.432a.7.7 0 0 0 1.098 0l2.389-3.413a.7.7 0 0 1 1.106.013L22 10",
  key: "1o8iok"
}], ["path", {
  d: "m2 18.002 2.456-3.684a.7.7 0 0 1 1.106-.013l2.39 3.413a.7.7 0 0 0 1.097 0l2.402-3.432a.7.7 0 0 1 1.098 0l2.402 3.432a.7.7 0 0 0 1.098 0l2.389-3.413a.7.7 0 0 1 1.106.013L22 18.002",
  key: "112qy7"
}]];
var ZodiacAries = [["path", {
  d: "M12 7.5a4.5 4.5 0 1 1 5 4.5",
  key: "k987hv"
}], ["path", {
  d: "M7 12a4.5 4.5 0 1 1 5-4.5V21",
  key: "mjup0w"
}]];
var ZodiacCancer = [["path", {
  d: "M21 14.5A9 6.5 0 0 1 5.5 19",
  key: "1xj2o6"
}], ["path", {
  d: "M3 9.5A9 6.5 0 0 1 18.5 5",
  key: "1gln3t"
}], ["circle", {
  cx: "17.5",
  cy: "14.5",
  r: "3.5",
  key: "1ccu1t"
}], ["circle", {
  cx: "6.5",
  cy: "9.5",
  r: "3.5",
  key: "x5tc2d"
}]];
var ZodiacCapricorn = [["path", {
  d: "M11 21a3 3 0 0 0 3-3V6.5a1 1 0 0 0-7 0",
  key: "1kkncs"
}], ["path", {
  d: "M7 19V6a3 3 0 0 0-3-3h0",
  key: "1jg5y1"
}], ["circle", {
  cx: "17",
  cy: "17",
  r: "3",
  key: "18b49y"
}]];
var ZodiacGemini = [["path", {
  d: "M16 4.525v14.948",
  key: "bgoxo0"
}], ["path", {
  d: "M20 3A17 17 0 0 1 4 3",
  key: "1djemw"
}], ["path", {
  d: "M4 21a17 17 0 0 1 16 0",
  key: "onoyo7"
}], ["path", {
  d: "M8 4.525v14.948",
  key: "u5iyof"
}]];
var ZodiacLibra = [["path", {
  d: "M3 16h6.857c.162-.012.19-.323.038-.38a6 6 0 1 1 4.212 0c-.153.057-.125.368.038.38H21",
  key: "1novf0"
}], ["path", {
  d: "M3 20h18",
  key: "1l19wn"
}]];
var ZodiacLeo = [["path", {
  d: "M10 16c0-4-3-4.5-3-8a5 5 0 0 1 10 0c0 3.466-3 6.196-3 10a3 3 0 0 0 6 0",
  key: "1qj6nb"
}], ["circle", {
  cx: "7",
  cy: "16",
  r: "3",
  key: "yyv3zl"
}]];
var ZodiacOphiuchus = [["path", {
  d: "M3 10A6.06 6.06 0 0 1 12 10 A6.06 6.06 0 0 0 21 10",
  key: "13lfmc"
}], ["path", {
  d: "M6 3v12a6 6 0 0 0 12 0V3",
  key: "1jnivp"
}]];
var ZodiacPisces = [["path", {
  d: "M19 21a15 15 0 0 1 0-18",
  key: "br2vug"
}], ["path", {
  d: "M20 12H4",
  key: "1mtusc"
}], ["path", {
  d: "M5 3a15 15 0 0 1 0 18",
  key: "1w7hae"
}]];
var ZodiacSagittarius = [["path", {
  d: "M15 3h6v6",
  key: "1q9fwt"
}], ["path", {
  d: "M21 3 3 21",
  key: "1011np"
}], ["path", {
  d: "m9 9 6 6",
  key: "z0biqf"
}]];
var ZodiacTaurus = [["circle", {
  cx: "12",
  cy: "15",
  r: "6",
  key: "lhqcmb"
}], ["path", {
  d: "M18 3A6 6 0 0 1 6 3",
  key: "1p399e"
}]];
var ZodiacScorpio = [["path", {
  d: "M10 19V5.5a1 1 0 0 1 5 0V17a2 2 0 0 0 2 2h5l-3-3",
  key: "1w8g0z"
}], ["path", {
  d: "m22 19-3 3",
  key: "1ix4wq"
}], ["path", {
  d: "M5 19V5.5a1 1 0 0 1 5 0",
  key: "1d4oa3"
}], ["path", {
  d: "M5 5.5A2.5 2.5 0 0 0 2.5 3",
  key: "gp646f"
}]];
var ZoomIn = [["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["line", {
  x1: "21",
  x2: "16.65",
  y1: "21",
  y2: "16.65",
  key: "13gj7c"
}], ["line", {
  x1: "11",
  x2: "11",
  y1: "8",
  y2: "14",
  key: "1vmskp"
}], ["line", {
  x1: "8",
  x2: "14",
  y1: "11",
  y2: "11",
  key: "durymu"
}]];
var ZodiacVirgo = [["path", {
  d: "M11 5.5a1 1 0 0 1 5 0V16a5 5 0 0 0 5 5",
  key: "1szkuh"
}], ["path", {
  d: "M16 11.5a1 1 0 0 1 5 0V16a5 5 0 0 1-5 5",
  key: "pyq0k2"
}], ["path", {
  d: "M6 19V6a3 3 0 0 0-3-3h0",
  key: "pvee4g"
}], ["path", {
  d: "M6 5.5a1 1 0 0 1 5 0V19",
  key: "vncctg"
}]];
var ZoomOut = [["circle", {
  cx: "11",
  cy: "11",
  r: "8",
  key: "4ej97u"
}], ["line", {
  x1: "21",
  x2: "16.65",
  y1: "21",
  y2: "16.65",
  key: "13gj7c"
}], ["line", {
  x1: "8",
  x2: "14",
  y1: "11",
  y2: "11",
  key: "durymu"
}]];
var lucideIcons = Object.freeze({
  __proto__: null,
  AArrowDown,
  AArrowUp,
  Accessibility,
  ALargeSmall,
  Activity,
  AirVent,
  Airplay,
  AlarmClockCheck,
  AlarmClockMinus,
  AlarmClockOff,
  AlarmClockPlus,
  AlarmClock,
  AlarmSmoke,
  Album,
  AlignCenterHorizontal,
  AlignCenterVertical,
  AlignEndHorizontal,
  AlignEndVertical,
  AlignHorizontalDistributeCenter,
  AlignHorizontalDistributeEnd,
  AlignHorizontalDistributeStart,
  AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyEnd,
  AlignHorizontalJustifyStart,
  AlignHorizontalSpaceAround,
  AlignHorizontalSpaceBetween,
  AlignStartHorizontal,
  AlignStartVertical,
  AlignVerticalDistributeCenter,
  AlignVerticalDistributeEnd,
  AlignVerticalDistributeStart,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd,
  AlignVerticalJustifyStart,
  AlignVerticalSpaceAround,
  AlignVerticalSpaceBetween,
  Ambulance,
  Ampersands,
  Ampersand,
  Amphora,
  Anchor,
  Angry,
  Antenna,
  Annoyed,
  Anvil,
  Aperture,
  AppWindowMac,
  AppWindow,
  Apple,
  ArchiveRestore,
  ArchiveX,
  Archive,
  Armchair,
  ArrowBigDownDash,
  ArrowBigDown,
  ArrowBigLeftDash,
  ArrowBigLeft,
  ArrowBigRightDash,
  ArrowBigRight,
  ArrowBigUpDash,
  ArrowBigUp,
  ArrowDown01,
  ArrowDown10,
  ArrowDownFromLine,
  ArrowDownAZ,
  ArrowDownLeft,
  ArrowDownNarrowWide,
  ArrowDownRight,
  ArrowDownToDot,
  ArrowDownToLine,
  ArrowDownUp,
  ArrowDownWideNarrow,
  ArrowDownZA,
  ArrowDown,
  ArrowLeftFromLine,
  ArrowLeftRight,
  ArrowLeftToLine,
  ArrowLeft,
  ArrowRightFromLine,
  ArrowRightLeft,
  ArrowRightToLine,
  ArrowRight,
  ArrowUp01,
  ArrowUp10,
  ArrowUpAZ,
  ArrowUpFromDot,
  ArrowUpDown,
  ArrowUpFromLine,
  ArrowUpLeft,
  ArrowUpNarrowWide,
  ArrowUpRight,
  ArrowUpToLine,
  ArrowUpWideNarrow,
  ArrowUpZA,
  ArrowUp,
  ArrowsUpFromLine,
  Asterisk,
  AtSign,
  Atom,
  AudioLines,
  AudioWaveform,
  Award,
  Axe,
  Axis3d,
  Baby,
  Backpack,
  BadgeAlert,
  BadgeCent,
  BadgeCheck,
  BadgeDollarSign,
  BadgeEuro,
  BadgeIndianRupee,
  BadgeInfo,
  BadgeJapaneseYen,
  BadgeMinus,
  BadgePercent,
  BadgePoundSterling,
  BadgeQuestionMark,
  BadgePlus,
  BadgeRussianRuble,
  BadgeSwissFranc,
  BadgeTurkishLira,
  BadgeX,
  Badge,
  BaggageClaim,
  Balloon,
  Ban,
  Banana,
  Bandage,
  BanknoteArrowDown,
  BanknoteArrowUp,
  BanknoteX,
  Banknote,
  Barcode,
  Barrel,
  Baseline,
  Bath,
  BatteryCharging,
  BatteryLow,
  BatteryFull,
  BatteryMedium,
  BatteryPlus,
  BatteryWarning,
  Battery,
  Beaker,
  BeanOff,
  Bean,
  BedDouble,
  BedSingle,
  Bed,
  Beef,
  BeerOff,
  Beer,
  BellDot,
  BellElectric,
  BellMinus,
  BellOff,
  BellPlus,
  BellRing,
  Bell,
  BetweenHorizontalEnd,
  BetweenHorizontalStart,
  BetweenVerticalEnd,
  BetweenVerticalStart,
  Bike,
  Binary,
  BicepsFlexed,
  Binoculars,
  Biohazard,
  Bird,
  Birdhouse,
  Bitcoin,
  Blend,
  Blinds,
  Blocks,
  BluetoothConnected,
  BluetoothOff,
  BluetoothSearching,
  Bluetooth,
  Bold,
  Bolt,
  Bomb,
  Bone,
  BookA,
  BookAlert,
  BookAudio,
  BookCheck,
  BookCopy,
  BookDashed,
  BookDown,
  BookHeart,
  BookHeadphones,
  BookImage,
  BookKey,
  BookLock,
  BookMarked,
  BookMinus,
  BookOpenCheck,
  BookOpenText,
  BookOpen,
  BookPlus,
  BookSearch,
  BookText,
  BookType,
  BookUp2,
  BookUp,
  BookUser,
  BookX,
  Book,
  BookmarkCheck,
  BookmarkMinus,
  BookmarkPlus,
  Bookmark,
  BookmarkX,
  BoomBox,
  BotMessageSquare,
  BotOff,
  Bot,
  BottleWine,
  BowArrow,
  Boxes,
  Box,
  Braces,
  Brackets,
  BrainCircuit,
  BrainCog,
  Brain,
  BrickWallFire,
  BrickWallShield,
  BrickWall,
  BriefcaseBusiness,
  BriefcaseConveyorBelt,
  BriefcaseMedical,
  Briefcase,
  BringToFront,
  BrushCleaning,
  Brush,
  Bubbles,
  BugOff,
  BugPlay,
  Bug,
  Building,
  Building2,
  BusFront,
  Bus,
  CableCar,
  Cable,
  CakeSlice,
  Cake,
  Calculator,
  Calendar1,
  CalendarArrowDown,
  CalendarArrowUp,
  CalendarCheck,
  CalendarCheck2,
  CalendarClock,
  CalendarCog,
  CalendarDays,
  CalendarFold,
  CalendarHeart,
  CalendarMinus2,
  CalendarMinus,
  CalendarOff,
  CalendarPlus2,
  CalendarRange,
  CalendarPlus,
  CalendarSearch,
  CalendarSync,
  CalendarX,
  CalendarX2,
  Calendar,
  Calendars,
  CameraOff,
  Camera,
  CandyCane,
  CandyOff,
  Candy,
  CannabisOff,
  Cannabis,
  CaptionsOff,
  Captions,
  CarFront,
  CarTaxiFront,
  Caravan,
  Car,
  CardSim,
  Carrot,
  CaseLower,
  CaseSensitive,
  CaseUpper,
  CassetteTape,
  Cast,
  Castle,
  Cat,
  CctvOff,
  Cctv,
  ChartBarBig,
  ChartBarDecreasing,
  ChartArea,
  ChartBarIncreasing,
  ChartBarStacked,
  ChartBar,
  ChartCandlestick,
  ChartColumnBig,
  ChartColumnDecreasing,
  ChartColumnIncreasing,
  ChartColumnStacked,
  ChartColumn,
  ChartGantt,
  ChartLine,
  ChartNetwork,
  ChartNoAxesColumnDecreasing,
  ChartNoAxesColumnIncreasing,
  ChartNoAxesColumn,
  ChartNoAxesCombined,
  ChartPie,
  ChartNoAxesGantt,
  ChartScatter,
  ChartSpline,
  CheckCheck,
  CheckLine,
  Check,
  ChefHat,
  Cherry,
  ChessBishop,
  ChessKing,
  ChessKnight,
  ChessPawn,
  ChessQueen,
  ChessRook,
  ChevronDown,
  ChevronFirst,
  ChevronLast,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronsDownUp,
  ChevronsDown,
  ChevronsLeftRightEllipsis,
  ChevronsLeftRight,
  ChevronsLeft,
  ChevronsRightLeft,
  ChevronsRight,
  ChevronsUpDown,
  ChevronsUp,
  Chromium,
  Church,
  CigaretteOff,
  Cigarette,
  CircleAlert,
  CircleArrowDown,
  CircleArrowLeft,
  CircleArrowOutDownLeft,
  CircleArrowOutDownRight,
  CircleArrowOutUpLeft,
  CircleArrowOutUpRight,
  CircleArrowRight,
  CircleArrowUp,
  CircleCheckBig,
  CircleCheck,
  CircleChevronDown,
  CircleChevronLeft,
  CircleChevronRight,
  CircleChevronUp,
  CircleDashed,
  CircleDivide,
  CircleDollarSign,
  CircleDotDashed,
  CircleDot,
  CircleEllipsis,
  CircleEqual,
  CircleFadingArrowUp,
  CircleFadingPlus,
  CircleGauge,
  CircleMinus,
  CircleOff,
  CircleParkingOff,
  CircleParking,
  CirclePause,
  CirclePercent,
  CirclePile,
  CirclePlay,
  CirclePlus,
  CirclePower,
  CirclePoundSterling,
  CircleQuestionMark,
  CircleSlash2,
  CircleSlash,
  CircleSmall,
  CircleStar,
  CircleStop,
  CircleUserRound,
  CircleUser,
  CircleX,
  Circle,
  CircuitBoard,
  Clapperboard,
  Citrus,
  ClipboardCheck,
  ClipboardClock,
  ClipboardCopy,
  ClipboardList,
  ClipboardMinus,
  ClipboardPaste,
  ClipboardPenLine,
  ClipboardPen,
  ClipboardPlus,
  ClipboardType,
  ClipboardX,
  Clipboard,
  Clock1,
  Clock10,
  Clock11,
  Clock12,
  Clock2,
  Clock3,
  Clock4,
  Clock5,
  Clock6,
  Clock7,
  Clock8,
  Clock9,
  ClockAlert,
  ClockArrowDown,
  ClockArrowUp,
  ClockCheck,
  ClockFading,
  Clock,
  ClockPlus,
  ClosedCaption,
  CloudAlert,
  CloudBackup,
  CloudCheck,
  CloudDownload,
  CloudCog,
  CloudDrizzle,
  CloudFog,
  CloudHail,
  CloudLightning,
  CloudMoonRain,
  CloudMoon,
  CloudOff,
  CloudRainWind,
  CloudRain,
  CloudSnow,
  CloudSunRain,
  CloudSun,
  CloudSync,
  CloudUpload,
  Cloud,
  Cloudy,
  Clover,
  Club,
  CodeXml,
  Code,
  Codepen,
  Codesandbox,
  Cog,
  Coffee,
  Columns2,
  Coins,
  Columns3Cog,
  Columns3,
  Columns4,
  Combine,
  Command,
  Component: Component2,
  Compass,
  Computer,
  ConciergeBell,
  Cone,
  Construction,
  ContactRound,
  Contact,
  Container,
  Contrast,
  Cookie,
  CookingPot,
  CopyCheck,
  CopyMinus,
  CopyPlus,
  CopySlash,
  CopyX,
  Copy,
  Copyleft,
  Copyright,
  CornerDownLeft,
  CornerDownRight,
  CornerLeftDown,
  CornerLeftUp,
  CornerRightDown,
  CornerUpLeft,
  CornerRightUp,
  CornerUpRight,
  Cpu,
  CreativeCommons,
  CreditCard,
  Croissant,
  Crop,
  Crosshair,
  Cross,
  Crown,
  Cuboid,
  CupSoda,
  Currency,
  Cylinder,
  DatabaseBackup,
  Dam,
  DatabaseSearch,
  DatabaseZap,
  Database,
  DecimalsArrowLeft,
  DecimalsArrowRight,
  Delete,
  Dessert,
  Diameter,
  DiamondMinus,
  DiamondPercent,
  DiamondPlus,
  Diamond,
  Dice1,
  Dice2,
  Dice3,
  Dice4,
  Dice5,
  Dice6,
  Dices,
  Diff,
  Disc2,
  Disc3,
  DiscAlbum,
  Disc,
  Divide,
  DnaOff,
  Dna,
  Dock,
  Dog,
  DollarSign,
  Donut,
  DoorClosedLocked,
  DoorOpen,
  DoorClosed,
  Dot,
  Download,
  DraftingCompass,
  Drama,
  Dribbble,
  Drill,
  Drone,
  DropletOff,
  Droplet,
  Droplets,
  Drum,
  Drumstick,
  Dumbbell,
  EarOff,
  Ear,
  EarthLock,
  Earth,
  Eclipse,
  EggFried,
  EggOff,
  Egg,
  Ellipse,
  EllipsisVertical,
  Ellipsis,
  EqualApproximately,
  EqualNot,
  Eraser,
  Equal,
  EthernetPort,
  Euro,
  EvCharger,
  Expand,
  ExternalLink,
  EyeClosed,
  EyeOff,
  Eye,
  Factory,
  Fan,
  Facebook,
  FastForward,
  Feather,
  Fence,
  FerrisWheel,
  Figma,
  FileArchive,
  FileAxis3d,
  FileBadge,
  FileBox,
  FileBracesCorner,
  FileBraces,
  FileChartColumnIncreasing,
  FileChartColumn,
  FileChartLine,
  FileChartPie,
  FileCheckCorner,
  FileClock,
  FileCheck,
  FileCodeCorner,
  FileCode,
  FileCog,
  FileDigit,
  FileDiff,
  FileDown,
  FileExclamationPoint,
  FileHeadphone,
  FileHeart,
  FileImage,
  FileInput,
  FileKey,
  FileLock,
  FileMinusCorner,
  FileMinus,
  FileMusic,
  FileOutput,
  FilePenLine,
  FilePen,
  FilePlay,
  FilePlusCorner,
  FilePlus,
  FileQuestionMark,
  FileScan,
  FileSearchCorner,
  FileSignal,
  FileSearch,
  FileSliders,
  FileSpreadsheet,
  FileStack,
  FileSymlink,
  FileTerminal,
  FileText,
  FileTypeCorner,
  FileType,
  FileUp,
  FileVideoCamera,
  FileVolume,
  FileUser,
  FileXCorner,
  FileX,
  File,
  Files,
  Film,
  FingerprintPattern,
  FireExtinguisher,
  FishOff,
  Fish,
  FishSymbol,
  FishingHook,
  FishingRod,
  FlagOff,
  FlagTriangleLeft,
  FlagTriangleRight,
  Flag,
  FlameKindling,
  Flame,
  Flashlight,
  FlashlightOff,
  FlaskConicalOff,
  FlaskConical,
  FlaskRound,
  FlipHorizontal2,
  FlipVertical2,
  Flower2,
  Flower,
  Focus,
  FoldHorizontal,
  FoldVertical,
  FolderCheck,
  FolderArchive,
  FolderClock,
  FolderClosed,
  FolderCode,
  FolderCog,
  FolderDot,
  FolderDown,
  FolderGit2,
  FolderHeart,
  FolderGit,
  FolderInput,
  FolderKanban,
  FolderKey,
  FolderLock,
  FolderMinus,
  FolderOpenDot,
  FolderOpen,
  FolderOutput,
  FolderPen,
  FolderPlus,
  FolderRoot,
  FolderSearch2,
  FolderSearch,
  FolderSymlink,
  FolderSync,
  FolderTree,
  FolderUp,
  FolderX,
  Folder,
  Folders,
  Footprints,
  Forklift,
  Form,
  Forward,
  Frame,
  Framer,
  Frown,
  Fuel,
  Fullscreen,
  FunnelPlus,
  FunnelX,
  Funnel,
  GalleryHorizontalEnd,
  GalleryHorizontal,
  GalleryVerticalEnd,
  GalleryThumbnails,
  GalleryVertical,
  Gamepad2,
  GamepadDirectional,
  Gamepad,
  Gavel,
  Gauge,
  Gem,
  GeorgianLari,
  Ghost,
  Gift,
  GitBranchMinus,
  GitBranchPlus,
  GitBranch,
  GitCommitHorizontal,
  GitCommitVertical,
  GitCompareArrows,
  GitCompare,
  GitFork,
  GitGraph,
  GitMergeConflict,
  GitMerge,
  GitPullRequestArrow,
  GitPullRequestClosed,
  GitPullRequestCreateArrow,
  GitPullRequestCreate,
  GitPullRequestDraft,
  GitPullRequest,
  Github,
  Gitlab,
  Glasses,
  GlassWater,
  GlobeLock,
  GlobeX,
  Globe,
  GlobeOff,
  Goal,
  Gpu,
  GraduationCap,
  Grape,
  Grid2x2Check,
  Grid2x2Plus,
  Grid2x2X,
  Grid2x2,
  Grid3x2,
  Grid3x3,
  GripHorizontal,
  GripVertical,
  Grip,
  Group,
  Guitar,
  Ham,
  Hamburger,
  Hammer,
  HandCoins,
  HandGrab,
  HandFist,
  HandHeart,
  HandMetal,
  HandHelping,
  HandPlatter,
  Hand,
  Handbag,
  Handshake,
  HardDriveDownload,
  HardDriveUpload,
  HardDrive,
  HardHat,
  HatGlasses,
  Hash,
  Haze,
  Hd,
  HdmiPort,
  Heading1,
  Heading2,
  Heading3,
  Heading4,
  Heading5,
  Heading6,
  Heading,
  HeadphoneOff,
  Headphones,
  Headset,
  HeartCrack,
  HeartHandshake,
  HeartMinus,
  HeartOff,
  HeartPlus,
  HeartPulse,
  Heart,
  Heater,
  Helicopter,
  Hexagon,
  Highlighter,
  History,
  HopOff,
  Hospital,
  Hop,
  Hotel,
  Hourglass,
  HouseHeart,
  HousePlug,
  HousePlus,
  HouseWifi,
  House,
  IceCreamBowl,
  IceCreamCone,
  IdCardLanyard,
  IdCard,
  ImageDown,
  ImageMinus,
  ImageOff,
  ImagePlay,
  ImagePlus,
  ImageUp,
  ImageUpscale,
  Image,
  Images,
  Import,
  Inbox,
  IndianRupee,
  Infinity,
  Info,
  InspectionPanel,
  Instagram,
  IterationCcw,
  Italic,
  IterationCw,
  JapaneseYen,
  Joystick,
  Kanban,
  Kayak,
  KeyRound,
  KeySquare,
  Key,
  KeyboardOff,
  KeyboardMusic,
  LampCeiling,
  Keyboard,
  LampFloor,
  LampDesk,
  LampWallDown,
  LampWallUp,
  Lamp,
  LandPlot,
  Landmark,
  Languages,
  LaptopMinimalCheck,
  LaptopMinimal,
  Laptop,
  LassoSelect,
  Lasso,
  Laugh,
  Layers2,
  LayersPlus,
  Layers,
  LayoutDashboard,
  LayoutGrid,
  LayoutList,
  LayoutPanelLeft,
  LayoutPanelTop,
  LayoutTemplate,
  Leaf,
  LeafyGreen,
  Lectern,
  LensConcave,
  LensConvex,
  LibraryBig,
  Library,
  LifeBuoy,
  Ligature,
  LightbulbOff,
  Lightbulb,
  LineDotRightHorizontal,
  LineSquiggle,
  Link2Off,
  Link2,
  Link,
  Linkedin,
  ListCheck,
  ListChecks,
  ListChevronsDownUp,
  ListChevronsUpDown,
  ListCollapse,
  ListEnd,
  ListFilterPlus,
  ListFilter,
  ListIndentDecrease,
  ListIndentIncrease,
  ListMinus,
  ListMusic,
  ListOrdered,
  ListRestart,
  ListPlus,
  ListTodo,
  ListStart,
  ListTree,
  ListVideo,
  ListX,
  List,
  LoaderCircle,
  LoaderPinwheel,
  Loader,
  LocateFixed,
  LocateOff,
  Locate,
  LockKeyholeOpen,
  LockKeyhole,
  LockOpen,
  Lock,
  LogIn,
  LogOut,
  Logs,
  Lollipop,
  Luggage,
  Magnet,
  MailCheck,
  MailMinus,
  MailOpen,
  MailPlus,
  MailQuestionMark,
  MailSearch,
  MailWarning,
  MailX,
  Mail,
  Mails,
  Mailbox,
  MapMinus,
  MapPinCheckInside,
  MapPinCheck,
  MapPinHouse,
  MapPinMinusInside,
  MapPinMinus,
  MapPinOff,
  MapPinPen,
  MapPinPlusInside,
  MapPinPlus,
  MapPinXInside,
  MapPinX,
  MapPin,
  MapPinned,
  MapPlus,
  Map,
  MarsStroke,
  Mars,
  Martini,
  Maximize2,
  Maximize,
  Medal,
  MegaphoneOff,
  Megaphone,
  Meh,
  MemoryStick,
  Menu,
  Merge,
  MessageCircleCheck,
  MessageCircleCode,
  MessageCircleDashed,
  MessageCircleHeart,
  MessageCircleMore,
  MessageCircleOff,
  MessageCirclePlus,
  MessageCircleQuestionMark,
  MessageCircleReply,
  MessageCircleWarning,
  MessageCircleX,
  MessageCircle,
  MessageSquareCheck,
  MessageSquareCode,
  MessageSquareDashed,
  MessageSquareDiff,
  MessageSquareDot,
  MessageSquareHeart,
  MessageSquareLock,
  MessageSquareMore,
  MessageSquareOff,
  MessageSquarePlus,
  MessageSquareQuote,
  MessageSquareReply,
  MessageSquareShare,
  MessageSquareText,
  MessageSquareWarning,
  MessageSquareX,
  MessageSquare,
  MessagesSquare,
  Metronome,
  MicOff,
  MicVocal,
  Mic,
  Microchip,
  Microscope,
  Microwave,
  Milestone,
  MilkOff,
  Minimize2,
  Milk,
  Minimize,
  Minus,
  MirrorRectangular,
  MonitorCheck,
  MirrorRound,
  MonitorCog,
  MonitorCloud,
  MonitorDot,
  MonitorDown,
  MonitorOff,
  MonitorPause,
  MonitorPlay,
  MonitorSmartphone,
  MonitorSpeaker,
  MonitorStop,
  MonitorUp,
  MonitorX,
  Monitor,
  MoonStar,
  Moon,
  Motorbike,
  MountainSnow,
  Mountain,
  MouseOff,
  MouseLeft,
  MousePointer2Off,
  MousePointer2,
  MousePointerBan,
  MousePointer,
  MousePointerClick,
  MouseRight,
  Mouse,
  Move3d,
  MoveDiagonal2,
  MoveDiagonal,
  MoveDownLeft,
  MoveDownRight,
  MoveDown,
  MoveHorizontal,
  MoveLeft,
  MoveRight,
  MoveUpLeft,
  MoveUp,
  MoveUpRight,
  MoveVertical,
  Move,
  Music2,
  Music3,
  Music4,
  Music,
  Navigation2Off,
  Navigation2,
  NavigationOff,
  Navigation,
  Network,
  Nfc,
  NonBinary,
  Newspaper,
  NotebookPen,
  NotebookTabs,
  NotebookText,
  NotepadTextDashed,
  Notebook,
  NotepadText,
  NutOff,
  Nut,
  OctagonAlert,
  OctagonMinus,
  OctagonPause,
  OctagonX,
  Octagon,
  Option,
  Orbit,
  Omega,
  Origami,
  Package2,
  PackageMinus,
  PackageCheck,
  PackageOpen,
  PackagePlus,
  PackageSearch,
  PackageX,
  Package,
  PaintBucket,
  PaintRoller,
  PaintbrushVertical,
  Paintbrush,
  Palette,
  Panda,
  PanelBottomClose,
  PanelBottomDashed,
  PanelBottomOpen,
  PanelBottom,
  PanelLeftClose,
  PanelLeftDashed,
  PanelLeftOpen,
  PanelLeftRightDashed,
  PanelLeft,
  PanelRightClose,
  PanelRightDashed,
  PanelRightOpen,
  PanelRight,
  PanelTopBottomDashed,
  PanelTopClose,
  PanelTopDashed,
  PanelTop,
  PanelTopOpen,
  PanelsLeftBottom,
  PanelsRightBottom,
  PanelsTopLeft,
  Paperclip,
  Parentheses,
  ParkingMeter,
  PartyPopper,
  Pause,
  PawPrint,
  PcCase,
  PenLine,
  PenOff,
  PenTool,
  Pen,
  PencilLine,
  PencilOff,
  PencilRuler,
  Pencil,
  Pentagon,
  Percent,
  PersonStanding,
  PhilippinePeso,
  PhoneCall,
  PhoneForwarded,
  PhoneIncoming,
  PhoneMissed,
  PhoneOff,
  PhoneOutgoing,
  Phone,
  Piano,
  Pi,
  Pickaxe,
  PictureInPicture2,
  PictureInPicture,
  PiggyBank,
  PilcrowLeft,
  PilcrowRight,
  Pilcrow,
  PillBottle,
  Pill,
  PinOff,
  Pin,
  Pipette,
  Pizza,
  PlaneLanding,
  PlaneTakeoff,
  Plane,
  Play,
  Plug2,
  PlugZap,
  Plug,
  Plus,
  PocketKnife,
  Pocket,
  Podcast,
  Pointer,
  PointerOff,
  Popcorn,
  Popsicle,
  PoundSterling,
  PowerOff,
  Power,
  Presentation,
  PrinterCheck,
  PrinterX,
  Projector,
  Printer,
  Proportions,
  Puzzle,
  Pyramid,
  QrCode,
  Quote,
  Rabbit,
  Radar,
  Radiation,
  Radical,
  RadioReceiver,
  RadioTower,
  Radio,
  Radius,
  RailSymbol,
  Rainbow,
  Rat,
  Ratio,
  ReceiptCent,
  ReceiptEuro,
  ReceiptIndianRupee,
  ReceiptJapaneseYen,
  ReceiptPoundSterling,
  ReceiptRussianRuble,
  ReceiptSwissFranc,
  ReceiptText,
  ReceiptTurkishLira,
  Receipt,
  RectangleCircle,
  RectangleEllipsis,
  RectangleGoggles,
  RectangleHorizontal,
  RectangleVertical,
  Recycle,
  Redo2,
  RedoDot,
  Redo,
  RefreshCcwDot,
  RefreshCcw,
  RefreshCwOff,
  RefreshCw,
  Refrigerator,
  Regex,
  RemoveFormatting,
  Repeat1,
  Repeat2,
  Repeat,
  ReplaceAll,
  Replace,
  Reply,
  ReplyAll,
  Rewind,
  Ribbon,
  Rocket,
  RockingChair,
  RollerCoaster,
  Rose,
  Rotate3d,
  RotateCcwKey,
  RotateCcwSquare,
  RotateCcw,
  RotateCwSquare,
  RotateCw,
  RouteOff,
  Route,
  Router,
  Rows2,
  Rows3,
  Rows4,
  Rss,
  RulerDimensionLine,
  RussianRuble,
  Ruler,
  Sailboat,
  Salad,
  Sandwich,
  SatelliteDish,
  Satellite,
  SaudiRiyal,
  SaveAll,
  SaveOff,
  Save,
  Scale3d,
  Scale,
  Scaling,
  ScanBarcode,
  ScanEye,
  ScanFace,
  ScanHeart,
  ScanLine,
  ScanQrCode,
  ScanSearch,
  ScanText,
  Scan,
  School,
  ScissorsLineDashed,
  Scissors,
  Scooter,
  ScreenShare,
  ScreenShareOff,
  ScrollText,
  Scroll,
  SearchAlert,
  SearchCheck,
  SearchCode,
  SearchX,
  SearchSlash,
  Search,
  Section,
  SendToBack,
  SendHorizontal,
  Send,
  SeparatorHorizontal,
  SeparatorVertical,
  ServerCrash,
  ServerCog,
  ServerOff,
  Server,
  Settings2,
  Settings,
  Shapes,
  Share2,
  Share,
  Sheet,
  Shell,
  ShelvingUnit,
  ShieldAlert,
  ShieldBan,
  ShieldCheck,
  ShieldEllipsis,
  ShieldHalf,
  ShieldMinus,
  ShieldOff,
  ShieldPlus,
  ShieldQuestionMark,
  ShieldUser,
  ShieldX,
  Shield,
  ShipWheel,
  Ship,
  Shirt,
  ShoppingBag,
  ShoppingBasket,
  ShoppingCart,
  Shovel,
  ShowerHead,
  Shredder,
  Shrimp,
  Shrink,
  Shrub,
  Shuffle,
  Sigma,
  SignalLow,
  SignalHigh,
  SignalMedium,
  Signal,
  SignalZero,
  Signature,
  SignpostBig,
  Signpost,
  Siren,
  SkipBack,
  SkipForward,
  Skull,
  Slack,
  Slash,
  Slice,
  SlidersHorizontal,
  SlidersVertical,
  SmartphoneCharging,
  SmartphoneNfc,
  Smartphone,
  SmilePlus,
  Smile,
  Snail,
  Snowflake,
  SoapDispenserDroplet,
  Sofa,
  SolarPanel,
  Soup,
  Space,
  Spade,
  Sparkles,
  Sparkle,
  Speaker,
  Speech,
  SpellCheck2,
  SpellCheck,
  SplinePointer,
  Spline,
  Split,
  Spool,
  Spotlight,
  SprayCan,
  Sprout,
  SquareActivity,
  SquareArrowDownLeft,
  SquareArrowDownRight,
  SquareArrowDown,
  SquareArrowLeft,
  SquareArrowOutDownLeft,
  SquareArrowOutDownRight,
  SquareArrowOutUpLeft,
  SquareArrowOutUpRight,
  SquareArrowRightEnter,
  SquareArrowRightExit,
  SquareArrowRight,
  SquareArrowUpLeft,
  SquareArrowUpRight,
  SquareArrowUp,
  SquareAsterisk,
  SquareBottomDashedScissors,
  SquareCenterlineDashedHorizontal,
  SquareCenterlineDashedVertical,
  SquareCheckBig,
  SquareChartGantt,
  SquareCheck,
  SquareChevronDown,
  SquareChevronRight,
  SquareChevronLeft,
  SquareChevronUp,
  SquareCode,
  SquareDashedBottomCode,
  SquareDashedBottom,
  SquareDashedKanban,
  SquareDashedTopSolid,
  SquareDashedMousePointer,
  SquareDashed,
  SquareDivide,
  SquareDot,
  SquareEqual,
  SquareFunction,
  SquareKanban,
  SquareM,
  SquareMenu,
  SquareLibrary,
  SquareMinus,
  SquareMousePointer,
  SquareParkingOff,
  SquareParking,
  SquarePause,
  SquarePercent,
  SquarePen,
  SquarePi,
  SquarePilcrow,
  SquarePlay,
  SquarePlus,
  SquarePower,
  SquareRadical,
  SquareRoundCorner,
  SquareScissors,
  SquareSigma,
  SquareSlash,
  SquareSplitHorizontal,
  SquareSplitVertical,
  SquareSquare,
  SquareStack,
  SquareStar,
  SquareStop,
  SquareTerminal,
  SquareUserRound,
  SquareUser,
  SquareX,
  Square,
  SquaresExclude,
  SquaresIntersect,
  SquaresSubtract,
  SquaresUnite,
  SquircleDashed,
  Squircle,
  Squirrel,
  Stamp,
  StarHalf,
  StarOff,
  Star,
  StepBack,
  StepForward,
  Stethoscope,
  Sticker,
  StickyNote,
  Stone,
  Store,
  StretchHorizontal,
  StretchVertical,
  Strikethrough,
  Subscript,
  SunDim,
  SunMedium,
  SunMoon,
  SunSnow,
  Sun,
  Sunset,
  Sunrise,
  Superscript,
  SwatchBook,
  SwissFranc,
  SwitchCamera,
  Sword,
  Swords,
  Syringe,
  Table2,
  TableCellsMerge,
  TableCellsSplit,
  TableColumnsSplit,
  TableOfContents,
  TableProperties,
  TableRowsSplit,
  Table,
  Tablet,
  TabletSmartphone,
  Tablets,
  Tag,
  Tags,
  Tally1,
  Tally2,
  Tally3,
  Tally4,
  Tangent,
  Tally5,
  Telescope,
  Target,
  TentTree,
  Terminal,
  Tent,
  TestTubeDiagonal,
  TestTubes,
  TestTube,
  TextAlignCenter,
  TextAlignEnd,
  TextAlignJustify,
  TextAlignStart,
  TextCursorInput,
  TextCursor,
  TextInitial,
  TextQuote,
  TextSearch,
  TextSelect,
  TextWrap,
  Theater,
  ThermometerSnowflake,
  ThermometerSun,
  Thermometer,
  ThumbsDown,
  TicketCheck,
  ThumbsUp,
  TicketMinus,
  TicketPercent,
  TicketPlus,
  TicketSlash,
  TicketX,
  Ticket,
  TicketsPlane,
  Tickets,
  TimerOff,
  TimerReset,
  Timer,
  ToggleLeft,
  ToggleRight,
  Toilet,
  ToolCase,
  Toolbox,
  Tornado,
  Torus,
  TouchpadOff,
  Touchpad,
  TowelRack,
  TowerControl,
  ToyBrick,
  Tractor,
  TrafficCone,
  TrainFrontTunnel,
  TrainFront,
  TrainTrack,
  Transgender,
  TramFront,
  Trash2,
  Trash,
  TreeDeciduous,
  TreePalm,
  TreePine,
  Trees,
  Trello,
  TrendingDown,
  TrendingUpDown,
  TriangleAlert,
  TrendingUp,
  TriangleDashed,
  TriangleRight,
  Triangle,
  Trophy,
  TruckElectric,
  Truck,
  TurkishLira,
  Turtle,
  TvMinimalPlay,
  Turntable,
  TvMinimal,
  Tv,
  Twitch,
  Twitter,
  TypeOutline,
  Type,
  UmbrellaOff,
  Umbrella,
  Undo2,
  Underline,
  UndoDot,
  Undo,
  UnfoldHorizontal,
  UnfoldVertical,
  University,
  Ungroup,
  Unlink2,
  Unplug,
  Unlink,
  Upload,
  Usb,
  UserCheck,
  UserCog,
  UserKey,
  UserLock,
  UserMinus,
  UserPen,
  UserPlus,
  UserRoundCheck,
  UserRoundCog,
  UserRoundKey,
  UserRoundMinus,
  UserRoundPen,
  UserRoundPlus,
  UserRoundSearch,
  UserRoundX,
  UserRound,
  UserSearch,
  UserStar,
  UserX,
  User,
  UsersRound,
  Users,
  UtensilsCrossed,
  Utensils,
  Van,
  Variable,
  UtilityPole,
  Vault,
  VectorSquare,
  Vegan,
  VenetianMask,
  VenusAndMars,
  Venus,
  VibrateOff,
  Vibrate,
  VideoOff,
  Video,
  Videotape,
  View,
  Voicemail,
  Volleyball,
  Volume1,
  Volume2,
  VolumeOff,
  VolumeX,
  Vote,
  Volume,
  WalletCards,
  WalletMinimal,
  Wallet,
  Wallpaper,
  WandSparkles,
  Wand,
  Warehouse,
  WashingMachine,
  Watch,
  WavesArrowDown,
  WavesArrowUp,
  WavesLadder,
  Waves,
  Waypoints,
  WebhookOff,
  Webcam,
  Webhook,
  WeightTilde,
  Weight,
  WheatOff,
  WholeWord,
  Wheat,
  WifiHigh,
  WifiCog,
  WifiLow,
  WifiOff,
  WifiSync,
  WifiPen,
  WifiZero,
  Wifi,
  WindArrowDown,
  Wind,
  WineOff,
  Workflow,
  Wine,
  Worm,
  XLineTop,
  Wrench,
  X,
  Youtube,
  ZapOff,
  Zap,
  ZodiacAquarius,
  ZodiacAries,
  ZodiacCancer,
  ZodiacCapricorn,
  ZodiacGemini,
  ZodiacLibra,
  ZodiacLeo,
  ZodiacOphiuchus,
  ZodiacPisces,
  ZodiacSagittarius,
  ZodiacTaurus,
  ZodiacScorpio,
  ZoomIn,
  ZodiacVirgo,
  ZoomOut
});
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": 2,
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};
var LUCIDE_ICONS = new InjectionToken("LucideIcons", {
  factory: () => new LucideIconProvider({})
});
var LucideIconProvider = class {
  constructor(icons) {
    this.icons = icons;
  }
  getIcon(name) {
    return this.hasIcon(name) ? this.icons[name] : null;
  }
  hasIcon(name) {
    return typeof this.icons === "object" && name in this.icons;
  }
};
var LucideIconConfig = class {
  constructor() {
    this.color = defaultAttributes.stroke;
    this.size = defaultAttributes.width;
    this.strokeWidth = defaultAttributes["stroke-width"];
    this.absoluteStrokeWidth = false;
  }
};
LucideIconConfig.ɵfac = function LucideIconConfig_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || LucideIconConfig)();
};
LucideIconConfig.ɵprov = ɵɵdefineInjectable({
  token: LucideIconConfig,
  factory: LucideIconConfig.ɵfac,
  providedIn: "root"
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LucideIconConfig, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
  return false;
};
function formatFixed(number, decimals = 3) {
  return parseFloat(number.toFixed(decimals)).toString(10);
}
var LucideAngularComponent = class {
  constructor(elem, renderer, changeDetector, iconProviders, iconConfig) {
    this.elem = elem;
    this.renderer = renderer;
    this.changeDetector = changeDetector;
    this.iconProviders = iconProviders;
    this.iconConfig = iconConfig;
    this.absoluteStrokeWidth = false;
    this.defaultSize = defaultAttributes.height;
  }
  get size() {
    return this._size ?? this.iconConfig.size;
  }
  set size(value) {
    if (value) {
      this._size = this.parseNumber(value);
    } else {
      delete this._size;
    }
  }
  get strokeWidth() {
    return this._strokeWidth ?? this.iconConfig.strokeWidth;
  }
  set strokeWidth(value) {
    if (value) {
      this._strokeWidth = this.parseNumber(value);
    } else {
      delete this._strokeWidth;
    }
  }
  ngOnChanges(changes) {
    if (changes.name || changes.img || changes.color || changes.size || changes.absoluteStrokeWidth || changes.strokeWidth || changes.class) {
      this.color = this.color ?? this.iconConfig.color;
      this.size = this.parseNumber(this.size ?? this.iconConfig.size);
      this.strokeWidth = this.parseNumber(this.strokeWidth ?? this.iconConfig.strokeWidth);
      this.absoluteStrokeWidth = this.absoluteStrokeWidth ?? this.iconConfig.absoluteStrokeWidth;
      const nameOrIcon = this.img ?? this.name;
      const restAttributes = this.getRestAttributes();
      if (!hasA11yProp(restAttributes)) {
        this.renderer.setAttribute(this.elem.nativeElement, "aria-hidden", "true");
      }
      if (typeof nameOrIcon === "string") {
        const icoOfName = this.getIcon(this.toPascalCase(nameOrIcon));
        if (icoOfName) {
          this.replaceElement(icoOfName);
        } else {
          throw new Error(`The "${nameOrIcon}" icon has not been provided by any available icon providers.`);
        }
      } else if (Array.isArray(nameOrIcon)) {
        this.replaceElement(nameOrIcon);
      } else {
        throw new Error(`No icon name or image has been provided.`);
      }
    }
    this.changeDetector.markForCheck();
  }
  replaceElement(img) {
    const childElements = this.elem.nativeElement.childNodes;
    const attributes = __spreadProps(__spreadValues({}, defaultAttributes), {
      width: this.size,
      height: this.size,
      stroke: this.color ?? this.iconConfig.color,
      "stroke-width": this.absoluteStrokeWidth ? formatFixed(this.strokeWidth / (this.size / this.defaultSize)) : this.strokeWidth.toString(10)
    });
    const icoElement = this.createElement(["svg", attributes, img]);
    icoElement.classList.add("lucide");
    if (typeof this.name === "string") {
      icoElement.classList.add(`lucide-${this.name.replace("_", "-")}`);
    }
    if (this.class) {
      icoElement.classList.add(...this.class.split(/ /).map((a) => a.trim()).filter((a) => a.length > 0));
    }
    for (const child of childElements) {
      this.renderer.removeChild(this.elem.nativeElement, child);
    }
    this.renderer.appendChild(this.elem.nativeElement, icoElement);
  }
  getRestAttributes() {
    const restAttributeMap = this.elem.nativeElement.attributes;
    const restAttributes = Object.fromEntries(Array.from(restAttributeMap).map((item) => [item.name, item.value]));
    return restAttributes;
  }
  toPascalCase(str) {
    return str.replace(/(\w)([a-z0-9]*)(_|-|\s*)/g, (g0, g1, g2) => g1.toUpperCase() + g2.toLowerCase());
  }
  parseNumber(value) {
    if (typeof value === "string") {
      const parsedValue = parseInt(value, 10);
      if (isNaN(parsedValue)) {
        throw new Error(`${value} is not numeric.`);
      }
      return parsedValue;
    }
    return value;
  }
  getIcon(name) {
    for (const iconProvider of Array.isArray(this.iconProviders) ? this.iconProviders : [this.iconProviders]) {
      if (iconProvider.hasIcon(name)) {
        return iconProvider.getIcon(name);
      }
    }
    return null;
  }
  createElement([tag, attrs, children = []]) {
    const element = this.renderer.createElement(tag, "http://www.w3.org/2000/svg");
    Object.keys(attrs).forEach((name) => {
      const attrValue = typeof attrs[name] === "string" ? attrs[name] : attrs[name].toString(10);
      this.renderer.setAttribute(element, name, attrValue);
    });
    if (children.length) {
      children.forEach((child) => {
        const childElement = this.createElement(child);
        this.renderer.appendChild(element, childElement);
      });
    }
    return element;
  }
};
LucideAngularComponent.ɵfac = function LucideAngularComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || LucideAngularComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(LUCIDE_ICONS), ɵɵdirectiveInject(LucideIconConfig));
};
LucideAngularComponent.ɵcmp = ɵɵdefineComponent({
  type: LucideAngularComponent,
  selectors: [["lucide-angular"], ["lucide-icon"], ["i-lucide"], ["span-lucide"]],
  inputs: {
    class: "class",
    name: "name",
    img: "img",
    color: "color",
    absoluteStrokeWidth: "absoluteStrokeWidth",
    size: "size",
    strokeWidth: "strokeWidth"
  },
  standalone: false,
  features: [ɵɵNgOnChangesFeature],
  ngContentSelectors: _c0,
  decls: 1,
  vars: 0,
  template: function LucideAngularComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵprojectionDef();
      ɵɵprojection(0);
    }
  },
  encapsulation: 2
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LucideAngularComponent, [{
    type: Component,
    args: [{
      selector: "lucide-angular, lucide-icon, i-lucide, span-lucide",
      template: "<ng-content></ng-content>"
    }]
  }], function() {
    return [{
      type: ElementRef,
      decorators: [{
        type: Inject,
        args: [ElementRef]
      }]
    }, {
      type: Renderer2,
      decorators: [{
        type: Inject,
        args: [Renderer2]
      }]
    }, {
      type: ChangeDetectorRef,
      decorators: [{
        type: Inject,
        args: [ChangeDetectorRef]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [LUCIDE_ICONS]
      }]
    }, {
      type: LucideIconConfig,
      decorators: [{
        type: Inject,
        args: [LucideIconConfig]
      }]
    }];
  }, {
    class: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    img: [{
      type: Input
    }],
    color: [{
      type: Input
    }],
    absoluteStrokeWidth: [{
      type: Input
    }],
    size: [{
      type: Input
    }],
    strokeWidth: [{
      type: Input
    }]
  });
})();
var Icons = class {
  constructor(icons) {
    this.icons = icons;
  }
};
var legacyIconProviderFactory = (icons) => {
  return new LucideIconProvider(icons ?? {});
};
var LucideAngularModule = class _LucideAngularModule {
  static pick(icons) {
    return {
      ngModule: _LucideAngularModule,
      providers: [{
        provide: LUCIDE_ICONS,
        multi: true,
        useValue: new LucideIconProvider(icons)
      }, {
        provide: LUCIDE_ICONS,
        multi: true,
        useFactory: legacyIconProviderFactory,
        deps: [[new Optional(), Icons]]
      }]
    };
  }
};
LucideAngularModule.ɵfac = function LucideAngularModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || LucideAngularModule)();
};
LucideAngularModule.ɵmod = ɵɵdefineNgModule({
  type: LucideAngularModule,
  declarations: [LucideAngularComponent],
  exports: [LucideAngularComponent]
});
LucideAngularModule.ɵinj = ɵɵdefineInjector({
  imports: [[]]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LucideAngularModule, [{
    type: NgModule,
    args: [{
      declarations: [LucideAngularComponent],
      imports: [],
      exports: [LucideAngularComponent]
    }]
  }], null, null);
})();
export {
  AArrowDown,
  AArrowDown as AArrowDownIcon,
  AArrowUp,
  AArrowUp as AArrowUpIcon,
  ALargeSmall,
  ALargeSmall as ALargeSmallIcon,
  Accessibility,
  Accessibility as AccessibilityIcon,
  Activity,
  Activity as ActivityIcon,
  SquareActivity as ActivitySquare,
  SquareActivity as ActivitySquareIcon,
  AirVent,
  AirVent as AirVentIcon,
  Airplay,
  Airplay as AirplayIcon,
  AlarmClockCheck as AlarmCheck,
  AlarmClockCheck as AlarmCheckIcon,
  AlarmClock,
  AlarmClockCheck,
  AlarmClockCheck as AlarmClockCheckIcon,
  AlarmClock as AlarmClockIcon,
  AlarmClockMinus,
  AlarmClockMinus as AlarmClockMinusIcon,
  AlarmClockOff,
  AlarmClockOff as AlarmClockOffIcon,
  AlarmClockPlus,
  AlarmClockPlus as AlarmClockPlusIcon,
  AlarmClockMinus as AlarmMinus,
  AlarmClockMinus as AlarmMinusIcon,
  AlarmClockPlus as AlarmPlus,
  AlarmClockPlus as AlarmPlusIcon,
  AlarmSmoke,
  AlarmSmoke as AlarmSmokeIcon,
  Album,
  Album as AlbumIcon,
  CircleAlert as AlertCircle,
  CircleAlert as AlertCircleIcon,
  OctagonAlert as AlertOctagon,
  OctagonAlert as AlertOctagonIcon,
  TriangleAlert as AlertTriangle,
  TriangleAlert as AlertTriangleIcon,
  TextAlignCenter as AlignCenter,
  AlignCenterHorizontal,
  AlignCenterHorizontal as AlignCenterHorizontalIcon,
  TextAlignCenter as AlignCenterIcon,
  AlignCenterVertical,
  AlignCenterVertical as AlignCenterVerticalIcon,
  AlignEndHorizontal,
  AlignEndHorizontal as AlignEndHorizontalIcon,
  AlignEndVertical,
  AlignEndVertical as AlignEndVerticalIcon,
  AlignHorizontalDistributeCenter,
  AlignHorizontalDistributeCenter as AlignHorizontalDistributeCenterIcon,
  AlignHorizontalDistributeEnd,
  AlignHorizontalDistributeEnd as AlignHorizontalDistributeEndIcon,
  AlignHorizontalDistributeStart,
  AlignHorizontalDistributeStart as AlignHorizontalDistributeStartIcon,
  AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyCenter as AlignHorizontalJustifyCenterIcon,
  AlignHorizontalJustifyEnd,
  AlignHorizontalJustifyEnd as AlignHorizontalJustifyEndIcon,
  AlignHorizontalJustifyStart,
  AlignHorizontalJustifyStart as AlignHorizontalJustifyStartIcon,
  AlignHorizontalSpaceAround,
  AlignHorizontalSpaceAround as AlignHorizontalSpaceAroundIcon,
  AlignHorizontalSpaceBetween,
  AlignHorizontalSpaceBetween as AlignHorizontalSpaceBetweenIcon,
  TextAlignJustify as AlignJustify,
  TextAlignJustify as AlignJustifyIcon,
  TextAlignStart as AlignLeft,
  TextAlignStart as AlignLeftIcon,
  TextAlignEnd as AlignRight,
  TextAlignEnd as AlignRightIcon,
  AlignStartHorizontal,
  AlignStartHorizontal as AlignStartHorizontalIcon,
  AlignStartVertical,
  AlignStartVertical as AlignStartVerticalIcon,
  AlignVerticalDistributeCenter,
  AlignVerticalDistributeCenter as AlignVerticalDistributeCenterIcon,
  AlignVerticalDistributeEnd,
  AlignVerticalDistributeEnd as AlignVerticalDistributeEndIcon,
  AlignVerticalDistributeStart,
  AlignVerticalDistributeStart as AlignVerticalDistributeStartIcon,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyCenter as AlignVerticalJustifyCenterIcon,
  AlignVerticalJustifyEnd,
  AlignVerticalJustifyEnd as AlignVerticalJustifyEndIcon,
  AlignVerticalJustifyStart,
  AlignVerticalJustifyStart as AlignVerticalJustifyStartIcon,
  AlignVerticalSpaceAround,
  AlignVerticalSpaceAround as AlignVerticalSpaceAroundIcon,
  AlignVerticalSpaceBetween,
  AlignVerticalSpaceBetween as AlignVerticalSpaceBetweenIcon,
  Ambulance,
  Ambulance as AmbulanceIcon,
  Ampersand,
  Ampersand as AmpersandIcon,
  Ampersands,
  Ampersands as AmpersandsIcon,
  Amphora,
  Amphora as AmphoraIcon,
  Anchor,
  Anchor as AnchorIcon,
  Angry,
  Angry as AngryIcon,
  Annoyed,
  Annoyed as AnnoyedIcon,
  Antenna,
  Antenna as AntennaIcon,
  Anvil,
  Anvil as AnvilIcon,
  Aperture,
  Aperture as ApertureIcon,
  AppWindow,
  AppWindow as AppWindowIcon,
  AppWindowMac,
  AppWindowMac as AppWindowMacIcon,
  Apple,
  Apple as AppleIcon,
  Archive,
  Archive as ArchiveIcon,
  ArchiveRestore,
  ArchiveRestore as ArchiveRestoreIcon,
  ArchiveX,
  ArchiveX as ArchiveXIcon,
  ChartArea as AreaChart,
  ChartArea as AreaChartIcon,
  Armchair,
  Armchair as ArmchairIcon,
  ArrowBigDown,
  ArrowBigDownDash,
  ArrowBigDownDash as ArrowBigDownDashIcon,
  ArrowBigDown as ArrowBigDownIcon,
  ArrowBigLeft,
  ArrowBigLeftDash,
  ArrowBigLeftDash as ArrowBigLeftDashIcon,
  ArrowBigLeft as ArrowBigLeftIcon,
  ArrowBigRight,
  ArrowBigRightDash,
  ArrowBigRightDash as ArrowBigRightDashIcon,
  ArrowBigRight as ArrowBigRightIcon,
  ArrowBigUp,
  ArrowBigUpDash,
  ArrowBigUpDash as ArrowBigUpDashIcon,
  ArrowBigUp as ArrowBigUpIcon,
  ArrowDown,
  ArrowDown01,
  ArrowDown01 as ArrowDown01Icon,
  ArrowDown10,
  ArrowDown10 as ArrowDown10Icon,
  ArrowDownAZ,
  ArrowDownAZ as ArrowDownAZIcon,
  ArrowDownAZ as ArrowDownAz,
  ArrowDownAZ as ArrowDownAzIcon,
  CircleArrowDown as ArrowDownCircle,
  CircleArrowDown as ArrowDownCircleIcon,
  ArrowDownFromLine,
  ArrowDownFromLine as ArrowDownFromLineIcon,
  ArrowDown as ArrowDownIcon,
  ArrowDownLeft,
  CircleArrowOutDownLeft as ArrowDownLeftFromCircle,
  CircleArrowOutDownLeft as ArrowDownLeftFromCircleIcon,
  SquareArrowOutDownLeft as ArrowDownLeftFromSquare,
  SquareArrowOutDownLeft as ArrowDownLeftFromSquareIcon,
  ArrowDownLeft as ArrowDownLeftIcon,
  SquareArrowDownLeft as ArrowDownLeftSquare,
  SquareArrowDownLeft as ArrowDownLeftSquareIcon,
  ArrowDownNarrowWide,
  ArrowDownNarrowWide as ArrowDownNarrowWideIcon,
  ArrowDownRight,
  CircleArrowOutDownRight as ArrowDownRightFromCircle,
  CircleArrowOutDownRight as ArrowDownRightFromCircleIcon,
  SquareArrowOutDownRight as ArrowDownRightFromSquare,
  SquareArrowOutDownRight as ArrowDownRightFromSquareIcon,
  ArrowDownRight as ArrowDownRightIcon,
  SquareArrowDownRight as ArrowDownRightSquare,
  SquareArrowDownRight as ArrowDownRightSquareIcon,
  SquareArrowDown as ArrowDownSquare,
  SquareArrowDown as ArrowDownSquareIcon,
  ArrowDownToDot,
  ArrowDownToDot as ArrowDownToDotIcon,
  ArrowDownToLine,
  ArrowDownToLine as ArrowDownToLineIcon,
  ArrowDownUp,
  ArrowDownUp as ArrowDownUpIcon,
  ArrowDownWideNarrow,
  ArrowDownWideNarrow as ArrowDownWideNarrowIcon,
  ArrowDownZA,
  ArrowDownZA as ArrowDownZAIcon,
  ArrowDownZA as ArrowDownZa,
  ArrowDownZA as ArrowDownZaIcon,
  ArrowLeft,
  CircleArrowLeft as ArrowLeftCircle,
  CircleArrowLeft as ArrowLeftCircleIcon,
  ArrowLeftFromLine,
  ArrowLeftFromLine as ArrowLeftFromLineIcon,
  ArrowLeft as ArrowLeftIcon,
  ArrowLeftRight,
  ArrowLeftRight as ArrowLeftRightIcon,
  SquareArrowLeft as ArrowLeftSquare,
  SquareArrowLeft as ArrowLeftSquareIcon,
  ArrowLeftToLine,
  ArrowLeftToLine as ArrowLeftToLineIcon,
  ArrowRight,
  CircleArrowRight as ArrowRightCircle,
  CircleArrowRight as ArrowRightCircleIcon,
  ArrowRightFromLine,
  ArrowRightFromLine as ArrowRightFromLineIcon,
  ArrowRight as ArrowRightIcon,
  ArrowRightLeft,
  ArrowRightLeft as ArrowRightLeftIcon,
  SquareArrowRight as ArrowRightSquare,
  SquareArrowRight as ArrowRightSquareIcon,
  ArrowRightToLine,
  ArrowRightToLine as ArrowRightToLineIcon,
  ArrowUp,
  ArrowUp01,
  ArrowUp01 as ArrowUp01Icon,
  ArrowUp10,
  ArrowUp10 as ArrowUp10Icon,
  ArrowUpAZ,
  ArrowUpAZ as ArrowUpAZIcon,
  ArrowUpAZ as ArrowUpAz,
  ArrowUpAZ as ArrowUpAzIcon,
  CircleArrowUp as ArrowUpCircle,
  CircleArrowUp as ArrowUpCircleIcon,
  ArrowUpDown,
  ArrowUpDown as ArrowUpDownIcon,
  ArrowUpFromDot,
  ArrowUpFromDot as ArrowUpFromDotIcon,
  ArrowUpFromLine,
  ArrowUpFromLine as ArrowUpFromLineIcon,
  ArrowUp as ArrowUpIcon,
  ArrowUpLeft,
  CircleArrowOutUpLeft as ArrowUpLeftFromCircle,
  CircleArrowOutUpLeft as ArrowUpLeftFromCircleIcon,
  SquareArrowOutUpLeft as ArrowUpLeftFromSquare,
  SquareArrowOutUpLeft as ArrowUpLeftFromSquareIcon,
  ArrowUpLeft as ArrowUpLeftIcon,
  SquareArrowUpLeft as ArrowUpLeftSquare,
  SquareArrowUpLeft as ArrowUpLeftSquareIcon,
  ArrowUpNarrowWide,
  ArrowUpNarrowWide as ArrowUpNarrowWideIcon,
  ArrowUpRight,
  CircleArrowOutUpRight as ArrowUpRightFromCircle,
  CircleArrowOutUpRight as ArrowUpRightFromCircleIcon,
  SquareArrowOutUpRight as ArrowUpRightFromSquare,
  SquareArrowOutUpRight as ArrowUpRightFromSquareIcon,
  ArrowUpRight as ArrowUpRightIcon,
  SquareArrowUpRight as ArrowUpRightSquare,
  SquareArrowUpRight as ArrowUpRightSquareIcon,
  SquareArrowUp as ArrowUpSquare,
  SquareArrowUp as ArrowUpSquareIcon,
  ArrowUpToLine,
  ArrowUpToLine as ArrowUpToLineIcon,
  ArrowUpWideNarrow,
  ArrowUpWideNarrow as ArrowUpWideNarrowIcon,
  ArrowUpZA,
  ArrowUpZA as ArrowUpZAIcon,
  ArrowUpZA as ArrowUpZa,
  ArrowUpZA as ArrowUpZaIcon,
  ArrowsUpFromLine,
  ArrowsUpFromLine as ArrowsUpFromLineIcon,
  Asterisk,
  Asterisk as AsteriskIcon,
  SquareAsterisk as AsteriskSquare,
  SquareAsterisk as AsteriskSquareIcon,
  AtSign,
  AtSign as AtSignIcon,
  Atom,
  Atom as AtomIcon,
  AudioLines,
  AudioLines as AudioLinesIcon,
  AudioWaveform,
  AudioWaveform as AudioWaveformIcon,
  Award,
  Award as AwardIcon,
  Axe,
  Axe as AxeIcon,
  Axis3d as Axis3D,
  Axis3d as Axis3DIcon,
  Axis3d,
  Axis3d as Axis3dIcon,
  Baby,
  Baby as BabyIcon,
  Backpack,
  Backpack as BackpackIcon,
  Badge,
  BadgeAlert,
  BadgeAlert as BadgeAlertIcon,
  BadgeCent,
  BadgeCent as BadgeCentIcon,
  BadgeCheck,
  BadgeCheck as BadgeCheckIcon,
  BadgeDollarSign,
  BadgeDollarSign as BadgeDollarSignIcon,
  BadgeEuro,
  BadgeEuro as BadgeEuroIcon,
  BadgeQuestionMark as BadgeHelp,
  BadgeQuestionMark as BadgeHelpIcon,
  Badge as BadgeIcon,
  BadgeIndianRupee,
  BadgeIndianRupee as BadgeIndianRupeeIcon,
  BadgeInfo,
  BadgeInfo as BadgeInfoIcon,
  BadgeJapaneseYen,
  BadgeJapaneseYen as BadgeJapaneseYenIcon,
  BadgeMinus,
  BadgeMinus as BadgeMinusIcon,
  BadgePercent,
  BadgePercent as BadgePercentIcon,
  BadgePlus,
  BadgePlus as BadgePlusIcon,
  BadgePoundSterling,
  BadgePoundSterling as BadgePoundSterlingIcon,
  BadgeQuestionMark,
  BadgeQuestionMark as BadgeQuestionMarkIcon,
  BadgeRussianRuble,
  BadgeRussianRuble as BadgeRussianRubleIcon,
  BadgeSwissFranc,
  BadgeSwissFranc as BadgeSwissFrancIcon,
  BadgeTurkishLira,
  BadgeTurkishLira as BadgeTurkishLiraIcon,
  BadgeX,
  BadgeX as BadgeXIcon,
  BaggageClaim,
  BaggageClaim as BaggageClaimIcon,
  Balloon,
  Balloon as BalloonIcon,
  Ban,
  Ban as BanIcon,
  Banana,
  Banana as BananaIcon,
  Bandage,
  Bandage as BandageIcon,
  Banknote,
  BanknoteArrowDown,
  BanknoteArrowDown as BanknoteArrowDownIcon,
  BanknoteArrowUp,
  BanknoteArrowUp as BanknoteArrowUpIcon,
  Banknote as BanknoteIcon,
  BanknoteX,
  BanknoteX as BanknoteXIcon,
  ChartNoAxesColumnIncreasing as BarChart,
  ChartNoAxesColumn as BarChart2,
  ChartNoAxesColumn as BarChart2Icon,
  ChartColumn as BarChart3,
  ChartColumn as BarChart3Icon,
  ChartColumnIncreasing as BarChart4,
  ChartColumnIncreasing as BarChart4Icon,
  ChartColumnBig as BarChartBig,
  ChartColumnBig as BarChartBigIcon,
  ChartBar as BarChartHorizontal,
  ChartBarBig as BarChartHorizontalBig,
  ChartBarBig as BarChartHorizontalBigIcon,
  ChartBar as BarChartHorizontalIcon,
  ChartNoAxesColumnIncreasing as BarChartIcon,
  Barcode,
  Barcode as BarcodeIcon,
  Barrel,
  Barrel as BarrelIcon,
  Baseline,
  Baseline as BaselineIcon,
  Bath,
  Bath as BathIcon,
  Battery,
  BatteryCharging,
  BatteryCharging as BatteryChargingIcon,
  BatteryFull,
  BatteryFull as BatteryFullIcon,
  Battery as BatteryIcon,
  BatteryLow,
  BatteryLow as BatteryLowIcon,
  BatteryMedium,
  BatteryMedium as BatteryMediumIcon,
  BatteryPlus,
  BatteryPlus as BatteryPlusIcon,
  BatteryWarning,
  BatteryWarning as BatteryWarningIcon,
  Beaker,
  Beaker as BeakerIcon,
  Bean,
  Bean as BeanIcon,
  BeanOff,
  BeanOff as BeanOffIcon,
  Bed,
  BedDouble,
  BedDouble as BedDoubleIcon,
  Bed as BedIcon,
  BedSingle,
  BedSingle as BedSingleIcon,
  Beef,
  Beef as BeefIcon,
  Beer,
  Beer as BeerIcon,
  BeerOff,
  BeerOff as BeerOffIcon,
  Bell,
  BellDot,
  BellDot as BellDotIcon,
  BellElectric,
  BellElectric as BellElectricIcon,
  Bell as BellIcon,
  BellMinus,
  BellMinus as BellMinusIcon,
  BellOff,
  BellOff as BellOffIcon,
  BellPlus,
  BellPlus as BellPlusIcon,
  BellRing,
  BellRing as BellRingIcon,
  BetweenHorizontalEnd as BetweenHorizonalEnd,
  BetweenHorizontalEnd as BetweenHorizonalEndIcon,
  BetweenHorizontalStart as BetweenHorizonalStart,
  BetweenHorizontalStart as BetweenHorizonalStartIcon,
  BetweenHorizontalEnd,
  BetweenHorizontalEnd as BetweenHorizontalEndIcon,
  BetweenHorizontalStart,
  BetweenHorizontalStart as BetweenHorizontalStartIcon,
  BetweenVerticalEnd,
  BetweenVerticalEnd as BetweenVerticalEndIcon,
  BetweenVerticalStart,
  BetweenVerticalStart as BetweenVerticalStartIcon,
  BicepsFlexed,
  BicepsFlexed as BicepsFlexedIcon,
  Bike,
  Bike as BikeIcon,
  Binary,
  Binary as BinaryIcon,
  Binoculars,
  Binoculars as BinocularsIcon,
  Biohazard,
  Biohazard as BiohazardIcon,
  Bird,
  Bird as BirdIcon,
  Birdhouse,
  Birdhouse as BirdhouseIcon,
  Bitcoin,
  Bitcoin as BitcoinIcon,
  Blend,
  Blend as BlendIcon,
  Blinds,
  Blinds as BlindsIcon,
  Blocks,
  Blocks as BlocksIcon,
  Bluetooth,
  BluetoothConnected,
  BluetoothConnected as BluetoothConnectedIcon,
  Bluetooth as BluetoothIcon,
  BluetoothOff,
  BluetoothOff as BluetoothOffIcon,
  BluetoothSearching,
  BluetoothSearching as BluetoothSearchingIcon,
  Bold,
  Bold as BoldIcon,
  Bolt,
  Bolt as BoltIcon,
  Bomb,
  Bomb as BombIcon,
  Bone,
  Bone as BoneIcon,
  Book,
  BookA,
  BookA as BookAIcon,
  BookAlert,
  BookAlert as BookAlertIcon,
  BookAudio,
  BookAudio as BookAudioIcon,
  BookCheck,
  BookCheck as BookCheckIcon,
  BookCopy,
  BookCopy as BookCopyIcon,
  BookDashed,
  BookDashed as BookDashedIcon,
  BookDown,
  BookDown as BookDownIcon,
  BookHeadphones,
  BookHeadphones as BookHeadphonesIcon,
  BookHeart,
  BookHeart as BookHeartIcon,
  Book as BookIcon,
  BookImage,
  BookImage as BookImageIcon,
  BookKey,
  BookKey as BookKeyIcon,
  BookLock,
  BookLock as BookLockIcon,
  BookMarked,
  BookMarked as BookMarkedIcon,
  BookMinus,
  BookMinus as BookMinusIcon,
  BookOpen,
  BookOpenCheck,
  BookOpenCheck as BookOpenCheckIcon,
  BookOpen as BookOpenIcon,
  BookOpenText,
  BookOpenText as BookOpenTextIcon,
  BookPlus,
  BookPlus as BookPlusIcon,
  BookSearch,
  BookSearch as BookSearchIcon,
  BookDashed as BookTemplate,
  BookDashed as BookTemplateIcon,
  BookText,
  BookText as BookTextIcon,
  BookType,
  BookType as BookTypeIcon,
  BookUp,
  BookUp2,
  BookUp2 as BookUp2Icon,
  BookUp as BookUpIcon,
  BookUser,
  BookUser as BookUserIcon,
  BookX,
  BookX as BookXIcon,
  Bookmark,
  BookmarkCheck,
  BookmarkCheck as BookmarkCheckIcon,
  Bookmark as BookmarkIcon,
  BookmarkMinus,
  BookmarkMinus as BookmarkMinusIcon,
  BookmarkPlus,
  BookmarkPlus as BookmarkPlusIcon,
  BookmarkX,
  BookmarkX as BookmarkXIcon,
  BoomBox,
  BoomBox as BoomBoxIcon,
  Bot,
  Bot as BotIcon,
  BotMessageSquare,
  BotMessageSquare as BotMessageSquareIcon,
  BotOff,
  BotOff as BotOffIcon,
  BottleWine,
  BottleWine as BottleWineIcon,
  BowArrow,
  BowArrow as BowArrowIcon,
  Box,
  Box as BoxIcon,
  SquareDashed as BoxSelect,
  SquareDashed as BoxSelectIcon,
  Boxes,
  Boxes as BoxesIcon,
  Braces,
  Braces as BracesIcon,
  Brackets,
  Brackets as BracketsIcon,
  Brain,
  BrainCircuit,
  BrainCircuit as BrainCircuitIcon,
  BrainCog,
  BrainCog as BrainCogIcon,
  Brain as BrainIcon,
  BrickWall,
  BrickWallFire,
  BrickWallFire as BrickWallFireIcon,
  BrickWall as BrickWallIcon,
  BrickWallShield,
  BrickWallShield as BrickWallShieldIcon,
  Briefcase,
  BriefcaseBusiness,
  BriefcaseBusiness as BriefcaseBusinessIcon,
  BriefcaseConveyorBelt,
  BriefcaseConveyorBelt as BriefcaseConveyorBeltIcon,
  Briefcase as BriefcaseIcon,
  BriefcaseMedical,
  BriefcaseMedical as BriefcaseMedicalIcon,
  BringToFront,
  BringToFront as BringToFrontIcon,
  Brush,
  BrushCleaning,
  BrushCleaning as BrushCleaningIcon,
  Brush as BrushIcon,
  Bubbles,
  Bubbles as BubblesIcon,
  Bug,
  Bug as BugIcon,
  BugOff,
  BugOff as BugOffIcon,
  BugPlay,
  BugPlay as BugPlayIcon,
  Building,
  Building2,
  Building2 as Building2Icon,
  Building as BuildingIcon,
  Bus,
  BusFront,
  BusFront as BusFrontIcon,
  Bus as BusIcon,
  Cable,
  CableCar,
  CableCar as CableCarIcon,
  Cable as CableIcon,
  Cake,
  Cake as CakeIcon,
  CakeSlice,
  CakeSlice as CakeSliceIcon,
  Calculator,
  Calculator as CalculatorIcon,
  Calendar,
  Calendar1,
  Calendar1 as Calendar1Icon,
  CalendarArrowDown,
  CalendarArrowDown as CalendarArrowDownIcon,
  CalendarArrowUp,
  CalendarArrowUp as CalendarArrowUpIcon,
  CalendarCheck,
  CalendarCheck2,
  CalendarCheck2 as CalendarCheck2Icon,
  CalendarCheck as CalendarCheckIcon,
  CalendarClock,
  CalendarClock as CalendarClockIcon,
  CalendarCog,
  CalendarCog as CalendarCogIcon,
  CalendarDays,
  CalendarDays as CalendarDaysIcon,
  CalendarFold,
  CalendarFold as CalendarFoldIcon,
  CalendarHeart,
  CalendarHeart as CalendarHeartIcon,
  Calendar as CalendarIcon,
  CalendarMinus,
  CalendarMinus2,
  CalendarMinus2 as CalendarMinus2Icon,
  CalendarMinus as CalendarMinusIcon,
  CalendarOff,
  CalendarOff as CalendarOffIcon,
  CalendarPlus,
  CalendarPlus2,
  CalendarPlus2 as CalendarPlus2Icon,
  CalendarPlus as CalendarPlusIcon,
  CalendarRange,
  CalendarRange as CalendarRangeIcon,
  CalendarSearch,
  CalendarSearch as CalendarSearchIcon,
  CalendarSync,
  CalendarSync as CalendarSyncIcon,
  CalendarX,
  CalendarX2,
  CalendarX2 as CalendarX2Icon,
  CalendarX as CalendarXIcon,
  Calendars,
  Calendars as CalendarsIcon,
  Camera,
  Camera as CameraIcon,
  CameraOff,
  CameraOff as CameraOffIcon,
  ChartCandlestick as CandlestickChart,
  ChartCandlestick as CandlestickChartIcon,
  Candy,
  CandyCane,
  CandyCane as CandyCaneIcon,
  Candy as CandyIcon,
  CandyOff,
  CandyOff as CandyOffIcon,
  Cannabis,
  Cannabis as CannabisIcon,
  CannabisOff,
  CannabisOff as CannabisOffIcon,
  Captions,
  Captions as CaptionsIcon,
  CaptionsOff,
  CaptionsOff as CaptionsOffIcon,
  Car,
  CarFront,
  CarFront as CarFrontIcon,
  Car as CarIcon,
  CarTaxiFront,
  CarTaxiFront as CarTaxiFrontIcon,
  Caravan,
  Caravan as CaravanIcon,
  CardSim,
  CardSim as CardSimIcon,
  Carrot,
  Carrot as CarrotIcon,
  CaseLower,
  CaseLower as CaseLowerIcon,
  CaseSensitive,
  CaseSensitive as CaseSensitiveIcon,
  CaseUpper,
  CaseUpper as CaseUpperIcon,
  CassetteTape,
  CassetteTape as CassetteTapeIcon,
  Cast,
  Cast as CastIcon,
  Castle,
  Castle as CastleIcon,
  Cat,
  Cat as CatIcon,
  Cctv,
  Cctv as CctvIcon,
  CctvOff,
  CctvOff as CctvOffIcon,
  ChartArea,
  ChartArea as ChartAreaIcon,
  ChartBar,
  ChartBarBig,
  ChartBarBig as ChartBarBigIcon,
  ChartBarDecreasing,
  ChartBarDecreasing as ChartBarDecreasingIcon,
  ChartBar as ChartBarIcon,
  ChartBarIncreasing,
  ChartBarIncreasing as ChartBarIncreasingIcon,
  ChartBarStacked,
  ChartBarStacked as ChartBarStackedIcon,
  ChartCandlestick,
  ChartCandlestick as ChartCandlestickIcon,
  ChartColumn,
  ChartColumnBig,
  ChartColumnBig as ChartColumnBigIcon,
  ChartColumnDecreasing,
  ChartColumnDecreasing as ChartColumnDecreasingIcon,
  ChartColumn as ChartColumnIcon,
  ChartColumnIncreasing,
  ChartColumnIncreasing as ChartColumnIncreasingIcon,
  ChartColumnStacked,
  ChartColumnStacked as ChartColumnStackedIcon,
  ChartGantt,
  ChartGantt as ChartGanttIcon,
  ChartLine,
  ChartLine as ChartLineIcon,
  ChartNetwork,
  ChartNetwork as ChartNetworkIcon,
  ChartNoAxesColumn,
  ChartNoAxesColumnDecreasing,
  ChartNoAxesColumnDecreasing as ChartNoAxesColumnDecreasingIcon,
  ChartNoAxesColumn as ChartNoAxesColumnIcon,
  ChartNoAxesColumnIncreasing,
  ChartNoAxesColumnIncreasing as ChartNoAxesColumnIncreasingIcon,
  ChartNoAxesCombined,
  ChartNoAxesCombined as ChartNoAxesCombinedIcon,
  ChartNoAxesGantt,
  ChartNoAxesGantt as ChartNoAxesGanttIcon,
  ChartPie,
  ChartPie as ChartPieIcon,
  ChartScatter,
  ChartScatter as ChartScatterIcon,
  ChartSpline,
  ChartSpline as ChartSplineIcon,
  Check,
  CheckCheck,
  CheckCheck as CheckCheckIcon,
  CircleCheckBig as CheckCircle,
  CircleCheck as CheckCircle2,
  CircleCheck as CheckCircle2Icon,
  CircleCheckBig as CheckCircleIcon,
  Check as CheckIcon,
  CheckLine,
  CheckLine as CheckLineIcon,
  SquareCheckBig as CheckSquare,
  SquareCheck as CheckSquare2,
  SquareCheck as CheckSquare2Icon,
  SquareCheckBig as CheckSquareIcon,
  ChefHat,
  ChefHat as ChefHatIcon,
  Cherry,
  Cherry as CherryIcon,
  ChessBishop,
  ChessBishop as ChessBishopIcon,
  ChessKing,
  ChessKing as ChessKingIcon,
  ChessKnight,
  ChessKnight as ChessKnightIcon,
  ChessPawn,
  ChessPawn as ChessPawnIcon,
  ChessQueen,
  ChessQueen as ChessQueenIcon,
  ChessRook,
  ChessRook as ChessRookIcon,
  ChevronDown,
  CircleChevronDown as ChevronDownCircle,
  CircleChevronDown as ChevronDownCircleIcon,
  ChevronDown as ChevronDownIcon,
  SquareChevronDown as ChevronDownSquare,
  SquareChevronDown as ChevronDownSquareIcon,
  ChevronFirst,
  ChevronFirst as ChevronFirstIcon,
  ChevronLast,
  ChevronLast as ChevronLastIcon,
  ChevronLeft,
  CircleChevronLeft as ChevronLeftCircle,
  CircleChevronLeft as ChevronLeftCircleIcon,
  ChevronLeft as ChevronLeftIcon,
  SquareChevronLeft as ChevronLeftSquare,
  SquareChevronLeft as ChevronLeftSquareIcon,
  ChevronRight,
  CircleChevronRight as ChevronRightCircle,
  CircleChevronRight as ChevronRightCircleIcon,
  ChevronRight as ChevronRightIcon,
  SquareChevronRight as ChevronRightSquare,
  SquareChevronRight as ChevronRightSquareIcon,
  ChevronUp,
  CircleChevronUp as ChevronUpCircle,
  CircleChevronUp as ChevronUpCircleIcon,
  ChevronUp as ChevronUpIcon,
  SquareChevronUp as ChevronUpSquare,
  SquareChevronUp as ChevronUpSquareIcon,
  ChevronsDown,
  ChevronsDown as ChevronsDownIcon,
  ChevronsDownUp,
  ChevronsDownUp as ChevronsDownUpIcon,
  ChevronsLeft,
  ChevronsLeft as ChevronsLeftIcon,
  ChevronsLeftRight,
  ChevronsLeftRightEllipsis,
  ChevronsLeftRightEllipsis as ChevronsLeftRightEllipsisIcon,
  ChevronsLeftRight as ChevronsLeftRightIcon,
  ChevronsRight,
  ChevronsRight as ChevronsRightIcon,
  ChevronsRightLeft,
  ChevronsRightLeft as ChevronsRightLeftIcon,
  ChevronsUp,
  ChevronsUpDown,
  ChevronsUpDown as ChevronsUpDownIcon,
  ChevronsUp as ChevronsUpIcon,
  Chromium as Chrome,
  Chromium as ChromeIcon,
  Chromium,
  Chromium as ChromiumIcon,
  Church,
  Church as ChurchIcon,
  Cigarette,
  Cigarette as CigaretteIcon,
  CigaretteOff,
  CigaretteOff as CigaretteOffIcon,
  Circle,
  CircleAlert,
  CircleAlert as CircleAlertIcon,
  CircleArrowDown,
  CircleArrowDown as CircleArrowDownIcon,
  CircleArrowLeft,
  CircleArrowLeft as CircleArrowLeftIcon,
  CircleArrowOutDownLeft,
  CircleArrowOutDownLeft as CircleArrowOutDownLeftIcon,
  CircleArrowOutDownRight,
  CircleArrowOutDownRight as CircleArrowOutDownRightIcon,
  CircleArrowOutUpLeft,
  CircleArrowOutUpLeft as CircleArrowOutUpLeftIcon,
  CircleArrowOutUpRight,
  CircleArrowOutUpRight as CircleArrowOutUpRightIcon,
  CircleArrowRight,
  CircleArrowRight as CircleArrowRightIcon,
  CircleArrowUp,
  CircleArrowUp as CircleArrowUpIcon,
  CircleCheck,
  CircleCheckBig,
  CircleCheckBig as CircleCheckBigIcon,
  CircleCheck as CircleCheckIcon,
  CircleChevronDown,
  CircleChevronDown as CircleChevronDownIcon,
  CircleChevronLeft,
  CircleChevronLeft as CircleChevronLeftIcon,
  CircleChevronRight,
  CircleChevronRight as CircleChevronRightIcon,
  CircleChevronUp,
  CircleChevronUp as CircleChevronUpIcon,
  CircleDashed,
  CircleDashed as CircleDashedIcon,
  CircleDivide,
  CircleDivide as CircleDivideIcon,
  CircleDollarSign,
  CircleDollarSign as CircleDollarSignIcon,
  CircleDot,
  CircleDotDashed,
  CircleDotDashed as CircleDotDashedIcon,
  CircleDot as CircleDotIcon,
  CircleEllipsis,
  CircleEllipsis as CircleEllipsisIcon,
  CircleEqual,
  CircleEqual as CircleEqualIcon,
  CircleFadingArrowUp,
  CircleFadingArrowUp as CircleFadingArrowUpIcon,
  CircleFadingPlus,
  CircleFadingPlus as CircleFadingPlusIcon,
  CircleGauge,
  CircleGauge as CircleGaugeIcon,
  CircleQuestionMark as CircleHelp,
  CircleQuestionMark as CircleHelpIcon,
  Circle as CircleIcon,
  CircleMinus,
  CircleMinus as CircleMinusIcon,
  CircleOff,
  CircleOff as CircleOffIcon,
  CircleParking,
  CircleParking as CircleParkingIcon,
  CircleParkingOff,
  CircleParkingOff as CircleParkingOffIcon,
  CirclePause,
  CirclePause as CirclePauseIcon,
  CirclePercent,
  CirclePercent as CirclePercentIcon,
  CirclePile,
  CirclePile as CirclePileIcon,
  CirclePlay,
  CirclePlay as CirclePlayIcon,
  CirclePlus,
  CirclePlus as CirclePlusIcon,
  CirclePoundSterling,
  CirclePoundSterling as CirclePoundSterlingIcon,
  CirclePower,
  CirclePower as CirclePowerIcon,
  CircleQuestionMark,
  CircleQuestionMark as CircleQuestionMarkIcon,
  CircleSlash,
  CircleSlash2,
  CircleSlash2 as CircleSlash2Icon,
  CircleSlash as CircleSlashIcon,
  CircleSlash2 as CircleSlashed,
  CircleSlash2 as CircleSlashedIcon,
  CircleSmall,
  CircleSmall as CircleSmallIcon,
  CircleStar,
  CircleStar as CircleStarIcon,
  CircleStop,
  CircleStop as CircleStopIcon,
  CircleUser,
  CircleUser as CircleUserIcon,
  CircleUserRound,
  CircleUserRound as CircleUserRoundIcon,
  CircleX,
  CircleX as CircleXIcon,
  CircuitBoard,
  CircuitBoard as CircuitBoardIcon,
  Citrus,
  Citrus as CitrusIcon,
  Clapperboard,
  Clapperboard as ClapperboardIcon,
  Clipboard,
  ClipboardCheck,
  ClipboardCheck as ClipboardCheckIcon,
  ClipboardClock,
  ClipboardClock as ClipboardClockIcon,
  ClipboardCopy,
  ClipboardCopy as ClipboardCopyIcon,
  ClipboardPen as ClipboardEdit,
  ClipboardPen as ClipboardEditIcon,
  Clipboard as ClipboardIcon,
  ClipboardList,
  ClipboardList as ClipboardListIcon,
  ClipboardMinus,
  ClipboardMinus as ClipboardMinusIcon,
  ClipboardPaste,
  ClipboardPaste as ClipboardPasteIcon,
  ClipboardPen,
  ClipboardPen as ClipboardPenIcon,
  ClipboardPenLine,
  ClipboardPenLine as ClipboardPenLineIcon,
  ClipboardPlus,
  ClipboardPlus as ClipboardPlusIcon,
  ClipboardPenLine as ClipboardSignature,
  ClipboardPenLine as ClipboardSignatureIcon,
  ClipboardType,
  ClipboardType as ClipboardTypeIcon,
  ClipboardX,
  ClipboardX as ClipboardXIcon,
  Clock,
  Clock1,
  Clock10,
  Clock10 as Clock10Icon,
  Clock11,
  Clock11 as Clock11Icon,
  Clock12,
  Clock12 as Clock12Icon,
  Clock1 as Clock1Icon,
  Clock2,
  Clock2 as Clock2Icon,
  Clock3,
  Clock3 as Clock3Icon,
  Clock4,
  Clock4 as Clock4Icon,
  Clock5,
  Clock5 as Clock5Icon,
  Clock6,
  Clock6 as Clock6Icon,
  Clock7,
  Clock7 as Clock7Icon,
  Clock8,
  Clock8 as Clock8Icon,
  Clock9,
  Clock9 as Clock9Icon,
  ClockAlert,
  ClockAlert as ClockAlertIcon,
  ClockArrowDown,
  ClockArrowDown as ClockArrowDownIcon,
  ClockArrowUp,
  ClockArrowUp as ClockArrowUpIcon,
  ClockCheck,
  ClockCheck as ClockCheckIcon,
  ClockFading,
  ClockFading as ClockFadingIcon,
  Clock as ClockIcon,
  ClockPlus,
  ClockPlus as ClockPlusIcon,
  ClosedCaption,
  ClosedCaption as ClosedCaptionIcon,
  Cloud,
  CloudAlert,
  CloudAlert as CloudAlertIcon,
  CloudBackup,
  CloudBackup as CloudBackupIcon,
  CloudCheck,
  CloudCheck as CloudCheckIcon,
  CloudCog,
  CloudCog as CloudCogIcon,
  CloudDownload,
  CloudDownload as CloudDownloadIcon,
  CloudDrizzle,
  CloudDrizzle as CloudDrizzleIcon,
  CloudFog,
  CloudFog as CloudFogIcon,
  CloudHail,
  CloudHail as CloudHailIcon,
  Cloud as CloudIcon,
  CloudLightning,
  CloudLightning as CloudLightningIcon,
  CloudMoon,
  CloudMoon as CloudMoonIcon,
  CloudMoonRain,
  CloudMoonRain as CloudMoonRainIcon,
  CloudOff,
  CloudOff as CloudOffIcon,
  CloudRain,
  CloudRain as CloudRainIcon,
  CloudRainWind,
  CloudRainWind as CloudRainWindIcon,
  CloudSnow,
  CloudSnow as CloudSnowIcon,
  CloudSun,
  CloudSun as CloudSunIcon,
  CloudSunRain,
  CloudSunRain as CloudSunRainIcon,
  CloudSync,
  CloudSync as CloudSyncIcon,
  CloudUpload,
  CloudUpload as CloudUploadIcon,
  Cloudy,
  Cloudy as CloudyIcon,
  Clover,
  Clover as CloverIcon,
  Club,
  Club as ClubIcon,
  Code,
  CodeXml as Code2,
  CodeXml as Code2Icon,
  Code as CodeIcon,
  SquareCode as CodeSquare,
  SquareCode as CodeSquareIcon,
  CodeXml,
  CodeXml as CodeXmlIcon,
  Codepen,
  Codepen as CodepenIcon,
  Codesandbox,
  Codesandbox as CodesandboxIcon,
  Coffee,
  Coffee as CoffeeIcon,
  Cog,
  Cog as CogIcon,
  Coins,
  Coins as CoinsIcon,
  Columns2 as Columns,
  Columns2,
  Columns2 as Columns2Icon,
  Columns3,
  Columns3Cog,
  Columns3Cog as Columns3CogIcon,
  Columns3 as Columns3Icon,
  Columns4,
  Columns4 as Columns4Icon,
  Columns2 as ColumnsIcon,
  Columns3Cog as ColumnsSettings,
  Columns3Cog as ColumnsSettingsIcon,
  Combine,
  Combine as CombineIcon,
  Command,
  Command as CommandIcon,
  Compass,
  Compass as CompassIcon,
  Component2 as Component,
  Component2 as ComponentIcon,
  Computer,
  Computer as ComputerIcon,
  ConciergeBell,
  ConciergeBell as ConciergeBellIcon,
  Cone,
  Cone as ConeIcon,
  Construction,
  Construction as ConstructionIcon,
  Contact,
  ContactRound as Contact2,
  ContactRound as Contact2Icon,
  Contact as ContactIcon,
  ContactRound,
  ContactRound as ContactRoundIcon,
  Container,
  Container as ContainerIcon,
  Contrast,
  Contrast as ContrastIcon,
  Cookie,
  Cookie as CookieIcon,
  CookingPot,
  CookingPot as CookingPotIcon,
  Copy,
  CopyCheck,
  CopyCheck as CopyCheckIcon,
  Copy as CopyIcon,
  CopyMinus,
  CopyMinus as CopyMinusIcon,
  CopyPlus,
  CopyPlus as CopyPlusIcon,
  CopySlash,
  CopySlash as CopySlashIcon,
  CopyX,
  CopyX as CopyXIcon,
  Copyleft,
  Copyleft as CopyleftIcon,
  Copyright,
  Copyright as CopyrightIcon,
  CornerDownLeft,
  CornerDownLeft as CornerDownLeftIcon,
  CornerDownRight,
  CornerDownRight as CornerDownRightIcon,
  CornerLeftDown,
  CornerLeftDown as CornerLeftDownIcon,
  CornerLeftUp,
  CornerLeftUp as CornerLeftUpIcon,
  CornerRightDown,
  CornerRightDown as CornerRightDownIcon,
  CornerRightUp,
  CornerRightUp as CornerRightUpIcon,
  CornerUpLeft,
  CornerUpLeft as CornerUpLeftIcon,
  CornerUpRight,
  CornerUpRight as CornerUpRightIcon,
  Cpu,
  Cpu as CpuIcon,
  CreativeCommons,
  CreativeCommons as CreativeCommonsIcon,
  CreditCard,
  CreditCard as CreditCardIcon,
  Croissant,
  Croissant as CroissantIcon,
  Crop,
  Crop as CropIcon,
  Cross,
  Cross as CrossIcon,
  Crosshair,
  Crosshair as CrosshairIcon,
  Crown,
  Crown as CrownIcon,
  Cuboid,
  Cuboid as CuboidIcon,
  CupSoda,
  CupSoda as CupSodaIcon,
  Braces as CurlyBraces,
  Braces as CurlyBracesIcon,
  Currency,
  Currency as CurrencyIcon,
  Cylinder,
  Cylinder as CylinderIcon,
  Dam,
  Dam as DamIcon,
  Database,
  DatabaseBackup,
  DatabaseBackup as DatabaseBackupIcon,
  Database as DatabaseIcon,
  DatabaseSearch,
  DatabaseSearch as DatabaseSearchIcon,
  DatabaseZap,
  DatabaseZap as DatabaseZapIcon,
  DecimalsArrowLeft,
  DecimalsArrowLeft as DecimalsArrowLeftIcon,
  DecimalsArrowRight,
  DecimalsArrowRight as DecimalsArrowRightIcon,
  Delete,
  Delete as DeleteIcon,
  Dessert,
  Dessert as DessertIcon,
  Diameter,
  Diameter as DiameterIcon,
  Diamond,
  Diamond as DiamondIcon,
  DiamondMinus,
  DiamondMinus as DiamondMinusIcon,
  DiamondPercent,
  DiamondPercent as DiamondPercentIcon,
  DiamondPlus,
  DiamondPlus as DiamondPlusIcon,
  Dice1,
  Dice1 as Dice1Icon,
  Dice2,
  Dice2 as Dice2Icon,
  Dice3,
  Dice3 as Dice3Icon,
  Dice4,
  Dice4 as Dice4Icon,
  Dice5,
  Dice5 as Dice5Icon,
  Dice6,
  Dice6 as Dice6Icon,
  Dices,
  Dices as DicesIcon,
  Diff,
  Diff as DiffIcon,
  Disc,
  Disc2,
  Disc2 as Disc2Icon,
  Disc3,
  Disc3 as Disc3Icon,
  DiscAlbum,
  DiscAlbum as DiscAlbumIcon,
  Disc as DiscIcon,
  Divide,
  CircleDivide as DivideCircle,
  CircleDivide as DivideCircleIcon,
  Divide as DivideIcon,
  SquareDivide as DivideSquare,
  SquareDivide as DivideSquareIcon,
  Dna,
  Dna as DnaIcon,
  DnaOff,
  DnaOff as DnaOffIcon,
  Dock,
  Dock as DockIcon,
  Dog,
  Dog as DogIcon,
  DollarSign,
  DollarSign as DollarSignIcon,
  Donut,
  Donut as DonutIcon,
  DoorClosed,
  DoorClosed as DoorClosedIcon,
  DoorClosedLocked,
  DoorClosedLocked as DoorClosedLockedIcon,
  DoorOpen,
  DoorOpen as DoorOpenIcon,
  Dot,
  Dot as DotIcon,
  SquareDot as DotSquare,
  SquareDot as DotSquareIcon,
  Download,
  CloudDownload as DownloadCloud,
  CloudDownload as DownloadCloudIcon,
  Download as DownloadIcon,
  DraftingCompass,
  DraftingCompass as DraftingCompassIcon,
  Drama,
  Drama as DramaIcon,
  Dribbble,
  Dribbble as DribbbleIcon,
  Drill,
  Drill as DrillIcon,
  Drone,
  Drone as DroneIcon,
  Droplet,
  Droplet as DropletIcon,
  DropletOff,
  DropletOff as DropletOffIcon,
  Droplets,
  Droplets as DropletsIcon,
  Drum,
  Drum as DrumIcon,
  Drumstick,
  Drumstick as DrumstickIcon,
  Dumbbell,
  Dumbbell as DumbbellIcon,
  Ear,
  Ear as EarIcon,
  EarOff,
  EarOff as EarOffIcon,
  Earth,
  Earth as EarthIcon,
  EarthLock,
  EarthLock as EarthLockIcon,
  Eclipse,
  Eclipse as EclipseIcon,
  SquarePen as Edit,
  Pen as Edit2,
  Pen as Edit2Icon,
  PenLine as Edit3,
  PenLine as Edit3Icon,
  SquarePen as EditIcon,
  Egg,
  EggFried,
  EggFried as EggFriedIcon,
  Egg as EggIcon,
  EggOff,
  EggOff as EggOffIcon,
  Ellipse,
  Ellipse as EllipseIcon,
  Ellipsis,
  Ellipsis as EllipsisIcon,
  EllipsisVertical,
  EllipsisVertical as EllipsisVerticalIcon,
  Equal,
  EqualApproximately,
  EqualApproximately as EqualApproximatelyIcon,
  Equal as EqualIcon,
  EqualNot,
  EqualNot as EqualNotIcon,
  SquareEqual as EqualSquare,
  SquareEqual as EqualSquareIcon,
  Eraser,
  Eraser as EraserIcon,
  EthernetPort,
  EthernetPort as EthernetPortIcon,
  Euro,
  Euro as EuroIcon,
  EvCharger,
  EvCharger as EvChargerIcon,
  Expand,
  Expand as ExpandIcon,
  ExternalLink,
  ExternalLink as ExternalLinkIcon,
  Eye,
  EyeClosed,
  EyeClosed as EyeClosedIcon,
  Eye as EyeIcon,
  EyeOff,
  EyeOff as EyeOffIcon,
  Facebook,
  Facebook as FacebookIcon,
  Factory,
  Factory as FactoryIcon,
  Fan,
  Fan as FanIcon,
  FastForward,
  FastForward as FastForwardIcon,
  Feather,
  Feather as FeatherIcon,
  Fence,
  Fence as FenceIcon,
  FerrisWheel,
  FerrisWheel as FerrisWheelIcon,
  Figma,
  Figma as FigmaIcon,
  File,
  FileArchive,
  FileArchive as FileArchiveIcon,
  FileHeadphone as FileAudio,
  FileHeadphone as FileAudio2,
  FileHeadphone as FileAudio2Icon,
  FileHeadphone as FileAudioIcon,
  FileAxis3d as FileAxis3D,
  FileAxis3d as FileAxis3DIcon,
  FileAxis3d,
  FileAxis3d as FileAxis3dIcon,
  FileBadge,
  FileBadge as FileBadge2,
  FileBadge as FileBadge2Icon,
  FileBadge as FileBadgeIcon,
  FileChartColumnIncreasing as FileBarChart,
  FileChartColumn as FileBarChart2,
  FileChartColumn as FileBarChart2Icon,
  FileChartColumnIncreasing as FileBarChartIcon,
  FileBox,
  FileBox as FileBoxIcon,
  FileBraces,
  FileBracesCorner,
  FileBracesCorner as FileBracesCornerIcon,
  FileBraces as FileBracesIcon,
  FileChartColumn,
  FileChartColumn as FileChartColumnIcon,
  FileChartColumnIncreasing,
  FileChartColumnIncreasing as FileChartColumnIncreasingIcon,
  FileChartLine,
  FileChartLine as FileChartLineIcon,
  FileChartPie,
  FileChartPie as FileChartPieIcon,
  FileCheck,
  FileCheckCorner as FileCheck2,
  FileCheckCorner as FileCheck2Icon,
  FileCheckCorner,
  FileCheckCorner as FileCheckCornerIcon,
  FileCheck as FileCheckIcon,
  FileClock,
  FileClock as FileClockIcon,
  FileCode,
  FileCodeCorner as FileCode2,
  FileCodeCorner as FileCode2Icon,
  FileCodeCorner,
  FileCodeCorner as FileCodeCornerIcon,
  FileCode as FileCodeIcon,
  FileCog,
  FileCog as FileCog2,
  FileCog as FileCog2Icon,
  FileCog as FileCogIcon,
  FileDiff,
  FileDiff as FileDiffIcon,
  FileDigit,
  FileDigit as FileDigitIcon,
  FileDown,
  FileDown as FileDownIcon,
  FilePen as FileEdit,
  FilePen as FileEditIcon,
  FileExclamationPoint,
  FileExclamationPoint as FileExclamationPointIcon,
  FileHeadphone,
  FileHeadphone as FileHeadphoneIcon,
  FileHeart,
  FileHeart as FileHeartIcon,
  File as FileIcon,
  FileImage,
  FileImage as FileImageIcon,
  FileInput,
  FileInput as FileInputIcon,
  FileBraces as FileJson,
  FileBracesCorner as FileJson2,
  FileBracesCorner as FileJson2Icon,
  FileBraces as FileJsonIcon,
  FileKey,
  FileKey as FileKey2,
  FileKey as FileKey2Icon,
  FileKey as FileKeyIcon,
  FileChartLine as FileLineChart,
  FileChartLine as FileLineChartIcon,
  FileLock,
  FileLock as FileLock2,
  FileLock as FileLock2Icon,
  FileLock as FileLockIcon,
  FileMinus,
  FileMinusCorner as FileMinus2,
  FileMinusCorner as FileMinus2Icon,
  FileMinusCorner,
  FileMinusCorner as FileMinusCornerIcon,
  FileMinus as FileMinusIcon,
  FileMusic,
  FileMusic as FileMusicIcon,
  FileOutput,
  FileOutput as FileOutputIcon,
  FilePen,
  FilePen as FilePenIcon,
  FilePenLine,
  FilePenLine as FilePenLineIcon,
  FileChartPie as FilePieChart,
  FileChartPie as FilePieChartIcon,
  FilePlay,
  FilePlay as FilePlayIcon,
  FilePlus,
  FilePlusCorner as FilePlus2,
  FilePlusCorner as FilePlus2Icon,
  FilePlusCorner,
  FilePlusCorner as FilePlusCornerIcon,
  FilePlus as FilePlusIcon,
  FileQuestionMark as FileQuestion,
  FileQuestionMark as FileQuestionIcon,
  FileQuestionMark,
  FileQuestionMark as FileQuestionMarkIcon,
  FileScan,
  FileScan as FileScanIcon,
  FileSearch,
  FileSearchCorner as FileSearch2,
  FileSearchCorner as FileSearch2Icon,
  FileSearchCorner,
  FileSearchCorner as FileSearchCornerIcon,
  FileSearch as FileSearchIcon,
  FileSignal,
  FileSignal as FileSignalIcon,
  FilePenLine as FileSignature,
  FilePenLine as FileSignatureIcon,
  FileSliders,
  FileSliders as FileSlidersIcon,
  FileSpreadsheet,
  FileSpreadsheet as FileSpreadsheetIcon,
  FileStack,
  FileStack as FileStackIcon,
  FileSymlink,
  FileSymlink as FileSymlinkIcon,
  FileTerminal,
  FileTerminal as FileTerminalIcon,
  FileText,
  FileText as FileTextIcon,
  FileType,
  FileTypeCorner as FileType2,
  FileTypeCorner as FileType2Icon,
  FileTypeCorner,
  FileTypeCorner as FileTypeCornerIcon,
  FileType as FileTypeIcon,
  FileUp,
  FileUp as FileUpIcon,
  FileUser,
  FileUser as FileUserIcon,
  FilePlay as FileVideo,
  FileVideoCamera as FileVideo2,
  FileVideoCamera as FileVideo2Icon,
  FileVideoCamera,
  FileVideoCamera as FileVideoCameraIcon,
  FilePlay as FileVideoIcon,
  FileVolume,
  FileSignal as FileVolume2,
  FileSignal as FileVolume2Icon,
  FileVolume as FileVolumeIcon,
  FileExclamationPoint as FileWarning,
  FileExclamationPoint as FileWarningIcon,
  FileX,
  FileXCorner as FileX2,
  FileXCorner as FileX2Icon,
  FileXCorner,
  FileXCorner as FileXCornerIcon,
  FileX as FileXIcon,
  Files,
  Files as FilesIcon,
  Film,
  Film as FilmIcon,
  Funnel as Filter,
  Funnel as FilterIcon,
  FunnelX as FilterX,
  FunnelX as FilterXIcon,
  FingerprintPattern as Fingerprint,
  FingerprintPattern as FingerprintIcon,
  FingerprintPattern,
  FingerprintPattern as FingerprintPatternIcon,
  FireExtinguisher,
  FireExtinguisher as FireExtinguisherIcon,
  Fish,
  Fish as FishIcon,
  FishOff,
  FishOff as FishOffIcon,
  FishSymbol,
  FishSymbol as FishSymbolIcon,
  FishingHook,
  FishingHook as FishingHookIcon,
  FishingRod,
  FishingRod as FishingRodIcon,
  Flag,
  Flag as FlagIcon,
  FlagOff,
  FlagOff as FlagOffIcon,
  FlagTriangleLeft,
  FlagTriangleLeft as FlagTriangleLeftIcon,
  FlagTriangleRight,
  FlagTriangleRight as FlagTriangleRightIcon,
  Flame,
  Flame as FlameIcon,
  FlameKindling,
  FlameKindling as FlameKindlingIcon,
  Flashlight,
  Flashlight as FlashlightIcon,
  FlashlightOff,
  FlashlightOff as FlashlightOffIcon,
  FlaskConical,
  FlaskConical as FlaskConicalIcon,
  FlaskConicalOff,
  FlaskConicalOff as FlaskConicalOffIcon,
  FlaskRound,
  FlaskRound as FlaskRoundIcon,
  SquareCenterlineDashedHorizontal as FlipHorizontal,
  FlipHorizontal2,
  FlipHorizontal2 as FlipHorizontal2Icon,
  SquareCenterlineDashedHorizontal as FlipHorizontalIcon,
  SquareCenterlineDashedVertical as FlipVertical,
  FlipVertical2,
  FlipVertical2 as FlipVertical2Icon,
  SquareCenterlineDashedVertical as FlipVerticalIcon,
  Flower,
  Flower2,
  Flower2 as Flower2Icon,
  Flower as FlowerIcon,
  Focus,
  Focus as FocusIcon,
  FoldHorizontal,
  FoldHorizontal as FoldHorizontalIcon,
  FoldVertical,
  FoldVertical as FoldVerticalIcon,
  Folder,
  FolderArchive,
  FolderArchive as FolderArchiveIcon,
  FolderCheck,
  FolderCheck as FolderCheckIcon,
  FolderClock,
  FolderClock as FolderClockIcon,
  FolderClosed,
  FolderClosed as FolderClosedIcon,
  FolderCode,
  FolderCode as FolderCodeIcon,
  FolderCog,
  FolderCog as FolderCog2,
  FolderCog as FolderCog2Icon,
  FolderCog as FolderCogIcon,
  FolderDot,
  FolderDot as FolderDotIcon,
  FolderDown,
  FolderDown as FolderDownIcon,
  FolderPen as FolderEdit,
  FolderPen as FolderEditIcon,
  FolderGit,
  FolderGit2,
  FolderGit2 as FolderGit2Icon,
  FolderGit as FolderGitIcon,
  FolderHeart,
  FolderHeart as FolderHeartIcon,
  Folder as FolderIcon,
  FolderInput,
  FolderInput as FolderInputIcon,
  FolderKanban,
  FolderKanban as FolderKanbanIcon,
  FolderKey,
  FolderKey as FolderKeyIcon,
  FolderLock,
  FolderLock as FolderLockIcon,
  FolderMinus,
  FolderMinus as FolderMinusIcon,
  FolderOpen,
  FolderOpenDot,
  FolderOpenDot as FolderOpenDotIcon,
  FolderOpen as FolderOpenIcon,
  FolderOutput,
  FolderOutput as FolderOutputIcon,
  FolderPen,
  FolderPen as FolderPenIcon,
  FolderPlus,
  FolderPlus as FolderPlusIcon,
  FolderRoot,
  FolderRoot as FolderRootIcon,
  FolderSearch,
  FolderSearch2,
  FolderSearch2 as FolderSearch2Icon,
  FolderSearch as FolderSearchIcon,
  FolderSymlink,
  FolderSymlink as FolderSymlinkIcon,
  FolderSync,
  FolderSync as FolderSyncIcon,
  FolderTree,
  FolderTree as FolderTreeIcon,
  FolderUp,
  FolderUp as FolderUpIcon,
  FolderX,
  FolderX as FolderXIcon,
  Folders,
  Folders as FoldersIcon,
  Footprints,
  Footprints as FootprintsIcon,
  Utensils as ForkKnife,
  UtensilsCrossed as ForkKnifeCrossed,
  UtensilsCrossed as ForkKnifeCrossedIcon,
  Utensils as ForkKnifeIcon,
  Forklift,
  Forklift as ForkliftIcon,
  Form,
  Form as FormIcon,
  RectangleEllipsis as FormInput,
  RectangleEllipsis as FormInputIcon,
  Forward,
  Forward as ForwardIcon,
  Frame,
  Frame as FrameIcon,
  Framer,
  Framer as FramerIcon,
  Frown,
  Frown as FrownIcon,
  Fuel,
  Fuel as FuelIcon,
  Fullscreen,
  Fullscreen as FullscreenIcon,
  SquareFunction as FunctionSquare,
  SquareFunction as FunctionSquareIcon,
  Funnel,
  Funnel as FunnelIcon,
  FunnelPlus,
  FunnelPlus as FunnelPlusIcon,
  FunnelX,
  FunnelX as FunnelXIcon,
  GalleryHorizontal,
  GalleryHorizontalEnd,
  GalleryHorizontalEnd as GalleryHorizontalEndIcon,
  GalleryHorizontal as GalleryHorizontalIcon,
  GalleryThumbnails,
  GalleryThumbnails as GalleryThumbnailsIcon,
  GalleryVertical,
  GalleryVerticalEnd,
  GalleryVerticalEnd as GalleryVerticalEndIcon,
  GalleryVertical as GalleryVerticalIcon,
  Gamepad,
  Gamepad2,
  Gamepad2 as Gamepad2Icon,
  GamepadDirectional,
  GamepadDirectional as GamepadDirectionalIcon,
  Gamepad as GamepadIcon,
  ChartNoAxesGantt as GanttChart,
  ChartNoAxesGantt as GanttChartIcon,
  SquareChartGantt as GanttChartSquare,
  SquareChartGantt as GanttChartSquareIcon,
  Gauge,
  CircleGauge as GaugeCircle,
  CircleGauge as GaugeCircleIcon,
  Gauge as GaugeIcon,
  Gavel,
  Gavel as GavelIcon,
  Gem,
  Gem as GemIcon,
  GeorgianLari,
  GeorgianLari as GeorgianLariIcon,
  Ghost,
  Ghost as GhostIcon,
  Gift,
  Gift as GiftIcon,
  GitBranch,
  GitBranch as GitBranchIcon,
  GitBranchMinus,
  GitBranchMinus as GitBranchMinusIcon,
  GitBranchPlus,
  GitBranchPlus as GitBranchPlusIcon,
  GitCommitHorizontal as GitCommit,
  GitCommitHorizontal,
  GitCommitHorizontal as GitCommitHorizontalIcon,
  GitCommitHorizontal as GitCommitIcon,
  GitCommitVertical,
  GitCommitVertical as GitCommitVerticalIcon,
  GitCompare,
  GitCompareArrows,
  GitCompareArrows as GitCompareArrowsIcon,
  GitCompare as GitCompareIcon,
  GitFork,
  GitFork as GitForkIcon,
  GitGraph,
  GitGraph as GitGraphIcon,
  GitMerge,
  GitMergeConflict,
  GitMergeConflict as GitMergeConflictIcon,
  GitMerge as GitMergeIcon,
  GitPullRequest,
  GitPullRequestArrow,
  GitPullRequestArrow as GitPullRequestArrowIcon,
  GitPullRequestClosed,
  GitPullRequestClosed as GitPullRequestClosedIcon,
  GitPullRequestCreate,
  GitPullRequestCreateArrow,
  GitPullRequestCreateArrow as GitPullRequestCreateArrowIcon,
  GitPullRequestCreate as GitPullRequestCreateIcon,
  GitPullRequestDraft,
  GitPullRequestDraft as GitPullRequestDraftIcon,
  GitPullRequest as GitPullRequestIcon,
  Github,
  Github as GithubIcon,
  Gitlab,
  Gitlab as GitlabIcon,
  GlassWater,
  GlassWater as GlassWaterIcon,
  Glasses,
  Glasses as GlassesIcon,
  Globe,
  Earth as Globe2,
  Earth as Globe2Icon,
  Globe as GlobeIcon,
  GlobeLock,
  GlobeLock as GlobeLockIcon,
  GlobeOff,
  GlobeOff as GlobeOffIcon,
  GlobeX,
  GlobeX as GlobeXIcon,
  Goal,
  Goal as GoalIcon,
  Gpu,
  Gpu as GpuIcon,
  HandGrab as Grab,
  HandGrab as GrabIcon,
  GraduationCap,
  GraduationCap as GraduationCapIcon,
  Grape,
  Grape as GrapeIcon,
  Grid3x3 as Grid,
  Grid2x2 as Grid2X2,
  Grid2x2Check as Grid2X2Check,
  Grid2x2Check as Grid2X2CheckIcon,
  Grid2x2 as Grid2X2Icon,
  Grid2x2Plus as Grid2X2Plus,
  Grid2x2Plus as Grid2X2PlusIcon,
  Grid2x2X as Grid2X2X,
  Grid2x2X as Grid2X2XIcon,
  Grid2x2,
  Grid2x2Check,
  Grid2x2Check as Grid2x2CheckIcon,
  Grid2x2 as Grid2x2Icon,
  Grid2x2Plus,
  Grid2x2Plus as Grid2x2PlusIcon,
  Grid2x2X,
  Grid2x2X as Grid2x2XIcon,
  Grid3x3 as Grid3X3,
  Grid3x3 as Grid3X3Icon,
  Grid3x2,
  Grid3x2 as Grid3x2Icon,
  Grid3x3,
  Grid3x3 as Grid3x3Icon,
  Grid3x3 as GridIcon,
  Grip,
  GripHorizontal,
  GripHorizontal as GripHorizontalIcon,
  Grip as GripIcon,
  GripVertical,
  GripVertical as GripVerticalIcon,
  Group,
  Group as GroupIcon,
  Guitar,
  Guitar as GuitarIcon,
  Ham,
  Ham as HamIcon,
  Hamburger,
  Hamburger as HamburgerIcon,
  Hammer,
  Hammer as HammerIcon,
  Hand,
  HandCoins,
  HandCoins as HandCoinsIcon,
  HandFist,
  HandFist as HandFistIcon,
  HandGrab,
  HandGrab as HandGrabIcon,
  HandHeart,
  HandHeart as HandHeartIcon,
  HandHelping,
  HandHelping as HandHelpingIcon,
  Hand as HandIcon,
  HandMetal,
  HandMetal as HandMetalIcon,
  HandPlatter,
  HandPlatter as HandPlatterIcon,
  Handbag,
  Handbag as HandbagIcon,
  Handshake,
  Handshake as HandshakeIcon,
  HardDrive,
  HardDriveDownload,
  HardDriveDownload as HardDriveDownloadIcon,
  HardDrive as HardDriveIcon,
  HardDriveUpload,
  HardDriveUpload as HardDriveUploadIcon,
  HardHat,
  HardHat as HardHatIcon,
  Hash,
  Hash as HashIcon,
  HatGlasses,
  HatGlasses as HatGlassesIcon,
  Haze,
  Haze as HazeIcon,
  Hd,
  Hd as HdIcon,
  HdmiPort,
  HdmiPort as HdmiPortIcon,
  Heading,
  Heading1,
  Heading1 as Heading1Icon,
  Heading2,
  Heading2 as Heading2Icon,
  Heading3,
  Heading3 as Heading3Icon,
  Heading4,
  Heading4 as Heading4Icon,
  Heading5,
  Heading5 as Heading5Icon,
  Heading6,
  Heading6 as Heading6Icon,
  Heading as HeadingIcon,
  HeadphoneOff,
  HeadphoneOff as HeadphoneOffIcon,
  Headphones,
  Headphones as HeadphonesIcon,
  Headset,
  Headset as HeadsetIcon,
  Heart,
  HeartCrack,
  HeartCrack as HeartCrackIcon,
  HeartHandshake,
  HeartHandshake as HeartHandshakeIcon,
  Heart as HeartIcon,
  HeartMinus,
  HeartMinus as HeartMinusIcon,
  HeartOff,
  HeartOff as HeartOffIcon,
  HeartPlus,
  HeartPlus as HeartPlusIcon,
  HeartPulse,
  HeartPulse as HeartPulseIcon,
  Heater,
  Heater as HeaterIcon,
  Helicopter,
  Helicopter as HelicopterIcon,
  CircleQuestionMark as HelpCircle,
  CircleQuestionMark as HelpCircleIcon,
  HandHelping as HelpingHand,
  HandHelping as HelpingHandIcon,
  Hexagon,
  Hexagon as HexagonIcon,
  Highlighter,
  Highlighter as HighlighterIcon,
  History,
  History as HistoryIcon,
  House as Home,
  House as HomeIcon,
  Hop,
  Hop as HopIcon,
  HopOff,
  HopOff as HopOffIcon,
  Hospital,
  Hospital as HospitalIcon,
  Hotel,
  Hotel as HotelIcon,
  Hourglass,
  Hourglass as HourglassIcon,
  House,
  HouseHeart,
  HouseHeart as HouseHeartIcon,
  House as HouseIcon,
  HousePlug,
  HousePlug as HousePlugIcon,
  HousePlus,
  HousePlus as HousePlusIcon,
  HouseWifi,
  HouseWifi as HouseWifiIcon,
  IceCreamCone as IceCream,
  IceCreamBowl as IceCream2,
  IceCreamBowl as IceCream2Icon,
  IceCreamBowl,
  IceCreamBowl as IceCreamBowlIcon,
  IceCreamCone,
  IceCreamCone as IceCreamConeIcon,
  IceCreamCone as IceCreamIcon,
  IdCard,
  IdCard as IdCardIcon,
  IdCardLanyard,
  IdCardLanyard as IdCardLanyardIcon,
  Image,
  ImageDown,
  ImageDown as ImageDownIcon,
  Image as ImageIcon,
  ImageMinus,
  ImageMinus as ImageMinusIcon,
  ImageOff,
  ImageOff as ImageOffIcon,
  ImagePlay,
  ImagePlay as ImagePlayIcon,
  ImagePlus,
  ImagePlus as ImagePlusIcon,
  ImageUp,
  ImageUp as ImageUpIcon,
  ImageUpscale,
  ImageUpscale as ImageUpscaleIcon,
  Images,
  Images as ImagesIcon,
  Import,
  Import as ImportIcon,
  Inbox,
  Inbox as InboxIcon,
  ListIndentIncrease as Indent,
  ListIndentDecrease as IndentDecrease,
  ListIndentDecrease as IndentDecreaseIcon,
  ListIndentIncrease as IndentIcon,
  ListIndentIncrease as IndentIncrease,
  ListIndentIncrease as IndentIncreaseIcon,
  IndianRupee,
  IndianRupee as IndianRupeeIcon,
  Infinity,
  Infinity as InfinityIcon,
  Info,
  Info as InfoIcon,
  SquareMousePointer as Inspect,
  SquareMousePointer as InspectIcon,
  InspectionPanel,
  InspectionPanel as InspectionPanelIcon,
  Instagram,
  Instagram as InstagramIcon,
  Italic,
  Italic as ItalicIcon,
  IterationCcw,
  IterationCcw as IterationCcwIcon,
  IterationCw,
  IterationCw as IterationCwIcon,
  JapaneseYen,
  JapaneseYen as JapaneseYenIcon,
  Joystick,
  Joystick as JoystickIcon,
  Kanban,
  Kanban as KanbanIcon,
  SquareKanban as KanbanSquare,
  SquareDashedKanban as KanbanSquareDashed,
  SquareDashedKanban as KanbanSquareDashedIcon,
  SquareKanban as KanbanSquareIcon,
  Kayak,
  Kayak as KayakIcon,
  Key,
  Key as KeyIcon,
  KeyRound,
  KeyRound as KeyRoundIcon,
  KeySquare,
  KeySquare as KeySquareIcon,
  Keyboard,
  Keyboard as KeyboardIcon,
  KeyboardMusic,
  KeyboardMusic as KeyboardMusicIcon,
  KeyboardOff,
  KeyboardOff as KeyboardOffIcon,
  LUCIDE_ICONS,
  Lamp,
  LampCeiling,
  LampCeiling as LampCeilingIcon,
  LampDesk,
  LampDesk as LampDeskIcon,
  LampFloor,
  LampFloor as LampFloorIcon,
  Lamp as LampIcon,
  LampWallDown,
  LampWallDown as LampWallDownIcon,
  LampWallUp,
  LampWallUp as LampWallUpIcon,
  LandPlot,
  LandPlot as LandPlotIcon,
  Landmark,
  Landmark as LandmarkIcon,
  Languages,
  Languages as LanguagesIcon,
  Laptop,
  LaptopMinimal as Laptop2,
  LaptopMinimal as Laptop2Icon,
  Laptop as LaptopIcon,
  LaptopMinimal,
  LaptopMinimalCheck,
  LaptopMinimalCheck as LaptopMinimalCheckIcon,
  LaptopMinimal as LaptopMinimalIcon,
  Lasso,
  Lasso as LassoIcon,
  LassoSelect,
  LassoSelect as LassoSelectIcon,
  Laugh,
  Laugh as LaughIcon,
  Layers,
  Layers2,
  Layers2 as Layers2Icon,
  Layers as Layers3,
  Layers as Layers3Icon,
  Layers as LayersIcon,
  LayersPlus,
  LayersPlus as LayersPlusIcon,
  PanelsTopLeft as Layout,
  LayoutDashboard,
  LayoutDashboard as LayoutDashboardIcon,
  LayoutGrid,
  LayoutGrid as LayoutGridIcon,
  PanelsTopLeft as LayoutIcon,
  LayoutList,
  LayoutList as LayoutListIcon,
  LayoutPanelLeft,
  LayoutPanelLeft as LayoutPanelLeftIcon,
  LayoutPanelTop,
  LayoutPanelTop as LayoutPanelTopIcon,
  LayoutTemplate,
  LayoutTemplate as LayoutTemplateIcon,
  Leaf,
  Leaf as LeafIcon,
  LeafyGreen,
  LeafyGreen as LeafyGreenIcon,
  Lectern,
  Lectern as LecternIcon,
  LensConcave,
  LensConcave as LensConcaveIcon,
  LensConvex,
  LensConvex as LensConvexIcon,
  TextInitial as LetterText,
  TextInitial as LetterTextIcon,
  Library,
  LibraryBig,
  LibraryBig as LibraryBigIcon,
  Library as LibraryIcon,
  SquareLibrary as LibrarySquare,
  SquareLibrary as LibrarySquareIcon,
  LifeBuoy,
  LifeBuoy as LifeBuoyIcon,
  Ligature,
  Ligature as LigatureIcon,
  Lightbulb,
  Lightbulb as LightbulbIcon,
  LightbulbOff,
  LightbulbOff as LightbulbOffIcon,
  ChartLine as LineChart,
  ChartLine as LineChartIcon,
  LineDotRightHorizontal,
  LineDotRightHorizontal as LineDotRightHorizontalIcon,
  LineSquiggle,
  LineSquiggle as LineSquiggleIcon,
  Link,
  Link2,
  Link2 as Link2Icon,
  Link2Off,
  Link2Off as Link2OffIcon,
  Link as LinkIcon,
  Linkedin,
  Linkedin as LinkedinIcon,
  List,
  ListCheck,
  ListCheck as ListCheckIcon,
  ListChecks,
  ListChecks as ListChecksIcon,
  ListChevronsDownUp,
  ListChevronsDownUp as ListChevronsDownUpIcon,
  ListChevronsUpDown,
  ListChevronsUpDown as ListChevronsUpDownIcon,
  ListCollapse,
  ListCollapse as ListCollapseIcon,
  ListEnd,
  ListEnd as ListEndIcon,
  ListFilter,
  ListFilter as ListFilterIcon,
  ListFilterPlus,
  ListFilterPlus as ListFilterPlusIcon,
  List as ListIcon,
  ListIndentDecrease,
  ListIndentDecrease as ListIndentDecreaseIcon,
  ListIndentIncrease,
  ListIndentIncrease as ListIndentIncreaseIcon,
  ListMinus,
  ListMinus as ListMinusIcon,
  ListMusic,
  ListMusic as ListMusicIcon,
  ListOrdered,
  ListOrdered as ListOrderedIcon,
  ListPlus,
  ListPlus as ListPlusIcon,
  ListRestart,
  ListRestart as ListRestartIcon,
  ListStart,
  ListStart as ListStartIcon,
  ListTodo,
  ListTodo as ListTodoIcon,
  ListTree,
  ListTree as ListTreeIcon,
  ListVideo,
  ListVideo as ListVideoIcon,
  ListX,
  ListX as ListXIcon,
  Loader,
  LoaderCircle as Loader2,
  LoaderCircle as Loader2Icon,
  LoaderCircle,
  LoaderCircle as LoaderCircleIcon,
  Loader as LoaderIcon,
  LoaderPinwheel,
  LoaderPinwheel as LoaderPinwheelIcon,
  Locate,
  LocateFixed,
  LocateFixed as LocateFixedIcon,
  Locate as LocateIcon,
  LocateOff,
  LocateOff as LocateOffIcon,
  MapPinPen as LocationEdit,
  MapPinPen as LocationEditIcon,
  Lock,
  Lock as LockIcon,
  LockKeyhole,
  LockKeyhole as LockKeyholeIcon,
  LockKeyholeOpen,
  LockKeyholeOpen as LockKeyholeOpenIcon,
  LockOpen,
  LockOpen as LockOpenIcon,
  LogIn,
  LogIn as LogInIcon,
  LogOut,
  LogOut as LogOutIcon,
  Logs,
  Logs as LogsIcon,
  Lollipop,
  Lollipop as LollipopIcon,
  AArrowDown as LucideAArrowDown,
  AArrowUp as LucideAArrowUp,
  ALargeSmall as LucideALargeSmall,
  Accessibility as LucideAccessibility,
  Activity as LucideActivity,
  SquareActivity as LucideActivitySquare,
  AirVent as LucideAirVent,
  Airplay as LucideAirplay,
  AlarmClockCheck as LucideAlarmCheck,
  AlarmClock as LucideAlarmClock,
  AlarmClockCheck as LucideAlarmClockCheck,
  AlarmClockMinus as LucideAlarmClockMinus,
  AlarmClockOff as LucideAlarmClockOff,
  AlarmClockPlus as LucideAlarmClockPlus,
  AlarmClockMinus as LucideAlarmMinus,
  AlarmClockPlus as LucideAlarmPlus,
  AlarmSmoke as LucideAlarmSmoke,
  Album as LucideAlbum,
  CircleAlert as LucideAlertCircle,
  OctagonAlert as LucideAlertOctagon,
  TriangleAlert as LucideAlertTriangle,
  TextAlignCenter as LucideAlignCenter,
  AlignCenterHorizontal as LucideAlignCenterHorizontal,
  AlignCenterVertical as LucideAlignCenterVertical,
  AlignEndHorizontal as LucideAlignEndHorizontal,
  AlignEndVertical as LucideAlignEndVertical,
  AlignHorizontalDistributeCenter as LucideAlignHorizontalDistributeCenter,
  AlignHorizontalDistributeEnd as LucideAlignHorizontalDistributeEnd,
  AlignHorizontalDistributeStart as LucideAlignHorizontalDistributeStart,
  AlignHorizontalJustifyCenter as LucideAlignHorizontalJustifyCenter,
  AlignHorizontalJustifyEnd as LucideAlignHorizontalJustifyEnd,
  AlignHorizontalJustifyStart as LucideAlignHorizontalJustifyStart,
  AlignHorizontalSpaceAround as LucideAlignHorizontalSpaceAround,
  AlignHorizontalSpaceBetween as LucideAlignHorizontalSpaceBetween,
  TextAlignJustify as LucideAlignJustify,
  TextAlignStart as LucideAlignLeft,
  TextAlignEnd as LucideAlignRight,
  AlignStartHorizontal as LucideAlignStartHorizontal,
  AlignStartVertical as LucideAlignStartVertical,
  AlignVerticalDistributeCenter as LucideAlignVerticalDistributeCenter,
  AlignVerticalDistributeEnd as LucideAlignVerticalDistributeEnd,
  AlignVerticalDistributeStart as LucideAlignVerticalDistributeStart,
  AlignVerticalJustifyCenter as LucideAlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd as LucideAlignVerticalJustifyEnd,
  AlignVerticalJustifyStart as LucideAlignVerticalJustifyStart,
  AlignVerticalSpaceAround as LucideAlignVerticalSpaceAround,
  AlignVerticalSpaceBetween as LucideAlignVerticalSpaceBetween,
  Ambulance as LucideAmbulance,
  Ampersand as LucideAmpersand,
  Ampersands as LucideAmpersands,
  Amphora as LucideAmphora,
  Anchor as LucideAnchor,
  Angry as LucideAngry,
  LucideAngularComponent,
  LucideAngularModule,
  Annoyed as LucideAnnoyed,
  Antenna as LucideAntenna,
  Anvil as LucideAnvil,
  Aperture as LucideAperture,
  AppWindow as LucideAppWindow,
  AppWindowMac as LucideAppWindowMac,
  Apple as LucideApple,
  Archive as LucideArchive,
  ArchiveRestore as LucideArchiveRestore,
  ArchiveX as LucideArchiveX,
  ChartArea as LucideAreaChart,
  Armchair as LucideArmchair,
  ArrowBigDown as LucideArrowBigDown,
  ArrowBigDownDash as LucideArrowBigDownDash,
  ArrowBigLeft as LucideArrowBigLeft,
  ArrowBigLeftDash as LucideArrowBigLeftDash,
  ArrowBigRight as LucideArrowBigRight,
  ArrowBigRightDash as LucideArrowBigRightDash,
  ArrowBigUp as LucideArrowBigUp,
  ArrowBigUpDash as LucideArrowBigUpDash,
  ArrowDown as LucideArrowDown,
  ArrowDown01 as LucideArrowDown01,
  ArrowDown10 as LucideArrowDown10,
  ArrowDownAZ as LucideArrowDownAZ,
  ArrowDownAZ as LucideArrowDownAz,
  CircleArrowDown as LucideArrowDownCircle,
  ArrowDownFromLine as LucideArrowDownFromLine,
  ArrowDownLeft as LucideArrowDownLeft,
  CircleArrowOutDownLeft as LucideArrowDownLeftFromCircle,
  SquareArrowOutDownLeft as LucideArrowDownLeftFromSquare,
  SquareArrowDownLeft as LucideArrowDownLeftSquare,
  ArrowDownNarrowWide as LucideArrowDownNarrowWide,
  ArrowDownRight as LucideArrowDownRight,
  CircleArrowOutDownRight as LucideArrowDownRightFromCircle,
  SquareArrowOutDownRight as LucideArrowDownRightFromSquare,
  SquareArrowDownRight as LucideArrowDownRightSquare,
  SquareArrowDown as LucideArrowDownSquare,
  ArrowDownToDot as LucideArrowDownToDot,
  ArrowDownToLine as LucideArrowDownToLine,
  ArrowDownUp as LucideArrowDownUp,
  ArrowDownWideNarrow as LucideArrowDownWideNarrow,
  ArrowDownZA as LucideArrowDownZA,
  ArrowDownZA as LucideArrowDownZa,
  ArrowLeft as LucideArrowLeft,
  CircleArrowLeft as LucideArrowLeftCircle,
  ArrowLeftFromLine as LucideArrowLeftFromLine,
  ArrowLeftRight as LucideArrowLeftRight,
  SquareArrowLeft as LucideArrowLeftSquare,
  ArrowLeftToLine as LucideArrowLeftToLine,
  ArrowRight as LucideArrowRight,
  CircleArrowRight as LucideArrowRightCircle,
  ArrowRightFromLine as LucideArrowRightFromLine,
  ArrowRightLeft as LucideArrowRightLeft,
  SquareArrowRight as LucideArrowRightSquare,
  ArrowRightToLine as LucideArrowRightToLine,
  ArrowUp as LucideArrowUp,
  ArrowUp01 as LucideArrowUp01,
  ArrowUp10 as LucideArrowUp10,
  ArrowUpAZ as LucideArrowUpAZ,
  ArrowUpAZ as LucideArrowUpAz,
  CircleArrowUp as LucideArrowUpCircle,
  ArrowUpDown as LucideArrowUpDown,
  ArrowUpFromDot as LucideArrowUpFromDot,
  ArrowUpFromLine as LucideArrowUpFromLine,
  ArrowUpLeft as LucideArrowUpLeft,
  CircleArrowOutUpLeft as LucideArrowUpLeftFromCircle,
  SquareArrowOutUpLeft as LucideArrowUpLeftFromSquare,
  SquareArrowUpLeft as LucideArrowUpLeftSquare,
  ArrowUpNarrowWide as LucideArrowUpNarrowWide,
  ArrowUpRight as LucideArrowUpRight,
  CircleArrowOutUpRight as LucideArrowUpRightFromCircle,
  SquareArrowOutUpRight as LucideArrowUpRightFromSquare,
  SquareArrowUpRight as LucideArrowUpRightSquare,
  SquareArrowUp as LucideArrowUpSquare,
  ArrowUpToLine as LucideArrowUpToLine,
  ArrowUpWideNarrow as LucideArrowUpWideNarrow,
  ArrowUpZA as LucideArrowUpZA,
  ArrowUpZA as LucideArrowUpZa,
  ArrowsUpFromLine as LucideArrowsUpFromLine,
  Asterisk as LucideAsterisk,
  SquareAsterisk as LucideAsteriskSquare,
  AtSign as LucideAtSign,
  Atom as LucideAtom,
  AudioLines as LucideAudioLines,
  AudioWaveform as LucideAudioWaveform,
  Award as LucideAward,
  Axe as LucideAxe,
  Axis3d as LucideAxis3D,
  Axis3d as LucideAxis3d,
  Baby as LucideBaby,
  Backpack as LucideBackpack,
  Badge as LucideBadge,
  BadgeAlert as LucideBadgeAlert,
  BadgeCent as LucideBadgeCent,
  BadgeCheck as LucideBadgeCheck,
  BadgeDollarSign as LucideBadgeDollarSign,
  BadgeEuro as LucideBadgeEuro,
  BadgeQuestionMark as LucideBadgeHelp,
  BadgeIndianRupee as LucideBadgeIndianRupee,
  BadgeInfo as LucideBadgeInfo,
  BadgeJapaneseYen as LucideBadgeJapaneseYen,
  BadgeMinus as LucideBadgeMinus,
  BadgePercent as LucideBadgePercent,
  BadgePlus as LucideBadgePlus,
  BadgePoundSterling as LucideBadgePoundSterling,
  BadgeQuestionMark as LucideBadgeQuestionMark,
  BadgeRussianRuble as LucideBadgeRussianRuble,
  BadgeSwissFranc as LucideBadgeSwissFranc,
  BadgeTurkishLira as LucideBadgeTurkishLira,
  BadgeX as LucideBadgeX,
  BaggageClaim as LucideBaggageClaim,
  Balloon as LucideBalloon,
  Ban as LucideBan,
  Banana as LucideBanana,
  Bandage as LucideBandage,
  Banknote as LucideBanknote,
  BanknoteArrowDown as LucideBanknoteArrowDown,
  BanknoteArrowUp as LucideBanknoteArrowUp,
  BanknoteX as LucideBanknoteX,
  ChartNoAxesColumnIncreasing as LucideBarChart,
  ChartNoAxesColumn as LucideBarChart2,
  ChartColumn as LucideBarChart3,
  ChartColumnIncreasing as LucideBarChart4,
  ChartColumnBig as LucideBarChartBig,
  ChartBar as LucideBarChartHorizontal,
  ChartBarBig as LucideBarChartHorizontalBig,
  Barcode as LucideBarcode,
  Barrel as LucideBarrel,
  Baseline as LucideBaseline,
  Bath as LucideBath,
  Battery as LucideBattery,
  BatteryCharging as LucideBatteryCharging,
  BatteryFull as LucideBatteryFull,
  BatteryLow as LucideBatteryLow,
  BatteryMedium as LucideBatteryMedium,
  BatteryPlus as LucideBatteryPlus,
  BatteryWarning as LucideBatteryWarning,
  Beaker as LucideBeaker,
  Bean as LucideBean,
  BeanOff as LucideBeanOff,
  Bed as LucideBed,
  BedDouble as LucideBedDouble,
  BedSingle as LucideBedSingle,
  Beef as LucideBeef,
  Beer as LucideBeer,
  BeerOff as LucideBeerOff,
  Bell as LucideBell,
  BellDot as LucideBellDot,
  BellElectric as LucideBellElectric,
  BellMinus as LucideBellMinus,
  BellOff as LucideBellOff,
  BellPlus as LucideBellPlus,
  BellRing as LucideBellRing,
  BetweenHorizontalEnd as LucideBetweenHorizonalEnd,
  BetweenHorizontalStart as LucideBetweenHorizonalStart,
  BetweenHorizontalEnd as LucideBetweenHorizontalEnd,
  BetweenHorizontalStart as LucideBetweenHorizontalStart,
  BetweenVerticalEnd as LucideBetweenVerticalEnd,
  BetweenVerticalStart as LucideBetweenVerticalStart,
  BicepsFlexed as LucideBicepsFlexed,
  Bike as LucideBike,
  Binary as LucideBinary,
  Binoculars as LucideBinoculars,
  Biohazard as LucideBiohazard,
  Bird as LucideBird,
  Birdhouse as LucideBirdhouse,
  Bitcoin as LucideBitcoin,
  Blend as LucideBlend,
  Blinds as LucideBlinds,
  Blocks as LucideBlocks,
  Bluetooth as LucideBluetooth,
  BluetoothConnected as LucideBluetoothConnected,
  BluetoothOff as LucideBluetoothOff,
  BluetoothSearching as LucideBluetoothSearching,
  Bold as LucideBold,
  Bolt as LucideBolt,
  Bomb as LucideBomb,
  Bone as LucideBone,
  Book as LucideBook,
  BookA as LucideBookA,
  BookAlert as LucideBookAlert,
  BookAudio as LucideBookAudio,
  BookCheck as LucideBookCheck,
  BookCopy as LucideBookCopy,
  BookDashed as LucideBookDashed,
  BookDown as LucideBookDown,
  BookHeadphones as LucideBookHeadphones,
  BookHeart as LucideBookHeart,
  BookImage as LucideBookImage,
  BookKey as LucideBookKey,
  BookLock as LucideBookLock,
  BookMarked as LucideBookMarked,
  BookMinus as LucideBookMinus,
  BookOpen as LucideBookOpen,
  BookOpenCheck as LucideBookOpenCheck,
  BookOpenText as LucideBookOpenText,
  BookPlus as LucideBookPlus,
  BookSearch as LucideBookSearch,
  BookDashed as LucideBookTemplate,
  BookText as LucideBookText,
  BookType as LucideBookType,
  BookUp as LucideBookUp,
  BookUp2 as LucideBookUp2,
  BookUser as LucideBookUser,
  BookX as LucideBookX,
  Bookmark as LucideBookmark,
  BookmarkCheck as LucideBookmarkCheck,
  BookmarkMinus as LucideBookmarkMinus,
  BookmarkPlus as LucideBookmarkPlus,
  BookmarkX as LucideBookmarkX,
  BoomBox as LucideBoomBox,
  Bot as LucideBot,
  BotMessageSquare as LucideBotMessageSquare,
  BotOff as LucideBotOff,
  BottleWine as LucideBottleWine,
  BowArrow as LucideBowArrow,
  Box as LucideBox,
  SquareDashed as LucideBoxSelect,
  Boxes as LucideBoxes,
  Braces as LucideBraces,
  Brackets as LucideBrackets,
  Brain as LucideBrain,
  BrainCircuit as LucideBrainCircuit,
  BrainCog as LucideBrainCog,
  BrickWall as LucideBrickWall,
  BrickWallFire as LucideBrickWallFire,
  BrickWallShield as LucideBrickWallShield,
  Briefcase as LucideBriefcase,
  BriefcaseBusiness as LucideBriefcaseBusiness,
  BriefcaseConveyorBelt as LucideBriefcaseConveyorBelt,
  BriefcaseMedical as LucideBriefcaseMedical,
  BringToFront as LucideBringToFront,
  Brush as LucideBrush,
  BrushCleaning as LucideBrushCleaning,
  Bubbles as LucideBubbles,
  Bug as LucideBug,
  BugOff as LucideBugOff,
  BugPlay as LucideBugPlay,
  Building as LucideBuilding,
  Building2 as LucideBuilding2,
  Bus as LucideBus,
  BusFront as LucideBusFront,
  Cable as LucideCable,
  CableCar as LucideCableCar,
  Cake as LucideCake,
  CakeSlice as LucideCakeSlice,
  Calculator as LucideCalculator,
  Calendar as LucideCalendar,
  Calendar1 as LucideCalendar1,
  CalendarArrowDown as LucideCalendarArrowDown,
  CalendarArrowUp as LucideCalendarArrowUp,
  CalendarCheck as LucideCalendarCheck,
  CalendarCheck2 as LucideCalendarCheck2,
  CalendarClock as LucideCalendarClock,
  CalendarCog as LucideCalendarCog,
  CalendarDays as LucideCalendarDays,
  CalendarFold as LucideCalendarFold,
  CalendarHeart as LucideCalendarHeart,
  CalendarMinus as LucideCalendarMinus,
  CalendarMinus2 as LucideCalendarMinus2,
  CalendarOff as LucideCalendarOff,
  CalendarPlus as LucideCalendarPlus,
  CalendarPlus2 as LucideCalendarPlus2,
  CalendarRange as LucideCalendarRange,
  CalendarSearch as LucideCalendarSearch,
  CalendarSync as LucideCalendarSync,
  CalendarX as LucideCalendarX,
  CalendarX2 as LucideCalendarX2,
  Calendars as LucideCalendars,
  Camera as LucideCamera,
  CameraOff as LucideCameraOff,
  ChartCandlestick as LucideCandlestickChart,
  Candy as LucideCandy,
  CandyCane as LucideCandyCane,
  CandyOff as LucideCandyOff,
  Cannabis as LucideCannabis,
  CannabisOff as LucideCannabisOff,
  Captions as LucideCaptions,
  CaptionsOff as LucideCaptionsOff,
  Car as LucideCar,
  CarFront as LucideCarFront,
  CarTaxiFront as LucideCarTaxiFront,
  Caravan as LucideCaravan,
  CardSim as LucideCardSim,
  Carrot as LucideCarrot,
  CaseLower as LucideCaseLower,
  CaseSensitive as LucideCaseSensitive,
  CaseUpper as LucideCaseUpper,
  CassetteTape as LucideCassetteTape,
  Cast as LucideCast,
  Castle as LucideCastle,
  Cat as LucideCat,
  Cctv as LucideCctv,
  CctvOff as LucideCctvOff,
  ChartArea as LucideChartArea,
  ChartBar as LucideChartBar,
  ChartBarBig as LucideChartBarBig,
  ChartBarDecreasing as LucideChartBarDecreasing,
  ChartBarIncreasing as LucideChartBarIncreasing,
  ChartBarStacked as LucideChartBarStacked,
  ChartCandlestick as LucideChartCandlestick,
  ChartColumn as LucideChartColumn,
  ChartColumnBig as LucideChartColumnBig,
  ChartColumnDecreasing as LucideChartColumnDecreasing,
  ChartColumnIncreasing as LucideChartColumnIncreasing,
  ChartColumnStacked as LucideChartColumnStacked,
  ChartGantt as LucideChartGantt,
  ChartLine as LucideChartLine,
  ChartNetwork as LucideChartNetwork,
  ChartNoAxesColumn as LucideChartNoAxesColumn,
  ChartNoAxesColumnDecreasing as LucideChartNoAxesColumnDecreasing,
  ChartNoAxesColumnIncreasing as LucideChartNoAxesColumnIncreasing,
  ChartNoAxesCombined as LucideChartNoAxesCombined,
  ChartNoAxesGantt as LucideChartNoAxesGantt,
  ChartPie as LucideChartPie,
  ChartScatter as LucideChartScatter,
  ChartSpline as LucideChartSpline,
  Check as LucideCheck,
  CheckCheck as LucideCheckCheck,
  CircleCheckBig as LucideCheckCircle,
  CircleCheck as LucideCheckCircle2,
  CheckLine as LucideCheckLine,
  SquareCheckBig as LucideCheckSquare,
  SquareCheck as LucideCheckSquare2,
  ChefHat as LucideChefHat,
  Cherry as LucideCherry,
  ChessBishop as LucideChessBishop,
  ChessKing as LucideChessKing,
  ChessKnight as LucideChessKnight,
  ChessPawn as LucideChessPawn,
  ChessQueen as LucideChessQueen,
  ChessRook as LucideChessRook,
  ChevronDown as LucideChevronDown,
  CircleChevronDown as LucideChevronDownCircle,
  SquareChevronDown as LucideChevronDownSquare,
  ChevronFirst as LucideChevronFirst,
  ChevronLast as LucideChevronLast,
  ChevronLeft as LucideChevronLeft,
  CircleChevronLeft as LucideChevronLeftCircle,
  SquareChevronLeft as LucideChevronLeftSquare,
  ChevronRight as LucideChevronRight,
  CircleChevronRight as LucideChevronRightCircle,
  SquareChevronRight as LucideChevronRightSquare,
  ChevronUp as LucideChevronUp,
  CircleChevronUp as LucideChevronUpCircle,
  SquareChevronUp as LucideChevronUpSquare,
  ChevronsDown as LucideChevronsDown,
  ChevronsDownUp as LucideChevronsDownUp,
  ChevronsLeft as LucideChevronsLeft,
  ChevronsLeftRight as LucideChevronsLeftRight,
  ChevronsLeftRightEllipsis as LucideChevronsLeftRightEllipsis,
  ChevronsRight as LucideChevronsRight,
  ChevronsRightLeft as LucideChevronsRightLeft,
  ChevronsUp as LucideChevronsUp,
  ChevronsUpDown as LucideChevronsUpDown,
  Chromium as LucideChrome,
  Chromium as LucideChromium,
  Church as LucideChurch,
  Cigarette as LucideCigarette,
  CigaretteOff as LucideCigaretteOff,
  Circle as LucideCircle,
  CircleAlert as LucideCircleAlert,
  CircleArrowDown as LucideCircleArrowDown,
  CircleArrowLeft as LucideCircleArrowLeft,
  CircleArrowOutDownLeft as LucideCircleArrowOutDownLeft,
  CircleArrowOutDownRight as LucideCircleArrowOutDownRight,
  CircleArrowOutUpLeft as LucideCircleArrowOutUpLeft,
  CircleArrowOutUpRight as LucideCircleArrowOutUpRight,
  CircleArrowRight as LucideCircleArrowRight,
  CircleArrowUp as LucideCircleArrowUp,
  CircleCheck as LucideCircleCheck,
  CircleCheckBig as LucideCircleCheckBig,
  CircleChevronDown as LucideCircleChevronDown,
  CircleChevronLeft as LucideCircleChevronLeft,
  CircleChevronRight as LucideCircleChevronRight,
  CircleChevronUp as LucideCircleChevronUp,
  CircleDashed as LucideCircleDashed,
  CircleDivide as LucideCircleDivide,
  CircleDollarSign as LucideCircleDollarSign,
  CircleDot as LucideCircleDot,
  CircleDotDashed as LucideCircleDotDashed,
  CircleEllipsis as LucideCircleEllipsis,
  CircleEqual as LucideCircleEqual,
  CircleFadingArrowUp as LucideCircleFadingArrowUp,
  CircleFadingPlus as LucideCircleFadingPlus,
  CircleGauge as LucideCircleGauge,
  CircleQuestionMark as LucideCircleHelp,
  CircleMinus as LucideCircleMinus,
  CircleOff as LucideCircleOff,
  CircleParking as LucideCircleParking,
  CircleParkingOff as LucideCircleParkingOff,
  CirclePause as LucideCirclePause,
  CirclePercent as LucideCirclePercent,
  CirclePile as LucideCirclePile,
  CirclePlay as LucideCirclePlay,
  CirclePlus as LucideCirclePlus,
  CirclePoundSterling as LucideCirclePoundSterling,
  CirclePower as LucideCirclePower,
  CircleQuestionMark as LucideCircleQuestionMark,
  CircleSlash as LucideCircleSlash,
  CircleSlash2 as LucideCircleSlash2,
  CircleSlash2 as LucideCircleSlashed,
  CircleSmall as LucideCircleSmall,
  CircleStar as LucideCircleStar,
  CircleStop as LucideCircleStop,
  CircleUser as LucideCircleUser,
  CircleUserRound as LucideCircleUserRound,
  CircleX as LucideCircleX,
  CircuitBoard as LucideCircuitBoard,
  Citrus as LucideCitrus,
  Clapperboard as LucideClapperboard,
  Clipboard as LucideClipboard,
  ClipboardCheck as LucideClipboardCheck,
  ClipboardClock as LucideClipboardClock,
  ClipboardCopy as LucideClipboardCopy,
  ClipboardPen as LucideClipboardEdit,
  ClipboardList as LucideClipboardList,
  ClipboardMinus as LucideClipboardMinus,
  ClipboardPaste as LucideClipboardPaste,
  ClipboardPen as LucideClipboardPen,
  ClipboardPenLine as LucideClipboardPenLine,
  ClipboardPlus as LucideClipboardPlus,
  ClipboardPenLine as LucideClipboardSignature,
  ClipboardType as LucideClipboardType,
  ClipboardX as LucideClipboardX,
  Clock as LucideClock,
  Clock1 as LucideClock1,
  Clock10 as LucideClock10,
  Clock11 as LucideClock11,
  Clock12 as LucideClock12,
  Clock2 as LucideClock2,
  Clock3 as LucideClock3,
  Clock4 as LucideClock4,
  Clock5 as LucideClock5,
  Clock6 as LucideClock6,
  Clock7 as LucideClock7,
  Clock8 as LucideClock8,
  Clock9 as LucideClock9,
  ClockAlert as LucideClockAlert,
  ClockArrowDown as LucideClockArrowDown,
  ClockArrowUp as LucideClockArrowUp,
  ClockCheck as LucideClockCheck,
  ClockFading as LucideClockFading,
  ClockPlus as LucideClockPlus,
  ClosedCaption as LucideClosedCaption,
  Cloud as LucideCloud,
  CloudAlert as LucideCloudAlert,
  CloudBackup as LucideCloudBackup,
  CloudCheck as LucideCloudCheck,
  CloudCog as LucideCloudCog,
  CloudDownload as LucideCloudDownload,
  CloudDrizzle as LucideCloudDrizzle,
  CloudFog as LucideCloudFog,
  CloudHail as LucideCloudHail,
  CloudLightning as LucideCloudLightning,
  CloudMoon as LucideCloudMoon,
  CloudMoonRain as LucideCloudMoonRain,
  CloudOff as LucideCloudOff,
  CloudRain as LucideCloudRain,
  CloudRainWind as LucideCloudRainWind,
  CloudSnow as LucideCloudSnow,
  CloudSun as LucideCloudSun,
  CloudSunRain as LucideCloudSunRain,
  CloudSync as LucideCloudSync,
  CloudUpload as LucideCloudUpload,
  Cloudy as LucideCloudy,
  Clover as LucideClover,
  Club as LucideClub,
  Code as LucideCode,
  CodeXml as LucideCode2,
  SquareCode as LucideCodeSquare,
  CodeXml as LucideCodeXml,
  Codepen as LucideCodepen,
  Codesandbox as LucideCodesandbox,
  Coffee as LucideCoffee,
  Cog as LucideCog,
  Coins as LucideCoins,
  Columns2 as LucideColumns,
  Columns2 as LucideColumns2,
  Columns3 as LucideColumns3,
  Columns3Cog as LucideColumns3Cog,
  Columns4 as LucideColumns4,
  Columns3Cog as LucideColumnsSettings,
  Combine as LucideCombine,
  Command as LucideCommand,
  Compass as LucideCompass,
  Component2 as LucideComponent,
  Computer as LucideComputer,
  ConciergeBell as LucideConciergeBell,
  Cone as LucideCone,
  Construction as LucideConstruction,
  Contact as LucideContact,
  ContactRound as LucideContact2,
  ContactRound as LucideContactRound,
  Container as LucideContainer,
  Contrast as LucideContrast,
  Cookie as LucideCookie,
  CookingPot as LucideCookingPot,
  Copy as LucideCopy,
  CopyCheck as LucideCopyCheck,
  CopyMinus as LucideCopyMinus,
  CopyPlus as LucideCopyPlus,
  CopySlash as LucideCopySlash,
  CopyX as LucideCopyX,
  Copyleft as LucideCopyleft,
  Copyright as LucideCopyright,
  CornerDownLeft as LucideCornerDownLeft,
  CornerDownRight as LucideCornerDownRight,
  CornerLeftDown as LucideCornerLeftDown,
  CornerLeftUp as LucideCornerLeftUp,
  CornerRightDown as LucideCornerRightDown,
  CornerRightUp as LucideCornerRightUp,
  CornerUpLeft as LucideCornerUpLeft,
  CornerUpRight as LucideCornerUpRight,
  Cpu as LucideCpu,
  CreativeCommons as LucideCreativeCommons,
  CreditCard as LucideCreditCard,
  Croissant as LucideCroissant,
  Crop as LucideCrop,
  Cross as LucideCross,
  Crosshair as LucideCrosshair,
  Crown as LucideCrown,
  Cuboid as LucideCuboid,
  CupSoda as LucideCupSoda,
  Braces as LucideCurlyBraces,
  Currency as LucideCurrency,
  Cylinder as LucideCylinder,
  Dam as LucideDam,
  Database as LucideDatabase,
  DatabaseBackup as LucideDatabaseBackup,
  DatabaseSearch as LucideDatabaseSearch,
  DatabaseZap as LucideDatabaseZap,
  DecimalsArrowLeft as LucideDecimalsArrowLeft,
  DecimalsArrowRight as LucideDecimalsArrowRight,
  Delete as LucideDelete,
  Dessert as LucideDessert,
  Diameter as LucideDiameter,
  Diamond as LucideDiamond,
  DiamondMinus as LucideDiamondMinus,
  DiamondPercent as LucideDiamondPercent,
  DiamondPlus as LucideDiamondPlus,
  Dice1 as LucideDice1,
  Dice2 as LucideDice2,
  Dice3 as LucideDice3,
  Dice4 as LucideDice4,
  Dice5 as LucideDice5,
  Dice6 as LucideDice6,
  Dices as LucideDices,
  Diff as LucideDiff,
  Disc as LucideDisc,
  Disc2 as LucideDisc2,
  Disc3 as LucideDisc3,
  DiscAlbum as LucideDiscAlbum,
  Divide as LucideDivide,
  CircleDivide as LucideDivideCircle,
  SquareDivide as LucideDivideSquare,
  Dna as LucideDna,
  DnaOff as LucideDnaOff,
  Dock as LucideDock,
  Dog as LucideDog,
  DollarSign as LucideDollarSign,
  Donut as LucideDonut,
  DoorClosed as LucideDoorClosed,
  DoorClosedLocked as LucideDoorClosedLocked,
  DoorOpen as LucideDoorOpen,
  Dot as LucideDot,
  SquareDot as LucideDotSquare,
  Download as LucideDownload,
  CloudDownload as LucideDownloadCloud,
  DraftingCompass as LucideDraftingCompass,
  Drama as LucideDrama,
  Dribbble as LucideDribbble,
  Drill as LucideDrill,
  Drone as LucideDrone,
  Droplet as LucideDroplet,
  DropletOff as LucideDropletOff,
  Droplets as LucideDroplets,
  Drum as LucideDrum,
  Drumstick as LucideDrumstick,
  Dumbbell as LucideDumbbell,
  Ear as LucideEar,
  EarOff as LucideEarOff,
  Earth as LucideEarth,
  EarthLock as LucideEarthLock,
  Eclipse as LucideEclipse,
  SquarePen as LucideEdit,
  Pen as LucideEdit2,
  PenLine as LucideEdit3,
  Egg as LucideEgg,
  EggFried as LucideEggFried,
  EggOff as LucideEggOff,
  Ellipse as LucideEllipse,
  Ellipsis as LucideEllipsis,
  EllipsisVertical as LucideEllipsisVertical,
  Equal as LucideEqual,
  EqualApproximately as LucideEqualApproximately,
  EqualNot as LucideEqualNot,
  SquareEqual as LucideEqualSquare,
  Eraser as LucideEraser,
  EthernetPort as LucideEthernetPort,
  Euro as LucideEuro,
  EvCharger as LucideEvCharger,
  Expand as LucideExpand,
  ExternalLink as LucideExternalLink,
  Eye as LucideEye,
  EyeClosed as LucideEyeClosed,
  EyeOff as LucideEyeOff,
  Facebook as LucideFacebook,
  Factory as LucideFactory,
  Fan as LucideFan,
  FastForward as LucideFastForward,
  Feather as LucideFeather,
  Fence as LucideFence,
  FerrisWheel as LucideFerrisWheel,
  Figma as LucideFigma,
  File as LucideFile,
  FileArchive as LucideFileArchive,
  FileHeadphone as LucideFileAudio,
  FileHeadphone as LucideFileAudio2,
  FileAxis3d as LucideFileAxis3D,
  FileAxis3d as LucideFileAxis3d,
  FileBadge as LucideFileBadge,
  FileBadge as LucideFileBadge2,
  FileChartColumnIncreasing as LucideFileBarChart,
  FileChartColumn as LucideFileBarChart2,
  FileBox as LucideFileBox,
  FileBraces as LucideFileBraces,
  FileBracesCorner as LucideFileBracesCorner,
  FileChartColumn as LucideFileChartColumn,
  FileChartColumnIncreasing as LucideFileChartColumnIncreasing,
  FileChartLine as LucideFileChartLine,
  FileChartPie as LucideFileChartPie,
  FileCheck as LucideFileCheck,
  FileCheckCorner as LucideFileCheck2,
  FileCheckCorner as LucideFileCheckCorner,
  FileClock as LucideFileClock,
  FileCode as LucideFileCode,
  FileCodeCorner as LucideFileCode2,
  FileCodeCorner as LucideFileCodeCorner,
  FileCog as LucideFileCog,
  FileCog as LucideFileCog2,
  FileDiff as LucideFileDiff,
  FileDigit as LucideFileDigit,
  FileDown as LucideFileDown,
  FilePen as LucideFileEdit,
  FileExclamationPoint as LucideFileExclamationPoint,
  FileHeadphone as LucideFileHeadphone,
  FileHeart as LucideFileHeart,
  FileImage as LucideFileImage,
  FileInput as LucideFileInput,
  FileBraces as LucideFileJson,
  FileBracesCorner as LucideFileJson2,
  FileKey as LucideFileKey,
  FileKey as LucideFileKey2,
  FileChartLine as LucideFileLineChart,
  FileLock as LucideFileLock,
  FileLock as LucideFileLock2,
  FileMinus as LucideFileMinus,
  FileMinusCorner as LucideFileMinus2,
  FileMinusCorner as LucideFileMinusCorner,
  FileMusic as LucideFileMusic,
  FileOutput as LucideFileOutput,
  FilePen as LucideFilePen,
  FilePenLine as LucideFilePenLine,
  FileChartPie as LucideFilePieChart,
  FilePlay as LucideFilePlay,
  FilePlus as LucideFilePlus,
  FilePlusCorner as LucideFilePlus2,
  FilePlusCorner as LucideFilePlusCorner,
  FileQuestionMark as LucideFileQuestion,
  FileQuestionMark as LucideFileQuestionMark,
  FileScan as LucideFileScan,
  FileSearch as LucideFileSearch,
  FileSearchCorner as LucideFileSearch2,
  FileSearchCorner as LucideFileSearchCorner,
  FileSignal as LucideFileSignal,
  FilePenLine as LucideFileSignature,
  FileSliders as LucideFileSliders,
  FileSpreadsheet as LucideFileSpreadsheet,
  FileStack as LucideFileStack,
  FileSymlink as LucideFileSymlink,
  FileTerminal as LucideFileTerminal,
  FileText as LucideFileText,
  FileType as LucideFileType,
  FileTypeCorner as LucideFileType2,
  FileTypeCorner as LucideFileTypeCorner,
  FileUp as LucideFileUp,
  FileUser as LucideFileUser,
  FilePlay as LucideFileVideo,
  FileVideoCamera as LucideFileVideo2,
  FileVideoCamera as LucideFileVideoCamera,
  FileVolume as LucideFileVolume,
  FileSignal as LucideFileVolume2,
  FileExclamationPoint as LucideFileWarning,
  FileX as LucideFileX,
  FileXCorner as LucideFileX2,
  FileXCorner as LucideFileXCorner,
  Files as LucideFiles,
  Film as LucideFilm,
  Funnel as LucideFilter,
  FunnelX as LucideFilterX,
  FingerprintPattern as LucideFingerprint,
  FingerprintPattern as LucideFingerprintPattern,
  FireExtinguisher as LucideFireExtinguisher,
  Fish as LucideFish,
  FishOff as LucideFishOff,
  FishSymbol as LucideFishSymbol,
  FishingHook as LucideFishingHook,
  FishingRod as LucideFishingRod,
  Flag as LucideFlag,
  FlagOff as LucideFlagOff,
  FlagTriangleLeft as LucideFlagTriangleLeft,
  FlagTriangleRight as LucideFlagTriangleRight,
  Flame as LucideFlame,
  FlameKindling as LucideFlameKindling,
  Flashlight as LucideFlashlight,
  FlashlightOff as LucideFlashlightOff,
  FlaskConical as LucideFlaskConical,
  FlaskConicalOff as LucideFlaskConicalOff,
  FlaskRound as LucideFlaskRound,
  SquareCenterlineDashedHorizontal as LucideFlipHorizontal,
  FlipHorizontal2 as LucideFlipHorizontal2,
  SquareCenterlineDashedVertical as LucideFlipVertical,
  FlipVertical2 as LucideFlipVertical2,
  Flower as LucideFlower,
  Flower2 as LucideFlower2,
  Focus as LucideFocus,
  FoldHorizontal as LucideFoldHorizontal,
  FoldVertical as LucideFoldVertical,
  Folder as LucideFolder,
  FolderArchive as LucideFolderArchive,
  FolderCheck as LucideFolderCheck,
  FolderClock as LucideFolderClock,
  FolderClosed as LucideFolderClosed,
  FolderCode as LucideFolderCode,
  FolderCog as LucideFolderCog,
  FolderCog as LucideFolderCog2,
  FolderDot as LucideFolderDot,
  FolderDown as LucideFolderDown,
  FolderPen as LucideFolderEdit,
  FolderGit as LucideFolderGit,
  FolderGit2 as LucideFolderGit2,
  FolderHeart as LucideFolderHeart,
  FolderInput as LucideFolderInput,
  FolderKanban as LucideFolderKanban,
  FolderKey as LucideFolderKey,
  FolderLock as LucideFolderLock,
  FolderMinus as LucideFolderMinus,
  FolderOpen as LucideFolderOpen,
  FolderOpenDot as LucideFolderOpenDot,
  FolderOutput as LucideFolderOutput,
  FolderPen as LucideFolderPen,
  FolderPlus as LucideFolderPlus,
  FolderRoot as LucideFolderRoot,
  FolderSearch as LucideFolderSearch,
  FolderSearch2 as LucideFolderSearch2,
  FolderSymlink as LucideFolderSymlink,
  FolderSync as LucideFolderSync,
  FolderTree as LucideFolderTree,
  FolderUp as LucideFolderUp,
  FolderX as LucideFolderX,
  Folders as LucideFolders,
  Footprints as LucideFootprints,
  Utensils as LucideForkKnife,
  UtensilsCrossed as LucideForkKnifeCrossed,
  Forklift as LucideForklift,
  Form as LucideForm,
  RectangleEllipsis as LucideFormInput,
  Forward as LucideForward,
  Frame as LucideFrame,
  Framer as LucideFramer,
  Frown as LucideFrown,
  Fuel as LucideFuel,
  Fullscreen as LucideFullscreen,
  SquareFunction as LucideFunctionSquare,
  Funnel as LucideFunnel,
  FunnelPlus as LucideFunnelPlus,
  FunnelX as LucideFunnelX,
  GalleryHorizontal as LucideGalleryHorizontal,
  GalleryHorizontalEnd as LucideGalleryHorizontalEnd,
  GalleryThumbnails as LucideGalleryThumbnails,
  GalleryVertical as LucideGalleryVertical,
  GalleryVerticalEnd as LucideGalleryVerticalEnd,
  Gamepad as LucideGamepad,
  Gamepad2 as LucideGamepad2,
  GamepadDirectional as LucideGamepadDirectional,
  ChartNoAxesGantt as LucideGanttChart,
  SquareChartGantt as LucideGanttChartSquare,
  Gauge as LucideGauge,
  CircleGauge as LucideGaugeCircle,
  Gavel as LucideGavel,
  Gem as LucideGem,
  GeorgianLari as LucideGeorgianLari,
  Ghost as LucideGhost,
  Gift as LucideGift,
  GitBranch as LucideGitBranch,
  GitBranchMinus as LucideGitBranchMinus,
  GitBranchPlus as LucideGitBranchPlus,
  GitCommitHorizontal as LucideGitCommit,
  GitCommitHorizontal as LucideGitCommitHorizontal,
  GitCommitVertical as LucideGitCommitVertical,
  GitCompare as LucideGitCompare,
  GitCompareArrows as LucideGitCompareArrows,
  GitFork as LucideGitFork,
  GitGraph as LucideGitGraph,
  GitMerge as LucideGitMerge,
  GitMergeConflict as LucideGitMergeConflict,
  GitPullRequest as LucideGitPullRequest,
  GitPullRequestArrow as LucideGitPullRequestArrow,
  GitPullRequestClosed as LucideGitPullRequestClosed,
  GitPullRequestCreate as LucideGitPullRequestCreate,
  GitPullRequestCreateArrow as LucideGitPullRequestCreateArrow,
  GitPullRequestDraft as LucideGitPullRequestDraft,
  Github as LucideGithub,
  Gitlab as LucideGitlab,
  GlassWater as LucideGlassWater,
  Glasses as LucideGlasses,
  Globe as LucideGlobe,
  Earth as LucideGlobe2,
  GlobeLock as LucideGlobeLock,
  GlobeOff as LucideGlobeOff,
  GlobeX as LucideGlobeX,
  Goal as LucideGoal,
  Gpu as LucideGpu,
  HandGrab as LucideGrab,
  GraduationCap as LucideGraduationCap,
  Grape as LucideGrape,
  Grid3x3 as LucideGrid,
  Grid2x2 as LucideGrid2X2,
  Grid2x2Check as LucideGrid2X2Check,
  Grid2x2Plus as LucideGrid2X2Plus,
  Grid2x2X as LucideGrid2X2X,
  Grid2x2 as LucideGrid2x2,
  Grid2x2Check as LucideGrid2x2Check,
  Grid2x2Plus as LucideGrid2x2Plus,
  Grid2x2X as LucideGrid2x2X,
  Grid3x3 as LucideGrid3X3,
  Grid3x2 as LucideGrid3x2,
  Grid3x3 as LucideGrid3x3,
  Grip as LucideGrip,
  GripHorizontal as LucideGripHorizontal,
  GripVertical as LucideGripVertical,
  Group as LucideGroup,
  Guitar as LucideGuitar,
  Ham as LucideHam,
  Hamburger as LucideHamburger,
  Hammer as LucideHammer,
  Hand as LucideHand,
  HandCoins as LucideHandCoins,
  HandFist as LucideHandFist,
  HandGrab as LucideHandGrab,
  HandHeart as LucideHandHeart,
  HandHelping as LucideHandHelping,
  HandMetal as LucideHandMetal,
  HandPlatter as LucideHandPlatter,
  Handbag as LucideHandbag,
  Handshake as LucideHandshake,
  HardDrive as LucideHardDrive,
  HardDriveDownload as LucideHardDriveDownload,
  HardDriveUpload as LucideHardDriveUpload,
  HardHat as LucideHardHat,
  Hash as LucideHash,
  HatGlasses as LucideHatGlasses,
  Haze as LucideHaze,
  Hd as LucideHd,
  HdmiPort as LucideHdmiPort,
  Heading as LucideHeading,
  Heading1 as LucideHeading1,
  Heading2 as LucideHeading2,
  Heading3 as LucideHeading3,
  Heading4 as LucideHeading4,
  Heading5 as LucideHeading5,
  Heading6 as LucideHeading6,
  HeadphoneOff as LucideHeadphoneOff,
  Headphones as LucideHeadphones,
  Headset as LucideHeadset,
  Heart as LucideHeart,
  HeartCrack as LucideHeartCrack,
  HeartHandshake as LucideHeartHandshake,
  HeartMinus as LucideHeartMinus,
  HeartOff as LucideHeartOff,
  HeartPlus as LucideHeartPlus,
  HeartPulse as LucideHeartPulse,
  Heater as LucideHeater,
  Helicopter as LucideHelicopter,
  CircleQuestionMark as LucideHelpCircle,
  HandHelping as LucideHelpingHand,
  Hexagon as LucideHexagon,
  Highlighter as LucideHighlighter,
  History as LucideHistory,
  House as LucideHome,
  Hop as LucideHop,
  HopOff as LucideHopOff,
  Hospital as LucideHospital,
  Hotel as LucideHotel,
  Hourglass as LucideHourglass,
  House as LucideHouse,
  HouseHeart as LucideHouseHeart,
  HousePlug as LucideHousePlug,
  HousePlus as LucideHousePlus,
  HouseWifi as LucideHouseWifi,
  IceCreamCone as LucideIceCream,
  IceCreamBowl as LucideIceCream2,
  IceCreamBowl as LucideIceCreamBowl,
  IceCreamCone as LucideIceCreamCone,
  LucideIconConfig,
  LucideIconProvider,
  IdCard as LucideIdCard,
  IdCardLanyard as LucideIdCardLanyard,
  Image as LucideImage,
  ImageDown as LucideImageDown,
  ImageMinus as LucideImageMinus,
  ImageOff as LucideImageOff,
  ImagePlay as LucideImagePlay,
  ImagePlus as LucideImagePlus,
  ImageUp as LucideImageUp,
  ImageUpscale as LucideImageUpscale,
  Images as LucideImages,
  Import as LucideImport,
  Inbox as LucideInbox,
  ListIndentIncrease as LucideIndent,
  ListIndentDecrease as LucideIndentDecrease,
  ListIndentIncrease as LucideIndentIncrease,
  IndianRupee as LucideIndianRupee,
  Infinity as LucideInfinity,
  Info as LucideInfo,
  SquareMousePointer as LucideInspect,
  InspectionPanel as LucideInspectionPanel,
  Instagram as LucideInstagram,
  Italic as LucideItalic,
  IterationCcw as LucideIterationCcw,
  IterationCw as LucideIterationCw,
  JapaneseYen as LucideJapaneseYen,
  Joystick as LucideJoystick,
  Kanban as LucideKanban,
  SquareKanban as LucideKanbanSquare,
  SquareDashedKanban as LucideKanbanSquareDashed,
  Kayak as LucideKayak,
  Key as LucideKey,
  KeyRound as LucideKeyRound,
  KeySquare as LucideKeySquare,
  Keyboard as LucideKeyboard,
  KeyboardMusic as LucideKeyboardMusic,
  KeyboardOff as LucideKeyboardOff,
  Lamp as LucideLamp,
  LampCeiling as LucideLampCeiling,
  LampDesk as LucideLampDesk,
  LampFloor as LucideLampFloor,
  LampWallDown as LucideLampWallDown,
  LampWallUp as LucideLampWallUp,
  LandPlot as LucideLandPlot,
  Landmark as LucideLandmark,
  Languages as LucideLanguages,
  Laptop as LucideLaptop,
  LaptopMinimal as LucideLaptop2,
  LaptopMinimal as LucideLaptopMinimal,
  LaptopMinimalCheck as LucideLaptopMinimalCheck,
  Lasso as LucideLasso,
  LassoSelect as LucideLassoSelect,
  Laugh as LucideLaugh,
  Layers as LucideLayers,
  Layers2 as LucideLayers2,
  Layers as LucideLayers3,
  LayersPlus as LucideLayersPlus,
  PanelsTopLeft as LucideLayout,
  LayoutDashboard as LucideLayoutDashboard,
  LayoutGrid as LucideLayoutGrid,
  LayoutList as LucideLayoutList,
  LayoutPanelLeft as LucideLayoutPanelLeft,
  LayoutPanelTop as LucideLayoutPanelTop,
  LayoutTemplate as LucideLayoutTemplate,
  Leaf as LucideLeaf,
  LeafyGreen as LucideLeafyGreen,
  Lectern as LucideLectern,
  LensConcave as LucideLensConcave,
  LensConvex as LucideLensConvex,
  TextInitial as LucideLetterText,
  Library as LucideLibrary,
  LibraryBig as LucideLibraryBig,
  SquareLibrary as LucideLibrarySquare,
  LifeBuoy as LucideLifeBuoy,
  Ligature as LucideLigature,
  Lightbulb as LucideLightbulb,
  LightbulbOff as LucideLightbulbOff,
  ChartLine as LucideLineChart,
  LineDotRightHorizontal as LucideLineDotRightHorizontal,
  LineSquiggle as LucideLineSquiggle,
  Link as LucideLink,
  Link2 as LucideLink2,
  Link2Off as LucideLink2Off,
  Linkedin as LucideLinkedin,
  List as LucideList,
  ListCheck as LucideListCheck,
  ListChecks as LucideListChecks,
  ListChevronsDownUp as LucideListChevronsDownUp,
  ListChevronsUpDown as LucideListChevronsUpDown,
  ListCollapse as LucideListCollapse,
  ListEnd as LucideListEnd,
  ListFilter as LucideListFilter,
  ListFilterPlus as LucideListFilterPlus,
  ListIndentDecrease as LucideListIndentDecrease,
  ListIndentIncrease as LucideListIndentIncrease,
  ListMinus as LucideListMinus,
  ListMusic as LucideListMusic,
  ListOrdered as LucideListOrdered,
  ListPlus as LucideListPlus,
  ListRestart as LucideListRestart,
  ListStart as LucideListStart,
  ListTodo as LucideListTodo,
  ListTree as LucideListTree,
  ListVideo as LucideListVideo,
  ListX as LucideListX,
  Loader as LucideLoader,
  LoaderCircle as LucideLoader2,
  LoaderCircle as LucideLoaderCircle,
  LoaderPinwheel as LucideLoaderPinwheel,
  Locate as LucideLocate,
  LocateFixed as LucideLocateFixed,
  LocateOff as LucideLocateOff,
  MapPinPen as LucideLocationEdit,
  Lock as LucideLock,
  LockKeyhole as LucideLockKeyhole,
  LockKeyholeOpen as LucideLockKeyholeOpen,
  LockOpen as LucideLockOpen,
  LogIn as LucideLogIn,
  LogOut as LucideLogOut,
  Logs as LucideLogs,
  Lollipop as LucideLollipop,
  Luggage as LucideLuggage,
  SquareM as LucideMSquare,
  Magnet as LucideMagnet,
  Mail as LucideMail,
  MailCheck as LucideMailCheck,
  MailMinus as LucideMailMinus,
  MailOpen as LucideMailOpen,
  MailPlus as LucideMailPlus,
  MailQuestionMark as LucideMailQuestion,
  MailQuestionMark as LucideMailQuestionMark,
  MailSearch as LucideMailSearch,
  MailWarning as LucideMailWarning,
  MailX as LucideMailX,
  Mailbox as LucideMailbox,
  Mails as LucideMails,
  Map as LucideMap,
  MapMinus as LucideMapMinus,
  MapPin as LucideMapPin,
  MapPinCheck as LucideMapPinCheck,
  MapPinCheckInside as LucideMapPinCheckInside,
  MapPinHouse as LucideMapPinHouse,
  MapPinMinus as LucideMapPinMinus,
  MapPinMinusInside as LucideMapPinMinusInside,
  MapPinOff as LucideMapPinOff,
  MapPinPen as LucideMapPinPen,
  MapPinPlus as LucideMapPinPlus,
  MapPinPlusInside as LucideMapPinPlusInside,
  MapPinX as LucideMapPinX,
  MapPinXInside as LucideMapPinXInside,
  MapPinned as LucideMapPinned,
  MapPlus as LucideMapPlus,
  Mars as LucideMars,
  MarsStroke as LucideMarsStroke,
  Martini as LucideMartini,
  Maximize as LucideMaximize,
  Maximize2 as LucideMaximize2,
  Medal as LucideMedal,
  Megaphone as LucideMegaphone,
  MegaphoneOff as LucideMegaphoneOff,
  Meh as LucideMeh,
  MemoryStick as LucideMemoryStick,
  Menu as LucideMenu,
  SquareMenu as LucideMenuSquare,
  Merge as LucideMerge,
  MessageCircle as LucideMessageCircle,
  MessageCircleCheck as LucideMessageCircleCheck,
  MessageCircleCode as LucideMessageCircleCode,
  MessageCircleDashed as LucideMessageCircleDashed,
  MessageCircleHeart as LucideMessageCircleHeart,
  MessageCircleMore as LucideMessageCircleMore,
  MessageCircleOff as LucideMessageCircleOff,
  MessageCirclePlus as LucideMessageCirclePlus,
  MessageCircleQuestionMark as LucideMessageCircleQuestion,
  MessageCircleQuestionMark as LucideMessageCircleQuestionMark,
  MessageCircleReply as LucideMessageCircleReply,
  MessageCircleWarning as LucideMessageCircleWarning,
  MessageCircleX as LucideMessageCircleX,
  MessageSquare as LucideMessageSquare,
  MessageSquareCheck as LucideMessageSquareCheck,
  MessageSquareCode as LucideMessageSquareCode,
  MessageSquareDashed as LucideMessageSquareDashed,
  MessageSquareDiff as LucideMessageSquareDiff,
  MessageSquareDot as LucideMessageSquareDot,
  MessageSquareHeart as LucideMessageSquareHeart,
  MessageSquareLock as LucideMessageSquareLock,
  MessageSquareMore as LucideMessageSquareMore,
  MessageSquareOff as LucideMessageSquareOff,
  MessageSquarePlus as LucideMessageSquarePlus,
  MessageSquareQuote as LucideMessageSquareQuote,
  MessageSquareReply as LucideMessageSquareReply,
  MessageSquareShare as LucideMessageSquareShare,
  MessageSquareText as LucideMessageSquareText,
  MessageSquareWarning as LucideMessageSquareWarning,
  MessageSquareX as LucideMessageSquareX,
  MessagesSquare as LucideMessagesSquare,
  Metronome as LucideMetronome,
  Mic as LucideMic,
  MicVocal as LucideMic2,
  MicOff as LucideMicOff,
  MicVocal as LucideMicVocal,
  Microchip as LucideMicrochip,
  Microscope as LucideMicroscope,
  Microwave as LucideMicrowave,
  Milestone as LucideMilestone,
  Milk as LucideMilk,
  MilkOff as LucideMilkOff,
  Minimize as LucideMinimize,
  Minimize2 as LucideMinimize2,
  Minus as LucideMinus,
  CircleMinus as LucideMinusCircle,
  SquareMinus as LucideMinusSquare,
  MirrorRectangular as LucideMirrorRectangular,
  MirrorRound as LucideMirrorRound,
  Monitor as LucideMonitor,
  MonitorCheck as LucideMonitorCheck,
  MonitorCloud as LucideMonitorCloud,
  MonitorCog as LucideMonitorCog,
  MonitorDot as LucideMonitorDot,
  MonitorDown as LucideMonitorDown,
  MonitorOff as LucideMonitorOff,
  MonitorPause as LucideMonitorPause,
  MonitorPlay as LucideMonitorPlay,
  MonitorSmartphone as LucideMonitorSmartphone,
  MonitorSpeaker as LucideMonitorSpeaker,
  MonitorStop as LucideMonitorStop,
  MonitorUp as LucideMonitorUp,
  MonitorX as LucideMonitorX,
  Moon as LucideMoon,
  MoonStar as LucideMoonStar,
  Ellipsis as LucideMoreHorizontal,
  EllipsisVertical as LucideMoreVertical,
  Motorbike as LucideMotorbike,
  Mountain as LucideMountain,
  MountainSnow as LucideMountainSnow,
  Mouse as LucideMouse,
  MouseLeft as LucideMouseLeft,
  MouseOff as LucideMouseOff,
  MousePointer as LucideMousePointer,
  MousePointer2 as LucideMousePointer2,
  MousePointer2Off as LucideMousePointer2Off,
  MousePointerBan as LucideMousePointerBan,
  MousePointerClick as LucideMousePointerClick,
  SquareDashedMousePointer as LucideMousePointerSquareDashed,
  MouseRight as LucideMouseRight,
  Move as LucideMove,
  Move3d as LucideMove3D,
  Move3d as LucideMove3d,
  MoveDiagonal as LucideMoveDiagonal,
  MoveDiagonal2 as LucideMoveDiagonal2,
  MoveDown as LucideMoveDown,
  MoveDownLeft as LucideMoveDownLeft,
  MoveDownRight as LucideMoveDownRight,
  MoveHorizontal as LucideMoveHorizontal,
  MoveLeft as LucideMoveLeft,
  MoveRight as LucideMoveRight,
  MoveUp as LucideMoveUp,
  MoveUpLeft as LucideMoveUpLeft,
  MoveUpRight as LucideMoveUpRight,
  MoveVertical as LucideMoveVertical,
  Music as LucideMusic,
  Music2 as LucideMusic2,
  Music3 as LucideMusic3,
  Music4 as LucideMusic4,
  Navigation as LucideNavigation,
  Navigation2 as LucideNavigation2,
  Navigation2Off as LucideNavigation2Off,
  NavigationOff as LucideNavigationOff,
  Network as LucideNetwork,
  Newspaper as LucideNewspaper,
  Nfc as LucideNfc,
  NonBinary as LucideNonBinary,
  Notebook as LucideNotebook,
  NotebookPen as LucideNotebookPen,
  NotebookTabs as LucideNotebookTabs,
  NotebookText as LucideNotebookText,
  NotepadText as LucideNotepadText,
  NotepadTextDashed as LucideNotepadTextDashed,
  Nut as LucideNut,
  NutOff as LucideNutOff,
  Octagon as LucideOctagon,
  OctagonAlert as LucideOctagonAlert,
  OctagonMinus as LucideOctagonMinus,
  OctagonPause as LucideOctagonPause,
  OctagonX as LucideOctagonX,
  Omega as LucideOmega,
  Option as LucideOption,
  Orbit as LucideOrbit,
  Origami as LucideOrigami,
  ListIndentDecrease as LucideOutdent,
  Package as LucidePackage,
  Package2 as LucidePackage2,
  PackageCheck as LucidePackageCheck,
  PackageMinus as LucidePackageMinus,
  PackageOpen as LucidePackageOpen,
  PackagePlus as LucidePackagePlus,
  PackageSearch as LucidePackageSearch,
  PackageX as LucidePackageX,
  PaintBucket as LucidePaintBucket,
  PaintRoller as LucidePaintRoller,
  Paintbrush as LucidePaintbrush,
  PaintbrushVertical as LucidePaintbrush2,
  PaintbrushVertical as LucidePaintbrushVertical,
  Palette as LucidePalette,
  TreePalm as LucidePalmtree,
  Panda as LucidePanda,
  PanelBottom as LucidePanelBottom,
  PanelBottomClose as LucidePanelBottomClose,
  PanelBottomDashed as LucidePanelBottomDashed,
  PanelBottomDashed as LucidePanelBottomInactive,
  PanelBottomOpen as LucidePanelBottomOpen,
  PanelLeft as LucidePanelLeft,
  PanelLeftClose as LucidePanelLeftClose,
  PanelLeftDashed as LucidePanelLeftDashed,
  PanelLeftDashed as LucidePanelLeftInactive,
  PanelLeftOpen as LucidePanelLeftOpen,
  PanelLeftRightDashed as LucidePanelLeftRightDashed,
  PanelRight as LucidePanelRight,
  PanelRightClose as LucidePanelRightClose,
  PanelRightDashed as LucidePanelRightDashed,
  PanelRightDashed as LucidePanelRightInactive,
  PanelRightOpen as LucidePanelRightOpen,
  PanelTop as LucidePanelTop,
  PanelTopBottomDashed as LucidePanelTopBottomDashed,
  PanelTopClose as LucidePanelTopClose,
  PanelTopDashed as LucidePanelTopDashed,
  PanelTopDashed as LucidePanelTopInactive,
  PanelTopOpen as LucidePanelTopOpen,
  PanelsLeftBottom as LucidePanelsLeftBottom,
  Columns3 as LucidePanelsLeftRight,
  PanelsRightBottom as LucidePanelsRightBottom,
  Rows3 as LucidePanelsTopBottom,
  PanelsTopLeft as LucidePanelsTopLeft,
  Paperclip as LucidePaperclip,
  Parentheses as LucideParentheses,
  CircleParking as LucideParkingCircle,
  CircleParkingOff as LucideParkingCircleOff,
  ParkingMeter as LucideParkingMeter,
  SquareParking as LucideParkingSquare,
  SquareParkingOff as LucideParkingSquareOff,
  PartyPopper as LucidePartyPopper,
  Pause as LucidePause,
  CirclePause as LucidePauseCircle,
  OctagonPause as LucidePauseOctagon,
  PawPrint as LucidePawPrint,
  PcCase as LucidePcCase,
  Pen as LucidePen,
  SquarePen as LucidePenBox,
  PenLine as LucidePenLine,
  PenOff as LucidePenOff,
  SquarePen as LucidePenSquare,
  PenTool as LucidePenTool,
  Pencil as LucidePencil,
  PencilLine as LucidePencilLine,
  PencilOff as LucidePencilOff,
  PencilRuler as LucidePencilRuler,
  Pentagon as LucidePentagon,
  Percent as LucidePercent,
  CirclePercent as LucidePercentCircle,
  DiamondPercent as LucidePercentDiamond,
  SquarePercent as LucidePercentSquare,
  PersonStanding as LucidePersonStanding,
  PhilippinePeso as LucidePhilippinePeso,
  Phone as LucidePhone,
  PhoneCall as LucidePhoneCall,
  PhoneForwarded as LucidePhoneForwarded,
  PhoneIncoming as LucidePhoneIncoming,
  PhoneMissed as LucidePhoneMissed,
  PhoneOff as LucidePhoneOff,
  PhoneOutgoing as LucidePhoneOutgoing,
  Pi as LucidePi,
  SquarePi as LucidePiSquare,
  Piano as LucidePiano,
  Pickaxe as LucidePickaxe,
  PictureInPicture as LucidePictureInPicture,
  PictureInPicture2 as LucidePictureInPicture2,
  ChartPie as LucidePieChart,
  PiggyBank as LucidePiggyBank,
  Pilcrow as LucidePilcrow,
  PilcrowLeft as LucidePilcrowLeft,
  PilcrowRight as LucidePilcrowRight,
  SquarePilcrow as LucidePilcrowSquare,
  Pill as LucidePill,
  PillBottle as LucidePillBottle,
  Pin as LucidePin,
  PinOff as LucidePinOff,
  Pipette as LucidePipette,
  Pizza as LucidePizza,
  Plane as LucidePlane,
  PlaneLanding as LucidePlaneLanding,
  PlaneTakeoff as LucidePlaneTakeoff,
  Play as LucidePlay,
  CirclePlay as LucidePlayCircle,
  SquarePlay as LucidePlaySquare,
  Plug as LucidePlug,
  Plug2 as LucidePlug2,
  PlugZap as LucidePlugZap,
  PlugZap as LucidePlugZap2,
  Plus as LucidePlus,
  CirclePlus as LucidePlusCircle,
  SquarePlus as LucidePlusSquare,
  Pocket as LucidePocket,
  PocketKnife as LucidePocketKnife,
  Podcast as LucidePodcast,
  Pointer as LucidePointer,
  PointerOff as LucidePointerOff,
  Popcorn as LucidePopcorn,
  Popsicle as LucidePopsicle,
  PoundSterling as LucidePoundSterling,
  Power as LucidePower,
  CirclePower as LucidePowerCircle,
  PowerOff as LucidePowerOff,
  SquarePower as LucidePowerSquare,
  Presentation as LucidePresentation,
  Printer as LucidePrinter,
  PrinterCheck as LucidePrinterCheck,
  PrinterX as LucidePrinterX,
  Projector as LucideProjector,
  Proportions as LucideProportions,
  Puzzle as LucidePuzzle,
  Pyramid as LucidePyramid,
  QrCode as LucideQrCode,
  Quote as LucideQuote,
  Rabbit as LucideRabbit,
  Radar as LucideRadar,
  Radiation as LucideRadiation,
  Radical as LucideRadical,
  Radio as LucideRadio,
  RadioReceiver as LucideRadioReceiver,
  RadioTower as LucideRadioTower,
  Radius as LucideRadius,
  RailSymbol as LucideRailSymbol,
  Rainbow as LucideRainbow,
  Rat as LucideRat,
  Ratio as LucideRatio,
  Receipt as LucideReceipt,
  ReceiptCent as LucideReceiptCent,
  ReceiptEuro as LucideReceiptEuro,
  ReceiptIndianRupee as LucideReceiptIndianRupee,
  ReceiptJapaneseYen as LucideReceiptJapaneseYen,
  ReceiptPoundSterling as LucideReceiptPoundSterling,
  ReceiptRussianRuble as LucideReceiptRussianRuble,
  ReceiptSwissFranc as LucideReceiptSwissFranc,
  ReceiptText as LucideReceiptText,
  ReceiptTurkishLira as LucideReceiptTurkishLira,
  RectangleCircle as LucideRectangleCircle,
  RectangleEllipsis as LucideRectangleEllipsis,
  RectangleGoggles as LucideRectangleGoggles,
  RectangleHorizontal as LucideRectangleHorizontal,
  RectangleVertical as LucideRectangleVertical,
  Recycle as LucideRecycle,
  Redo as LucideRedo,
  Redo2 as LucideRedo2,
  RedoDot as LucideRedoDot,
  RefreshCcw as LucideRefreshCcw,
  RefreshCcwDot as LucideRefreshCcwDot,
  RefreshCw as LucideRefreshCw,
  RefreshCwOff as LucideRefreshCwOff,
  Refrigerator as LucideRefrigerator,
  Regex as LucideRegex,
  RemoveFormatting as LucideRemoveFormatting,
  Repeat as LucideRepeat,
  Repeat1 as LucideRepeat1,
  Repeat2 as LucideRepeat2,
  Replace as LucideReplace,
  ReplaceAll as LucideReplaceAll,
  Reply as LucideReply,
  ReplyAll as LucideReplyAll,
  Rewind as LucideRewind,
  Ribbon as LucideRibbon,
  Rocket as LucideRocket,
  RockingChair as LucideRockingChair,
  RollerCoaster as LucideRollerCoaster,
  Rose as LucideRose,
  Rotate3d as LucideRotate3D,
  Rotate3d as LucideRotate3d,
  RotateCcw as LucideRotateCcw,
  RotateCcwKey as LucideRotateCcwKey,
  RotateCcwSquare as LucideRotateCcwSquare,
  RotateCw as LucideRotateCw,
  RotateCwSquare as LucideRotateCwSquare,
  Route as LucideRoute,
  RouteOff as LucideRouteOff,
  Router as LucideRouter,
  Rows2 as LucideRows,
  Rows2 as LucideRows2,
  Rows3 as LucideRows3,
  Rows4 as LucideRows4,
  Rss as LucideRss,
  Ruler as LucideRuler,
  RulerDimensionLine as LucideRulerDimensionLine,
  RussianRuble as LucideRussianRuble,
  Sailboat as LucideSailboat,
  Salad as LucideSalad,
  Sandwich as LucideSandwich,
  Satellite as LucideSatellite,
  SatelliteDish as LucideSatelliteDish,
  SaudiRiyal as LucideSaudiRiyal,
  Save as LucideSave,
  SaveAll as LucideSaveAll,
  SaveOff as LucideSaveOff,
  Scale as LucideScale,
  Scale3d as LucideScale3D,
  Scale3d as LucideScale3d,
  Scaling as LucideScaling,
  Scan as LucideScan,
  ScanBarcode as LucideScanBarcode,
  ScanEye as LucideScanEye,
  ScanFace as LucideScanFace,
  ScanHeart as LucideScanHeart,
  ScanLine as LucideScanLine,
  ScanQrCode as LucideScanQrCode,
  ScanSearch as LucideScanSearch,
  ScanText as LucideScanText,
  ChartScatter as LucideScatterChart,
  School as LucideSchool,
  University as LucideSchool2,
  Scissors as LucideScissors,
  ScissorsLineDashed as LucideScissorsLineDashed,
  SquareScissors as LucideScissorsSquare,
  SquareBottomDashedScissors as LucideScissorsSquareDashedBottom,
  Scooter as LucideScooter,
  ScreenShare as LucideScreenShare,
  ScreenShareOff as LucideScreenShareOff,
  Scroll as LucideScroll,
  ScrollText as LucideScrollText,
  Search as LucideSearch,
  SearchAlert as LucideSearchAlert,
  SearchCheck as LucideSearchCheck,
  SearchCode as LucideSearchCode,
  SearchSlash as LucideSearchSlash,
  SearchX as LucideSearchX,
  Section as LucideSection,
  Send as LucideSend,
  SendHorizontal as LucideSendHorizonal,
  SendHorizontal as LucideSendHorizontal,
  SendToBack as LucideSendToBack,
  SeparatorHorizontal as LucideSeparatorHorizontal,
  SeparatorVertical as LucideSeparatorVertical,
  Server as LucideServer,
  ServerCog as LucideServerCog,
  ServerCrash as LucideServerCrash,
  ServerOff as LucideServerOff,
  Settings as LucideSettings,
  Settings2 as LucideSettings2,
  Shapes as LucideShapes,
  Share as LucideShare,
  Share2 as LucideShare2,
  Sheet as LucideSheet,
  Shell as LucideShell,
  ShelvingUnit as LucideShelvingUnit,
  Shield as LucideShield,
  ShieldAlert as LucideShieldAlert,
  ShieldBan as LucideShieldBan,
  ShieldCheck as LucideShieldCheck,
  ShieldX as LucideShieldClose,
  ShieldEllipsis as LucideShieldEllipsis,
  ShieldHalf as LucideShieldHalf,
  ShieldMinus as LucideShieldMinus,
  ShieldOff as LucideShieldOff,
  ShieldPlus as LucideShieldPlus,
  ShieldQuestionMark as LucideShieldQuestion,
  ShieldQuestionMark as LucideShieldQuestionMark,
  ShieldUser as LucideShieldUser,
  ShieldX as LucideShieldX,
  Ship as LucideShip,
  ShipWheel as LucideShipWheel,
  Shirt as LucideShirt,
  ShoppingBag as LucideShoppingBag,
  ShoppingBasket as LucideShoppingBasket,
  ShoppingCart as LucideShoppingCart,
  Shovel as LucideShovel,
  ShowerHead as LucideShowerHead,
  Shredder as LucideShredder,
  Shrimp as LucideShrimp,
  Shrink as LucideShrink,
  Shrub as LucideShrub,
  Shuffle as LucideShuffle,
  PanelLeft as LucideSidebar,
  PanelLeftClose as LucideSidebarClose,
  PanelLeftOpen as LucideSidebarOpen,
  Sigma as LucideSigma,
  SquareSigma as LucideSigmaSquare,
  Signal as LucideSignal,
  SignalHigh as LucideSignalHigh,
  SignalLow as LucideSignalLow,
  SignalMedium as LucideSignalMedium,
  SignalZero as LucideSignalZero,
  Signature as LucideSignature,
  Signpost as LucideSignpost,
  SignpostBig as LucideSignpostBig,
  Siren as LucideSiren,
  SkipBack as LucideSkipBack,
  SkipForward as LucideSkipForward,
  Skull as LucideSkull,
  Slack as LucideSlack,
  Slash as LucideSlash,
  SquareSlash as LucideSlashSquare,
  Slice as LucideSlice,
  SlidersVertical as LucideSliders,
  SlidersHorizontal as LucideSlidersHorizontal,
  SlidersVertical as LucideSlidersVertical,
  Smartphone as LucideSmartphone,
  SmartphoneCharging as LucideSmartphoneCharging,
  SmartphoneNfc as LucideSmartphoneNfc,
  Smile as LucideSmile,
  SmilePlus as LucideSmilePlus,
  Snail as LucideSnail,
  Snowflake as LucideSnowflake,
  SoapDispenserDroplet as LucideSoapDispenserDroplet,
  Sofa as LucideSofa,
  SolarPanel as LucideSolarPanel,
  ArrowUpNarrowWide as LucideSortAsc,
  ArrowDownWideNarrow as LucideSortDesc,
  Soup as LucideSoup,
  Space as LucideSpace,
  Spade as LucideSpade,
  Sparkle as LucideSparkle,
  Sparkles as LucideSparkles,
  Speaker as LucideSpeaker,
  Speech as LucideSpeech,
  SpellCheck as LucideSpellCheck,
  SpellCheck2 as LucideSpellCheck2,
  Spline as LucideSpline,
  SplinePointer as LucideSplinePointer,
  Split as LucideSplit,
  SquareSplitHorizontal as LucideSplitSquareHorizontal,
  SquareSplitVertical as LucideSplitSquareVertical,
  Spool as LucideSpool,
  Spotlight as LucideSpotlight,
  SprayCan as LucideSprayCan,
  Sprout as LucideSprout,
  Square as LucideSquare,
  SquareActivity as LucideSquareActivity,
  SquareArrowDown as LucideSquareArrowDown,
  SquareArrowDownLeft as LucideSquareArrowDownLeft,
  SquareArrowDownRight as LucideSquareArrowDownRight,
  SquareArrowLeft as LucideSquareArrowLeft,
  SquareArrowOutDownLeft as LucideSquareArrowOutDownLeft,
  SquareArrowOutDownRight as LucideSquareArrowOutDownRight,
  SquareArrowOutUpLeft as LucideSquareArrowOutUpLeft,
  SquareArrowOutUpRight as LucideSquareArrowOutUpRight,
  SquareArrowRight as LucideSquareArrowRight,
  SquareArrowRightEnter as LucideSquareArrowRightEnter,
  SquareArrowRightExit as LucideSquareArrowRightExit,
  SquareArrowUp as LucideSquareArrowUp,
  SquareArrowUpLeft as LucideSquareArrowUpLeft,
  SquareArrowUpRight as LucideSquareArrowUpRight,
  SquareAsterisk as LucideSquareAsterisk,
  SquareBottomDashedScissors as LucideSquareBottomDashedScissors,
  SquareCenterlineDashedHorizontal as LucideSquareCenterlineDashedHorizontal,
  SquareCenterlineDashedVertical as LucideSquareCenterlineDashedVertical,
  SquareChartGantt as LucideSquareChartGantt,
  SquareCheck as LucideSquareCheck,
  SquareCheckBig as LucideSquareCheckBig,
  SquareChevronDown as LucideSquareChevronDown,
  SquareChevronLeft as LucideSquareChevronLeft,
  SquareChevronRight as LucideSquareChevronRight,
  SquareChevronUp as LucideSquareChevronUp,
  SquareCode as LucideSquareCode,
  SquareDashed as LucideSquareDashed,
  SquareDashedBottom as LucideSquareDashedBottom,
  SquareDashedBottomCode as LucideSquareDashedBottomCode,
  SquareDashedKanban as LucideSquareDashedKanban,
  SquareDashedMousePointer as LucideSquareDashedMousePointer,
  SquareDashedTopSolid as LucideSquareDashedTopSolid,
  SquareDivide as LucideSquareDivide,
  SquareDot as LucideSquareDot,
  SquareEqual as LucideSquareEqual,
  SquareFunction as LucideSquareFunction,
  SquareChartGantt as LucideSquareGanttChart,
  SquareKanban as LucideSquareKanban,
  SquareLibrary as LucideSquareLibrary,
  SquareM as LucideSquareM,
  SquareMenu as LucideSquareMenu,
  SquareMinus as LucideSquareMinus,
  SquareMousePointer as LucideSquareMousePointer,
  SquareParking as LucideSquareParking,
  SquareParkingOff as LucideSquareParkingOff,
  SquarePause as LucideSquarePause,
  SquarePen as LucideSquarePen,
  SquarePercent as LucideSquarePercent,
  SquarePi as LucideSquarePi,
  SquarePilcrow as LucideSquarePilcrow,
  SquarePlay as LucideSquarePlay,
  SquarePlus as LucideSquarePlus,
  SquarePower as LucideSquarePower,
  SquareRadical as LucideSquareRadical,
  SquareRoundCorner as LucideSquareRoundCorner,
  SquareScissors as LucideSquareScissors,
  SquareSigma as LucideSquareSigma,
  SquareSlash as LucideSquareSlash,
  SquareSplitHorizontal as LucideSquareSplitHorizontal,
  SquareSplitVertical as LucideSquareSplitVertical,
  SquareSquare as LucideSquareSquare,
  SquareStack as LucideSquareStack,
  SquareStar as LucideSquareStar,
  SquareStop as LucideSquareStop,
  SquareTerminal as LucideSquareTerminal,
  SquareUser as LucideSquareUser,
  SquareUserRound as LucideSquareUserRound,
  SquareX as LucideSquareX,
  SquaresExclude as LucideSquaresExclude,
  SquaresIntersect as LucideSquaresIntersect,
  SquaresSubtract as LucideSquaresSubtract,
  SquaresUnite as LucideSquaresUnite,
  Squircle as LucideSquircle,
  SquircleDashed as LucideSquircleDashed,
  Squirrel as LucideSquirrel,
  Stamp as LucideStamp,
  Star as LucideStar,
  StarHalf as LucideStarHalf,
  StarOff as LucideStarOff,
  Sparkles as LucideStars,
  StepBack as LucideStepBack,
  StepForward as LucideStepForward,
  Stethoscope as LucideStethoscope,
  Sticker as LucideSticker,
  StickyNote as LucideStickyNote,
  Stone as LucideStone,
  CircleStop as LucideStopCircle,
  Store as LucideStore,
  StretchHorizontal as LucideStretchHorizontal,
  StretchVertical as LucideStretchVertical,
  Strikethrough as LucideStrikethrough,
  Subscript as LucideSubscript,
  Captions as LucideSubtitles,
  Sun as LucideSun,
  SunDim as LucideSunDim,
  SunMedium as LucideSunMedium,
  SunMoon as LucideSunMoon,
  SunSnow as LucideSunSnow,
  Sunrise as LucideSunrise,
  Sunset as LucideSunset,
  Superscript as LucideSuperscript,
  SwatchBook as LucideSwatchBook,
  SwissFranc as LucideSwissFranc,
  SwitchCamera as LucideSwitchCamera,
  Sword as LucideSword,
  Swords as LucideSwords,
  Syringe as LucideSyringe,
  Table as LucideTable,
  Table2 as LucideTable2,
  TableCellsMerge as LucideTableCellsMerge,
  TableCellsSplit as LucideTableCellsSplit,
  TableColumnsSplit as LucideTableColumnsSplit,
  Columns3Cog as LucideTableConfig,
  TableOfContents as LucideTableOfContents,
  TableProperties as LucideTableProperties,
  TableRowsSplit as LucideTableRowsSplit,
  Tablet as LucideTablet,
  TabletSmartphone as LucideTabletSmartphone,
  Tablets as LucideTablets,
  Tag as LucideTag,
  Tags as LucideTags,
  Tally1 as LucideTally1,
  Tally2 as LucideTally2,
  Tally3 as LucideTally3,
  Tally4 as LucideTally4,
  Tally5 as LucideTally5,
  Tangent as LucideTangent,
  Target as LucideTarget,
  Telescope as LucideTelescope,
  Tent as LucideTent,
  TentTree as LucideTentTree,
  Terminal as LucideTerminal,
  SquareTerminal as LucideTerminalSquare,
  TestTube as LucideTestTube,
  TestTubeDiagonal as LucideTestTube2,
  TestTubeDiagonal as LucideTestTubeDiagonal,
  TestTubes as LucideTestTubes,
  TextAlignStart as LucideText,
  TextAlignCenter as LucideTextAlignCenter,
  TextAlignEnd as LucideTextAlignEnd,
  TextAlignJustify as LucideTextAlignJustify,
  TextAlignStart as LucideTextAlignStart,
  TextCursor as LucideTextCursor,
  TextCursorInput as LucideTextCursorInput,
  TextInitial as LucideTextInitial,
  TextQuote as LucideTextQuote,
  TextSearch as LucideTextSearch,
  TextSelect as LucideTextSelect,
  TextSelect as LucideTextSelection,
  TextWrap as LucideTextWrap,
  Theater as LucideTheater,
  Thermometer as LucideThermometer,
  ThermometerSnowflake as LucideThermometerSnowflake,
  ThermometerSun as LucideThermometerSun,
  ThumbsDown as LucideThumbsDown,
  ThumbsUp as LucideThumbsUp,
  Ticket as LucideTicket,
  TicketCheck as LucideTicketCheck,
  TicketMinus as LucideTicketMinus,
  TicketPercent as LucideTicketPercent,
  TicketPlus as LucideTicketPlus,
  TicketSlash as LucideTicketSlash,
  TicketX as LucideTicketX,
  Tickets as LucideTickets,
  TicketsPlane as LucideTicketsPlane,
  Timer as LucideTimer,
  TimerOff as LucideTimerOff,
  TimerReset as LucideTimerReset,
  ToggleLeft as LucideToggleLeft,
  ToggleRight as LucideToggleRight,
  Toilet as LucideToilet,
  ToolCase as LucideToolCase,
  Toolbox as LucideToolbox,
  Tornado as LucideTornado,
  Torus as LucideTorus,
  Touchpad as LucideTouchpad,
  TouchpadOff as LucideTouchpadOff,
  TowelRack as LucideTowelRack,
  TowerControl as LucideTowerControl,
  ToyBrick as LucideToyBrick,
  Tractor as LucideTractor,
  TrafficCone as LucideTrafficCone,
  TramFront as LucideTrain,
  TrainFront as LucideTrainFront,
  TrainFrontTunnel as LucideTrainFrontTunnel,
  TrainTrack as LucideTrainTrack,
  TramFront as LucideTramFront,
  Transgender as LucideTransgender,
  Trash as LucideTrash,
  Trash2 as LucideTrash2,
  TreeDeciduous as LucideTreeDeciduous,
  TreePalm as LucideTreePalm,
  TreePine as LucideTreePine,
  Trees as LucideTrees,
  Trello as LucideTrello,
  TrendingDown as LucideTrendingDown,
  TrendingUp as LucideTrendingUp,
  TrendingUpDown as LucideTrendingUpDown,
  Triangle as LucideTriangle,
  TriangleAlert as LucideTriangleAlert,
  TriangleDashed as LucideTriangleDashed,
  TriangleRight as LucideTriangleRight,
  Trophy as LucideTrophy,
  Truck as LucideTruck,
  TruckElectric as LucideTruckElectric,
  TurkishLira as LucideTurkishLira,
  Turntable as LucideTurntable,
  Turtle as LucideTurtle,
  Tv as LucideTv,
  TvMinimal as LucideTv2,
  TvMinimal as LucideTvMinimal,
  TvMinimalPlay as LucideTvMinimalPlay,
  Twitch as LucideTwitch,
  Twitter as LucideTwitter,
  Type as LucideType,
  TypeOutline as LucideTypeOutline,
  Umbrella as LucideUmbrella,
  UmbrellaOff as LucideUmbrellaOff,
  Underline as LucideUnderline,
  Undo as LucideUndo,
  Undo2 as LucideUndo2,
  UndoDot as LucideUndoDot,
  UnfoldHorizontal as LucideUnfoldHorizontal,
  UnfoldVertical as LucideUnfoldVertical,
  Ungroup as LucideUngroup,
  University as LucideUniversity,
  Unlink as LucideUnlink,
  Unlink2 as LucideUnlink2,
  LockOpen as LucideUnlock,
  LockKeyholeOpen as LucideUnlockKeyhole,
  Unplug as LucideUnplug,
  Upload as LucideUpload,
  CloudUpload as LucideUploadCloud,
  Usb as LucideUsb,
  User as LucideUser,
  UserRound as LucideUser2,
  UserCheck as LucideUserCheck,
  UserRoundCheck as LucideUserCheck2,
  CircleUser as LucideUserCircle,
  CircleUserRound as LucideUserCircle2,
  UserCog as LucideUserCog,
  UserRoundCog as LucideUserCog2,
  UserKey as LucideUserKey,
  UserLock as LucideUserLock,
  UserMinus as LucideUserMinus,
  UserRoundMinus as LucideUserMinus2,
  UserPen as LucideUserPen,
  UserPlus as LucideUserPlus,
  UserRoundPlus as LucideUserPlus2,
  UserRound as LucideUserRound,
  UserRoundCheck as LucideUserRoundCheck,
  UserRoundCog as LucideUserRoundCog,
  UserRoundKey as LucideUserRoundKey,
  UserRoundMinus as LucideUserRoundMinus,
  UserRoundPen as LucideUserRoundPen,
  UserRoundPlus as LucideUserRoundPlus,
  UserRoundSearch as LucideUserRoundSearch,
  UserRoundX as LucideUserRoundX,
  UserSearch as LucideUserSearch,
  SquareUser as LucideUserSquare,
  SquareUserRound as LucideUserSquare2,
  UserStar as LucideUserStar,
  UserX as LucideUserX,
  UserRoundX as LucideUserX2,
  Users as LucideUsers,
  UsersRound as LucideUsers2,
  UsersRound as LucideUsersRound,
  Utensils as LucideUtensils,
  UtensilsCrossed as LucideUtensilsCrossed,
  UtilityPole as LucideUtilityPole,
  Van as LucideVan,
  Variable as LucideVariable,
  Vault as LucideVault,
  VectorSquare as LucideVectorSquare,
  Vegan as LucideVegan,
  VenetianMask as LucideVenetianMask,
  Venus as LucideVenus,
  VenusAndMars as LucideVenusAndMars,
  BadgeCheck as LucideVerified,
  Vibrate as LucideVibrate,
  VibrateOff as LucideVibrateOff,
  Video as LucideVideo,
  VideoOff as LucideVideoOff,
  Videotape as LucideVideotape,
  View as LucideView,
  Voicemail as LucideVoicemail,
  Volleyball as LucideVolleyball,
  Volume as LucideVolume,
  Volume1 as LucideVolume1,
  Volume2 as LucideVolume2,
  VolumeOff as LucideVolumeOff,
  VolumeX as LucideVolumeX,
  Vote as LucideVote,
  Wallet as LucideWallet,
  WalletMinimal as LucideWallet2,
  WalletCards as LucideWalletCards,
  WalletMinimal as LucideWalletMinimal,
  Wallpaper as LucideWallpaper,
  Wand as LucideWand,
  WandSparkles as LucideWand2,
  WandSparkles as LucideWandSparkles,
  Warehouse as LucideWarehouse,
  WashingMachine as LucideWashingMachine,
  Watch as LucideWatch,
  Waves as LucideWaves,
  WavesArrowDown as LucideWavesArrowDown,
  WavesArrowUp as LucideWavesArrowUp,
  WavesLadder as LucideWavesLadder,
  Waypoints as LucideWaypoints,
  Webcam as LucideWebcam,
  Webhook as LucideWebhook,
  WebhookOff as LucideWebhookOff,
  Weight as LucideWeight,
  WeightTilde as LucideWeightTilde,
  Wheat as LucideWheat,
  WheatOff as LucideWheatOff,
  WholeWord as LucideWholeWord,
  Wifi as LucideWifi,
  WifiCog as LucideWifiCog,
  WifiHigh as LucideWifiHigh,
  WifiLow as LucideWifiLow,
  WifiOff as LucideWifiOff,
  WifiPen as LucideWifiPen,
  WifiSync as LucideWifiSync,
  WifiZero as LucideWifiZero,
  Wind as LucideWind,
  WindArrowDown as LucideWindArrowDown,
  Wine as LucideWine,
  WineOff as LucideWineOff,
  Workflow as LucideWorkflow,
  Worm as LucideWorm,
  TextWrap as LucideWrapText,
  Wrench as LucideWrench,
  X as LucideX,
  CircleX as LucideXCircle,
  XLineTop as LucideXLineTop,
  OctagonX as LucideXOctagon,
  SquareX as LucideXSquare,
  Youtube as LucideYoutube,
  Zap as LucideZap,
  ZapOff as LucideZapOff,
  ZodiacAquarius as LucideZodiacAquarius,
  ZodiacAries as LucideZodiacAries,
  ZodiacCancer as LucideZodiacCancer,
  ZodiacCapricorn as LucideZodiacCapricorn,
  ZodiacGemini as LucideZodiacGemini,
  ZodiacLeo as LucideZodiacLeo,
  ZodiacLibra as LucideZodiacLibra,
  ZodiacOphiuchus as LucideZodiacOphiuchus,
  ZodiacPisces as LucideZodiacPisces,
  ZodiacSagittarius as LucideZodiacSagittarius,
  ZodiacScorpio as LucideZodiacScorpio,
  ZodiacTaurus as LucideZodiacTaurus,
  ZodiacVirgo as LucideZodiacVirgo,
  ZoomIn as LucideZoomIn,
  ZoomOut as LucideZoomOut,
  Luggage,
  Luggage as LuggageIcon,
  SquareM as MSquare,
  SquareM as MSquareIcon,
  Magnet,
  Magnet as MagnetIcon,
  Mail,
  MailCheck,
  MailCheck as MailCheckIcon,
  Mail as MailIcon,
  MailMinus,
  MailMinus as MailMinusIcon,
  MailOpen,
  MailOpen as MailOpenIcon,
  MailPlus,
  MailPlus as MailPlusIcon,
  MailQuestionMark as MailQuestion,
  MailQuestionMark as MailQuestionIcon,
  MailQuestionMark,
  MailQuestionMark as MailQuestionMarkIcon,
  MailSearch,
  MailSearch as MailSearchIcon,
  MailWarning,
  MailWarning as MailWarningIcon,
  MailX,
  MailX as MailXIcon,
  Mailbox,
  Mailbox as MailboxIcon,
  Mails,
  Mails as MailsIcon,
  Map,
  Map as MapIcon,
  MapMinus,
  MapMinus as MapMinusIcon,
  MapPin,
  MapPinCheck,
  MapPinCheck as MapPinCheckIcon,
  MapPinCheckInside,
  MapPinCheckInside as MapPinCheckInsideIcon,
  MapPinHouse,
  MapPinHouse as MapPinHouseIcon,
  MapPin as MapPinIcon,
  MapPinMinus,
  MapPinMinus as MapPinMinusIcon,
  MapPinMinusInside,
  MapPinMinusInside as MapPinMinusInsideIcon,
  MapPinOff,
  MapPinOff as MapPinOffIcon,
  MapPinPen,
  MapPinPen as MapPinPenIcon,
  MapPinPlus,
  MapPinPlus as MapPinPlusIcon,
  MapPinPlusInside,
  MapPinPlusInside as MapPinPlusInsideIcon,
  MapPinX,
  MapPinX as MapPinXIcon,
  MapPinXInside,
  MapPinXInside as MapPinXInsideIcon,
  MapPinned,
  MapPinned as MapPinnedIcon,
  MapPlus,
  MapPlus as MapPlusIcon,
  Mars,
  Mars as MarsIcon,
  MarsStroke,
  MarsStroke as MarsStrokeIcon,
  Martini,
  Martini as MartiniIcon,
  Maximize,
  Maximize2,
  Maximize2 as Maximize2Icon,
  Maximize as MaximizeIcon,
  Medal,
  Medal as MedalIcon,
  Megaphone,
  Megaphone as MegaphoneIcon,
  MegaphoneOff,
  MegaphoneOff as MegaphoneOffIcon,
  Meh,
  Meh as MehIcon,
  MemoryStick,
  MemoryStick as MemoryStickIcon,
  Menu,
  Menu as MenuIcon,
  SquareMenu as MenuSquare,
  SquareMenu as MenuSquareIcon,
  Merge,
  Merge as MergeIcon,
  MessageCircle,
  MessageCircleCheck,
  MessageCircleCheck as MessageCircleCheckIcon,
  MessageCircleCode,
  MessageCircleCode as MessageCircleCodeIcon,
  MessageCircleDashed,
  MessageCircleDashed as MessageCircleDashedIcon,
  MessageCircleHeart,
  MessageCircleHeart as MessageCircleHeartIcon,
  MessageCircle as MessageCircleIcon,
  MessageCircleMore,
  MessageCircleMore as MessageCircleMoreIcon,
  MessageCircleOff,
  MessageCircleOff as MessageCircleOffIcon,
  MessageCirclePlus,
  MessageCirclePlus as MessageCirclePlusIcon,
  MessageCircleQuestionMark as MessageCircleQuestion,
  MessageCircleQuestionMark as MessageCircleQuestionIcon,
  MessageCircleQuestionMark,
  MessageCircleQuestionMark as MessageCircleQuestionMarkIcon,
  MessageCircleReply,
  MessageCircleReply as MessageCircleReplyIcon,
  MessageCircleWarning,
  MessageCircleWarning as MessageCircleWarningIcon,
  MessageCircleX,
  MessageCircleX as MessageCircleXIcon,
  MessageSquare,
  MessageSquareCheck,
  MessageSquareCheck as MessageSquareCheckIcon,
  MessageSquareCode,
  MessageSquareCode as MessageSquareCodeIcon,
  MessageSquareDashed,
  MessageSquareDashed as MessageSquareDashedIcon,
  MessageSquareDiff,
  MessageSquareDiff as MessageSquareDiffIcon,
  MessageSquareDot,
  MessageSquareDot as MessageSquareDotIcon,
  MessageSquareHeart,
  MessageSquareHeart as MessageSquareHeartIcon,
  MessageSquare as MessageSquareIcon,
  MessageSquareLock,
  MessageSquareLock as MessageSquareLockIcon,
  MessageSquareMore,
  MessageSquareMore as MessageSquareMoreIcon,
  MessageSquareOff,
  MessageSquareOff as MessageSquareOffIcon,
  MessageSquarePlus,
  MessageSquarePlus as MessageSquarePlusIcon,
  MessageSquareQuote,
  MessageSquareQuote as MessageSquareQuoteIcon,
  MessageSquareReply,
  MessageSquareReply as MessageSquareReplyIcon,
  MessageSquareShare,
  MessageSquareShare as MessageSquareShareIcon,
  MessageSquareText,
  MessageSquareText as MessageSquareTextIcon,
  MessageSquareWarning,
  MessageSquareWarning as MessageSquareWarningIcon,
  MessageSquareX,
  MessageSquareX as MessageSquareXIcon,
  MessagesSquare,
  MessagesSquare as MessagesSquareIcon,
  Metronome,
  Metronome as MetronomeIcon,
  Mic,
  MicVocal as Mic2,
  MicVocal as Mic2Icon,
  Mic as MicIcon,
  MicOff,
  MicOff as MicOffIcon,
  MicVocal,
  MicVocal as MicVocalIcon,
  Microchip,
  Microchip as MicrochipIcon,
  Microscope,
  Microscope as MicroscopeIcon,
  Microwave,
  Microwave as MicrowaveIcon,
  Milestone,
  Milestone as MilestoneIcon,
  Milk,
  Milk as MilkIcon,
  MilkOff,
  MilkOff as MilkOffIcon,
  Minimize,
  Minimize2,
  Minimize2 as Minimize2Icon,
  Minimize as MinimizeIcon,
  Minus,
  CircleMinus as MinusCircle,
  CircleMinus as MinusCircleIcon,
  Minus as MinusIcon,
  SquareMinus as MinusSquare,
  SquareMinus as MinusSquareIcon,
  MirrorRectangular,
  MirrorRectangular as MirrorRectangularIcon,
  MirrorRound,
  MirrorRound as MirrorRoundIcon,
  Monitor,
  MonitorCheck,
  MonitorCheck as MonitorCheckIcon,
  MonitorCloud,
  MonitorCloud as MonitorCloudIcon,
  MonitorCog,
  MonitorCog as MonitorCogIcon,
  MonitorDot,
  MonitorDot as MonitorDotIcon,
  MonitorDown,
  MonitorDown as MonitorDownIcon,
  Monitor as MonitorIcon,
  MonitorOff,
  MonitorOff as MonitorOffIcon,
  MonitorPause,
  MonitorPause as MonitorPauseIcon,
  MonitorPlay,
  MonitorPlay as MonitorPlayIcon,
  MonitorSmartphone,
  MonitorSmartphone as MonitorSmartphoneIcon,
  MonitorSpeaker,
  MonitorSpeaker as MonitorSpeakerIcon,
  MonitorStop,
  MonitorStop as MonitorStopIcon,
  MonitorUp,
  MonitorUp as MonitorUpIcon,
  MonitorX,
  MonitorX as MonitorXIcon,
  Moon,
  Moon as MoonIcon,
  MoonStar,
  MoonStar as MoonStarIcon,
  Ellipsis as MoreHorizontal,
  Ellipsis as MoreHorizontalIcon,
  EllipsisVertical as MoreVertical,
  EllipsisVertical as MoreVerticalIcon,
  Motorbike,
  Motorbike as MotorbikeIcon,
  Mountain,
  Mountain as MountainIcon,
  MountainSnow,
  MountainSnow as MountainSnowIcon,
  Mouse,
  Mouse as MouseIcon,
  MouseLeft,
  MouseLeft as MouseLeftIcon,
  MouseOff,
  MouseOff as MouseOffIcon,
  MousePointer,
  MousePointer2,
  MousePointer2 as MousePointer2Icon,
  MousePointer2Off,
  MousePointer2Off as MousePointer2OffIcon,
  MousePointerBan,
  MousePointerBan as MousePointerBanIcon,
  MousePointerClick,
  MousePointerClick as MousePointerClickIcon,
  MousePointer as MousePointerIcon,
  SquareDashedMousePointer as MousePointerSquareDashed,
  SquareDashedMousePointer as MousePointerSquareDashedIcon,
  MouseRight,
  MouseRight as MouseRightIcon,
  Move,
  Move3d as Move3D,
  Move3d as Move3DIcon,
  Move3d,
  Move3d as Move3dIcon,
  MoveDiagonal,
  MoveDiagonal2,
  MoveDiagonal2 as MoveDiagonal2Icon,
  MoveDiagonal as MoveDiagonalIcon,
  MoveDown,
  MoveDown as MoveDownIcon,
  MoveDownLeft,
  MoveDownLeft as MoveDownLeftIcon,
  MoveDownRight,
  MoveDownRight as MoveDownRightIcon,
  MoveHorizontal,
  MoveHorizontal as MoveHorizontalIcon,
  Move as MoveIcon,
  MoveLeft,
  MoveLeft as MoveLeftIcon,
  MoveRight,
  MoveRight as MoveRightIcon,
  MoveUp,
  MoveUp as MoveUpIcon,
  MoveUpLeft,
  MoveUpLeft as MoveUpLeftIcon,
  MoveUpRight,
  MoveUpRight as MoveUpRightIcon,
  MoveVertical,
  MoveVertical as MoveVerticalIcon,
  Music,
  Music2,
  Music2 as Music2Icon,
  Music3,
  Music3 as Music3Icon,
  Music4,
  Music4 as Music4Icon,
  Music as MusicIcon,
  Navigation,
  Navigation2,
  Navigation2 as Navigation2Icon,
  Navigation2Off,
  Navigation2Off as Navigation2OffIcon,
  Navigation as NavigationIcon,
  NavigationOff,
  NavigationOff as NavigationOffIcon,
  Network,
  Network as NetworkIcon,
  Newspaper,
  Newspaper as NewspaperIcon,
  Nfc,
  Nfc as NfcIcon,
  NonBinary,
  NonBinary as NonBinaryIcon,
  Notebook,
  Notebook as NotebookIcon,
  NotebookPen,
  NotebookPen as NotebookPenIcon,
  NotebookTabs,
  NotebookTabs as NotebookTabsIcon,
  NotebookText,
  NotebookText as NotebookTextIcon,
  NotepadText,
  NotepadTextDashed,
  NotepadTextDashed as NotepadTextDashedIcon,
  NotepadText as NotepadTextIcon,
  Nut,
  Nut as NutIcon,
  NutOff,
  NutOff as NutOffIcon,
  Octagon,
  OctagonAlert,
  OctagonAlert as OctagonAlertIcon,
  Octagon as OctagonIcon,
  OctagonMinus,
  OctagonMinus as OctagonMinusIcon,
  OctagonPause,
  OctagonPause as OctagonPauseIcon,
  OctagonX,
  OctagonX as OctagonXIcon,
  Omega,
  Omega as OmegaIcon,
  Option,
  Option as OptionIcon,
  Orbit,
  Orbit as OrbitIcon,
  Origami,
  Origami as OrigamiIcon,
  ListIndentDecrease as Outdent,
  ListIndentDecrease as OutdentIcon,
  Package,
  Package2,
  Package2 as Package2Icon,
  PackageCheck,
  PackageCheck as PackageCheckIcon,
  Package as PackageIcon,
  PackageMinus,
  PackageMinus as PackageMinusIcon,
  PackageOpen,
  PackageOpen as PackageOpenIcon,
  PackagePlus,
  PackagePlus as PackagePlusIcon,
  PackageSearch,
  PackageSearch as PackageSearchIcon,
  PackageX,
  PackageX as PackageXIcon,
  PaintBucket,
  PaintBucket as PaintBucketIcon,
  PaintRoller,
  PaintRoller as PaintRollerIcon,
  Paintbrush,
  PaintbrushVertical as Paintbrush2,
  PaintbrushVertical as Paintbrush2Icon,
  Paintbrush as PaintbrushIcon,
  PaintbrushVertical,
  PaintbrushVertical as PaintbrushVerticalIcon,
  Palette,
  Palette as PaletteIcon,
  TreePalm as Palmtree,
  TreePalm as PalmtreeIcon,
  Panda,
  Panda as PandaIcon,
  PanelBottom,
  PanelBottomClose,
  PanelBottomClose as PanelBottomCloseIcon,
  PanelBottomDashed,
  PanelBottomDashed as PanelBottomDashedIcon,
  PanelBottom as PanelBottomIcon,
  PanelBottomDashed as PanelBottomInactive,
  PanelBottomDashed as PanelBottomInactiveIcon,
  PanelBottomOpen,
  PanelBottomOpen as PanelBottomOpenIcon,
  PanelLeft,
  PanelLeftClose,
  PanelLeftClose as PanelLeftCloseIcon,
  PanelLeftDashed,
  PanelLeftDashed as PanelLeftDashedIcon,
  PanelLeft as PanelLeftIcon,
  PanelLeftDashed as PanelLeftInactive,
  PanelLeftDashed as PanelLeftInactiveIcon,
  PanelLeftOpen,
  PanelLeftOpen as PanelLeftOpenIcon,
  PanelLeftRightDashed,
  PanelLeftRightDashed as PanelLeftRightDashedIcon,
  PanelRight,
  PanelRightClose,
  PanelRightClose as PanelRightCloseIcon,
  PanelRightDashed,
  PanelRightDashed as PanelRightDashedIcon,
  PanelRight as PanelRightIcon,
  PanelRightDashed as PanelRightInactive,
  PanelRightDashed as PanelRightInactiveIcon,
  PanelRightOpen,
  PanelRightOpen as PanelRightOpenIcon,
  PanelTop,
  PanelTopBottomDashed,
  PanelTopBottomDashed as PanelTopBottomDashedIcon,
  PanelTopClose,
  PanelTopClose as PanelTopCloseIcon,
  PanelTopDashed,
  PanelTopDashed as PanelTopDashedIcon,
  PanelTop as PanelTopIcon,
  PanelTopDashed as PanelTopInactive,
  PanelTopDashed as PanelTopInactiveIcon,
  PanelTopOpen,
  PanelTopOpen as PanelTopOpenIcon,
  PanelsLeftBottom,
  PanelsLeftBottom as PanelsLeftBottomIcon,
  Columns3 as PanelsLeftRight,
  Columns3 as PanelsLeftRightIcon,
  PanelsRightBottom,
  PanelsRightBottom as PanelsRightBottomIcon,
  Rows3 as PanelsTopBottom,
  Rows3 as PanelsTopBottomIcon,
  PanelsTopLeft,
  PanelsTopLeft as PanelsTopLeftIcon,
  Paperclip,
  Paperclip as PaperclipIcon,
  Parentheses,
  Parentheses as ParenthesesIcon,
  CircleParking as ParkingCircle,
  CircleParking as ParkingCircleIcon,
  CircleParkingOff as ParkingCircleOff,
  CircleParkingOff as ParkingCircleOffIcon,
  ParkingMeter,
  ParkingMeter as ParkingMeterIcon,
  SquareParking as ParkingSquare,
  SquareParking as ParkingSquareIcon,
  SquareParkingOff as ParkingSquareOff,
  SquareParkingOff as ParkingSquareOffIcon,
  PartyPopper,
  PartyPopper as PartyPopperIcon,
  Pause,
  CirclePause as PauseCircle,
  CirclePause as PauseCircleIcon,
  Pause as PauseIcon,
  OctagonPause as PauseOctagon,
  OctagonPause as PauseOctagonIcon,
  PawPrint,
  PawPrint as PawPrintIcon,
  PcCase,
  PcCase as PcCaseIcon,
  Pen,
  SquarePen as PenBox,
  SquarePen as PenBoxIcon,
  Pen as PenIcon,
  PenLine,
  PenLine as PenLineIcon,
  PenOff,
  PenOff as PenOffIcon,
  SquarePen as PenSquare,
  SquarePen as PenSquareIcon,
  PenTool,
  PenTool as PenToolIcon,
  Pencil,
  Pencil as PencilIcon,
  PencilLine,
  PencilLine as PencilLineIcon,
  PencilOff,
  PencilOff as PencilOffIcon,
  PencilRuler,
  PencilRuler as PencilRulerIcon,
  Pentagon,
  Pentagon as PentagonIcon,
  Percent,
  CirclePercent as PercentCircle,
  CirclePercent as PercentCircleIcon,
  DiamondPercent as PercentDiamond,
  DiamondPercent as PercentDiamondIcon,
  Percent as PercentIcon,
  SquarePercent as PercentSquare,
  SquarePercent as PercentSquareIcon,
  PersonStanding,
  PersonStanding as PersonStandingIcon,
  PhilippinePeso,
  PhilippinePeso as PhilippinePesoIcon,
  Phone,
  PhoneCall,
  PhoneCall as PhoneCallIcon,
  PhoneForwarded,
  PhoneForwarded as PhoneForwardedIcon,
  Phone as PhoneIcon,
  PhoneIncoming,
  PhoneIncoming as PhoneIncomingIcon,
  PhoneMissed,
  PhoneMissed as PhoneMissedIcon,
  PhoneOff,
  PhoneOff as PhoneOffIcon,
  PhoneOutgoing,
  PhoneOutgoing as PhoneOutgoingIcon,
  Pi,
  Pi as PiIcon,
  SquarePi as PiSquare,
  SquarePi as PiSquareIcon,
  Piano,
  Piano as PianoIcon,
  Pickaxe,
  Pickaxe as PickaxeIcon,
  PictureInPicture,
  PictureInPicture2,
  PictureInPicture2 as PictureInPicture2Icon,
  PictureInPicture as PictureInPictureIcon,
  ChartPie as PieChart,
  ChartPie as PieChartIcon,
  PiggyBank,
  PiggyBank as PiggyBankIcon,
  Pilcrow,
  Pilcrow as PilcrowIcon,
  PilcrowLeft,
  PilcrowLeft as PilcrowLeftIcon,
  PilcrowRight,
  PilcrowRight as PilcrowRightIcon,
  SquarePilcrow as PilcrowSquare,
  SquarePilcrow as PilcrowSquareIcon,
  Pill,
  PillBottle,
  PillBottle as PillBottleIcon,
  Pill as PillIcon,
  Pin,
  Pin as PinIcon,
  PinOff,
  PinOff as PinOffIcon,
  Pipette,
  Pipette as PipetteIcon,
  Pizza,
  Pizza as PizzaIcon,
  Plane,
  Plane as PlaneIcon,
  PlaneLanding,
  PlaneLanding as PlaneLandingIcon,
  PlaneTakeoff,
  PlaneTakeoff as PlaneTakeoffIcon,
  Play,
  CirclePlay as PlayCircle,
  CirclePlay as PlayCircleIcon,
  Play as PlayIcon,
  SquarePlay as PlaySquare,
  SquarePlay as PlaySquareIcon,
  Plug,
  Plug2,
  Plug2 as Plug2Icon,
  Plug as PlugIcon,
  PlugZap,
  PlugZap as PlugZap2,
  PlugZap as PlugZap2Icon,
  PlugZap as PlugZapIcon,
  Plus,
  CirclePlus as PlusCircle,
  CirclePlus as PlusCircleIcon,
  Plus as PlusIcon,
  SquarePlus as PlusSquare,
  SquarePlus as PlusSquareIcon,
  Pocket,
  Pocket as PocketIcon,
  PocketKnife,
  PocketKnife as PocketKnifeIcon,
  Podcast,
  Podcast as PodcastIcon,
  Pointer,
  Pointer as PointerIcon,
  PointerOff,
  PointerOff as PointerOffIcon,
  Popcorn,
  Popcorn as PopcornIcon,
  Popsicle,
  Popsicle as PopsicleIcon,
  PoundSterling,
  PoundSterling as PoundSterlingIcon,
  Power,
  CirclePower as PowerCircle,
  CirclePower as PowerCircleIcon,
  Power as PowerIcon,
  PowerOff,
  PowerOff as PowerOffIcon,
  SquarePower as PowerSquare,
  SquarePower as PowerSquareIcon,
  Presentation,
  Presentation as PresentationIcon,
  Printer,
  PrinterCheck,
  PrinterCheck as PrinterCheckIcon,
  Printer as PrinterIcon,
  PrinterX,
  PrinterX as PrinterXIcon,
  Projector,
  Projector as ProjectorIcon,
  Proportions,
  Proportions as ProportionsIcon,
  Puzzle,
  Puzzle as PuzzleIcon,
  Pyramid,
  Pyramid as PyramidIcon,
  QrCode,
  QrCode as QrCodeIcon,
  Quote,
  Quote as QuoteIcon,
  Rabbit,
  Rabbit as RabbitIcon,
  Radar,
  Radar as RadarIcon,
  Radiation,
  Radiation as RadiationIcon,
  Radical,
  Radical as RadicalIcon,
  Radio,
  Radio as RadioIcon,
  RadioReceiver,
  RadioReceiver as RadioReceiverIcon,
  RadioTower,
  RadioTower as RadioTowerIcon,
  Radius,
  Radius as RadiusIcon,
  RailSymbol,
  RailSymbol as RailSymbolIcon,
  Rainbow,
  Rainbow as RainbowIcon,
  Rat,
  Rat as RatIcon,
  Ratio,
  Ratio as RatioIcon,
  Receipt,
  ReceiptCent,
  ReceiptCent as ReceiptCentIcon,
  ReceiptEuro,
  ReceiptEuro as ReceiptEuroIcon,
  Receipt as ReceiptIcon,
  ReceiptIndianRupee,
  ReceiptIndianRupee as ReceiptIndianRupeeIcon,
  ReceiptJapaneseYen,
  ReceiptJapaneseYen as ReceiptJapaneseYenIcon,
  ReceiptPoundSterling,
  ReceiptPoundSterling as ReceiptPoundSterlingIcon,
  ReceiptRussianRuble,
  ReceiptRussianRuble as ReceiptRussianRubleIcon,
  ReceiptSwissFranc,
  ReceiptSwissFranc as ReceiptSwissFrancIcon,
  ReceiptText,
  ReceiptText as ReceiptTextIcon,
  ReceiptTurkishLira,
  ReceiptTurkishLira as ReceiptTurkishLiraIcon,
  RectangleCircle,
  RectangleCircle as RectangleCircleIcon,
  RectangleEllipsis,
  RectangleEllipsis as RectangleEllipsisIcon,
  RectangleGoggles,
  RectangleGoggles as RectangleGogglesIcon,
  RectangleHorizontal,
  RectangleHorizontal as RectangleHorizontalIcon,
  RectangleVertical,
  RectangleVertical as RectangleVerticalIcon,
  Recycle,
  Recycle as RecycleIcon,
  Redo,
  Redo2,
  Redo2 as Redo2Icon,
  RedoDot,
  RedoDot as RedoDotIcon,
  Redo as RedoIcon,
  RefreshCcw,
  RefreshCcwDot,
  RefreshCcwDot as RefreshCcwDotIcon,
  RefreshCcw as RefreshCcwIcon,
  RefreshCw,
  RefreshCw as RefreshCwIcon,
  RefreshCwOff,
  RefreshCwOff as RefreshCwOffIcon,
  Refrigerator,
  Refrigerator as RefrigeratorIcon,
  Regex,
  Regex as RegexIcon,
  RemoveFormatting,
  RemoveFormatting as RemoveFormattingIcon,
  Repeat,
  Repeat1,
  Repeat1 as Repeat1Icon,
  Repeat2,
  Repeat2 as Repeat2Icon,
  Repeat as RepeatIcon,
  Replace,
  ReplaceAll,
  ReplaceAll as ReplaceAllIcon,
  Replace as ReplaceIcon,
  Reply,
  ReplyAll,
  ReplyAll as ReplyAllIcon,
  Reply as ReplyIcon,
  Rewind,
  Rewind as RewindIcon,
  Ribbon,
  Ribbon as RibbonIcon,
  Rocket,
  Rocket as RocketIcon,
  RockingChair,
  RockingChair as RockingChairIcon,
  RollerCoaster,
  RollerCoaster as RollerCoasterIcon,
  Rose,
  Rose as RoseIcon,
  Rotate3d as Rotate3D,
  Rotate3d as Rotate3DIcon,
  Rotate3d,
  Rotate3d as Rotate3dIcon,
  RotateCcw,
  RotateCcw as RotateCcwIcon,
  RotateCcwKey,
  RotateCcwKey as RotateCcwKeyIcon,
  RotateCcwSquare,
  RotateCcwSquare as RotateCcwSquareIcon,
  RotateCw,
  RotateCw as RotateCwIcon,
  RotateCwSquare,
  RotateCwSquare as RotateCwSquareIcon,
  Route,
  Route as RouteIcon,
  RouteOff,
  RouteOff as RouteOffIcon,
  Router,
  Router as RouterIcon,
  Rows2 as Rows,
  Rows2,
  Rows2 as Rows2Icon,
  Rows3,
  Rows3 as Rows3Icon,
  Rows4,
  Rows4 as Rows4Icon,
  Rows2 as RowsIcon,
  Rss,
  Rss as RssIcon,
  Ruler,
  RulerDimensionLine,
  RulerDimensionLine as RulerDimensionLineIcon,
  Ruler as RulerIcon,
  RussianRuble,
  RussianRuble as RussianRubleIcon,
  Sailboat,
  Sailboat as SailboatIcon,
  Salad,
  Salad as SaladIcon,
  Sandwich,
  Sandwich as SandwichIcon,
  Satellite,
  SatelliteDish,
  SatelliteDish as SatelliteDishIcon,
  Satellite as SatelliteIcon,
  SaudiRiyal,
  SaudiRiyal as SaudiRiyalIcon,
  Save,
  SaveAll,
  SaveAll as SaveAllIcon,
  Save as SaveIcon,
  SaveOff,
  SaveOff as SaveOffIcon,
  Scale,
  Scale3d as Scale3D,
  Scale3d as Scale3DIcon,
  Scale3d,
  Scale3d as Scale3dIcon,
  Scale as ScaleIcon,
  Scaling,
  Scaling as ScalingIcon,
  Scan,
  ScanBarcode,
  ScanBarcode as ScanBarcodeIcon,
  ScanEye,
  ScanEye as ScanEyeIcon,
  ScanFace,
  ScanFace as ScanFaceIcon,
  ScanHeart,
  ScanHeart as ScanHeartIcon,
  Scan as ScanIcon,
  ScanLine,
  ScanLine as ScanLineIcon,
  ScanQrCode,
  ScanQrCode as ScanQrCodeIcon,
  ScanSearch,
  ScanSearch as ScanSearchIcon,
  ScanText,
  ScanText as ScanTextIcon,
  ChartScatter as ScatterChart,
  ChartScatter as ScatterChartIcon,
  School,
  University as School2,
  University as School2Icon,
  School as SchoolIcon,
  Scissors,
  Scissors as ScissorsIcon,
  ScissorsLineDashed,
  ScissorsLineDashed as ScissorsLineDashedIcon,
  SquareScissors as ScissorsSquare,
  SquareBottomDashedScissors as ScissorsSquareDashedBottom,
  SquareBottomDashedScissors as ScissorsSquareDashedBottomIcon,
  SquareScissors as ScissorsSquareIcon,
  Scooter,
  Scooter as ScooterIcon,
  ScreenShare,
  ScreenShare as ScreenShareIcon,
  ScreenShareOff,
  ScreenShareOff as ScreenShareOffIcon,
  Scroll,
  Scroll as ScrollIcon,
  ScrollText,
  ScrollText as ScrollTextIcon,
  Search,
  SearchAlert,
  SearchAlert as SearchAlertIcon,
  SearchCheck,
  SearchCheck as SearchCheckIcon,
  SearchCode,
  SearchCode as SearchCodeIcon,
  Search as SearchIcon,
  SearchSlash,
  SearchSlash as SearchSlashIcon,
  SearchX,
  SearchX as SearchXIcon,
  Section,
  Section as SectionIcon,
  Send,
  SendHorizontal as SendHorizonal,
  SendHorizontal as SendHorizonalIcon,
  SendHorizontal,
  SendHorizontal as SendHorizontalIcon,
  Send as SendIcon,
  SendToBack,
  SendToBack as SendToBackIcon,
  SeparatorHorizontal,
  SeparatorHorizontal as SeparatorHorizontalIcon,
  SeparatorVertical,
  SeparatorVertical as SeparatorVerticalIcon,
  Server,
  ServerCog,
  ServerCog as ServerCogIcon,
  ServerCrash,
  ServerCrash as ServerCrashIcon,
  Server as ServerIcon,
  ServerOff,
  ServerOff as ServerOffIcon,
  Settings,
  Settings2,
  Settings2 as Settings2Icon,
  Settings as SettingsIcon,
  Shapes,
  Shapes as ShapesIcon,
  Share,
  Share2,
  Share2 as Share2Icon,
  Share as ShareIcon,
  Sheet,
  Sheet as SheetIcon,
  Shell,
  Shell as ShellIcon,
  ShelvingUnit,
  ShelvingUnit as ShelvingUnitIcon,
  Shield,
  ShieldAlert,
  ShieldAlert as ShieldAlertIcon,
  ShieldBan,
  ShieldBan as ShieldBanIcon,
  ShieldCheck,
  ShieldCheck as ShieldCheckIcon,
  ShieldX as ShieldClose,
  ShieldX as ShieldCloseIcon,
  ShieldEllipsis,
  ShieldEllipsis as ShieldEllipsisIcon,
  ShieldHalf,
  ShieldHalf as ShieldHalfIcon,
  Shield as ShieldIcon,
  ShieldMinus,
  ShieldMinus as ShieldMinusIcon,
  ShieldOff,
  ShieldOff as ShieldOffIcon,
  ShieldPlus,
  ShieldPlus as ShieldPlusIcon,
  ShieldQuestionMark as ShieldQuestion,
  ShieldQuestionMark as ShieldQuestionIcon,
  ShieldQuestionMark,
  ShieldQuestionMark as ShieldQuestionMarkIcon,
  ShieldUser,
  ShieldUser as ShieldUserIcon,
  ShieldX,
  ShieldX as ShieldXIcon,
  Ship,
  Ship as ShipIcon,
  ShipWheel,
  ShipWheel as ShipWheelIcon,
  Shirt,
  Shirt as ShirtIcon,
  ShoppingBag,
  ShoppingBag as ShoppingBagIcon,
  ShoppingBasket,
  ShoppingBasket as ShoppingBasketIcon,
  ShoppingCart,
  ShoppingCart as ShoppingCartIcon,
  Shovel,
  Shovel as ShovelIcon,
  ShowerHead,
  ShowerHead as ShowerHeadIcon,
  Shredder,
  Shredder as ShredderIcon,
  Shrimp,
  Shrimp as ShrimpIcon,
  Shrink,
  Shrink as ShrinkIcon,
  Shrub,
  Shrub as ShrubIcon,
  Shuffle,
  Shuffle as ShuffleIcon,
  PanelLeft as Sidebar,
  PanelLeftClose as SidebarClose,
  PanelLeftClose as SidebarCloseIcon,
  PanelLeft as SidebarIcon,
  PanelLeftOpen as SidebarOpen,
  PanelLeftOpen as SidebarOpenIcon,
  Sigma,
  Sigma as SigmaIcon,
  SquareSigma as SigmaSquare,
  SquareSigma as SigmaSquareIcon,
  Signal,
  SignalHigh,
  SignalHigh as SignalHighIcon,
  Signal as SignalIcon,
  SignalLow,
  SignalLow as SignalLowIcon,
  SignalMedium,
  SignalMedium as SignalMediumIcon,
  SignalZero,
  SignalZero as SignalZeroIcon,
  Signature,
  Signature as SignatureIcon,
  Signpost,
  SignpostBig,
  SignpostBig as SignpostBigIcon,
  Signpost as SignpostIcon,
  Siren,
  Siren as SirenIcon,
  SkipBack,
  SkipBack as SkipBackIcon,
  SkipForward,
  SkipForward as SkipForwardIcon,
  Skull,
  Skull as SkullIcon,
  Slack,
  Slack as SlackIcon,
  Slash,
  Slash as SlashIcon,
  SquareSlash as SlashSquare,
  SquareSlash as SlashSquareIcon,
  Slice,
  Slice as SliceIcon,
  SlidersVertical as Sliders,
  SlidersHorizontal,
  SlidersHorizontal as SlidersHorizontalIcon,
  SlidersVertical as SlidersIcon,
  SlidersVertical,
  SlidersVertical as SlidersVerticalIcon,
  Smartphone,
  SmartphoneCharging,
  SmartphoneCharging as SmartphoneChargingIcon,
  Smartphone as SmartphoneIcon,
  SmartphoneNfc,
  SmartphoneNfc as SmartphoneNfcIcon,
  Smile,
  Smile as SmileIcon,
  SmilePlus,
  SmilePlus as SmilePlusIcon,
  Snail,
  Snail as SnailIcon,
  Snowflake,
  Snowflake as SnowflakeIcon,
  SoapDispenserDroplet,
  SoapDispenserDroplet as SoapDispenserDropletIcon,
  Sofa,
  Sofa as SofaIcon,
  SolarPanel,
  SolarPanel as SolarPanelIcon,
  ArrowUpNarrowWide as SortAsc,
  ArrowUpNarrowWide as SortAscIcon,
  ArrowDownWideNarrow as SortDesc,
  ArrowDownWideNarrow as SortDescIcon,
  Soup,
  Soup as SoupIcon,
  Space,
  Space as SpaceIcon,
  Spade,
  Spade as SpadeIcon,
  Sparkle,
  Sparkle as SparkleIcon,
  Sparkles,
  Sparkles as SparklesIcon,
  Speaker,
  Speaker as SpeakerIcon,
  Speech,
  Speech as SpeechIcon,
  SpellCheck,
  SpellCheck2,
  SpellCheck2 as SpellCheck2Icon,
  SpellCheck as SpellCheckIcon,
  Spline,
  Spline as SplineIcon,
  SplinePointer,
  SplinePointer as SplinePointerIcon,
  Split,
  Split as SplitIcon,
  SquareSplitHorizontal as SplitSquareHorizontal,
  SquareSplitHorizontal as SplitSquareHorizontalIcon,
  SquareSplitVertical as SplitSquareVertical,
  SquareSplitVertical as SplitSquareVerticalIcon,
  Spool,
  Spool as SpoolIcon,
  Spotlight,
  Spotlight as SpotlightIcon,
  SprayCan,
  SprayCan as SprayCanIcon,
  Sprout,
  Sprout as SproutIcon,
  Square,
  SquareActivity,
  SquareActivity as SquareActivityIcon,
  SquareArrowDown,
  SquareArrowDown as SquareArrowDownIcon,
  SquareArrowDownLeft,
  SquareArrowDownLeft as SquareArrowDownLeftIcon,
  SquareArrowDownRight,
  SquareArrowDownRight as SquareArrowDownRightIcon,
  SquareArrowLeft,
  SquareArrowLeft as SquareArrowLeftIcon,
  SquareArrowOutDownLeft,
  SquareArrowOutDownLeft as SquareArrowOutDownLeftIcon,
  SquareArrowOutDownRight,
  SquareArrowOutDownRight as SquareArrowOutDownRightIcon,
  SquareArrowOutUpLeft,
  SquareArrowOutUpLeft as SquareArrowOutUpLeftIcon,
  SquareArrowOutUpRight,
  SquareArrowOutUpRight as SquareArrowOutUpRightIcon,
  SquareArrowRight,
  SquareArrowRightEnter,
  SquareArrowRightEnter as SquareArrowRightEnterIcon,
  SquareArrowRightExit,
  SquareArrowRightExit as SquareArrowRightExitIcon,
  SquareArrowRight as SquareArrowRightIcon,
  SquareArrowUp,
  SquareArrowUp as SquareArrowUpIcon,
  SquareArrowUpLeft,
  SquareArrowUpLeft as SquareArrowUpLeftIcon,
  SquareArrowUpRight,
  SquareArrowUpRight as SquareArrowUpRightIcon,
  SquareAsterisk,
  SquareAsterisk as SquareAsteriskIcon,
  SquareBottomDashedScissors,
  SquareBottomDashedScissors as SquareBottomDashedScissorsIcon,
  SquareCenterlineDashedHorizontal,
  SquareCenterlineDashedHorizontal as SquareCenterlineDashedHorizontalIcon,
  SquareCenterlineDashedVertical,
  SquareCenterlineDashedVertical as SquareCenterlineDashedVerticalIcon,
  SquareChartGantt,
  SquareChartGantt as SquareChartGanttIcon,
  SquareCheck,
  SquareCheckBig,
  SquareCheckBig as SquareCheckBigIcon,
  SquareCheck as SquareCheckIcon,
  SquareChevronDown,
  SquareChevronDown as SquareChevronDownIcon,
  SquareChevronLeft,
  SquareChevronLeft as SquareChevronLeftIcon,
  SquareChevronRight,
  SquareChevronRight as SquareChevronRightIcon,
  SquareChevronUp,
  SquareChevronUp as SquareChevronUpIcon,
  SquareCode,
  SquareCode as SquareCodeIcon,
  SquareDashed,
  SquareDashedBottom,
  SquareDashedBottomCode,
  SquareDashedBottomCode as SquareDashedBottomCodeIcon,
  SquareDashedBottom as SquareDashedBottomIcon,
  SquareDashed as SquareDashedIcon,
  SquareDashedKanban,
  SquareDashedKanban as SquareDashedKanbanIcon,
  SquareDashedMousePointer,
  SquareDashedMousePointer as SquareDashedMousePointerIcon,
  SquareDashedTopSolid,
  SquareDashedTopSolid as SquareDashedTopSolidIcon,
  SquareDivide,
  SquareDivide as SquareDivideIcon,
  SquareDot,
  SquareDot as SquareDotIcon,
  SquareEqual,
  SquareEqual as SquareEqualIcon,
  SquareFunction,
  SquareFunction as SquareFunctionIcon,
  SquareChartGantt as SquareGanttChart,
  SquareChartGantt as SquareGanttChartIcon,
  Square as SquareIcon,
  SquareKanban,
  SquareKanban as SquareKanbanIcon,
  SquareLibrary,
  SquareLibrary as SquareLibraryIcon,
  SquareM,
  SquareM as SquareMIcon,
  SquareMenu,
  SquareMenu as SquareMenuIcon,
  SquareMinus,
  SquareMinus as SquareMinusIcon,
  SquareMousePointer,
  SquareMousePointer as SquareMousePointerIcon,
  SquareParking,
  SquareParking as SquareParkingIcon,
  SquareParkingOff,
  SquareParkingOff as SquareParkingOffIcon,
  SquarePause,
  SquarePause as SquarePauseIcon,
  SquarePen,
  SquarePen as SquarePenIcon,
  SquarePercent,
  SquarePercent as SquarePercentIcon,
  SquarePi,
  SquarePi as SquarePiIcon,
  SquarePilcrow,
  SquarePilcrow as SquarePilcrowIcon,
  SquarePlay,
  SquarePlay as SquarePlayIcon,
  SquarePlus,
  SquarePlus as SquarePlusIcon,
  SquarePower,
  SquarePower as SquarePowerIcon,
  SquareRadical,
  SquareRadical as SquareRadicalIcon,
  SquareRoundCorner,
  SquareRoundCorner as SquareRoundCornerIcon,
  SquareScissors,
  SquareScissors as SquareScissorsIcon,
  SquareSigma,
  SquareSigma as SquareSigmaIcon,
  SquareSlash,
  SquareSlash as SquareSlashIcon,
  SquareSplitHorizontal,
  SquareSplitHorizontal as SquareSplitHorizontalIcon,
  SquareSplitVertical,
  SquareSplitVertical as SquareSplitVerticalIcon,
  SquareSquare,
  SquareSquare as SquareSquareIcon,
  SquareStack,
  SquareStack as SquareStackIcon,
  SquareStar,
  SquareStar as SquareStarIcon,
  SquareStop,
  SquareStop as SquareStopIcon,
  SquareTerminal,
  SquareTerminal as SquareTerminalIcon,
  SquareUser,
  SquareUser as SquareUserIcon,
  SquareUserRound,
  SquareUserRound as SquareUserRoundIcon,
  SquareX,
  SquareX as SquareXIcon,
  SquaresExclude,
  SquaresExclude as SquaresExcludeIcon,
  SquaresIntersect,
  SquaresIntersect as SquaresIntersectIcon,
  SquaresSubtract,
  SquaresSubtract as SquaresSubtractIcon,
  SquaresUnite,
  SquaresUnite as SquaresUniteIcon,
  Squircle,
  SquircleDashed,
  SquircleDashed as SquircleDashedIcon,
  Squircle as SquircleIcon,
  Squirrel,
  Squirrel as SquirrelIcon,
  Stamp,
  Stamp as StampIcon,
  Star,
  StarHalf,
  StarHalf as StarHalfIcon,
  Star as StarIcon,
  StarOff,
  StarOff as StarOffIcon,
  Sparkles as Stars,
  Sparkles as StarsIcon,
  StepBack,
  StepBack as StepBackIcon,
  StepForward,
  StepForward as StepForwardIcon,
  Stethoscope,
  Stethoscope as StethoscopeIcon,
  Sticker,
  Sticker as StickerIcon,
  StickyNote,
  StickyNote as StickyNoteIcon,
  Stone,
  Stone as StoneIcon,
  CircleStop as StopCircle,
  CircleStop as StopCircleIcon,
  Store,
  Store as StoreIcon,
  StretchHorizontal,
  StretchHorizontal as StretchHorizontalIcon,
  StretchVertical,
  StretchVertical as StretchVerticalIcon,
  Strikethrough,
  Strikethrough as StrikethroughIcon,
  Subscript,
  Subscript as SubscriptIcon,
  Captions as Subtitles,
  Captions as SubtitlesIcon,
  Sun,
  SunDim,
  SunDim as SunDimIcon,
  Sun as SunIcon,
  SunMedium,
  SunMedium as SunMediumIcon,
  SunMoon,
  SunMoon as SunMoonIcon,
  SunSnow,
  SunSnow as SunSnowIcon,
  Sunrise,
  Sunrise as SunriseIcon,
  Sunset,
  Sunset as SunsetIcon,
  Superscript,
  Superscript as SuperscriptIcon,
  SwatchBook,
  SwatchBook as SwatchBookIcon,
  SwissFranc,
  SwissFranc as SwissFrancIcon,
  SwitchCamera,
  SwitchCamera as SwitchCameraIcon,
  Sword,
  Sword as SwordIcon,
  Swords,
  Swords as SwordsIcon,
  Syringe,
  Syringe as SyringeIcon,
  Table,
  Table2,
  Table2 as Table2Icon,
  TableCellsMerge,
  TableCellsMerge as TableCellsMergeIcon,
  TableCellsSplit,
  TableCellsSplit as TableCellsSplitIcon,
  TableColumnsSplit,
  TableColumnsSplit as TableColumnsSplitIcon,
  Columns3Cog as TableConfig,
  Columns3Cog as TableConfigIcon,
  Table as TableIcon,
  TableOfContents,
  TableOfContents as TableOfContentsIcon,
  TableProperties,
  TableProperties as TablePropertiesIcon,
  TableRowsSplit,
  TableRowsSplit as TableRowsSplitIcon,
  Tablet,
  Tablet as TabletIcon,
  TabletSmartphone,
  TabletSmartphone as TabletSmartphoneIcon,
  Tablets,
  Tablets as TabletsIcon,
  Tag,
  Tag as TagIcon,
  Tags,
  Tags as TagsIcon,
  Tally1,
  Tally1 as Tally1Icon,
  Tally2,
  Tally2 as Tally2Icon,
  Tally3,
  Tally3 as Tally3Icon,
  Tally4,
  Tally4 as Tally4Icon,
  Tally5,
  Tally5 as Tally5Icon,
  Tangent,
  Tangent as TangentIcon,
  Target,
  Target as TargetIcon,
  Telescope,
  Telescope as TelescopeIcon,
  Tent,
  Tent as TentIcon,
  TentTree,
  TentTree as TentTreeIcon,
  Terminal,
  Terminal as TerminalIcon,
  SquareTerminal as TerminalSquare,
  SquareTerminal as TerminalSquareIcon,
  TestTube,
  TestTubeDiagonal as TestTube2,
  TestTubeDiagonal as TestTube2Icon,
  TestTubeDiagonal,
  TestTubeDiagonal as TestTubeDiagonalIcon,
  TestTube as TestTubeIcon,
  TestTubes,
  TestTubes as TestTubesIcon,
  TextAlignStart as Text,
  TextAlignCenter,
  TextAlignCenter as TextAlignCenterIcon,
  TextAlignEnd,
  TextAlignEnd as TextAlignEndIcon,
  TextAlignJustify,
  TextAlignJustify as TextAlignJustifyIcon,
  TextAlignStart,
  TextAlignStart as TextAlignStartIcon,
  TextCursor,
  TextCursor as TextCursorIcon,
  TextCursorInput,
  TextCursorInput as TextCursorInputIcon,
  TextAlignStart as TextIcon,
  TextInitial,
  TextInitial as TextInitialIcon,
  TextQuote,
  TextQuote as TextQuoteIcon,
  TextSearch,
  TextSearch as TextSearchIcon,
  TextSelect,
  TextSelect as TextSelectIcon,
  TextSelect as TextSelection,
  TextSelect as TextSelectionIcon,
  TextWrap,
  TextWrap as TextWrapIcon,
  Theater,
  Theater as TheaterIcon,
  Thermometer,
  Thermometer as ThermometerIcon,
  ThermometerSnowflake,
  ThermometerSnowflake as ThermometerSnowflakeIcon,
  ThermometerSun,
  ThermometerSun as ThermometerSunIcon,
  ThumbsDown,
  ThumbsDown as ThumbsDownIcon,
  ThumbsUp,
  ThumbsUp as ThumbsUpIcon,
  Ticket,
  TicketCheck,
  TicketCheck as TicketCheckIcon,
  Ticket as TicketIcon,
  TicketMinus,
  TicketMinus as TicketMinusIcon,
  TicketPercent,
  TicketPercent as TicketPercentIcon,
  TicketPlus,
  TicketPlus as TicketPlusIcon,
  TicketSlash,
  TicketSlash as TicketSlashIcon,
  TicketX,
  TicketX as TicketXIcon,
  Tickets,
  Tickets as TicketsIcon,
  TicketsPlane,
  TicketsPlane as TicketsPlaneIcon,
  Timer,
  Timer as TimerIcon,
  TimerOff,
  TimerOff as TimerOffIcon,
  TimerReset,
  TimerReset as TimerResetIcon,
  ToggleLeft,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight,
  ToggleRight as ToggleRightIcon,
  Toilet,
  Toilet as ToiletIcon,
  ToolCase,
  ToolCase as ToolCaseIcon,
  Toolbox,
  Toolbox as ToolboxIcon,
  Tornado,
  Tornado as TornadoIcon,
  Torus,
  Torus as TorusIcon,
  Touchpad,
  Touchpad as TouchpadIcon,
  TouchpadOff,
  TouchpadOff as TouchpadOffIcon,
  TowelRack,
  TowelRack as TowelRackIcon,
  TowerControl,
  TowerControl as TowerControlIcon,
  ToyBrick,
  ToyBrick as ToyBrickIcon,
  Tractor,
  Tractor as TractorIcon,
  TrafficCone,
  TrafficCone as TrafficConeIcon,
  TramFront as Train,
  TrainFront,
  TrainFront as TrainFrontIcon,
  TrainFrontTunnel,
  TrainFrontTunnel as TrainFrontTunnelIcon,
  TramFront as TrainIcon,
  TrainTrack,
  TrainTrack as TrainTrackIcon,
  TramFront,
  TramFront as TramFrontIcon,
  Transgender,
  Transgender as TransgenderIcon,
  Trash,
  Trash2,
  Trash2 as Trash2Icon,
  Trash as TrashIcon,
  TreeDeciduous,
  TreeDeciduous as TreeDeciduousIcon,
  TreePalm,
  TreePalm as TreePalmIcon,
  TreePine,
  TreePine as TreePineIcon,
  Trees,
  Trees as TreesIcon,
  Trello,
  Trello as TrelloIcon,
  TrendingDown,
  TrendingDown as TrendingDownIcon,
  TrendingUp,
  TrendingUpDown,
  TrendingUpDown as TrendingUpDownIcon,
  TrendingUp as TrendingUpIcon,
  Triangle,
  TriangleAlert,
  TriangleAlert as TriangleAlertIcon,
  TriangleDashed,
  TriangleDashed as TriangleDashedIcon,
  Triangle as TriangleIcon,
  TriangleRight,
  TriangleRight as TriangleRightIcon,
  Trophy,
  Trophy as TrophyIcon,
  Truck,
  TruckElectric,
  TruckElectric as TruckElectricIcon,
  Truck as TruckIcon,
  TurkishLira,
  TurkishLira as TurkishLiraIcon,
  Turntable,
  Turntable as TurntableIcon,
  Turtle,
  Turtle as TurtleIcon,
  Tv,
  TvMinimal as Tv2,
  TvMinimal as Tv2Icon,
  Tv as TvIcon,
  TvMinimal,
  TvMinimal as TvMinimalIcon,
  TvMinimalPlay,
  TvMinimalPlay as TvMinimalPlayIcon,
  Twitch,
  Twitch as TwitchIcon,
  Twitter,
  Twitter as TwitterIcon,
  Type,
  Type as TypeIcon,
  TypeOutline,
  TypeOutline as TypeOutlineIcon,
  Umbrella,
  Umbrella as UmbrellaIcon,
  UmbrellaOff,
  UmbrellaOff as UmbrellaOffIcon,
  Underline,
  Underline as UnderlineIcon,
  Undo,
  Undo2,
  Undo2 as Undo2Icon,
  UndoDot,
  UndoDot as UndoDotIcon,
  Undo as UndoIcon,
  UnfoldHorizontal,
  UnfoldHorizontal as UnfoldHorizontalIcon,
  UnfoldVertical,
  UnfoldVertical as UnfoldVerticalIcon,
  Ungroup,
  Ungroup as UngroupIcon,
  University,
  University as UniversityIcon,
  Unlink,
  Unlink2,
  Unlink2 as Unlink2Icon,
  Unlink as UnlinkIcon,
  LockOpen as Unlock,
  LockOpen as UnlockIcon,
  LockKeyholeOpen as UnlockKeyhole,
  LockKeyholeOpen as UnlockKeyholeIcon,
  Unplug,
  Unplug as UnplugIcon,
  Upload,
  CloudUpload as UploadCloud,
  CloudUpload as UploadCloudIcon,
  Upload as UploadIcon,
  Usb,
  Usb as UsbIcon,
  User,
  UserRound as User2,
  UserRound as User2Icon,
  UserCheck,
  UserRoundCheck as UserCheck2,
  UserRoundCheck as UserCheck2Icon,
  UserCheck as UserCheckIcon,
  CircleUser as UserCircle,
  CircleUserRound as UserCircle2,
  CircleUserRound as UserCircle2Icon,
  CircleUser as UserCircleIcon,
  UserCog,
  UserRoundCog as UserCog2,
  UserRoundCog as UserCog2Icon,
  UserCog as UserCogIcon,
  User as UserIcon,
  UserKey,
  UserKey as UserKeyIcon,
  UserLock,
  UserLock as UserLockIcon,
  UserMinus,
  UserRoundMinus as UserMinus2,
  UserRoundMinus as UserMinus2Icon,
  UserMinus as UserMinusIcon,
  UserPen,
  UserPen as UserPenIcon,
  UserPlus,
  UserRoundPlus as UserPlus2,
  UserRoundPlus as UserPlus2Icon,
  UserPlus as UserPlusIcon,
  UserRound,
  UserRoundCheck,
  UserRoundCheck as UserRoundCheckIcon,
  UserRoundCog,
  UserRoundCog as UserRoundCogIcon,
  UserRound as UserRoundIcon,
  UserRoundKey,
  UserRoundKey as UserRoundKeyIcon,
  UserRoundMinus,
  UserRoundMinus as UserRoundMinusIcon,
  UserRoundPen,
  UserRoundPen as UserRoundPenIcon,
  UserRoundPlus,
  UserRoundPlus as UserRoundPlusIcon,
  UserRoundSearch,
  UserRoundSearch as UserRoundSearchIcon,
  UserRoundX,
  UserRoundX as UserRoundXIcon,
  UserSearch,
  UserSearch as UserSearchIcon,
  SquareUser as UserSquare,
  SquareUserRound as UserSquare2,
  SquareUserRound as UserSquare2Icon,
  SquareUser as UserSquareIcon,
  UserStar,
  UserStar as UserStarIcon,
  UserX,
  UserRoundX as UserX2,
  UserRoundX as UserX2Icon,
  UserX as UserXIcon,
  Users,
  UsersRound as Users2,
  UsersRound as Users2Icon,
  Users as UsersIcon,
  UsersRound,
  UsersRound as UsersRoundIcon,
  Utensils,
  UtensilsCrossed,
  UtensilsCrossed as UtensilsCrossedIcon,
  Utensils as UtensilsIcon,
  UtilityPole,
  UtilityPole as UtilityPoleIcon,
  Van,
  Van as VanIcon,
  Variable,
  Variable as VariableIcon,
  Vault,
  Vault as VaultIcon,
  VectorSquare,
  VectorSquare as VectorSquareIcon,
  Vegan,
  Vegan as VeganIcon,
  VenetianMask,
  VenetianMask as VenetianMaskIcon,
  Venus,
  VenusAndMars,
  VenusAndMars as VenusAndMarsIcon,
  Venus as VenusIcon,
  BadgeCheck as Verified,
  BadgeCheck as VerifiedIcon,
  Vibrate,
  Vibrate as VibrateIcon,
  VibrateOff,
  VibrateOff as VibrateOffIcon,
  Video,
  Video as VideoIcon,
  VideoOff,
  VideoOff as VideoOffIcon,
  Videotape,
  Videotape as VideotapeIcon,
  View,
  View as ViewIcon,
  Voicemail,
  Voicemail as VoicemailIcon,
  Volleyball,
  Volleyball as VolleyballIcon,
  Volume,
  Volume1,
  Volume1 as Volume1Icon,
  Volume2,
  Volume2 as Volume2Icon,
  Volume as VolumeIcon,
  VolumeOff,
  VolumeOff as VolumeOffIcon,
  VolumeX,
  VolumeX as VolumeXIcon,
  Vote,
  Vote as VoteIcon,
  Wallet,
  WalletMinimal as Wallet2,
  WalletMinimal as Wallet2Icon,
  WalletCards,
  WalletCards as WalletCardsIcon,
  Wallet as WalletIcon,
  WalletMinimal,
  WalletMinimal as WalletMinimalIcon,
  Wallpaper,
  Wallpaper as WallpaperIcon,
  Wand,
  WandSparkles as Wand2,
  WandSparkles as Wand2Icon,
  Wand as WandIcon,
  WandSparkles,
  WandSparkles as WandSparklesIcon,
  Warehouse,
  Warehouse as WarehouseIcon,
  WashingMachine,
  WashingMachine as WashingMachineIcon,
  Watch,
  Watch as WatchIcon,
  Waves,
  WavesArrowDown,
  WavesArrowDown as WavesArrowDownIcon,
  WavesArrowUp,
  WavesArrowUp as WavesArrowUpIcon,
  Waves as WavesIcon,
  WavesLadder,
  WavesLadder as WavesLadderIcon,
  Waypoints,
  Waypoints as WaypointsIcon,
  Webcam,
  Webcam as WebcamIcon,
  Webhook,
  Webhook as WebhookIcon,
  WebhookOff,
  WebhookOff as WebhookOffIcon,
  Weight,
  Weight as WeightIcon,
  WeightTilde,
  WeightTilde as WeightTildeIcon,
  Wheat,
  Wheat as WheatIcon,
  WheatOff,
  WheatOff as WheatOffIcon,
  WholeWord,
  WholeWord as WholeWordIcon,
  Wifi,
  WifiCog,
  WifiCog as WifiCogIcon,
  WifiHigh,
  WifiHigh as WifiHighIcon,
  Wifi as WifiIcon,
  WifiLow,
  WifiLow as WifiLowIcon,
  WifiOff,
  WifiOff as WifiOffIcon,
  WifiPen,
  WifiPen as WifiPenIcon,
  WifiSync,
  WifiSync as WifiSyncIcon,
  WifiZero,
  WifiZero as WifiZeroIcon,
  Wind,
  WindArrowDown,
  WindArrowDown as WindArrowDownIcon,
  Wind as WindIcon,
  Wine,
  Wine as WineIcon,
  WineOff,
  WineOff as WineOffIcon,
  Workflow,
  Workflow as WorkflowIcon,
  Worm,
  Worm as WormIcon,
  TextWrap as WrapText,
  TextWrap as WrapTextIcon,
  Wrench,
  Wrench as WrenchIcon,
  X,
  CircleX as XCircle,
  CircleX as XCircleIcon,
  X as XIcon,
  XLineTop,
  XLineTop as XLineTopIcon,
  OctagonX as XOctagon,
  OctagonX as XOctagonIcon,
  SquareX as XSquare,
  SquareX as XSquareIcon,
  Youtube,
  Youtube as YoutubeIcon,
  Zap,
  Zap as ZapIcon,
  ZapOff,
  ZapOff as ZapOffIcon,
  ZodiacAquarius,
  ZodiacAquarius as ZodiacAquariusIcon,
  ZodiacAries,
  ZodiacAries as ZodiacAriesIcon,
  ZodiacCancer,
  ZodiacCancer as ZodiacCancerIcon,
  ZodiacCapricorn,
  ZodiacCapricorn as ZodiacCapricornIcon,
  ZodiacGemini,
  ZodiacGemini as ZodiacGeminiIcon,
  ZodiacLeo,
  ZodiacLeo as ZodiacLeoIcon,
  ZodiacLibra,
  ZodiacLibra as ZodiacLibraIcon,
  ZodiacOphiuchus,
  ZodiacOphiuchus as ZodiacOphiuchusIcon,
  ZodiacPisces,
  ZodiacPisces as ZodiacPiscesIcon,
  ZodiacSagittarius,
  ZodiacSagittarius as ZodiacSagittariusIcon,
  ZodiacScorpio,
  ZodiacScorpio as ZodiacScorpioIcon,
  ZodiacTaurus,
  ZodiacTaurus as ZodiacTaurusIcon,
  ZodiacVirgo,
  ZodiacVirgo as ZodiacVirgoIcon,
  ZoomIn,
  ZoomIn as ZoomInIcon,
  ZoomOut,
  ZoomOut as ZoomOutIcon,
  formatFixed,
  lucideIcons as icons
};
//# sourceMappingURL=lucide-angular.js.map
